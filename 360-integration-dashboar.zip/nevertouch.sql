-- ============================================================================
-- CLEANUP SCRIPT - DROP RAG-RELATED VIEWS AND TABLES
-- ============================================================================
-- Purpose: Remove all RAG-specific views, tables, and vector embeddings
-- This is an ADDITIONAL cleanup for RAG system components
-- ============================================================================

SET timezone = 'America/Los_Angeles';

-- ============================================================================
-- 1. DROP ALL VIEWS IN PUBLIC SCHEMA (DYNAMIC - CATCHES EVERYTHING)
-- ============================================================================

-- Method 1: Dynamic SQL to drop EVERY view
DO $$
DECLARE
    r RECORD;
BEGIN
    FOR r IN 
        SELECT table_name 
        FROM information_schema.views 
        WHERE table_schema = 'public'
    LOOP
        EXECUTE 'DROP VIEW IF EXISTS ' || quote_ident(r.table_name) || ' CASCADE';
        RAISE NOTICE 'Dropped view: %', r.table_name;
    END LOOP;
END $$;

-- Method 2: Explicit drops as backup (in case some views remain)
-- RAG-Specific Views
DROP VIEW IF EXISTS rag_query_logs CASCADE;
DROP VIEW IF EXISTS rag_performance_stats CASCADE;
DROP VIEW IF EXISTS vector_search_results CASCADE;
DROP VIEW IF EXISTS interface_embeddings_summary CASCADE;

-- Standard Dashboard Views
DROP VIEW IF EXISTS dashboard_360_summary CASCADE;
DROP VIEW IF EXISTS dashboard_360_storage_usage CASCADE;
DROP VIEW IF EXISTS dashboard_360_ai_usage CASCADE;
DROP VIEW IF EXISTS dashboard_360_integration_status CASCADE;
DROP VIEW IF EXISTS dashboard_360_user_stats CASCADE;

-- Additional Potential Views
DROP VIEW IF EXISTS interface_search_results CASCADE;
DROP VIEW IF EXISTS embedding_statistics CASCADE;
DROP VIEW IF EXISTS vector_cache_stats CASCADE;
DROP VIEW IF EXISTS rag_interactions_summary CASCADE;
DROP VIEW IF EXISTS interface_embeddings_stats CASCADE;

-- ============================================================================
-- 2. DROP RAG-RELATED TABLES (if they exist)
-- ============================================================================

-- Interface embeddings (vector search table)
DROP TABLE IF EXISTS interface_embeddings CASCADE;

-- RAG query logging
DROP TABLE IF EXISTS rag_query_logs CASCADE;

-- Vector search cache
DROP TABLE IF EXISTS embedding_cache CASCADE;

-- RAG interaction history
DROP TABLE IF EXISTS rag_interactions CASCADE;

-- ============================================================================
-- 3. DROP RAG-SPECIFIC INDEXES
-- ============================================================================

-- Vector similarity indexes
DROP INDEX IF EXISTS idx_interface_embeddings_vector CASCADE;
DROP INDEX IF EXISTS idx_interface_embeddings_interface_id CASCADE;
DROP INDEX IF EXISTS idx_interface_embeddings_content_type CASCADE;
DROP INDEX IF EXISTS idx_interface_embeddings_created_at CASCADE;
DROP INDEX IF EXISTS idx_interface_embeddings_model CASCADE;

-- RAG logs indexes
DROP INDEX IF EXISTS idx_rag_query_logs_timestamp CASCADE;
DROP INDEX IF EXISTS idx_rag_query_logs_user_id CASCADE;
DROP INDEX IF EXISTS idx_rag_query_logs_status CASCADE;

-- RAG interactions indexes
DROP INDEX IF EXISTS idx_rag_interactions_user_id CASCADE;
DROP INDEX IF EXISTS idx_rag_interactions_created_at CASCADE;
DROP INDEX IF EXISTS idx_rag_interactions_query_type CASCADE;

-- Embedding cache indexes
DROP INDEX IF EXISTS idx_embedding_cache_hash CASCADE;
DROP INDEX IF EXISTS idx_embedding_cache_created_at CASCADE;

-- ============================================================================
-- 4. DROP RAG-SPECIFIC SEQUENCES (if created)
-- ============================================================================

DROP SEQUENCE IF EXISTS rag_query_logs_id_seq CASCADE;
DROP SEQUENCE IF EXISTS rag_interactions_id_seq CASCADE;
DROP SEQUENCE IF EXISTS embedding_cache_id_seq CASCADE;

-- ============================================================================
-- 5. VERIFY CLEANUP
-- ============================================================================

SELECT '✅ RAG Views & Tables Cleanup Complete!' as status;

-- Check remaining RAG-related tables
SELECT table_name FROM information_schema.tables 
WHERE table_schema='public' 
AND (table_name LIKE '%rag%' OR table_name LIKE '%embedding%' OR table_name LIKE '%vector%')
ORDER BY table_name;

-- Check remaining RAG-related views
SELECT table_name FROM information_schema.views 
WHERE table_schema='public' 
AND (table_name LIKE '%rag%' OR table_name LIKE '%embedding%' OR table_name LIKE '%vector%')
ORDER BY table_name;

-- ============================================================================
-- SUMMARY
-- ============================================================================

/*
This script removes:

VIEWS:
  ✅ rag_query_logs
  ✅ rag_performance_stats
  ✅ vector_search_results
  ✅ interface_embeddings_summary

TABLES:
  ✅ interface_embeddings (vector storage)
  ✅ rag_query_logs (query history)
  ✅ embedding_cache (cache storage)
  ✅ rag_interactions (interaction logs)

INDEXES:
  ✅ All vector similarity indexes
  ✅ All RAG logging indexes
  ✅ All embedding indexes

SEQUENCES:
  ✅ All RAG-related sequences

Result: Clean database with NO RAG components remaining
*/

-- ============================================================================
-- END OF RAG CLEANUP SCRIPT
-- ============================================================================