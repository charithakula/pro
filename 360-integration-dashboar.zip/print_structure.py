#!/usr/bin/env python
"""
360° Enterprise Dashboard - Print Folder Structure
Prints the complete folder structure excluding venv and __pycache__
Run this script from the project root directory
"""

import os
import sys
from pathlib import Path

class Colors:
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    END = '\033[0m'

def print_tree(path, prefix="", exclude_dirs={'.git', 'venv', '__pycache__', '.pytest_cache', 'node_modules', '.vscode', '.idea'}):
    """
    Print directory tree structure
    """
    try:
        entries = sorted(os.listdir(path))
    except PermissionError:
        return

    # Filter out excluded directories
    entries = [e for e in entries if e not in exclude_dirs]
    
    dirs = [e for e in entries if os.path.isdir(os.path.join(path, e))]
    files = [e for e in entries if os.path.isfile(os.path.join(path, e))]
    
    # Print files first
    for i, file in enumerate(files):
        is_last_file = (i == len(files) - 1) and len(dirs) == 0
        current_prefix = "└── " if is_last_file else "├── "
        print(f"{prefix}{current_prefix}{Colors.CYAN}{file}{Colors.END}")
    
    # Then print directories
    for i, dir_name in enumerate(dirs):
        is_last = i == len(dirs) - 1
        current_prefix = "└── " if is_last else "├── "
        next_prefix = "    " if is_last else "│   "
        
        print(f"{prefix}{current_prefix}{Colors.YELLOW}{dir_name}/{Colors.END}")
        
        dir_path = os.path.join(path, dir_name)
        print_tree(dir_path, prefix + next_prefix, exclude_dirs)

def count_files_and_dirs(path, exclude_dirs={'.git', 'venv', '__pycache__', '.pytest_cache', 'node_modules', '.vscode', '.idea'}):
    """
    Count files and directories
    """
    total_files = 0
    total_dirs = 0
    
    for root, dirs, files in os.walk(path):
        # Remove excluded directories from dirs in place (prevents traversal)
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        total_files += len(files)
        total_dirs += len(dirs)
    
    return total_files, total_dirs

def get_directory_size(path, exclude_dirs={'.git', 'venv', '__pycache__', '.pytest_cache', 'node_modules', '.vscode', '.idea'}):
    """
    Calculate total size of directory
    """
    total_size = 0
    
    for root, dirs, files in os.walk(path):
        # Remove excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            file_path = os.path.join(root, file)
            try:
                total_size += os.path.getsize(file_path)
            except OSError:
                pass
    
    return total_size

def format_size(size):
    """
    Convert bytes to human readable format
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024.0:
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} TB"

def main():
    print(f"\n{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BLUE}360° Enterprise Dashboard - Project Structure{Colors.END}")
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")
    
    # Get current directory
    project_root = os.getcwd()
    print(f"{Colors.GREEN}Project Root:{Colors.END} {project_root}\n")
    
    print(f"{Colors.BLUE}Directory Tree (excluding venv, __pycache__, and .git):{Colors.END}\n")
    
    print(f"{Colors.YELLOW}{os.path.basename(project_root)}/{Colors.END}")
    print_tree(project_root)
    
    # Statistics
    print(f"\n{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BLUE}Project Statistics{Colors.END}")
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")
    
    total_files, total_dirs = count_files_and_dirs(project_root)
    total_size = get_directory_size(project_root)
    
    print(f"{Colors.GREEN}Total Directories:{Colors.END} {total_dirs}")
    print(f"{Colors.GREEN}Total Files:{Colors.END} {total_files}")
    print(f"{Colors.GREEN}Total Size:{Colors.END} {format_size(total_size)}")
    
    # Key folders
    print(f"\n{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BLUE}Key Folders{Colors.END}")
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")
    
    key_folders = {
        'backend': 'Flask backend application',
        'frontend': 'Frontend HTML, CSS, JS files',
        'backend/instance': 'SQLite database storage',
        'frontend/assets': 'Static assets (CSS, JS, images)',
        'frontend/dashboard_overview': 'Dashboard pages',
        'frontend/integration_pages': 'Integration management pages',
        'frontend/data_management': 'Data management pages',
        'frontend/shared_components': 'Shared UI components',
    }
    
    for folder, description in key_folders.items():
        exists = os.path.isdir(folder)
        status = f"{Colors.GREEN}✓{Colors.END}" if exists else f"{Colors.YELLOW}✗{Colors.END}"
        print(f"{status} {Colors.CYAN}{folder}/{Colors.END}")
        print(f"   {description}\n")
    
    # Key files
    print(f"{Colors.BLUE}{'='*70}{Colors.END}")
    print(f"{Colors.BLUE}Key Files{Colors.END}")
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")
    
    key_files = {
        'backend/app.py': 'Main Flask application',
        'backend/.env': 'Environment variables',
        'backend/routes.py': 'Flask routes',
        'backend/models.py': 'Database models',
        'frontend/index.html': 'Landing page',
        'frontend/login.html': 'Login page',
        'frontend/dashboard_overview/index.html': 'Dashboard page',
        '.gitignore': 'Git ignore file',
    }
    
    for file_path, description in key_files.items():
        exists = os.path.isfile(file_path)
        status = f"{Colors.GREEN}✓{Colors.END}" if exists else f"{Colors.YELLOW}✗{Colors.END}"
        print(f"{status} {Colors.CYAN}{file_path}{Colors.END}")
        print(f"   {description}\n")
    
    print(f"{Colors.BLUE}{'='*70}{Colors.END}\n")

if __name__ == '__main__':
    main()