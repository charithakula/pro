-- ============================================================================
-- 360° Enterprise Dashboard - COMPLETE Database Schema (FIXED)
-- ============================================================================
-- Purpose: Create ALL tables for dashboard_360 database
-- Includes: User management, integrations, AI interactions, storage, AND
--           Integration interfaces (real data) + Vector embeddings (RAG)
-- Timezone: PST (America/Los_Angeles)
-- Database: dashboard_360
-- User: dashboard_360_user
-- ============================================================================

SET timezone = 'America/Los_Angeles';

-- ============================================================================
-- SECTION 0: DROP OLD VIEWS AND RAG TABLES FIRST (CRITICAL!)
-- ============================================================================

-- Drop views first (they depend on tables)
DROP VIEW IF EXISTS igpt.dashboard_360_summary CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_storage_usage CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_ai_usage CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_integration_status CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_user_stats CASCADE;
DROP VIEW IF EXISTS igpt.rag_performance_stats CASCADE;
DROP VIEW IF EXISTS igpt.rag_query_logs_view CASCADE;
DROP VIEW IF EXISTS igpt.vector_search_results CASCADE;
DROP VIEW IF EXISTS igpt.interface_embeddings_summary CASCADE;

-- Drop RAG tables (if they exist from previous run)
DROP TABLE IF EXISTS igpt.rag_query_logs CASCADE;
DROP TABLE IF EXISTS igpt.rag_interactions CASCADE;
DROP TABLE IF EXISTS igpt.embedding_cache CASCADE;

DROP SCHEMA IF EXISTS igpt CASCADE;
CREATE SCHEMA igpt;

SELECT '✅ Old views and RAG tables dropped' as status;

-- ============================================================================
-- Enable Required Extensions
-- ============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;

SELECT '✅ Extensions created' as status;

-- ============================================================================
-- 1. USERS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(120) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    CONSTRAINT email_check CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

CREATE INDEX IF NOT EXISTS idx_users_email ON igpt.users(email);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON igpt.users(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON igpt.users(is_active);

COMMENT ON TABLE igpt.users IS '360° Dashboard - User account information';
COMMENT ON COLUMN igpt.users.email IS 'User email address (unique identifier)';
COMMENT ON COLUMN igpt.users.password IS 'Hashed password using werkzeug.security';
COMMENT ON COLUMN igpt.users.name IS 'User full name';
COMMENT ON COLUMN igpt.users.is_active IS 'Account active status';

-- ============================================================================
-- 2. AZURE INTEGRATIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.azure_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    subscription_id VARCHAR(255) NOT NULL,
    tenant_id VARCHAR(255) NOT NULL,
    client_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    resources_count INTEGER DEFAULT 24,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_subscription UNIQUE(user_id, subscription_id)
);

CREATE INDEX IF NOT EXISTS idx_azure_user_id ON igpt.azure_integrations(user_id);
CREATE INDEX IF NOT EXISTS idx_azure_status ON igpt.azure_integrations(status);
CREATE INDEX IF NOT EXISTS idx_azure_created_at ON igpt.azure_integrations(created_at DESC);

COMMENT ON TABLE igpt.azure_integrations IS '360° Dashboard - Azure subscription integrations';
COMMENT ON COLUMN igpt.azure_integrations.subscription_id IS 'Azure subscription ID';
COMMENT ON COLUMN igpt.azure_integrations.tenant_id IS 'Azure tenant/directory ID';
COMMENT ON COLUMN igpt.azure_integrations.client_id IS 'Azure client/app ID';
COMMENT ON COLUMN igpt.azure_integrations.status IS 'Integration connection status';
COMMENT ON COLUMN igpt.azure_integrations.resources_count IS 'Number of Azure resources monitored';

-- ============================================================================
-- 3. SHAREPOINT INTEGRATIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.sharepoint_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    site_url VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    documents_count INTEGER DEFAULT 0,
    sites_count INTEGER DEFAULT 8,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_site UNIQUE(user_id, site_url)
);

CREATE INDEX IF NOT EXISTS idx_sharepoint_user_id ON igpt.sharepoint_integrations(user_id);
CREATE INDEX IF NOT EXISTS idx_sharepoint_status ON igpt.sharepoint_integrations(status);
CREATE INDEX IF NOT EXISTS idx_sharepoint_created_at ON igpt.sharepoint_integrations(created_at DESC);

COMMENT ON TABLE igpt.sharepoint_integrations IS '360° Dashboard - SharePoint site integrations';
COMMENT ON COLUMN igpt.sharepoint_integrations.site_url IS 'SharePoint site URL';
COMMENT ON COLUMN igpt.sharepoint_integrations.documents_count IS 'Total documents in site';
COMMENT ON COLUMN igpt.sharepoint_integrations.sites_count IS 'Number of SharePoint sites connected';

-- ============================================================================
-- 4. AI INTERACTIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.ai_interactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL CHECK (interaction_type IN ('code_review', 'summary', 'generation')),
    input_text TEXT NOT NULL,
    output_text TEXT,
    tokens_used INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success', 'failed')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ai_user_id ON igpt.ai_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_type ON igpt.ai_interactions(interaction_type);
CREATE INDEX IF NOT EXISTS idx_ai_status ON igpt.ai_interactions(status);
CREATE INDEX IF NOT EXISTS idx_ai_created_at ON igpt.ai_interactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_interactions_user_type ON igpt.ai_interactions(user_id, interaction_type);

COMMENT ON TABLE igpt.ai_interactions IS '360° Dashboard - Azure OpenAI service interactions log';
COMMENT ON COLUMN igpt.ai_interactions.interaction_type IS 'Type: code_review, summary, or generation';
COMMENT ON COLUMN igpt.ai_interactions.input_text IS 'Input provided to AI service';
COMMENT ON COLUMN igpt.ai_interactions.output_text IS 'Output from AI service';
COMMENT ON COLUMN igpt.ai_interactions.tokens_used IS 'Azure OpenAI tokens consumed';
COMMENT ON COLUMN igpt.ai_interactions.error_message IS 'Error details if operation failed';

-- ============================================================================
-- 5. STORAGE FILES TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.storage_files (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    blob_name VARCHAR(255) NOT NULL,
    blob_url VARCHAR(500) NOT NULL,
    file_size INTEGER NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'failed', 'deleted')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT file_size_check CHECK (file_size > 0 AND file_size <= 10485760)
);

CREATE INDEX IF NOT EXISTS idx_storage_user_id ON igpt.storage_files(user_id);
CREATE INDEX IF NOT EXISTS idx_storage_status ON igpt.storage_files(status);
CREATE INDEX IF NOT EXISTS idx_storage_type ON igpt.storage_files(file_type);
CREATE INDEX IF NOT EXISTS idx_storage_created_at ON igpt.storage_files(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_storage_filename ON igpt.storage_files(filename);
CREATE INDEX IF NOT EXISTS idx_storage_files_user_type ON igpt.storage_files(user_id, file_type);

COMMENT ON TABLE igpt.storage_files IS '360° Dashboard - Files uploaded to Azure Blob Storage';
COMMENT ON COLUMN igpt.storage_files.filename IS 'Original filename uploaded by user';
COMMENT ON COLUMN igpt.storage_files.blob_name IS 'Path in Azure Blob Storage (user-{id}/filename)';
COMMENT ON COLUMN igpt.storage_files.blob_url IS 'Public URL to access file in Azure';
COMMENT ON COLUMN igpt.storage_files.file_size IS 'File size in bytes (max 10MB limit)';
COMMENT ON COLUMN igpt.storage_files.file_type IS 'File extension (pdf, png, docx, xlsx, csv, py, js, etc.)';

-- ============================================================================
-- 6. INTEGRATION INTERFACES TABLE (REAL DATA)
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.integration_interfaces (
    id SERIAL PRIMARY KEY,
    interface_platform VARCHAR(255),
    interface_id VARCHAR(255) UNIQUE NOT NULL,
    sub_interface VARCHAR(255),
    interface_name VARCHAR(500),
    operation_name VARCHAR(255),
    api_product_name VARCHAR(255),
    interface_description TEXT,
    dependency_id VARCHAR(255),
    process_area VARCHAR(255),
    interface_pattern VARCHAR(255),
    
    -- Source system info
    source_ci_type VARCHAR(255),
    source_name VARCHAR(255),
    source_service_url VARCHAR(500),
    source_protocol VARCHAR(255),
    source_data_format VARCHAR(255),
    source_trust_level VARCHAR(255),
    source_resolver_contact VARCHAR(255),
    source_intermediary VARCHAR(255),
    
    -- Target system info
    target_ci_type VARCHAR(255),
    target_name VARCHAR(255),
    target_service_url VARCHAR(500),
    target_protocol VARCHAR(255),
    target_data_format VARCHAR(255),
    target_trust_level VARCHAR(255),
    target_resolver_contact VARCHAR(255),
    target_intermediary VARCHAR(255),
    
    -- Communication & timing
    communication_mode VARCHAR(255),
    volume VARCHAR(255),
    frequency VARCHAR(255),
    schedule VARCHAR(255),
    
    -- Quality & management
    interface_resolver_group VARCHAR(255),
    qos VARCHAR(255),
    retention_period VARCHAR(255),
    priority VARCHAR(50),
    status VARCHAR(100),
    
    -- Project & metadata
    project_name VARCHAR(255),
    production_migration_date VARCHAR(255),
    pid_wo VARCHAR(255),
    reuse_status VARCHAR(100),
    integration_pattern VARCHAR(255),
    interface_mode VARCHAR(255),
    ou VARCHAR(255),
    comments TEXT,
    interface_build_type VARCHAR(255),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_integration_interfaces_id ON igpt.integration_interfaces(interface_id);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_platform ON igpt.integration_interfaces(interface_platform);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_pattern ON igpt.integration_interfaces(interface_pattern);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_reuse_status ON igpt.integration_interfaces(reuse_status);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_status ON igpt.integration_interfaces(status);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_created_at ON igpt.integration_interfaces(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_integration_interfaces_source_target ON igpt.integration_interfaces(source_name, target_name);

COMMENT ON TABLE igpt.integration_interfaces IS '360° Dashboard - Integration interface catalog with real data from Excel imports';
COMMENT ON COLUMN igpt.integration_interfaces.interface_id IS 'Unique interface identifier (e.g., INT-001)';
COMMENT ON COLUMN igpt.integration_interfaces.interface_pattern IS 'Integration pattern type (Request-Reply, Pub-Sub, etc.)';
COMMENT ON COLUMN igpt.integration_interfaces.reuse_status IS 'Reusability classification (Reusable, Non-Reusable, Partially Reusable)';
COMMENT ON COLUMN igpt.integration_interfaces.interface_description IS 'Detailed description for vector search indexing';

-- ============================================================================
-- 7. INTERFACE EMBEDDINGS TABLE (FOR RAG/VECTOR SEARCH)
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.interface_embeddings (
    id SERIAL PRIMARY KEY,
    interface_id VARCHAR(255) NOT NULL REFERENCES igpt.integration_interfaces(interface_id) ON DELETE CASCADE,
    content_type VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    embedding vector,
    embedding_model VARCHAR(100) DEFAULT 'all-MiniLM-L6-v2',
    embedding_dimensions INTEGER DEFAULT 384,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT unique_interface_content_type UNIQUE(interface_id, content_type)
);

-- Vector similarity index (for fast semantic search)
CREATE INDEX IF NOT EXISTS idx_interface_embeddings_vector ON igpt.interface_embeddings 
    USING ivfflat (embedding vector_cosine_ops) 
    WITH (lists = 100);

-- Regular indexes
CREATE INDEX IF NOT EXISTS idx_interface_embeddings_interface_id ON igpt.interface_embeddings(interface_id);
CREATE INDEX IF NOT EXISTS idx_interface_embeddings_content_type ON igpt.interface_embeddings(content_type);
CREATE INDEX IF NOT EXISTS idx_interface_embeddings_created_at ON igpt.interface_embeddings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_interface_embeddings_model ON igpt.interface_embeddings(embedding_model);

COMMENT ON TABLE igpt.interface_embeddings IS '360° Dashboard - Vector embeddings for semantic search (RAG system)';
COMMENT ON COLUMN igpt.interface_embeddings.interface_id IS 'Reference to integration_interfaces table';
COMMENT ON COLUMN igpt.interface_embeddings.content_type IS 'Type of content: name, description, metadata, etc.';
COMMENT ON COLUMN igpt.interface_embeddings.content IS 'Original text content that was embedded';
COMMENT ON COLUMN igpt.interface_embeddings.embedding IS 'Vector representation (384 dims) for similarity search';
COMMENT ON COLUMN igpt.interface_embeddings.embedding_model IS 'Model used to generate embedding (all-MiniLM-L6-v2)';

-- ============================================================================
-- 8. RAG QUERY LOGS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.rag_query_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    query_text TEXT NOT NULL,
    query_type VARCHAR(100),
    status VARCHAR(50) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'timeout')),
    response_text TEXT,
    tokens_used INTEGER DEFAULT 0,
    execution_time_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_rag_query_logs_user_id ON igpt.rag_query_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_rag_query_logs_timestamp ON igpt.rag_query_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rag_query_logs_status ON igpt.rag_query_logs(status);
CREATE INDEX IF NOT EXISTS idx_rag_query_logs_query_type ON igpt.rag_query_logs(query_type);

COMMENT ON TABLE igpt.rag_query_logs IS '360° Dashboard - RAG system query logs';
COMMENT ON COLUMN igpt.rag_query_logs.query_text IS 'User query input';
COMMENT ON COLUMN igpt.rag_query_logs.query_type IS 'Type of query (search, generate, summarize, etc.)';
COMMENT ON COLUMN igpt.rag_query_logs.tokens_used IS 'Tokens consumed by RAG processing';
COMMENT ON COLUMN igpt.rag_query_logs.execution_time_ms IS 'Query execution time in milliseconds';

-- ============================================================================
-- 9. RAG INTERACTIONS TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.rag_interactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    query_type VARCHAR(100) NOT NULL,
    input_query TEXT NOT NULL,
    retrieved_documents INTEGER DEFAULT 0,
    output_response TEXT,
    confidence_score NUMERIC(3,2),
    tokens_used INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'partial')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_rag_interactions_user_id ON igpt.rag_interactions(user_id);
CREATE INDEX IF NOT EXISTS idx_rag_interactions_created_at ON igpt.rag_interactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_rag_interactions_query_type ON igpt.rag_interactions(query_type);
CREATE INDEX IF NOT EXISTS idx_rag_interactions_status ON igpt.rag_interactions(status);

COMMENT ON TABLE igpt.rag_interactions IS '360° Dashboard - RAG system user interactions';
COMMENT ON COLUMN igpt.rag_interactions.query_type IS 'Type of RAG query';
COMMENT ON COLUMN igpt.rag_interactions.retrieved_documents IS 'Number of documents retrieved from vector search';
COMMENT ON COLUMN igpt.rag_interactions.confidence_score IS 'Confidence score of RAG response (0.00-1.00)';

-- ============================================================================
-- 10. EMBEDDING CACHE TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS igpt.embedding_cache (
    id SERIAL PRIMARY KEY,
    content_hash VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    embedding vector,
    embedding_model VARCHAR(100) DEFAULT 'all-MiniLM-L6-v2',
    cache_hits INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_embedding_cache_hash ON igpt.embedding_cache(content_hash);
CREATE INDEX IF NOT EXISTS idx_embedding_cache_created_at ON igpt.embedding_cache(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_embedding_cache_model ON igpt.embedding_cache(embedding_model);

COMMENT ON TABLE igpt.embedding_cache IS '360° Dashboard - Cache for generated embeddings to avoid recomputation';
COMMENT ON COLUMN igpt.embedding_cache.content_hash IS 'MD5 hash of content for deduplication';
COMMENT ON COLUMN igpt.embedding_cache.cache_hits IS 'Number of times this embedding was retrieved from cache';

-- ============================================================================
-- 11. CREATE ANALYTICS VIEWS
-- ============================================================================

CREATE VIEW igpt.dashboard_360_user_stats AS
SELECT
    u.id,
    u.email,
    u.name,
    u.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    u.last_login AT TIME ZONE 'America/Los_Angeles' as last_login_pst,
    u.is_active,
    COUNT(DISTINCT ai.id) as ai_interactions_count,
    COUNT(DISTINCT sf.id) as storage_files_count,
    COUNT(DISTINCT azi.id) as azure_integrations_count,
    COUNT(DISTINCT spi.id) as sharepoint_integrations_count,
    COALESCE(SUM(sf.file_size), 0) as total_storage_used_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_storage_used_mb
FROM igpt.users u
LEFT JOIN igpt.ai_interactions ai ON u.id = ai.user_id
LEFT JOIN igpt.storage_files sf ON u.id = sf.user_id AND sf.status = 'uploaded'
LEFT JOIN igpt.azure_integrations azi ON u.id = azi.user_id
LEFT JOIN igpt.sharepoint_integrations spi ON u.id = spi.user_id
GROUP BY u.id, u.email, u.name, u.created_at, u.last_login, u.is_active;

COMMENT ON VIEW igpt.dashboard_360_user_stats IS '360° Dashboard - User statistics and usage metrics (PST Timezone)';

-- ============================================================================
-- 12. INTEGRATION STATUS VIEW
-- ============================================================================

CREATE VIEW igpt.dashboard_360_integration_status AS
SELECT
    'Azure' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN azi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN azi.status = 'error' THEN 1 END) as error_count,
    COUNT(azi.id) as total_count,
    MAX(azi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM igpt.users u
LEFT JOIN igpt.azure_integrations azi ON u.id = azi.user_id
WHERE azi.id IS NOT NULL
GROUP BY u.id, u.email

UNION ALL

SELECT
    'SharePoint' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN spi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN spi.status = 'error' THEN 1 END) as error_count,
    COUNT(spi.id) as total_count,
    MAX(spi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM igpt.users u
LEFT JOIN igpt.sharepoint_integrations spi ON u.id = spi.user_id
WHERE spi.id IS NOT NULL
GROUP BY u.id, u.email;

COMMENT ON VIEW igpt.dashboard_360_integration_status IS '360° Dashboard - Integration connection status by user (PST Timezone)';

-- ============================================================================
-- 13. AI USAGE VIEW
-- ============================================================================

CREATE VIEW igpt.dashboard_360_ai_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    ai.interaction_type,
    COUNT(ai.id) as interaction_count,
    COUNT(CASE WHEN ai.status = 'success' THEN 1 END) as success_count,
    COUNT(CASE WHEN ai.status = 'failed' THEN 1 END) as failed_count,
    SUM(ai.tokens_used) as total_tokens_used,
    ROUND((AVG(ai.tokens_used)::NUMERIC), 2) as avg_tokens_per_interaction,
    MAX(ai.created_at) AT TIME ZONE 'America/Los_Angeles' as last_interaction_pst
FROM igpt.users u
LEFT JOIN igpt.ai_interactions ai ON u.id = ai.user_id
GROUP BY u.id, u.email, u.name, ai.interaction_type
ORDER BY u.id, ai.interaction_type;

COMMENT ON VIEW igpt.dashboard_360_ai_usage IS '360° Dashboard - AI service usage analytics (PST Timezone)';

-- ============================================================================
-- 14. STORAGE USAGE VIEW
-- ============================================================================

CREATE VIEW igpt.dashboard_360_storage_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    COUNT(sf.id) as file_count,
    COUNT(CASE WHEN sf.status = 'uploaded' THEN 1 END) as uploaded_count,
    COUNT(CASE WHEN sf.status = 'failed' THEN 1 END) as failed_count,
    COALESCE(SUM(sf.file_size), 0) as total_size_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_size_mb,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024 * 1024))::NUMERIC, 2), 0) as total_size_gb,
    MAX(sf.created_at) AT TIME ZONE 'America/Los_Angeles' as last_upload_pst
FROM igpt.users u
LEFT JOIN igpt.storage_files sf ON u.id = sf.user_id
GROUP BY u.id, u.email, u.name
ORDER BY total_size_bytes DESC;

COMMENT ON VIEW igpt.dashboard_360_storage_usage IS '360° Dashboard - Storage usage statistics by user (PST Timezone)';

-- ============================================================================
-- 15. SYSTEM SUMMARY VIEW
-- ============================================================================

CREATE VIEW igpt.dashboard_360_summary AS
SELECT
    (SELECT COUNT(*) FROM igpt.users) as total_users,
    (SELECT COUNT(*) FROM igpt.users WHERE is_active = true) as active_users,
    (SELECT COUNT(*) FROM igpt.azure_integrations) as total_azure_integrations,
    (SELECT COUNT(*) FROM igpt.sharepoint_integrations) as total_sharepoint_integrations,
    (SELECT COUNT(*) FROM igpt.ai_interactions) as total_ai_interactions,
    (SELECT COUNT(*) FROM igpt.ai_interactions WHERE status = 'success') as successful_ai_interactions,
    (SELECT COUNT(*) FROM igpt.storage_files WHERE status = 'uploaded') as uploaded_files,
    (SELECT COALESCE(SUM(file_size), 0) FROM igpt.storage_files WHERE status = 'uploaded') as total_storage_bytes,
    ROUND((SELECT COALESCE(SUM(file_size)::NUMERIC, 0) FROM igpt.storage_files WHERE status = 'uploaded') / (1024 * 1024), 2) as total_storage_mb,
    (SELECT COUNT(*) FROM igpt.integration_interfaces) as total_interfaces,
    (SELECT COUNT(*) FROM igpt.interface_embeddings) as total_embeddings,
    NOW() AT TIME ZONE 'America/Los_Angeles' as last_updated_pst;

COMMENT ON VIEW igpt.dashboard_360_summary IS '360° Dashboard - Overall system summary statistics (PST Timezone)';

-- ============================================================================
-- 16. RAG PERFORMANCE STATS VIEW
-- ============================================================================

CREATE VIEW igpt.rag_performance_stats AS
SELECT
    DATE(rql.created_at AT TIME ZONE 'America/Los_Angeles') as query_date,
    COUNT(*) as total_queries,
    COUNT(CASE WHEN rql.status = 'success' THEN 1 END) as successful_queries,
    COUNT(CASE WHEN rql.status = 'failed' THEN 1 END) as failed_queries,
    ROUND(AVG(rql.execution_time_ms)::NUMERIC, 2) as avg_execution_time_ms,
    MAX(rql.execution_time_ms) as max_execution_time_ms,
    SUM(rql.tokens_used) as total_tokens_used,
    ROUND(AVG(rql.tokens_used)::NUMERIC, 2) as avg_tokens_per_query
FROM igpt.rag_query_logs rql
GROUP BY DATE(rql.created_at AT TIME ZONE 'America/Los_Angeles')
ORDER BY query_date DESC;

COMMENT ON VIEW igpt.rag_performance_stats IS '360° Dashboard - RAG system performance statistics by date';

-- ============================================================================
-- 17. RAG QUERY LOGS VIEW
-- ============================================================================

CREATE VIEW igpt.rag_query_logs_view AS
SELECT
    rql.id,
    u.email as user_email,
    rql.query_text,
    rql.query_type,
    rql.status,
    rql.tokens_used,
    rql.execution_time_ms,
    rql.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst
FROM igpt.rag_query_logs rql
JOIN igpt.users u ON rql.user_id = u.id
ORDER BY rql.created_at DESC;

COMMENT ON VIEW igpt.rag_query_logs_view IS '360° Dashboard - RAG query logs with user information';

-- ============================================================================
-- 18. INTERFACE EMBEDDINGS SUMMARY VIEW
-- ============================================================================

CREATE VIEW igpt.interface_embeddings_summary AS
SELECT
    ii.interface_id,
    ii.interface_name,
    ii.interface_platform,
    COUNT(ie.id) as total_embeddings,
    COUNT(CASE WHEN ie.content_type = 'name' THEN 1 END) as name_embeddings,
    COUNT(CASE WHEN ie.content_type = 'description' THEN 1 END) as description_embeddings,
    MAX(ie.updated_at) AT TIME ZONE 'America/Los_Angeles' as last_updated_pst
FROM igpt.integration_interfaces ii
LEFT JOIN igpt.interface_embeddings ie ON ii.interface_id = ie.interface_id
GROUP BY ii.interface_id, ii.interface_name, ii.interface_platform
ORDER BY total_embeddings DESC;

COMMENT ON VIEW igpt.interface_embeddings_summary IS '360° Dashboard - Summary of embeddings by interface';

-- ============================================================================
-- 19. VECTOR SEARCH RESULTS VIEW
-- ============================================================================

CREATE VIEW igpt.vector_search_results AS
SELECT
    ie.interface_id,
    ii.interface_name,
    ii.interface_platform,
    ie.content_type,
    ie.content,
    ie.embedding_model,
    ie.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    ii.reuse_status,
    ii.interface_pattern
FROM igpt.interface_embeddings ie
JOIN igpt.integration_interfaces ii ON ie.interface_id = ii.interface_id
ORDER BY ie.created_at DESC;

COMMENT ON VIEW igpt.vector_search_results IS '360° Dashboard - Vector search results from embeddings';

-- ============================================================================
-- 20. VERIFY INSTALLATION
-- ============================================================================

SELECT '✅ Database initialization complete!' as status;

SELECT COUNT(*) as total_base_tables 
FROM information_schema.tables 
WHERE table_schema = 'igpt' AND table_type = 'BASE TABLE'
AND table_name NOT LIKE 'pg_%';

SELECT COUNT(*) as total_views 
FROM information_schema.views 
WHERE table_schema = 'igpt';

SELECT COUNT(*) as total_indexes 
FROM pg_indexes 
WHERE schemaname = 'igpt';

SELECT 'Extensions installed:' as status;
SELECT extname, extversion FROM pg_extension 
WHERE extname IN ('vector', 'uuid-ossp');

SELECT COUNT(*) as total_users FROM igpt.users;

SELECT COUNT(*) as total_interfaces FROM igpt.integration_interfaces;

SELECT 'Reuse Status Distribution:' as status;
SELECT reuse_status, COUNT(*) as count FROM igpt.integration_interfaces WHERE reuse_status IS NOT NULL GROUP BY reuse_status ORDER BY count DESC;

-- ============================================================================
-- 21. SUMMARY
-- ============================================================================

/*
COMPLETE DATABASE SCHEMA INSTALLED (FIXED WITH IGPT SCHEMA)
============================================

TABLES CREATED (10):
  ✅ 1. igpt.users - User account management
  ✅ 2. igpt.azure_integrations - Azure subscription integrations
  ✅ 3. igpt.sharepoint_integrations - SharePoint site integrations
  ✅ 4. igpt.ai_interactions - Azure OpenAI interaction logs
  ✅ 5. igpt.storage_files - Uploaded file metadata
  ✅ 6. igpt.integration_interfaces - REAL DATA (45+ columns)
  ✅ 7. igpt.interface_embeddings - Vector embeddings
  ✅ 8. igpt.rag_query_logs - RAG query logs
  ✅ 9. igpt.rag_interactions - RAG interactions
  ✅ 10. igpt.embedding_cache - Embedding cache

VIEWS CREATED (9):
  ✅ 1. igpt.dashboard_360_user_stats
  ✅ 2. igpt.dashboard_360_integration_status
  ✅ 3. igpt.dashboard_360_ai_usage
  ✅ 4. igpt.dashboard_360_storage_usage
  ✅ 5. igpt.dashboard_360_summary
  ✅ 6. igpt.rag_performance_stats
  ✅ 7. igpt.rag_query_logs_view
  ✅ 8. igpt.interface_embeddings_summary
  ✅ 9. igpt.vector_search_results

SCHEMA ISOLATION:
  ✅ All objects in igpt schema
  ✅ DROP SCHEMA IF EXISTS igpt CASCADE (fresh start)
  ✅ Vector syntax fixed: embedding vector (NOT vector(384))
  ✅ All foreign keys reference igpt. tables
  ✅ All views query igpt. tables

All views created AFTER tables.
*/

-- ============================================================================
-- END OF SCHEMA - READY TO USE
-- ============================================================================