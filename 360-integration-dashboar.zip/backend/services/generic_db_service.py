"""
Generic Database Service - SQLAlchemy Version
Uses the DatabaseConnector's connection string with SQLAlchemy
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from sqlalchemy import create_engine, text
from sqlalchemy.pool import QueuePool
from connectors.db_connector import get_database_connector
from queries.database_queries import DatabaseQueries

logger = logging.getLogger(__name__)


class GenericDatabaseService:
    """
    Database service using SQLAlchemy
    Uses DatabaseConnector's connection string and configuration
    """
    
    def __init__(self, db_connector=None):
        """Initialize with DatabaseConnector"""
        self.db_connector = db_connector or get_database_connector()
        self.engine = None
        
        if self.db_connector:
            logger.info(f"✓ Service initialized with connector: {type(self.db_connector).__name__}")
            self._init_engine()
        else:
            logger.warning("⚠ Database connector not available")
    
    
    def _init_engine(self):
        """Initialize SQLAlchemy engine from connector"""
        if not self.db_connector:
            return
        
        try:
            # Get connection string from connector
            connection_string = self.db_connector.get_connection_string()
            logger.info(f"✓ Creating SQLAlchemy engine")
            
            # Create engine with pooling configuration
            self.engine = create_engine(
                connection_string,
                poolclass=QueuePool,
                pool_size=self.db_connector.pool_size,
                max_overflow=20,
                pool_recycle=self.db_connector.pool_recycle,
                pool_pre_ping=True,
                echo=False,
                connect_args={
                    'connect_timeout': 10,
                    'application_name': '360_dashboard'
                }
            )
            
            logger.info(f"✓ SQLAlchemy engine created")
            logger.info(f"  - Pool size: {self.db_connector.pool_size}")
            logger.info(f"  - Pool recycle: {self.db_connector.pool_recycle}s")
        
        except Exception as e:
            logger.error(f"✗ Error creating SQLAlchemy engine: {e}")
            self.engine = None
    
    
    def is_available(self) -> bool:
        """Check if database is available"""
        if not self.engine:
            return False
        
        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info("✓ Database connection verified")
            return True
        except Exception as e:
            logger.warning(f"⚠ Database unavailable: {e}")
            return False
    
    
    def _execute_sql(self, query: str) -> Dict[str, Any]:
        """
        Execute SQL query using SQLAlchemy
        
        Args:
            query: SQL query string
        
        Returns:
            Result dictionary with results or error
        """
        if not self.engine:
            return {
                'success': False,
                'results': [],
                'error': 'Database engine not initialized',
                'connected': False
            }
        
        try:
            logger.debug(f"Executing query: {query[:100]}...")
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query))
                
                # Fetch results
                if result.returns_rows:
                    rows = result.fetchall()
                    # Convert Row objects to dictionaries
                    results = []
                    for row in rows:
                        results.append(dict(row._mapping))
                    
                    logger.info(f"✓ Query executed: {len(results)} rows")
                    
                    return {
                        'success': True,
                        'results': results,
                        'connected': True
                    }
                else:
                    logger.info(f"✓ Query executed (no results)")
                    return {
                        'success': True,
                        'results': [],
                        'connected': True
                    }
        
        except Exception as e:
            logger.error(f"✗ Query execution failed: {e}")
            import traceback
            logger.debug(traceback.format_exc())
            
            return {
                'success': False,
                'results': [],
                'error': str(e),
                'connected': False
            }
    
    
    def execute_raw_query(self, query: str, validate: bool = True) -> Dict[str, Any]:
        """Execute raw SQL with validation"""
        try:
            if not self.is_available():
                return {
                    'success': False,
                    'results': [],
                    'error': 'Database not available',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Validate query
            if validate:
                is_safe, message = DatabaseQueries.validate_query(query)
                if not is_safe:
                    logger.warning(f"⚠ Query blocked: {message}")
                    return {
                        'success': False,
                        'results': [],
                        'error': message,
                        'timestamp': datetime.utcnow().isoformat()
                    }
            
            logger.info(f"🔍 Executing query: {query[:80]}...")
            
            result = self._execute_sql(query)
            
            if 'timestamp' not in result:
                result['timestamp'] = datetime.utcnow().isoformat()
            
            if result.get('success'):
                logger.info(f"✓ Query executed: {len(result.get('results', []))} rows")
            else:
                logger.warning(f"⚠ Query failed: {result.get('error')}")
            
            return result
        
        except Exception as e:
            logger.error(f"✗ Query execution error: {e}")
            return {
                'success': False,
                'results': [],
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def execute_aggregation_query(self, table: str, group_by_field: str,
                                 count_field: str = None,
                                 where_clause: str = None,
                                 order_by: str = 'count_desc',
                                 limit: int = None) -> Dict[str, Any]:
        """Execute GROUP BY aggregation"""
        try:
            if not self.is_available():
                return {
                    'success': False,
                    'data': [],
                    'error': 'Database not available',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            logger.info(f"🔍 Aggregation: GROUP BY {group_by_field}")
            
            # Build query
            query = DatabaseQueries.build_aggregation_query(
                table=table,
                group_by_field=group_by_field,
                count_field=count_field,
                where_clause=where_clause,
                order_by=order_by,
                limit=limit
            )
            
            logger.debug(f"Query: {query}")
            
            result = self.execute_raw_query(query, validate=False)
            
            if not result.get('success'):
                return {
                    'success': False,
                    'data': [],
                    'error': result.get('error'),
                    'timestamp': result.get('timestamp')
                }
            
            rows = result.get('results', [])
            total = sum(row.get('item_count', 0) for row in rows)
            
            data = []
            for row in rows:
                field_val = row.get(group_by_field, 'Unknown')
                count = row.get('item_count', 0)
                percentage = (count / total * 100) if total > 0 else 0
                
                data.append({
                    'field': field_val,
                    'count': count,
                    'percentage': round(percentage, 2)
                })
            
            logger.info(f"✓ Aggregation: {len(data)} groups, total: {total}")
            
            return {
                'success': True,
                'data': data,
                'total': total,
                'count': len(data),
                'group_by': group_by_field,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"✗ Aggregation error: {e}")
            return {
                'success': False,
                'data': [],
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_chart_data(self, table: str, group_by_field: str,
                      count_field: str = None,
                      where_clause: str = None,
                      colors: List[str] = None,
                      limit: int = None) -> Dict[str, Any]:
        """Get Chart.js formatted data"""
        try:
            result = self.execute_aggregation_query(
                table=table,
                group_by_field=group_by_field,
                count_field=count_field,
                where_clause=where_clause,
                limit=limit
            )
            
            if not result.get('success'):
                return {
                    'success': False,
                    'labels': [],
                    'data': [],
                    'colors': [],
                    'error': result.get('error'),
                    'timestamp': result.get('timestamp')
                }
            
            data_items = result.get('data', [])
            
            # Color palette
            if not colors:
                colors = [
                    '#2d8659', '#40b89f', '#ffd60a', '#ffb703', '#d62828', '#2d6a4f',
                    '#1a4d2e', '#52b788', '#74c69d', '#95d5b2', '#a7c957', '#e63946'
                ]
            
            labels = [item['field'] for item in data_items]
            data = [item['count'] for item in data_items]
            item_colors = [colors[i % len(colors)] for i in range(len(data_items))]
            
            logger.info(f"✓ Chart data: {len(labels)} items")
            
            return {
                'success': True,
                'labels': labels,
                'data': data,
                'colors': item_colors,
                'total': result.get('total', 0),
                'count': result.get('count', 0),
                'group_by': group_by_field,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"✗ Chart data error: {e}")
            return {
                'success': False,
                'labels': [],
                'data': [],
                'colors': [],
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_stats(self, table: str, stat_fields: Dict[str, str],
                 where_clause: str = None) -> Dict[str, Any]:
        """Get statistics"""
        try:
            if not self.is_available():
                return {
                    'success': False,
                    'stats': {},
                    'error': 'Database not available',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            logger.info(f"🔍 Statistics query on {table}")
            
            query = DatabaseQueries.build_stats_query(
                table=table,
                stat_fields=stat_fields,
                where_clause=where_clause
            )
            
            result = self.execute_raw_query(query, validate=False)
            
            if not result.get('success') or not result.get('results'):
                return {
                    'success': False,
                    'stats': {},
                    'error': result.get('error'),
                    'timestamp': result.get('timestamp')
                }
            
            stats_row = result.get('results', [{}])[0]
            
            logger.info(f"✓ Statistics query completed")
            
            return {
                'success': True,
                'stats': stats_row,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"✗ Stats error: {e}")
            return {
                'success': False,
                'stats': {},
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_records(self, table: str, filters: Dict[str, Any] = None,
                   order_by: str = None, limit: int = 100,
                   offset: int = 0) -> Dict[str, Any]:
        """Get records with filtering"""
        try:
            if not self.is_available():
                return {
                    'success': False,
                    'records': [],
                    'error': 'Database not available',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            query = DatabaseQueries.build_select_query(
                table=table,
                filters=filters,
                order_by=order_by,
                limit=limit,
                offset=offset
            )
            
            result = self.execute_raw_query(query, validate=False)
            
            if not result.get('success'):
                return {
                    'success': False,
                    'records': [],
                    'error': result.get('error'),
                    'timestamp': result.get('timestamp')
                }
            
            records = result.get('results', [])
            
            logger.info(f"✓ Retrieved {len(records)} records")
            
            return {
                'success': True,
                'records': records,
                'count': len(records),
                'limit': limit,
                'offset': offset,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"✗ Records error: {e}")
            return {
                'success': False,
                'records': [],
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }


def get_generic_db_service(db_connector=None) -> Optional[GenericDatabaseService]:
    """Get service instance"""
    try:
        return GenericDatabaseService(db_connector)
    except Exception as e:
        logger.error(f"✗ Failed to create service: {e}")
        return None