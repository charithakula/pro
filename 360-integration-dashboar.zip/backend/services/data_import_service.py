"""
✅ Data Import Service - COMPLETE WITH ALL 44 COLUMNS MAPPED
==============================================================

Features:
✅ Maps ALL 44 database columns
✅ Intelligent column detection (case-insensitive, flexible matching)
✅ Batch INSERT with ON CONFLICT DO UPDATE (single transaction)
✅ DB_SCHEMA (igpt) support
✅ No row-by-row transaction failures
✅ Handles duplicates gracefully (updates existing records)
✅ Creates embeddings for AI search
✅ Comprehensive logging and error handling

Database Schema:
  • integration_interfaces table
  • 44 columns + 3 auto-generated (id, created_at, updated_at)
  • Total: 47 columns
"""

import logging
import pandas as pd
from datetime import datetime
from typing import Dict, Any, List, Optional
from flask import current_app
from sqlalchemy import text
import traceback

logger = logging.getLogger(__name__)


# ============================================================================
# DATABASE SCHEMA - ALL 44 COLUMNS
# ============================================================================

DATABASE_COLUMNS = [
    'id',
    'interface_platform',
    'interface_id',
    'sub_interface',
    'interface_name',
    'operation_name',
    'api_product_name',
    'interface_description',
    'dependency_id',
    'process_area',
    'interface_pattern',
    'source_ci_type',
    'source_name',
    'target_ci_type',
    'target_name',
    'communication_mode',
    'volume',
    'frequency',
    'schedule',
    'interface_resolver_group',
    'qos',
    'source_service_url',
    'target_service_url',
    'source_protocol',
    'source_data_format',
    'source_trust_level',
    'target_protocol',
    'target_data_format',
    'target_trust_level',
    'retention_period',
    'source_resolver_contact',
    'target_resolver_contact',
    'priority',
    'status',
    'source_intermediary',
    'target_intermediary',
    'project_name',
    'production_migration_date',
    'pid_wo',
    'reuse_status',
    'integration_pattern',
    'interface_mode',
    'ou',
    'comments',
    'interface_build_type',
    'created_at',
    'updated_at'
]


# ============================================================================
# COMPREHENSIVE COLUMN MAPPING - ALL 44 COLUMNS
# ============================================================================

COLUMN_MAPPING = {
    # PRIMARY IDENTIFICATION (6 columns)
    'interface_id': [
        'interface_id', 'id', 'Interface ID', 'InterfaceID', 'Interface_ID',
        'Interface ID (unique)', 'Unique ID'
    ],
    'interface_name': [
        'interface_name', 'name', 'Interface Name/API', 'API Name', 'Name',
        'Interface Name', 'API Product Name', 'api_product_name'
    ],
    'interface_description': [
        'interface_description', 'description', 'Description', 'Desc',
        'Interface Description', 'What', 'Comments'
    ],
    'interface_platform': [
        'interface_platform', 'platform', 'Platform', 'System',
        'Platform/Target System', 'Target System'
    ],
    'api_product_name': [
        'api_product_name', 'API Product Name', 'Product Name', 'API Product',
        'Product', 'API Name'
    ],
    'process_area': [
        'process_area', 'Process Area', 'Area', 'Business Area',
        'Functional Area', 'Domain', 'Department'
    ],

    # INTERFACE PATTERN & TYPE (4 columns)
    'interface_pattern': [
        'interface_pattern', 'Integration Pattern', 'Pattern',
        'Pattern Type', 'Interface Pattern Type'
    ],
    'interface_mode': [
        'interface_mode', 'Mode', 'Interface Mode', 'Operational Mode',
        'Real-time/Batch'
    ],
    'interface_build_type': [
        'interface_build_type', 'Build Type', 'Implementation Type',
        'Build', 'Type of Build'
    ],
    'sub_interface': [
        'sub_interface', 'Sub Interface', 'Sub-Interface', 'Sub',
        'Child Interface'
    ],

    # OPERATIONS & COMMUNICATION (8 columns)
    'operation_name': [
        'operation_name', 'Operation Name', 'OperationName', 'Operation',
        'Operation', 'Service Operation'
    ],
    'communication_mode': [
        'communication_mode', 'Communication Mode', 'Mode of Communication',
        'Comm Mode', 'Synchronous/Asynchronous'
    ],
    'volume': [
        'volume', 'Volume', 'Data Volume', 'Vol', 'Record Volume',
        'Transaction Volume'
    ],
    'frequency': [
        'frequency', 'Frequency', 'Frequency of Data Transfer',
        'Freq', 'Frequency/Schedule'
    ],
    'schedule': [
        'schedule', 'Schedule', 'Scheduled Time', 'Sched',
        'Schedule/Timing'
    ],
    'priority': [
        'priority', 'Priority', 'Priority (High, Medium, Low)',
        'Prior', 'Criticality'
    ],
    'qos': [
        'qos', 'QoS', 'Quality of Service', 'SLA',
        'Quality of Service (SLA)'
    ],
    'retention_period': [
        'retention_period', 'Retention Period', 'Data Retention',
        'Retention', 'Data Retention Period'
    ],

    # SOURCE SYSTEM (8 columns)
    'source_ci_type': [
        'source_ci_type', 'Type of Source CI', 'Source CI Type',
        'Source System Type', 'Source Type', 'Source CI'
    ],
    'source_name': [
        'source_name', 'Source Name', 'Source System', 'Source',
        'Source Application'
    ],
    'source_service_url': [
        'source_service_url', 'Source Service URL', 'Source URL',
        'Source Endpoint', 'Source Connection'
    ],
    'source_protocol': [
        'source_protocol', 'Source Connectivity Protocol', 'Source Protocol',
        'Source Conn Protocol', 'Source Tech'
    ],
    'source_data_format': [
        'source_data_format', 'Source Data format', 'Source Format',
        'Source Data Format', 'Source File Format'
    ],
    'source_trust_level': [
        'source_trust_level', 'Source Trust Level', 'Source Security Level',
        'Source Trust', 'Source Security'
    ],
    'source_resolver_contact': [
        'source_resolver_contact', 'Source Resolver Group/Contact Details',
        'Source Contact', 'Source Owner', 'Source Resolver'
    ],
    'source_intermediary': [
        'source_intermediary', 'Source intermediary', 'Source Middleware',
        'Source Intermediary System'
    ],

    # TARGET SYSTEM (8 columns)
    'target_ci_type': [
        'target_ci_type', 'Type of Target CI', 'Target CI Type',
        'Target System Type', 'Target Type', 'Target CI'
    ],
    'target_name': [
        'target_name', 'Target Name', 'Target System', 'Target',
        'Target Application'
    ],
    'target_service_url': [
        'target_service_url', 'Target Service URL', 'Target URL',
        'Target Endpoint', 'Target Connection'
    ],
    'target_protocol': [
        'target_protocol', 'Target Connectivity type', 'Target Protocol',
        'Target Conn Protocol', 'Target Tech'
    ],
    'target_data_format': [
        'target_data_format', 'Target Data format', 'Target Format',
        'Target Data Format', 'Target File Format'
    ],
    'target_trust_level': [
        'target_trust_level', 'Target Trust Level', 'Target Security Level',
        'Target Trust', 'Target Security'
    ],
    'target_resolver_contact': [
        'target_resolver_contact', 'Target Resolver Group/Contact Details',
        'Target Contact', 'Target Owner', 'Target Resolver'
    ],
    'target_intermediary': [
        'target_intermediary', 'Target Intermediary', 'Target Middleware',
        'Target Intermediary System'
    ],

    # DEPENDENCIES & RELATIONSHIPS (3 columns)
    'dependency_id': [
        'dependency_id', 'Dependency ID', 'Dependent Interface',
        'Dependent ID', 'Related Interface'
    ],
    'interface_resolver_group': [
        'interface_resolver_group', 'Interface Resolver Group',
        'Resolver Group', 'Resolution Group'
    ],

    # STATUS & METADATA (8 columns)
    'status': [
        'status', 'Status', 'Interface Status', 'State',
        'Current Status'
    ],
    'reuse_status': [
        'reuse_status', 'Reuse Status', 'Reusable', 'Reusability',
        'Reuse'
    ],
    'integration_pattern': [
        'integration_pattern', 'Integration Pattern', 'Pattern Type',
        'Integration Type'
    ],
    'ou': [
        'ou', 'OU', 'Organizational Unit', 'Department',
        'Business Unit', 'Org Unit'
    ],
    'project_name': [
        'project_name', 'Project Name', 'Project', 'Program',
        'Initiative'
    ],
    'production_migration_date': [
        'production_migration_date', 'Production Migration Date',
        'Go-Live Date', 'Launch Date', 'Migration Date'
    ],
    'pid_wo': [
        'pid_wo', 'PID/WO#', 'Work Order', 'PID', 'WO',
        'Work Order Number'
    ],
    'comments': [
        'comments', 'Comments', 'Notes', 'Remarks',
        'Additional Comments', 'Notes/Comments'
    ],
}


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    Get schema from Flask config (config.py)
    
    Returns:
        Schema name (e.g., 'igpt')
    """
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        # Outside application context, default to 'igpt'
        return 'igpt'


def find_matching_column(df_columns: List[str], target_column: str) -> Optional[str]:
    """
    Find matching column in DataFrame based on mapping.
    
    Case-insensitive, flexible matching algorithm:
    1. Try exact match (case-insensitive)
    2. Try substring match
    3. Return None if not found
    """
    possible_names = COLUMN_MAPPING.get(target_column, [target_column])
    
    for possible_name in possible_names:
        for df_col in df_columns:
            # Exact match (case-insensitive)
            if df_col.lower().strip() == possible_name.lower().strip():
                return df_col
    
    # Fallback: substring match
    for possible_name in possible_names:
        for df_col in df_columns:
            if possible_name.lower() in df_col.lower():
                return df_col
    
    return None


# ============================================================================
# DATA IMPORT SERVICE - COMPLETE 44 COLUMNS
# ============================================================================

class DataImportService:
    """
    Data Import Service with Batch UPSERT - ALL 44 COLUMNS MAPPED
    
    Features:
    ✅ Maps all 44 database columns
    ✅ Intelligent column detection (case-insensitive, flexible matching)
    ✅ Batch INSERT with ON CONFLICT DO UPDATE (single transaction)
    ✅ DB_SCHEMA (igpt) support
    ✅ No row-by-row transaction failures
    ✅ Handles duplicates gracefully (updates existing records)
    ✅ Creates embeddings for AI search
    ✅ Returns comprehensive statistics
    """
    
    def __init__(self, db_connection=None, hybrid_rag_service=None):
        """Initialize Data Import Service"""
        self.db = db_connection
        self.rag_service = hybrid_rag_service
        self.db_schema = get_db_schema()
        
        logger.info("=" * 80)
        logger.info("📋 Data Import Service Initialized - COMPLETE 44 COLUMNS")
        logger.info(f"   Schema: {self.db_schema}")
        logger.info(f"   Total Database Columns: {len(DATABASE_COLUMNS)}")
        logger.info(f"   Mapped Columns: {len(COLUMN_MAPPING)}")
        logger.info(f"   RAG Service: {'Available' if hybrid_rag_service else 'Not Available'}")
        logger.info("=" * 80)
    
    
    def import_excel_file(self, filepath: str) -> Dict[str, Any]:
        """
        Import Excel file with BATCH UPSERT (all rows in single transaction)
        
        ✅ Uses batch INSERT with ON CONFLICT DO UPDATE
        ✅ No row-by-row failures - handles duplicates automatically
        ✅ Maps ALL 44 database columns
        ✅ Proper SQL generation with correct timestamp placement
        """
        try:
            logger.info(f"\n📁 Importing file: {filepath}")
            
            # Step 1: Read file
            # ============================================================================
            logger.info("📋 STEP 1: Read File")
            try:
                if filepath.lower().endswith('.csv'):
                    df = pd.read_csv(filepath)
                else:
                    df = pd.read_excel(filepath)
                
                logger.info(f"✓ File read successfully: {len(df)} rows, {len(df.columns)} columns")
                logger.info(f"✓ Excel columns: {list(df.columns)[:5]}... (showing first 5)")
            except Exception as e:
                logger.error(f"❌ File read failed: {e}")
                return {
                    'success': False,
                    'inserted_rows': 0,
                    'skipped_rows': 0,
                    'embeddings_created': 0,
                    'error': f'File read failed: {str(e)}',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            if len(df) == 0:
                logger.error("❌ No data in file!")
                return {
                    'success': False,
                    'inserted_rows': 0,
                    'skipped_rows': 0,
                    'embeddings_created': 0,
                    'error': 'File is empty',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Step 2: Clean column names
            # ============================================================================
            logger.info("📋 STEP 2: Clean Column Names")
            df.columns = df.columns.str.strip()
            logger.info(f"✓ Column names cleaned")
            
            # Step 3: Map ALL columns (intelligent matching)
            # ============================================================================
            logger.info("📋 STEP 3: Map Columns (ALL 44 COLUMNS)")
            logger.info(f"   Using intelligent column detection...")
            
            mapped_columns = {}
            unmapped_columns = []
            
            for target_col in COLUMN_MAPPING.keys():
                found_col = find_matching_column(df.columns.tolist(), target_col)
                if found_col:
                    mapped_columns[target_col] = found_col
                    logger.info(f"   ✓ {target_col:30} ← {found_col}")
                else:
                    unmapped_columns.append(target_col)
            
            logger.info(f"\n✓ Mapped {len(mapped_columns)}/44 columns")
            if unmapped_columns:
                logger.info(f"⚠️  Unmapped columns ({len(unmapped_columns)}): {unmapped_columns[:5]}...")
            
            # Check for required column
            if 'interface_id' not in mapped_columns:
                logger.error("❌ Required column 'interface_id' not found!")
                return {
                    'success': False,
                    'inserted_rows': 0,
                    'skipped_rows': len(df),
                    'embeddings_created': 0,
                    'error': 'Required column: interface_id not found',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Step 4: Process DataFrame rows
            # ============================================================================
            logger.info("📋 STEP 4: Process DataFrame")
            
            mapped_data = []
            
            for idx, row in df.iterrows():
                row_data = {}
                
                # Add all mapped columns
                for target_col, df_col in mapped_columns.items():
                    value = row[df_col]
                    
                    # Handle NaN/None/empty
                    if pd.isna(value) or value is None:
                        row_data[target_col] = None
                    else:
                        row_data[target_col] = str(value).strip()
                
                # Only add if has interface_id
                if row_data.get('interface_id'):
                    mapped_data.append(row_data)
            
            logger.info(f"✓ Processed {len(mapped_data)} valid rows")
            
            if len(mapped_data) == 0:
                logger.error("❌ No valid rows after processing!")
                return {
                    'success': False,
                    'inserted_rows': 0,
                    'skipped_rows': len(df),
                    'embeddings_created': 0,
                    'error': 'No valid data rows (all missing interface_id)',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Step 5: BATCH INSERT with UPSERT (single transaction)
            # ============================================================================
            logger.info("📋 STEP 5: Batch INSERT with UPSERT")
            logger.info(f"   Using schema: {self.db_schema}")
            logger.info(f"   Method: Batch INSERT with ON CONFLICT DO UPDATE")
            logger.info(f"   Rows: {len(mapped_data)}")
            logger.info(f"   Columns per row: {len(mapped_columns)}")
            
            try:
                schema = self.db_schema
                
                # ✅ KEY FIX: Build single batch INSERT with UPSERT
                # This handles ALL rows in a single transaction
                
                if len(mapped_data) > 0:
                    logger.info(f"   Building batch INSERT with {len(mapped_data)} rows...")
                    
                    # ✅ STEP 1: Discover actual database columns
                    logger.info(f"   Step 1: Discovering actual database columns...")
                    
                    actual_columns = set()
                    try:
                        if hasattr(self.db, 'execute'):
                            # SQLAlchemy
                            result = self.db.execute(text(f"""
                                SELECT column_name 
                                FROM information_schema.columns 
                                WHERE table_schema = '{schema}' 
                                AND table_name = 'integration_interfaces'
                                ORDER BY ordinal_position
                            """))
                            actual_columns = {row[0] for row in result.fetchall()}
                        else:
                            # Raw psycopg2
                            cursor = self.db.cursor()
                            cursor.execute(f"""
                                SELECT column_name 
                                FROM information_schema.columns 
                                WHERE table_schema = '{schema}' 
                                AND table_name = 'integration_interfaces'
                                ORDER BY ordinal_position
                            """)
                            actual_columns = {row[0] for row in cursor.fetchall()}
                            cursor.close()
                        
                        logger.info(f"   ✓ Found {len(actual_columns)} database columns")
                    
                    except Exception as col_err:
                        logger.warning(f"   ⚠️ Could not discover columns: {col_err}")
                        # Fallback to all DATABASE_COLUMNS
                        actual_columns = set(DATABASE_COLUMNS)
                    
                    # ✅ STEP 2: Build column lists (use all mapped columns that exist in DB)
                    logger.info(f"   Step 2: Building column list...")
                    
                    # Use all mapped columns that actually exist in database
                    insert_columns = []
                    for col in sorted(mapped_columns.keys()):
                        if col in actual_columns:
                            insert_columns.append(col)
                    
                    logger.info(f"   ✓ Will insert to {len(insert_columns)} columns: {insert_columns[:5]}... (showing first 5)")
                    
                    # ✅ STEP 3: Build VALUES clauses for all rows
                    logger.info(f"   Step 3: Building batch VALUES...")
                    
                    value_clauses = []
                    
                    for row_data in mapped_data:
                        # Build value row with only actual columns
                        values = []
                        
                        for col in insert_columns:
                            value = row_data.get(col)
                            
                            # Handle None/empty
                            if not value or value == '':
                                values.append('NULL')
                            else:
                                # Safely escape string values
                                value_escaped = str(value).replace("'", "''")
                                values.append(f"'{value_escaped}'")
                        
                        # ✅ FIXED: Add timestamps as part of the values
                        values.append('NOW()')  # created_at
                        values.append('NOW()')  # updated_at
                        
                        value_row = "(" + ", ".join(values) + ")"
                        value_clauses.append(value_row)
                    
                    logger.info(f"   ✓ Built {len(value_clauses)} value clauses")
                    
                    # ✅ STEP 4: Build the complete batch INSERT with proper column list
                    logger.info(f"   Step 4: Building batch INSERT statement...")
                    
                    # Build column list including created_at and updated_at
                    columns_list = insert_columns + ['created_at', 'updated_at']
                    columns_str = ", ".join(columns_list)
                    
                    batch_insert_sql = f"""
                        INSERT INTO {schema}.integration_interfaces (
                            {columns_str}
                        ) VALUES
                    """
                    
                    batch_insert_sql += ",\n".join(value_clauses)
                    
                    # Add ON CONFLICT DO UPDATE clause - only for columns that exist
                    update_sets = []
                    for col in insert_columns:
                        if col != 'interface_id':  # Don't update the primary key
                            update_sets.append(f"{col} = EXCLUDED.{col}")
                    
                    batch_insert_sql += f"""
                        ON CONFLICT (interface_id) DO UPDATE SET
                            {', '.join(update_sets)},
                            updated_at = NOW()
                    """
                    
                    logger.info(f"   ✓ SQL statement prepared ({len(value_clauses)} rows)")
                    
                    # ✅ STEP 5: Execute the ENTIRE batch as single transaction
                    logger.info(f"   Step 5: Executing UPSERT...")
                    
                    try:
                        if hasattr(self.db, 'execute'):
                            # SQLAlchemy connection
                            result = self.db.execute(text(batch_insert_sql))
                            rows_affected = result.rowcount if hasattr(result, 'rowcount') else len(mapped_data)
                        else:
                            # Raw psycopg2 connection
                            cursor = self.db.cursor()
                            cursor.execute(batch_insert_sql)
                            rows_affected = cursor.rowcount
                            cursor.close()
                        
                        # ✅ After UPSERT executes, all rows are either inserted or updated
                        inserted_count = len(mapped_data)
                        
                        logger.info(f"   ✓ Batch UPSERT executed successfully")
                        logger.info(f"   ✓ Rows affected: {rows_affected}")
                        
                        # Commit the transaction
                        logger.info(f"   Committing {inserted_count} rows...")
                        self.db.commit()
                        logger.info(f"   ✅ Committed successfully")
                    
                    except Exception as exec_err:
                        logger.error(f"   ❌ Execution failed: {exec_err}")
                        raise
            
            except Exception as batch_err:
                logger.error(f"❌ Batch UPSERT failed: {batch_err}")
                logger.error(f"   Error type: {type(batch_err).__name__}")
                logger.error(f"   Traceback: {traceback.format_exc()}")
                
                # Rollback on failure
                try:
                    self.db.rollback()
                    logger.info(f"   ↻ Transaction rolled back")
                except Exception as rollback_err:
                    logger.warning(f"   ⚠️ Rollback failed: {rollback_err}")
                
                return {
                    'success': False,
                    'inserted_rows': 0,
                    'skipped_rows': len(mapped_data),
                    'embeddings_created': 0,
                    'error': f'Batch UPSERT failed: {str(batch_err)}',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Step 6: Generate embeddings (optional)
            # ============================================================================
            embeddings_created = 0
            
            if self.rag_service and inserted_count > 0:
                logger.info(f"\n📋 STEP 6: Create Embeddings")
                logger.info(f"   Creating embeddings for {inserted_count} records...")
                
                try:
                    embedding_result = self.rag_service.create_embeddings_for_uploaded_data(mapped_data)
                    
                    if embedding_result.get('success'):
                        embeddings_created = embedding_result.get('total_embeddings', 0)
                        logger.info(f"   ✓ Created {embeddings_created} embeddings")
                    else:
                        logger.warning(f"   ⚠️ Embedding creation failed: {embedding_result.get('error')}")
                
                except Exception as embed_err:
                    logger.warning(f"   ⚠️ Embedding error: {embed_err}")
                    logger.warning(f"   (Continuing without embeddings)")
            else:
                logger.info(f"\n📋 STEP 6: Embeddings")
                if not self.rag_service:
                    logger.info(f"   ⚠️ RAG service not available (skipping embeddings)")
                else:
                    logger.info(f"   ⚠️ No records to embed (inserted_count = 0)")
            
            # Step 7: Return success
            # ============================================================================
            logger.info("\n" + "=" * 80)
            logger.info("✅ IMPORT COMPLETED SUCCESSFULLY")
            logger.info("=" * 80)
            logger.info(f"   Inserted/Updated: {inserted_count} rows")
            logger.info(f"   Columns mapped: {len(mapped_columns)}/44")
            logger.info(f"   Embeddings: {embeddings_created}")
            logger.info(f"   Method: Batch UPSERT (ON CONFLICT DO UPDATE)")
            logger.info("=" * 80 + "\n")
            
            return {
                'success': True,
                'inserted_rows': inserted_count,
                'skipped_rows': 0,
                'embeddings_created': embeddings_created,
                'columns_mapped': len(mapped_columns),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"❌ Import failed: {e}")
            logger.error(f"   Type: {type(e).__name__}")
            logger.error(f"   Traceback: {traceback.format_exc()}")
            
            try:
                self.db.rollback()
            except:
                pass
            
            return {
                'success': False,
                'inserted_rows': 0,
                'skipped_rows': 0,
                'embeddings_created': 0,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def clear_data(self) -> Dict[str, Any]:
        """
        Clear all data from tables - ✅ FIXED: Uses DB_SCHEMA
        """
        try:
            schema = self.db_schema
            
            logger.info(f"🗑️  Clearing data from {schema} schema...")
            
            if hasattr(self.db, 'execute'):
                self.db.execute(text(f"DELETE FROM {schema}.interface_embeddings"))
                self.db.execute(text(f"DELETE FROM {schema}.integration_interfaces"))
            else:
                cursor = self.db.cursor()
                cursor.execute(f"DELETE FROM {schema}.interface_embeddings")
                cursor.execute(f"DELETE FROM {schema}.integration_interfaces")
                cursor.close()
            
            self.db.commit()
            
            logger.info("✅ Data cleared")
            
            return {
                'success': True,
                'message': 'All data cleared',
                'schema': schema,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"❌ Clear failed: {e}")
            
            try:
                self.db.rollback()
            except:
                pass
            
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_import_stats(self) -> Dict[str, Any]:
        """
        Get import statistics - ✅ FIXED: Uses DB_SCHEMA
        """
        try:
            schema = self.db_schema
            
            if hasattr(self.db, 'execute'):
                # Total records
                total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                total_records = total_result.scalar() or 0
                
                # Total embeddings
                embed_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.interface_embeddings"))
                total_embeddings = embed_result.scalar() or 0
                
                # By status
                status_result = self.db.execute(text(f"""
                    SELECT status, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE status IS NOT NULL
                    GROUP BY status
                    ORDER BY count DESC
                """))
                status_breakdown = {row[0]: row[1] for row in status_result.fetchall()}
                
                # By platform
                platform_result = self.db.execute(text(f"""
                    SELECT interface_platform, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE interface_platform IS NOT NULL
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """))
                platform_breakdown = {row[0]: row[1] for row in platform_result.fetchall()}
            
            else:
                cursor = self.db.cursor()
                
                cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                total_records = cursor.fetchone()[0]
                
                cursor.execute(f"SELECT COUNT(*) FROM {schema}.interface_embeddings")
                total_embeddings = cursor.fetchone()[0]
                
                cursor.execute(f"""
                    SELECT status, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE status IS NOT NULL
                    GROUP BY status
                    ORDER BY count DESC
                """)
                status_breakdown = {row[0]: row[1] for row in cursor.fetchall()}
                
                cursor.execute(f"""
                    SELECT interface_platform, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE interface_platform IS NOT NULL
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """)
                platform_breakdown = {row[0]: row[1] for row in cursor.fetchall()}
                
                cursor.close()
            
            logger.info(f"✅ Stats retrieved: {total_records} records, {total_embeddings} embeddings")
            
            return {
                'success': True,
                'schema': schema,
                'total_records': total_records,
                'total_embeddings': total_embeddings,
                'by_status': status_breakdown,
                'by_platform': platform_breakdown,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"❌ Stats failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }


__all__ = ['DataImportService', 'COLUMN_MAPPING', 'DATABASE_COLUMNS', 'find_matching_column']