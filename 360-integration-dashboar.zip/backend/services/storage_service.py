"""
Azure Storage Services - Business Logic Layer
360° Enterprise Dashboard - File Management Services
High-level file operations and management
"""

import logging
import os
from typing import Dict, List, Any, Optional, BinaryIO
from datetime import datetime
from connectors.azure_storage_connector import get_azure_storage_connector

logger = logging.getLogger(__name__)


class StorageService:
    """
    High-level Azure Storage service operations
    Provides business logic for file management
    """
    
    def __init__(self, config=None):
        """
        Initialize Storage service
        
        Args:
            config: Flask configuration object
        """
        self.connector = get_azure_storage_connector(config)
        self.config = config
    
    
    def is_available(self) -> bool:
        """Check if storage is available"""
        if self.connector is None:
            return False
        health = self.connector.health_check()
        return health['status'] == 'healthy'
    
    
    # ========================================================================
    # FILE UPLOAD OPERATIONS
    # ========================================================================
    
    def upload_file(self, file_path: str, blob_name: Optional[str] = None,
                   user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Upload a file from disk
        
        Args:
            file_path: Local file path
            blob_name: Custom blob name (optional)
            user_id: User identifier for tracking
        
        Returns:
            Upload result dictionary
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'file_path': file_path
            }
        
        try:
            logger.info(f"Uploading file: {file_path}")
            
            result = self.connector.upload_file(
                file_path=file_path,
                blob_name=blob_name,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Upload file error: {e}")
            return {
                'success': False,
                'error': str(e),
                'file_path': file_path
            }
    
    
    def upload_bytes(self, data: bytes, blob_name: str,
                    user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Upload bytes/data
        
        Args:
            data: Bytes to upload
            blob_name: Blob name
            user_id: User identifier
        
        Returns:
            Upload result dictionary
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'blob_name': blob_name
            }
        
        try:
            logger.info(f"Uploading bytes: {blob_name} ({len(data)} bytes)")
            
            result = self.connector.upload_bytes(
                data=data,
                blob_name=blob_name,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Upload bytes error: {e}")
            return {
                'success': False,
                'error': str(e),
                'blob_name': blob_name
            }
    
    
    # ========================================================================
    # FILE DOWNLOAD OPERATIONS
    # ========================================================================
    
    def download_file(self, blob_name: str, local_path: str,
                     user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Download a file to disk
        
        Args:
            blob_name: Blob name
            local_path: Local path to save
            user_id: User identifier
        
        Returns:
            Download result dictionary
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'blob_name': blob_name
            }
        
        try:
            logger.info(f"Downloading file: {blob_name} -> {local_path}")
            
            result = self.connector.download_file(
                blob_name=blob_name,
                local_path=local_path,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Download file error: {e}")
            return {
                'success': False,
                'error': str(e),
                'blob_name': blob_name
            }
    
    
    def download_bytes(self, blob_name: str,
                      user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Download file as bytes
        
        Args:
            blob_name: Blob name
            user_id: User identifier
        
        Returns:
            Download result with bytes
            {
                'success': bool,
                'data': bytes,
                'file_size': int,
                ...
            }
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'blob_name': blob_name,
                'data': None
            }
        
        try:
            logger.info(f"Downloading bytes: {blob_name}")
            
            result = self.connector.download_bytes(
                blob_name=blob_name,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Download bytes error: {e}")
            return {
                'success': False,
                'error': str(e),
                'blob_name': blob_name,
                'data': None
            }
    
    
    # ========================================================================
    # FILE MANAGEMENT OPERATIONS
    # ========================================================================
    
    def delete_file(self, blob_name: str,
                   user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete a file
        
        Args:
            blob_name: Blob name to delete
            user_id: User identifier
        
        Returns:
            Delete result dictionary
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'blob_name': blob_name
            }
        
        try:
            logger.info(f"Deleting file: {blob_name}")
            
            result = self.connector.delete_file(
                blob_name=blob_name,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Delete file error: {e}")
            return {
                'success': False,
                'error': str(e),
                'blob_name': blob_name
            }
    
    
    def delete_files(self, blob_names: List[str],
                    user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Delete multiple files
        
        Args:
            blob_names: List of blob names
            user_id: User identifier
        
        Returns:
            Batch delete result
            {
                'success': bool,
                'deleted': List[str],
                'failed': List[Dict],
                'count': int
            }
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'deleted': [],
                'failed': blob_names
            }
        
        deleted = []
        failed = []
        
        try:
            logger.info(f"Batch deleting {len(blob_names)} files")
            
            for blob_name in blob_names:
                result = self.delete_file(blob_name, user_id=user_id)
                if result['success']:
                    deleted.append(blob_name)
                else:
                    failed.append({
                        'blob_name': blob_name,
                        'error': result.get('error')
                    })
            
            return {
                'success': len(failed) == 0,
                'deleted': deleted,
                'failed': failed,
                'count': len(deleted),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Batch delete error: {e}")
            return {
                'success': False,
                'error': str(e),
                'deleted': deleted,
                'failed': failed
            }
    
    
    def list_files(self, prefix: Optional[str] = None,
                  user_id: Optional[str] = None) -> Dict[str, Any]:
        """
        List files in storage
        
        Args:
            prefix: Folder/prefix filter
            user_id: List user's files only
        
        Returns:
            File list
            {
                'success': bool,
                'files': List[Dict],
                'count': int
            }
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'files': [],
                'count': 0
            }
        
        try:
            logger.info(f"Listing files (prefix: {prefix or 'none'})")
            
            result = self.connector.list_files(
                prefix=prefix,
                user_id=user_id
            )
            
            return result
        
        except Exception as e:
            logger.error(f"List files error: {e}")
            return {
                'success': False,
                'error': str(e),
                'files': [],
                'count': 0
            }
    
    
    def get_file_url(self, blob_name: str,
                    user_id: Optional[str] = None,
                    sas_expiry_hours: int = 24) -> Dict[str, Any]:
        """
        Get URL for a file
        
        Args:
            blob_name: Blob name
            user_id: User identifier
            sas_expiry_hours: SAS token expiry hours
        
        Returns:
            URL result
            {
                'success': bool,
                'url': str,
                'expires_at': str,
                ...
            }
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Storage service is not available',
                'blob_name': blob_name,
                'url': None
            }
        
        try:
            logger.info(f"Getting URL for: {blob_name}")
            
            result = self.connector.get_file_url(
                blob_name=blob_name,
                user_id=user_id,
                sas_expiry_hours=sas_expiry_hours
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Get file URL error: {e}")
            return {
                'success': False,
                'error': str(e),
                'blob_name': blob_name,
                'url': None
            }
    
    
    # ========================================================================
    # STORAGE MANAGEMENT
    # ========================================================================
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """
        Get storage statistics
        
        Returns:
            Storage stats
            {
                'account_name': str,
                'container_name': str,
                'total_files': int,
                'total_size': int,
                'total_size_mb': float
            }
        """
        if not self.is_available():
            return {
                'error': 'Storage service is not available',
                'total_files': 0,
                'total_size': 0
            }
        
        try:
            logger.info("Getting storage statistics")
            
            result = self.connector.get_storage_stats()
            
            return result
        
        except Exception as e:
            logger.error(f"Get storage stats error: {e}")
            return {
                'error': str(e),
                'total_files': 0,
                'total_size': 0
            }
    
    
    def get_user_storage_stats(self, user_id: str) -> Dict[str, Any]:
        """
        Get storage stats for a specific user
        
        Args:
            user_id: User identifier
        
        Returns:
            User storage stats
            {
                'user_id': str,
                'total_files': int,
                'total_size': int,
                'total_size_mb': float
            }
        """
        try:
            logger.info(f"Getting storage stats for user: {user_id}")
            
            # List user's files
            result = self.list_files(user_id=user_id)
            
            if not result['success']:
                return {
                    'success': False,
                    'user_id': user_id,
                    'error': result.get('error')
                }
            
            # Calculate stats
            total_files = result['count']
            total_size = sum(f.get('size', 0) for f in result['files'])
            
            return {
                'success': True,
                'user_id': user_id,
                'total_files': total_files,
                'total_size': total_size,
                'total_size_mb': round(total_size / (1024 * 1024), 2),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Get user storage stats error: {e}")
            return {
                'success': False,
                'user_id': user_id,
                'error': str(e)
            }
    
    
    # ========================================================================
    # HEALTH & STATUS
    # ========================================================================
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check storage service health
        
        Returns:
            Health status
            {
                'status': 'healthy|unhealthy',
                'connected': bool,
                ...
            }
        """
        if not self.connector:
            return {
                'status': 'unavailable',
                'message': 'Storage connector not initialized',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return self.connector.health_check()
    
    
    def get_service_status(self) -> Dict[str, Any]:
        """
        Get complete service status
        
        Returns:
            Service status
        """
        health = self.health_check()
        
        status_info = {
            'health': health,
            'available': health['status'] == 'healthy',
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if self.connector and health['status'] == 'healthy':
            try:
                stats = self.connector.get_storage_stats()
                status_info['stats'] = stats
            except:
                pass
        
        return status_info


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def get_storage_service(config=None) -> Optional[StorageService]:
    """
    Get Storage service instance
    
    Args:
        config: Flask configuration object
    
    Returns:
        StorageService instance or None
    """
    try:
        return StorageService(config)
    except Exception as e:
        logger.error(f"Failed to create Storage service: {e}")
        return None