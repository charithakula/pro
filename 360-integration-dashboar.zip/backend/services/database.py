"""
Enhanced Database Module for Hybrid RAG System
Provides database connections, sessions, and health checks
FIXED: Now reads connection string from environment
"""

import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime
import contextlib
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.orm import sessionmaker, Session

logger = logging.getLogger(__name__)

# Global database session factory
_SessionLocal = None
_engine = None


def init_db(database_url: str = None, echo: bool = False) -> bool:
    """
    Initialize database connection and session factory
    
    Args:
        database_url: Database connection URL (if None, builds from environment)
        echo: Whether to echo SQL queries
        
    Returns:
        True if successful, False otherwise
    """
    global _SessionLocal, _engine
    
    try:
        if database_url is None:
            # Build connection string from environment variables
            db_type = os.getenv('DB_TYPE', 'postgresql')
            db_user = os.getenv('DB_USER', 'dashboard_user')
            db_password = os.getenv('DB_PASSWORD', '')
            db_host = os.getenv('DB_HOST', 'localhost')
            db_port = os.getenv('DB_PORT', '5434')  # Note: 5434 as default
            db_name = os.getenv('DB_NAME', 'dashboard_360')
            
            database_url = (
                f"{db_type}://{db_user}:{db_password}@"
                f"{db_host}:{db_port}/{db_name}"
            )
            
            logger.info(f"📊 Built connection string from environment: {db_host}:{db_port}/{db_name}")
        
        logger.info(f"🔄 Initializing database connection...")
        
        # Create engine with connection pooling
        _engine = create_engine(
            database_url,
            echo=echo,
            pool_pre_ping=True,  # Test connections before using
            pool_size=int(os.getenv('SQLALCHEMY_POOL_SIZE', 10)),
            max_overflow=20,
            pool_recycle=int(os.getenv('SQLALCHEMY_POOL_RECYCLE', 3600)),
            pool_timeout=int(os.getenv('SQLALCHEMY_POOL_TIMEOUT', 30)),
            connect_args={'connect_timeout': 10}
        )
        
        # Create session factory
        _SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=_engine
        )
        
        logger.info("✅ Database initialized successfully")
        return True
    
    except Exception as e:
        logger.error(f"❌ Database initialization failed: {e}")
        _SessionLocal = None
        _engine = None
        return False


def get_db_session() -> Optional[Session]:
    """
    Get a database session for Hybrid RAG operations
    
    Returns:
        SQLAlchemy Session or None if not initialized
        
    Usage:
        session = get_db_session()
        if session:
            result = session.execute(text("SELECT * FROM table"))
            session.close()
    """
    try:
        if _SessionLocal is None:
            logger.warning("⚠️ Database session not initialized")
            return None
        
        session = _SessionLocal()
        logger.debug("✓ Database session created")
        return session
    
    except Exception as e:
        logger.error(f"❌ Error creating database session: {e}")
        return None


@contextlib.contextmanager
def get_db_session_context():
    """
    Context manager for database sessions
    
    Usage:
        with get_db_session_context() as session:
            result = session.execute(text("SELECT * FROM table"))
    """
    session = None
    try:
        session = get_db_session()
        if session is None:
            raise RuntimeError("Database session not initialized")
        yield session
        session.commit()
    except Exception as e:
        if session:
            session.rollback()
        logger.error(f"❌ Database session error: {e}")
        raise
    finally:
        if session:
            session.close()


def execute_query(query_text: str, params: Dict[str, Any] = None) -> Optional[Any]:
    """
    Execute a SQL query and return results
    
    Args:
        query_text: SQL query string
        params: Query parameters
        
    Returns:
        Query results or None if failed
    """
    try:
        with get_db_session_context() as session:
            result = session.execute(text(query_text), params or {})
            rows = result.fetchall()
            logger.info(f"✓ Query executed: {len(rows)} rows returned")
            return rows
    
    except Exception as e:
        logger.error(f"❌ Query execution failed: {e}")
        return None


def execute_query_scalar(query_text: str, params: Dict[str, Any] = None) -> Optional[Any]:
    """
    Execute a SQL query and return single scalar value
    
    Args:
        query_text: SQL query string
        params: Query parameters
        
    Returns:
        Scalar value or None
    """
    try:
        with get_db_session_context() as session:
            result = session.execute(text(query_text), params or {})
            value = result.scalar()
            logger.info(f"✓ Scalar query executed: {value}")
            return value
    
    except Exception as e:
        logger.error(f"❌ Scalar query failed: {e}")
        return None


def check_db_health() -> Dict[str, Any]:
    """
    Check database health and status
    
    Returns:
        Dictionary with health status
    """
    try:
        if _engine is None:
            return {
                'status': 'unhealthy',
                'connected': False,
                'error': 'Engine not initialized'
            }
        
        with get_db_session_context() as session:
            # Test basic connectivity
            session.execute(text("SELECT 1"))
            
            # Get table count
            inspector = inspect(_engine)
            tables = inspector.get_table_names()
            
            logger.info(f"✓ Database healthy: {len(tables)} tables")
            
            return {
                'status': 'healthy',
                'connected': True,
                'tables_count': len(tables),
                'tables': tables,
                'timestamp': datetime.utcnow().isoformat()
            }
    
    except Exception as e:
        logger.error(f"❌ Database health check failed: {e}")
        return {
            'status': 'unhealthy',
            'connected': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }


def get_db_connection():
    """
    Get database connection (legacy compatibility)
    
    Returns:
        Database session
    """
    return get_db_session()


def get_table_info(table_name: str) -> Dict[str, Any]:
    """
    Get information about a specific table
    
    Args:
        table_name: Name of the table
        
    Returns:
        Dictionary with table information
    """
    try:
        if _engine is None:
            return {'error': 'Engine not initialized'}
        
        inspector = inspect(_engine)
        
        if not inspector.has_table(table_name):
            return {'error': f'Table {table_name} not found'}
        
        columns = inspector.get_columns(table_name)
        primary_keys = inspector.get_pk_constraint(table_name)
        
        return {
            'table_name': table_name,
            'columns': [{'name': col['name'], 'type': str(col['type'])} for col in columns],
            'primary_keys': primary_keys,
            'column_count': len(columns)
        }
    
    except Exception as e:
        logger.error(f"❌ Error getting table info: {e}")
        return {'error': str(e)}


def clear_db() -> Dict[str, Any]:
    """
    Clear all data from Hybrid RAG database tables
    Useful for resetting and reimporting data
    
    Returns:
        Dictionary with cleared counts
    """
    try:
        logger.info("🗑️ Clearing database tables...")
        
        with get_db_session_context() as session:
            tables_cleared = 0
            rows_deleted = 0
            
            # List of tables to clear (in order due to foreign keys)
            tables_to_clear = [
                'interface_embeddings',  # Clear embeddings first
                'integration_interfaces',  # Then clear interfaces
            ]
            
            for table_name in tables_to_clear:
                try:
                    result = session.execute(text(f"DELETE FROM {table_name}"))
                    deleted = result.rowcount
                    rows_deleted += deleted
                    tables_cleared += 1
                    logger.info(f"✓ Cleared {table_name}: {deleted} rows")
                except Exception as table_error:
                    logger.warning(f"⚠️ Could not clear {table_name}: {table_error}")
            
            session.commit()
            
            logger.info(f"✅ Database cleared: {tables_cleared} tables, {rows_deleted} rows")
            
            return {
                'success': True,
                'tables_cleared': tables_cleared,
                'rows_deleted': rows_deleted,
                'timestamp': datetime.utcnow().isoformat()
            }
    
    except Exception as e:
        logger.error(f"❌ Error clearing database: {e}")
        return {
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }


def close_db():
    """Close database connections"""
    global _engine, _SessionLocal
    try:
        if _engine:
            _engine.dispose()
            logger.info("✓ Database connections closed")
    except Exception as e:
        logger.error(f"❌ Error closing database: {e}")
    finally:
        _SessionLocal = None
        _engine = None


# Initialization log
logger.info("✅ Database module loaded")