"""
Query Router - Intelligent Query Routing for Hybrid RAG System
Routes questions to optimal processing path: Direct LLM, SQL-First, or Hybrid
"""

import logging
from typing import Dict, Any, List, Optional
from enum import Enum
from datetime import datetime

logger = logging.getLogger(__name__)


class QueryType(Enum):
    """Enum for different query types"""
    STATISTICAL = "statistical"  # Aggregations, counts, sums
    TEMPORAL = "temporal"  # Date/time based queries
    COMPARATIVE = "comparative"  # Comparisons between entities
    DESCRIPTIVE = "descriptive"  # General information retrieval
    ANALYTICAL = "analytical"  # Complex multi-step analysis
    UNKNOWN = "unknown"  # Unclassified


class ProcessingPath(Enum):
    """Enum for processing paths"""
    DIRECT_LLM = "direct_llm"  # Ask LLM directly
    SQL_FIRST = "sql_first"  # Generate and execute SQL first
    HYBRID = "hybrid"  # Combine SQL + semantic search + LLM


class QueryRouter:
    """
    Intelligent query router for Hybrid RAG system
    Routes questions to optimal processing strategy
    """
    
    def __init__(self, config=None):
        """
        Initialize Query Router
        
        Args:
            config: Configuration object (optional)
        """
        self.config = config
        self.routing_history = []
        logger.info("✓ QueryRouter initialized")
    
    def classify_query(self, question: str) -> Dict[str, Any]:
        """
        Classify query type based on question content
        
        Args:
            question: User's question
            
        Returns:
            Dictionary with classification details
        """
        try:
            question_lower = question.lower()
            
            # Statistical queries
            if any(word in question_lower for word in ['count', 'how many', 'total', 'sum', 'average', 'number of']):
                query_type = QueryType.STATISTICAL
                confidence = 0.95
            
            # Temporal queries
            elif any(word in question_lower for word in ['when', 'date', 'time', 'year', 'month', 'week']):
                query_type = QueryType.TEMPORAL
                confidence = 0.9
            
            # Comparative queries
            elif any(word in question_lower for word in ['compare', 'vs', 'versus', 'difference', 'similar']):
                query_type = QueryType.COMPARATIVE
                confidence = 0.88
            
            # Analytical queries
            elif any(word in question_lower for word in ['analyze', 'analysis', 'trend', 'pattern', 'correlation']):
                query_type = QueryType.ANALYTICAL
                confidence = 0.85
            
            # Descriptive queries
            elif any(word in question_lower for word in ['what', 'which', 'where', 'who', 'describe']):
                query_type = QueryType.DESCRIPTIVE
                confidence = 0.8
            
            else:
                query_type = QueryType.UNKNOWN
                confidence = 0.5
            
            logger.info(f"Query classified as: {query_type.value} (confidence: {confidence})")
            
            return {
                'type': query_type,
                'type_name': query_type.value,
                'confidence': confidence,
                'description': self._get_type_description(query_type)
            }
        
        except Exception as e:
            logger.error(f"Error classifying query: {e}")
            return {
                'type': QueryType.UNKNOWN,
                'type_name': QueryType.UNKNOWN.value,
                'confidence': 0.0,
                'description': 'Unable to classify query'
            }
    
    def route_query(self, question: str, has_data: bool = True) -> Dict[str, Any]:
        """
        Route query to optimal processing path
        
        Args:
            question: User's question
            has_data: Whether data has been loaded into database
            
        Returns:
            Dictionary with routing decision
        """
        try:
            # Classify the query
            classification = self.classify_query(question)
            query_type = classification['type']
            
            # Determine processing path based on query type and data availability
            if not has_data:
                # No data loaded - use direct LLM
                path = ProcessingPath.DIRECT_LLM
                reasoning = "No data loaded - using Direct LLM mode"
            
            elif query_type == QueryType.STATISTICAL:
                # Statistical queries are best for SQL
                path = ProcessingPath.SQL_FIRST
                reasoning = "Statistical query - SQL generation recommended"
            
            elif query_type == QueryType.TEMPORAL:
                # Temporal queries can use SQL
                path = ProcessingPath.SQL_FIRST
                reasoning = "Temporal query - SQL with date filtering"
            
            elif query_type == QueryType.ANALYTICAL:
                # Complex analytical queries benefit from hybrid approach
                path = ProcessingPath.HYBRID
                reasoning = "Analytical query - Hybrid approach for complex analysis"
            
            elif query_type == QueryType.COMPARATIVE:
                # Comparative queries can use SQL joins
                path = ProcessingPath.SQL_FIRST
                reasoning = "Comparative query - SQL for multi-entity comparison"
            
            elif query_type == QueryType.DESCRIPTIVE:
                # Descriptive queries work well with hybrid
                path = ProcessingPath.HYBRID
                reasoning = "Descriptive query - Hybrid for comprehensive retrieval"
            
            else:
                # Unknown - use hybrid as default
                path = ProcessingPath.HYBRID
                reasoning = "Unknown query type - using Hybrid approach"
            
            routing_decision = {
                'path': path,
                'path_name': path.value,
                'question_type': classification['type_name'],
                'reasoning': reasoning,
                'classification_confidence': classification['confidence'],
                'timestamp': datetime.utcnow().isoformat()
            }
            
            # Store in history
            self.routing_history.append(routing_decision)
            
            logger.info(f"Query routed to: {path.value}")
            
            return routing_decision
        
        except Exception as e:
            logger.error(f"Error routing query: {e}")
            return {
                'path': ProcessingPath.HYBRID,
                'path_name': ProcessingPath.HYBRID.value,
                'question_type': QueryType.UNKNOWN.value,
                'reasoning': f'Error in routing: {str(e)}',
                'classification_confidence': 0.0,
                'timestamp': datetime.utcnow().isoformat()
            }
    
    def get_routing_stats(self) -> Dict[str, Any]:
        """
        Get statistics about routing decisions
        
        Returns:
            Dictionary with routing statistics
        """
        try:
            stats = {
                'total_queries_routed': len(self.routing_history),
                'paths_used': {},
                'query_types': {},
                'average_confidence': 0.0
            }
            
            if not self.routing_history:
                return stats
            
            # Count path usage
            for decision in self.routing_history:
                path = decision.get('path_name', 'unknown')
                stats['paths_used'][path] = stats['paths_used'].get(path, 0) + 1
            
            # Count query types
            for decision in self.routing_history:
                qtype = decision.get('question_type', 'unknown')
                stats['query_types'][qtype] = stats['query_types'].get(qtype, 0) + 1
            
            # Calculate average confidence
            confidences = [d.get('classification_confidence', 0) for d in self.routing_history]
            stats['average_confidence'] = sum(confidences) / len(confidences) if confidences else 0.0
            
            return stats
        
        except Exception as e:
            logger.error(f"Error calculating routing stats: {e}")
            return {}
    
    @staticmethod
    def _get_type_description(query_type: QueryType) -> str:
        """Get human-readable description for query type"""
        descriptions = {
            QueryType.STATISTICAL: "Statistical/Aggregation query",
            QueryType.TEMPORAL: "Date/Time based query",
            QueryType.COMPARATIVE: "Comparison query",
            QueryType.DESCRIPTIVE: "Descriptive/Information query",
            QueryType.ANALYTICAL: "Complex analytical query",
            QueryType.UNKNOWN: "Unknown query type"
        }
        return descriptions.get(query_type, "Unknown")


def get_query_router(config=None) -> Optional[QueryRouter]:
    """
    Factory function to get QueryRouter instance
    
    Args:
        config: Configuration object (optional)
    
    Returns:
        QueryRouter instance or None if initialization fails
    """
    try:
        return QueryRouter(config=config)
    except Exception as e:
        logger.error(f"Failed to create QueryRouter: {e}")
        return None