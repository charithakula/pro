"""
File Service Layer
Handles all file operations (Excel, CSV, etc.)
Separates file logic from chat logic
"""

import os
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class FileServiceError(Exception):
    """Custom exception for file service errors"""
    pass


class ExcelDataService:
    """Service for handling Excel file operations"""
    
    def __init__(self):
        self.loaded_files = {}
        self.current_file = None
        self.current_sheets = {}
    
    def load_file(self, filepath: str) -> Dict[str, Any]:
        """
        Load Excel file and extract metadata
        
        Args:
            filepath: Path to Excel file
            
        Returns:
            Dictionary with file metadata and sheet information
        """
        try:
            if not os.path.exists(filepath):
                raise FileServiceError(f"File not found: {filepath}")
            
            excel_file = pd.ExcelFile(filepath)
            
            sheets_data = {
                'filename': os.path.basename(filepath),
                'filepath': filepath,
                'sheets': {},
                'sheet_names': excel_file.sheet_names,
                'total_sheets': len(excel_file.sheet_names),
                'file_size': os.path.getsize(filepath),
                'loaded_at': datetime.utcnow().isoformat()
            }
            
            # Load each sheet
            for sheet_name in excel_file.sheet_names:
                df = pd.read_excel(filepath, sheet_name=sheet_name)
                
                sheets_data['sheets'][sheet_name] = {
                    'dataframe': df,
                    'columns': list(df.columns),
                    'total_columns': len(df.columns),
                    'total_rows': len(df),
                    'dtypes': df.dtypes.to_dict(),
                    'preview': df.head(5).to_dict(orient='records')
                }
            
            self.loaded_files[filepath] = sheets_data
            self.current_file = filepath
            self.current_sheets = sheets_data['sheets']
            
            logger.info(f"✓ Loaded Excel file with {len(excel_file.sheet_names)} sheets")
            return sheets_data
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error loading Excel file: {e}")
            raise FileServiceError(f"Failed to load Excel file: {str(e)}")
    
    def load_csv(self, filepath: str, delimiter: str = ',') -> Dict[str, Any]:
        """
        Load CSV file and extract metadata
        
        Args:
            filepath: Path to CSV file
            delimiter: CSV delimiter (default: ',')
            
        Returns:
            Dictionary with file metadata
        """
        try:
            if not os.path.exists(filepath):
                raise FileServiceError(f"File not found: {filepath}")
            
            df = pd.read_csv(filepath, delimiter=delimiter)
            
            csv_data = {
                'filename': os.path.basename(filepath),
                'filepath': filepath,
                'sheets': {
                    'data': {
                        'dataframe': df,
                        'columns': list(df.columns),
                        'total_columns': len(df.columns),
                        'total_rows': len(df),
                        'dtypes': df.dtypes.to_dict(),
                        'preview': df.head(5).to_dict(orient='records')
                    }
                },
                'sheet_names': ['data'],
                'total_sheets': 1,
                'file_size': os.path.getsize(filepath),
                'loaded_at': datetime.utcnow().isoformat()
            }
            
            self.loaded_files[filepath] = csv_data
            self.current_file = filepath
            self.current_sheets = csv_data['sheets']
            
            logger.info(f"✓ Loaded CSV file successfully")
            return csv_data
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error loading CSV file: {e}")
            raise FileServiceError(f"Failed to load CSV file: {str(e)}")
    
    def get_file_summary(self, filepath: str) -> Dict[str, Any]:
        """Get summary of loaded file"""
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            
            return {
                'filename': file_data['filename'],
                'filepath': filepath,
                'file_size': file_data['file_size'],
                'total_sheets': file_data['total_sheets'],
                'sheets': [
                    {
                        'name': sheet_name,
                        'rows': sheet_info['total_rows'],
                        'columns': sheet_info['columns'],
                        'column_count': sheet_info['total_columns']
                    }
                    for sheet_name, sheet_info in file_data['sheets'].items()
                ]
            }
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting file summary: {e}")
            raise FileServiceError(f"Failed to get file summary: {str(e)}")
    
    def search_across_sheets(self, filepath: str, query: str) -> Dict[str, Any]:
        """Search for data across all sheets"""
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            results = {
                'query': query,
                'matches': {},
                'total_matches': 0
            }
            
            query_lower = query.lower()
            
            for sheet_name, sheet_info in file_data['sheets'].items():
                df = sheet_info['dataframe']
                matching_rows = []
                
                # Search in column names
                matching_columns = [col for col in df.columns if query_lower in col.lower()]
                
                # Search in cell values
                for col in df.columns:
                    if df[col].dtype == 'object':
                        mask = df[col].astype(str).str.lower().str.contains(query_lower, na=False)
                        if mask.any():
                            matching_rows.extend(df[mask].to_dict(orient='records'))
                
                if matching_columns or matching_rows:
                    results['matches'][sheet_name] = {
                        'matching_columns': matching_columns,
                        'matching_rows_count': len(matching_rows),
                        'sample_rows': matching_rows[:3]
                    }
                    results['total_matches'] += len(matching_rows)
            
            return results
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error searching sheets: {e}")
            raise FileServiceError(f"Failed to search sheets: {str(e)}")
    
    def convert_to_context(self, filepath: str, sheet_name: Optional[str] = None, max_length: int = 4000) -> str:
        """
        Convert Excel/CSV sheets to formatted text for LLM context
        
        Args:
            filepath: Path to file
            sheet_name: Specific sheet to convert (optional)
            max_length: Maximum context length in characters
            
        Returns:
            Formatted text context
        """
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            context = f"File: {file_data['filename']}\n"
            context += f"Total Sheets: {file_data['total_sheets']}\n"
            context += "=" * 60 + "\n\n"
            
            if sheet_name:
                if sheet_name not in file_data['sheets']:
                    raise FileServiceError(f"Sheet '{sheet_name}' not found")
                
                sheet_info = file_data['sheets'][sheet_name]
                df = sheet_info['dataframe']
                
                context += f"Sheet: {sheet_name}\n"
                context += f"Rows: {sheet_info['total_rows']}, Columns: {sheet_info['total_columns']}\n"
                context += f"Columns: {', '.join(sheet_info['columns'])}\n"
                context += "-" * 60 + "\n"
                context += df.head(10).to_string()
            
            else:
                # Include all sheets summary
                for sheet_name, sheet_info in file_data['sheets'].items():
                    df = sheet_info['dataframe']
                    context += f"Sheet: {sheet_name}\n"
                    context += f"Rows: {sheet_info['total_rows']}, Columns: {sheet_info['total_columns']}\n"
                    context += f"Columns: {', '.join(sheet_info['columns'])}\n"
                    context += "-" * 60 + "\n"
                    context += df.head(5).to_string() + "\n\n"
            
            return context[:max_length]
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error converting to context: {e}")
            raise FileServiceError(f"Failed to convert to context: {str(e)}")
    
    def get_sheet_statistics(self, filepath: str, sheet_name: str) -> Dict[str, Any]:
        """Get statistics for a specific sheet"""
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            if sheet_name not in file_data['sheets']:
                raise FileServiceError(f"Sheet '{sheet_name}' not found")
            
            sheet_info = file_data['sheets'][sheet_name]
            df = sheet_info['dataframe']
            
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            stats = {}
            
            for col in numeric_cols:
                stats[col] = {
                    'min': float(df[col].min()),
                    'max': float(df[col].max()),
                    'mean': float(df[col].mean()),
                    'sum': float(df[col].sum()),
                    'count': int(df[col].count())
                }
            
            return {
                'sheet': sheet_name,
                'rows': len(df),
                'columns': list(df.columns),
                'column_count': len(df.columns),
                'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                'statistics': stats,
                'preview': df.to_dict(orient='records'),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting statistics: {e}")
            raise FileServiceError(f"Failed to get statistics: {str(e)}")
    
    def get_column_info(self, filepath: str, sheet_name: str, column_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific column"""
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            if sheet_name not in file_data['sheets']:
                raise FileServiceError(f"Sheet '{sheet_name}' not found")
            
            df = file_data['sheets'][sheet_name]['dataframe']
            
            if column_name not in df.columns:
                raise FileServiceError(f"Column '{column_name}' not found")
            
            col_data = df[column_name]
            
            info = {
                'column': column_name,
                'dtype': str(col_data.dtype),
                'total_values': len(col_data),
                'non_null_count': col_data.count(),
                'null_count': col_data.isna().sum(),
                'unique_count': col_data.nunique(),
                'unique_values': col_data.unique()[:10].tolist()
            }
            
            # Add numeric statistics if applicable
            if col_data.dtype in ['int64', 'float64']:
                info['statistics'] = {
                    'min': float(col_data.min()),
                    'max': float(col_data.max()),
                    'mean': float(col_data.mean()),
                    'median': float(col_data.median()),
                    'std': float(col_data.std())
                }
            
            return info
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting column info: {e}")
            raise FileServiceError(f"Failed to get column info: {str(e)}")
    
    def clear_loaded_files(self, filepath: Optional[str] = None):
        """
        Clear loaded files from memory
        
        Args:
            filepath: Specific file to clear (optional, clears all if None)
        """
        try:
            if filepath:
                if filepath in self.loaded_files:
                    del self.loaded_files[filepath]
                    logger.info(f"✓ Cleared file: {filepath}")
            else:
                self.loaded_files.clear()
                self.current_file = None
                self.current_sheets = {}
                logger.info("✓ Cleared all loaded files")
        except Exception as e:
            logger.error(f"✗ Error clearing files: {e}")
            raise FileServiceError(f"Failed to clear files: {str(e)}")
    
    def validate_file(self, filepath: str) -> Dict[str, Any]:
        """Validate file integrity and structure"""
        try:
            if not os.path.exists(filepath):
                raise FileServiceError(f"File not found: {filepath}")
            
            file_size = os.path.getsize(filepath)
            if file_size == 0:
                raise FileServiceError("File is empty")
            
            # Try to load the file
            if filepath.endswith('.csv'):
                df = pd.read_csv(filepath)
            else:
                df = pd.read_excel(filepath)
            
            return {
                'valid': True,
                'file_size': file_size,
                'rows': len(df),
                'columns': len(df.columns),
                'can_parse': True
            }
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ File validation error: {e}")
            raise FileServiceError(f"File validation failed: {str(e)}")
    
    def export_sheet_to_csv(self, filepath: str, sheet_name: str, output_path: str):
        """Export a sheet to CSV"""
        try:
            if filepath not in self.loaded_files:
                if filepath.endswith('.csv'):
                    self.load_csv(filepath)
                else:
                    self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            if sheet_name not in file_data['sheets']:
                raise FileServiceError(f"Sheet '{sheet_name}' not found")
            
            df = file_data['sheets'][sheet_name]['dataframe']
            df.to_csv(output_path, index=False)
            
            logger.info(f"✓ Exported sheet to CSV: {output_path}")
            return {
                'success': True,
                'output_path': output_path,
                'rows_exported': len(df)
            }
        
        except FileServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Export error: {e}")
            raise FileServiceError(f"Failed to export sheet: {str(e)}")