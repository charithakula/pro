"""
Local Embedding Service - Generate embeddings without Azure API
Uses sentence-transformers for fast, free, offline embedding generation
Perfect for pgvector storage in PostgreSQL
"""

import logging
from typing import List, Union
import numpy as np

logger = logging.getLogger(__name__)


class LocalEmbeddingService:
    """
    Generate embeddings locally using sentence-transformers
    No Azure API calls needed - works completely offline
    Perfect with PostgreSQL pgvector extension
    """
    
    def __init__(self, model_name: str = 'all-MiniLM-L6-v2'):
        """
        Initialize local embedding model
        
        Args:
            model_name: HuggingFace model identifier
                       Default: all-MiniLM-L6-v2 (fast, 384 dims)
                       
        Available models:
        - all-MiniLM-L6-v2: Fast, small, good quality (384 dims) ← RECOMMENDED
        - all-MiniLM-L12-v2: Better quality, slightly slower (384 dims)
        - all-mpnet-base-v2: High quality, slower (768 dims)
        - multi-qa-mpnet-base-dot-v1: Great for search (768 dims)
        """
        try:
            from sentence_transformers import SentenceTransformer
            
            logger.info(f"🔄 Loading local embedding model: {model_name}")
            logger.info("   (First load will download ~90MB - this is normal)")
            
            self.model = SentenceTransformer(model_name)
            self.model_name = model_name
            
            # Get embedding dimension
            dummy_embedding = self.model.encode("test")
            self.embedding_dim = len(dummy_embedding)
            
            logger.info(f"✅ Local embedding model loaded successfully")
            logger.info(f"   Model: {model_name}")
            logger.info(f"   Embedding dimension: {self.embedding_dim}")
            logger.info(f"   Ready for pgvector storage")
            
        except ImportError:
            logger.error("❌ sentence-transformers not installed")
            logger.error("   Install with: pip install sentence-transformers")
            raise
        except Exception as e:
            logger.error(f"❌ Failed to load embedding model: {e}")
            logger.error("   Check model name is valid HuggingFace model")
            raise
    
    
    def generate_embeddings(self, texts: Union[str, List[str]]) -> np.ndarray:
        """
        Generate embeddings for one or more texts
        
        Args:
            texts: Single text string or list of strings
        
        Returns:
            numpy array of embeddings
            Shape: (n_texts, embedding_dim) for multiple texts
            Shape: (embedding_dim,) for single text
        
        Examples:
            # Single text
            embedding = service.generate_embeddings("Hello world")
            # Shape: (384,)
            
            # Multiple texts
            embeddings = service.generate_embeddings(["Text 1", "Text 2"])
            # Shape: (2, 384)
        """
        try:
            # Handle single string
            if isinstance(texts, str):
                texts = [texts]
                single_text = True
            else:
                single_text = False
            
            # Validate input
            if not texts:
                raise ValueError("texts cannot be empty")
            
            if not isinstance(texts, list):
                texts = list(texts)
            
            logger.debug(f"Generating embeddings for {len(texts)} texts")
            
            # Generate embeddings
            embeddings = self.model.encode(texts, convert_to_numpy=True)
            
            # Return single embedding if input was string
            if single_text:
                return embeddings[0]
            
            return embeddings
        
        except Exception as e:
            logger.error(f"❌ Embedding generation failed: {e}")
            raise
    
    
    def generate_embedding(self, text: str) -> List[float]:
        """
        Generate single embedding and return as list (for pgvector)
        
        Args:
            text: Text to embed
        
        Returns:
            List of floats (compatible with pgvector)
        
        Example:
            embedding = service.generate_embedding("API documentation")
            # Returns: [0.123, -0.456, 0.789, ...]
            # Length: 384 (or whatever embedding_dim)
        """
        try:
            if not isinstance(text, str) or not text.strip():
                raise ValueError("text must be non-empty string")
            
            embedding = self.generate_embeddings(text)
            
            # Convert numpy array to list for database storage
            return embedding.tolist()
        
        except Exception as e:
            logger.error(f"❌ Single embedding generation failed: {e}")
            raise
    
    
    def similarity_score(self, embedding1: List[float], embedding2: List[float]) -> float:
        """
        Calculate cosine similarity between two embeddings
        
        Args:
            embedding1: First embedding (list of floats)
            embedding2: Second embedding (list of floats)
        
        Returns:
            Similarity score (0 to 1, higher = more similar)
        
        Note:
            PostgreSQL pgvector uses <-> operator for distance (1 - similarity)
            This function returns raw similarity for reference only
        """
        try:
            from sklearn.metrics.pairwise import cosine_similarity
            
            e1 = np.array(embedding1).reshape(1, -1)
            e2 = np.array(embedding2).reshape(1, -1)
            
            similarity = cosine_similarity(e1, e2)[0][0]
            return float(similarity)
        
        except ImportError:
            logger.warning("sklearn not available for similarity calculation")
            return None
        except Exception as e:
            logger.error(f"Similarity calculation failed: {e}")
            return None
    
    
    def batch_generate_embeddings(
        self, 
        texts: List[str], 
        batch_size: int = 32
    ) -> List[List[float]]:
        """
        Generate embeddings for many texts efficiently (batched)
        
        Args:
            texts: List of texts to embed
            batch_size: Process this many texts at once (default: 32)
        
        Returns:
            List of embeddings (each is list of floats)
        
        Benefits:
            - More memory efficient for large datasets
            - Faster than generating one at a time
            - Shows progress logging
        
        Example:
            texts = ["API 1 docs", "API 2 docs", "API 3 docs", ...]
            embeddings = service.batch_generate_embeddings(texts, batch_size=16)
        """
        try:
            if not texts:
                raise ValueError("texts cannot be empty")
            
            logger.info(f"Batch generating embeddings for {len(texts)} texts")
            
            all_embeddings = []
            
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i+batch_size]
                logger.debug(f"  Processing batch {i//batch_size + 1} ({len(batch)} texts)")
                
                embeddings = self.generate_embeddings(batch)
                
                # Convert to list format
                for emb in embeddings:
                    all_embeddings.append(emb.tolist())
            
            logger.info(f"✅ Generated {len(all_embeddings)} embeddings")
            return all_embeddings
        
        except Exception as e:
            logger.error(f"❌ Batch embedding generation failed: {e}")
            raise
    
    
    def get_embedding_info(self) -> dict:
        """Get information about loaded model"""
        return {
            'model_name': self.model_name,
            'embedding_dimension': self.embedding_dim,
            'vector_storage': 'pgvector compatible',
            'deployment': 'local (no API calls)',
            'speed': 'instant',
            'cost': 'free'
        }


def get_embedding_service(model_name: str = 'all-MiniLM-L6-v2') -> LocalEmbeddingService:
    """
    Factory function to get embedding service
    
    Args:
        model_name: Which model to use (default: all-MiniLM-L6-v2)
    
    Returns:
        LocalEmbeddingService instance
    
    Example:
        service = get_embedding_service()
        embedding = service.generate_embedding("some text")
    """
    try:
        return LocalEmbeddingService(model_name=model_name)
    except Exception as e:
        logger.error(f"❌ Failed to initialize embedding service: {e}")
        return None