"""
Chat Service Layer
Handles all business logic for chat operations
Separates service logic from route handlers
"""

import os
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
import pandas as pd
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class ChatServiceError(Exception):
    """Custom exception for chat service errors"""
    pass


class ExcelDataService:
    """Service for handling Excel file operations"""
    
    def __init__(self):
        self.loaded_files = {}
        self.current_file = None
        self.current_sheets = {}
    
    def load_file(self, filepath: str) -> Dict[str, Any]:
        """
        Load Excel file and extract metadata
        
        Args:
            filepath: Path to Excel file
            
        Returns:
            Dictionary with file metadata and sheet information
        """
        try:
            excel_file = pd.ExcelFile(filepath)
            
            sheets_data = {
                'filename': os.path.basename(filepath),
                'filepath': filepath,
                'sheets': {},
                'sheet_names': excel_file.sheet_names,
                'total_sheets': len(excel_file.sheet_names),
                'loaded_at': datetime.utcnow().isoformat()
            }
            
            # Load each sheet
            for sheet_name in excel_file.sheet_names:
                df = pd.read_excel(filepath, sheet_name=sheet_name)
                
                sheets_data['sheets'][sheet_name] = {
                    'dataframe': df,
                    'columns': list(df.columns),
                    'total_columns': len(df.columns),
                    'total_rows': len(df),
                    'dtypes': df.dtypes.to_dict(),
                    'preview': df.head(5).to_dict(orient='records')
                }
            
            self.loaded_files[filepath] = sheets_data
            self.current_file = filepath
            self.current_sheets = sheets_data['sheets']
            
            logger.info(f"✓ Loaded Excel file with {len(excel_file.sheet_names)} sheets")
            return sheets_data
        
        except Exception as e:
            logger.error(f"✗ Error loading Excel file: {e}")
            raise ChatServiceError(f"Failed to load Excel file: {str(e)}")
    
    def get_file_summary(self, filepath: str) -> Dict[str, Any]:
        """Get summary of loaded Excel file"""
        try:
            if filepath not in self.loaded_files:
                self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            
            return {
                'filename': file_data['filename'],
                'sheets': [
                    {
                        'name': sheet_name,
                        'rows': sheet_info['total_rows'],
                        'columns': sheet_info['columns'],
                        'column_count': sheet_info['total_columns']
                    }
                    for sheet_name, sheet_info in file_data['sheets'].items()
                ]
            }
        
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting file summary: {e}")
            raise ChatServiceError(f"Failed to get file summary: {str(e)}")
    
    def search_across_sheets(self, filepath: str, query: str) -> Dict[str, Any]:
        """Search for data across all sheets"""
        try:
            if filepath not in self.loaded_files:
                self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            results = {
                'query': query,
                'matches': {}
            }
            
            query_lower = query.lower()
            
            for sheet_name, sheet_info in file_data['sheets'].items():
                df = sheet_info['dataframe']
                matching_rows = []
                
                # Search in column names
                matching_columns = [col for col in df.columns if query_lower in col.lower()]
                
                # Search in cell values
                for col in df.columns:
                    if df[col].dtype == 'object':
                        mask = df[col].astype(str).str.lower().str.contains(query_lower, na=False)
                        if mask.any():
                            matching_rows.extend(df[mask].to_dict(orient='records'))
                
                if matching_columns or matching_rows:
                    results['matches'][sheet_name] = {
                        'matching_columns': matching_columns,
                        'matching_rows_count': len(matching_rows),
                        'sample_rows': matching_rows[:3]
                    }
            
            return results
        
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error searching sheets: {e}")
            raise ChatServiceError(f"Failed to search sheets: {str(e)}")
    
    def convert_to_context(self, filepath: str, sheet_name: Optional[str] = None, max_length: int = 4000) -> str:
        """
        Convert Excel sheets to formatted text for LLM context
        
        Args:
            filepath: Path to Excel file
            sheet_name: Specific sheet to convert (optional)
            max_length: Maximum context length in characters
            
        Returns:
            Formatted text context
        """
        try:
            if filepath not in self.loaded_files:
                self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            context = f"File: {file_data['filename']}\n"
            context += f"Total Sheets: {file_data['total_sheets']}\n"
            context += "=" * 60 + "\n\n"
            
            if sheet_name:
                if sheet_name not in file_data['sheets']:
                    raise ChatServiceError(f"Sheet '{sheet_name}' not found")
                
                sheet_info = file_data['sheets'][sheet_name]
                df = sheet_info['dataframe']
                
                context += f"Sheet: {sheet_name}\n"
                context += f"Rows: {sheet_info['total_rows']}, Columns: {sheet_info['total_columns']}\n"
                context += f"Columns: {', '.join(sheet_info['columns'])}\n"
                context += "-" * 60 + "\n"
                context += df.head(10).to_string()
            
            else:
                # Include all sheets summary
                for sheet_name, sheet_info in file_data['sheets'].items():
                    df = sheet_info['dataframe']
                    context += f"Sheet: {sheet_name}\n"
                    context += f"Rows: {sheet_info['total_rows']}, Columns: {sheet_info['total_columns']}\n"
                    context += f"Columns: {', '.join(sheet_info['columns'])}\n"
                    context += "-" * 60 + "\n"
                    context += df.head(5).to_string() + "\n\n"
            
            return context[:max_length]
        
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error converting to context: {e}")
            raise ChatServiceError(f"Failed to convert to context: {str(e)}")
    
    def get_sheet_statistics(self, filepath: str, sheet_name: str) -> Dict[str, Any]:
        """Get statistics for a specific sheet"""
        try:
            if filepath not in self.loaded_files:
                self.load_file(filepath)
            
            file_data = self.loaded_files[filepath]
            if sheet_name not in file_data['sheets']:
                raise ChatServiceError(f"Sheet '{sheet_name}' not found")
            
            sheet_info = file_data['sheets'][sheet_name]
            df = sheet_info['dataframe']
            
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            stats = {}
            
            for col in numeric_cols:
                stats[col] = {
                    'min': float(df[col].min()),
                    'max': float(df[col].max()),
                    'mean': float(df[col].mean()),
                    'sum': float(df[col].sum())
                }
            
            return {
                'sheet': sheet_name,
                'rows': len(df),
                'columns': list(df.columns),
                'column_count': len(df.columns),
                'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                'statistics': stats,
                'preview': df.to_dict(orient='records')
            }
        
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting statistics: {e}")
            raise ChatServiceError(f"Failed to get statistics: {str(e)}")


class LLMService:
    """Service for Azure OpenAI LLM interactions"""
    
    def __init__(self, config=None):
        """
        Initialize LLM service
        
        Args:
            config: Configuration object with Azure OpenAI settings
        """
        self.config = config
        self.client = None
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Azure OpenAI client"""
        try:
            if self.config and hasattr(self.config, 'AZURE_OPENAI_ENDPOINT'):
                self.client = AzureOpenAI(
                    api_version=self.config.AZURE_OPENAI_API_VERSION,
                    azure_endpoint=self.config.AZURE_OPENAI_ENDPOINT,
                    api_key=self.config.AZURE_OPENAI_KEY
                )
            else:
                self.client = AzureOpenAI(
                    api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
                    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
                    api_key=os.getenv("AZURE_OPENAI_KEY")
                )
            logger.info("✓ Azure OpenAI client initialized")
        
        except Exception as e:
            logger.error(f"✗ Failed to initialize Azure OpenAI client: {e}")
            self.client = None
    
    def get_response(self, query: str, context: str, data_source: str = "Excel") -> str:
        """
        Get LLM response with context
        
        Args:
            query: User question
            context: Data context for the question
            data_source: Source of data (Excel, SharePoint, etc)
            
        Returns:
            LLM response text
        """
        if not self.client:
            raise ChatServiceError("Azure OpenAI client not initialized")
        
        system_message = f"""You are an intelligent data analyst assistant with access to {data_source} data.
Your role is to:
1. Analyze the provided data carefully
2. Answer questions based on the actual data
3. Provide specific values, calculations, and insights
4. Be accurate and cite data when relevant
5. Handle multiple sheets/documents if applicable
6. Format responses clearly

When analyzing data:
- Consider all available sheets/columns
- Provide aggregations when relevant
- Show calculations step-by-step
- Highlight important patterns or anomalies"""

        user_message = f"""Data Source: {data_source}

{context}

User Question: {query}

Please provide a detailed answer based on the data provided above."""

        try:
            deployment_name = self.config.AZURE_OPENAI_DEPLOYMENT_NAME if self.config else os.getenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4")
            
            response = self.client.chat.completions.create(
                model=deployment_name,
                messages=[
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": user_message}
                ],
                temperature=0.7,
                max_tokens=1500,
                top_p=0.95,
            )
            
            return response.choices[0].message.content
        
        except Exception as e:
            logger.error(f"✗ LLM Error: {e}")
            raise ChatServiceError(f"Failed to get LLM response: {str(e)}")
    
    def health_check(self) -> Dict[str, Any]:
        """Check LLM service health"""
        return {
            'status': 'healthy' if self.client else 'unavailable',
            'timestamp': datetime.utcnow().isoformat()
        }


class SharePointService:
    """Service for SharePoint document operations"""
    
    def __init__(self, connector=None):
        """
        Initialize SharePoint service
        
        Args:
            connector: SharePoint connector instance
        """
        self.connector = connector
    
    def is_available(self) -> bool:
        """Check if SharePoint is available"""
        return self.connector is not None
    
    def get_libraries(self) -> Dict[str, Any]:
        """Get available SharePoint libraries"""
        if not self.is_available():
            raise ChatServiceError("SharePoint connector not available")
        
        try:
            result = self.connector.get_document_libraries()
            return {
                'available': True,
                'libraries': result.get('libraries', [])
            }
        except Exception as e:
            logger.error(f"✗ Error getting libraries: {e}")
            raise ChatServiceError(f"Failed to get SharePoint libraries: {str(e)}")
    
    def get_documents(self, library: str) -> Dict[str, Any]:
        """Get documents from a library"""
        if not self.is_available():
            raise ChatServiceError("SharePoint connector not available")
        
        try:
            return self.connector.get_documents(library)
        except Exception as e:
            logger.error(f"✗ Error getting documents: {e}")
            raise ChatServiceError(f"Failed to get documents: {str(e)}")
    
    def search_documents(self, library: str, search_term: str) -> Dict[str, Any]:
        """Search documents in a library"""
        if not self.is_available():
            raise ChatServiceError("SharePoint connector not available")
        
        try:
            return self.connector.search_documents(library, search_term)
        except Exception as e:
            logger.error(f"✗ Error searching documents: {e}")
            raise ChatServiceError(f"Failed to search documents: {str(e)}")


class ChatService:
    """Main chat service orchestrating all operations"""
    
    def __init__(self, config=None, sharepoint_connector=None):
        """
        Initialize chat service
        
        Args:
            config: Configuration object
            sharepoint_connector: SharePoint connector instance
        """
        self.config = config
        self.excel_service = ExcelDataService()
        self.llm_service = LLMService(config)
        self.sharepoint_service = SharePointService(sharepoint_connector)
    
    def upload_file(self, filepath: str) -> Dict[str, Any]:
        """
        Upload and process a file
        
        Args:
            filepath: Path to uploaded file
            
        Returns:
            File information dictionary
        """
        try:
            file_info = self.excel_service.load_file(filepath)
            logger.info(f"✓ File uploaded successfully: {os.path.basename(filepath)}")
            return file_info
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Upload error: {e}")
            raise ChatServiceError(f"Failed to upload file: {str(e)}")
    
    def send_message(self, query: str, data_source_type: str, excel_file: Optional[str] = None, 
                    sheet_name: Optional[str] = None, sharepoint_library: Optional[str] = None) -> Dict[str, Any]:
        """
        Process user message and return LLM response
        
        Args:
            query: User question
            data_source_type: 'excel' or 'sharepoint'
            excel_file: Path to Excel file (if using Excel)
            sheet_name: Specific sheet to analyze (optional)
            sharepoint_library: SharePoint library name (if using SharePoint)
            
        Returns:
            Dictionary with response and metadata
        """
        try:
            context = ""
            source_info = ""
            data_source = ""
            
            if data_source_type == 'excel':
                if not excel_file:
                    raise ChatServiceError("No Excel file specified")
                
                context = self.excel_service.convert_to_context(excel_file, sheet_name)
                source_info = f"Excel: {os.path.basename(excel_file)}"
                if sheet_name:
                    source_info += f" (Sheet: {sheet_name})"
                data_source = "Excel"
            
            elif data_source_type == 'sharepoint':
                if not self.sharepoint_service.is_available():
                    raise ChatServiceError("SharePoint not configured")
                
                context = f"SharePoint Library: {sharepoint_library}\n"
                context += "Document metadata available for analysis"
                source_info = f"SharePoint: {sharepoint_library}"
                data_source = "SharePoint"
            
            else:
                raise ChatServiceError(f"Invalid data source type: {data_source_type}")
            
            # Get LLM response
            response = self.llm_service.get_response(query, context, data_source)
            
            return {
                'success': True,
                'response': response,
                'timestamp': datetime.utcnow().strftime('%H:%M:%S'),
                'data_source': source_info,
                'data_source_type': data_source_type
            }
        
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error processing message: {e}")
            raise ChatServiceError(f"Failed to process message: {str(e)}")
    
    def get_file_info(self, filepath: str) -> Dict[str, Any]:
        """Get information about a file"""
        try:
            return self.excel_service.get_file_summary(filepath)
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting file info: {e}")
            raise ChatServiceError(f"Failed to get file info: {str(e)}")
    
    def search_data(self, filepath: str, search_term: str) -> Dict[str, Any]:
        """Search across sheets"""
        try:
            return self.excel_service.search_across_sheets(filepath, search_term)
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error searching data: {e}")
            raise ChatServiceError(f"Failed to search data: {str(e)}")
    
    def get_sheet_details(self, filepath: str, sheet_name: str) -> Dict[str, Any]:
        """Get details about a specific sheet"""
        try:
            return self.excel_service.get_sheet_statistics(filepath, sheet_name)
        except ChatServiceError:
            raise
        except Exception as e:
            logger.error(f"✗ Error getting sheet details: {e}")
            raise ChatServiceError(f"Failed to get sheet details: {str(e)}")