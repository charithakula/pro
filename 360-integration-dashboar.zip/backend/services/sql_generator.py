"""
SQL Generator Service
Converts natural language questions to SQL queries using Azure OpenAI
"""

import logging
import json
from typing import Dict, List, Optional, Any
from openai import AzureOpenAI

logger = logging.getLogger(__name__)


class SQLGeneratorError(Exception):
    """Custom exception for SQL generator errors"""
    pass


class SQLGenerator:
    """
    Generates SQL queries from natural language using LLM
    """
    
    def __init__(self, openai_client: AzureOpenAI, config=None):
        self.client = openai_client
        self.config = config
        self.schema_context = self._build_schema_context()
    
    def _build_schema_context(self) -> str:
        """Build comprehensive schema context for SQL generation"""
        return """
DATABASE SCHEMA:
Table: integration_interfaces

Columns:
- id (INTEGER): Primary key, auto-increment
- interface_platform (TEXT): Platform like 'SAP CPI', 'Azure APIM', 'IBM API Connect', 'MuleSoft', 'Dell Boomi', 'Informatica', 'Azure Logic Apps'
- interface_id (TEXT): Unique interface identifier (e.g., 'INT-1001')
- sub_interface (TEXT): Sub-interface identifier (e.g., 'SUB-INT-001')
- interface_name (TEXT): API/Interface name (e.g., 'CustomerDataAPI', 'OrderAPI')
- operation_name (TEXT): Operation name (e.g., 'getCustomerDetails', 'getOrderDetails')
- api_product_name (TEXT): API Product name
- interface_description (TEXT): Description of the interface
- dependency_id (TEXT): Dependency identifier
- process_area (TEXT): Business area - 'Finance', 'HR', 'Sales', 'Supply Chain', 'Customer Service', 'IT Operations', 'Marketing'
- interface_pattern (TEXT): Pattern like 'Request-Response', 'Fire and Forget', 'Publish-Subscribe', 'Request-Reply', 'One-Way', 'Batch Processing'
- source_ci_type (TEXT): Source component type - 'Application', 'Database', 'File System', 'Message Queue', 'API Gateway', 'Web Service'
- source_name (TEXT): Source system name
- target_ci_type (TEXT): Target component type
- target_name (TEXT): Target system name
- communication_mode (TEXT): 'Synchronous' or 'Asynchronous'
- volume (TEXT): Message volume (e.g., '100 msgs/day', '5000 msgs/day')
- frequency (TEXT): 'Real-time', 'Hourly', 'Daily', 'Weekly', 'Monthly', 'On-Demand'
- schedule (TEXT): Scheduled time (e.g., '14:00', 'N/A')
- interface_resolver_group (TEXT): Resolver team
- qos (TEXT): Quality of Service - 'Best Effort', 'Guaranteed', 'At Least Once', 'Exactly Once'
- source_service_url (TEXT): Source endpoint URL
- target_service_url (TEXT): Target endpoint URL
- source_protocol (TEXT): Source protocol - 'HTTPS', 'REST', 'SOAP', 'SFTP', 'JDBC', 'AMQP', 'HTTP'
- source_data_format (TEXT): Source format - 'JSON', 'XML', 'CSV', 'Parquet', 'Avro', 'Plain Text'
- source_trust_level (TEXT): 'Public', 'Internal', 'Confidential', 'Restricted'
- target_protocol (TEXT): Target connectivity protocol
- target_data_format (TEXT): Target data format
- target_trust_level (TEXT): Target trust level
- retention_period (TEXT): Data retention (e.g., '30 days', '90 days')
- source_resolver_contact (TEXT): Source team contact email
- target_resolver_contact (TEXT): Target team contact email
- priority (TEXT): 'High', 'Medium', 'Low'
- status (TEXT): 'Active', 'Inactive', 'In Development', 'Retired', 'Testing'
- source_intermediary (TEXT): Source intermediary system
- target_intermediary (TEXT): Target intermediary system
- project_name (TEXT): Project name
- production_migration_date (DATE): Migration date
- pid_wo (TEXT): Work order number
- reuse_status (TEXT): 'Reusable', 'Non-Reusable', 'Partially Reusable'
- integration_pattern (TEXT): Integration pattern (same as interface_pattern)
- interface_mode (TEXT): 'Real-time', 'Batch', 'Near Real-time', 'Scheduled'
- ou (TEXT): Organizational unit
- comments (TEXT): Additional comments
- interface_build_type (TEXT): 'New', 'Enhancement', 'Migration', 'Replatform'
- created_at (TIMESTAMP): Record creation timestamp

IMPORTANT SQL RULES:
1. Always use SELECT queries only (no INSERT, UPDATE, DELETE)
2. Use aggregate functions for counting: COUNT(*), COUNT(DISTINCT column)
3. Use GROUP BY when aggregating by dimensions
4. Use WHERE for filtering
5. Use ORDER BY for sorting
6. Column names with spaces are wrapped in double quotes (not single quotes)
7. String values in WHERE clauses use single quotes
8. For LIKE searches, use ILIKE for case-insensitive matching
9. Common aggregations: COUNT(*), SUM(), AVG(), MIN(), MAX()
10. Join patterns not needed (single table)
"""
    
    def generate_sql(self, user_question: str, context_data: Optional[List[Dict]] = None) -> str:
        """
        Generate SQL query from natural language question
        
        Args:
            user_question: The user's question
            context_data: Optional context from vector search
            
        Returns:
            SQL query string
        """
        
        try:
            # Build context from vector search results
            context_text = ""
            if context_data:
                context_text = "\n\nRELEVANT DATA EXAMPLES:\n"
                for i, item in enumerate(context_data[:3], 1):
                    context_text += f"Example {i}: {json.dumps(item, indent=2)}\n"
            
            prompt = f"""{self.schema_context}
{context_text}

USER QUESTION: {user_question}

Generate a PostgreSQL query that answers this question.

REQUIREMENTS:
1. Return ONLY the SQL query, no explanations
2. Use proper SQL syntax for PostgreSQL
3. Include appropriate WHERE, GROUP BY, ORDER BY, and LIMIT clauses
4. For aggregations, use COUNT, SUM, AVG as needed
5. Ensure column names match the schema exactly
6. Use ILIKE for case-insensitive text searches
7. Add LIMIT clause for large result sets (default LIMIT 100)

SQL QUERY:
"""
            
            deployment = self.config.AZURE_OPENAI_DEPLOYMENT if self.config else "gpt-4"
            
            response = self.client.chat.completions.create(
                model=deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a SQL expert specializing in PostgreSQL. Generate only valid SQL queries."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,
                max_tokens=500
            )
            
            sql_query = response.choices[0].message.content.strip()
            
            # Clean up the query
            sql_query = sql_query.replace("```sql", "").replace("```", "").strip()
            
            # Remove any explanatory text before or after
            if ";" in sql_query:
                sql_query = sql_query.split(";")[0] + ";"
            
            logger.info(f"✅ Generated SQL Query:\n{sql_query}")
            
            return sql_query
            
        except Exception as e:
            logger.error(f"❌ SQL Generation Error: {e}")
            raise SQLGeneratorError(f"Failed to generate SQL: {str(e)}")
    
    def fix_sql_query(self, sql_query: str, error_message: str) -> str:
        """
        Attempt to fix a broken SQL query based on error message
        
        Args:
            sql_query: The broken SQL query
            error_message: The error message from database
            
        Returns:
            Fixed SQL query
        """
        
        try:
            prompt = f"""The following SQL query produced an error:

SQL QUERY:
{sql_query}

ERROR MESSAGE:
{error_message}

SCHEMA REFERENCE:
{self.schema_context}

Please fix the SQL query to resolve the error. Return ONLY the corrected SQL query.

CORRECTED SQL QUERY:
"""
            
            deployment = self.config.AZURE_OPENAI_DEPLOYMENT if self.config else "gpt-4"
            
            response = self.client.chat.completions.create(
                model=deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a SQL debugging expert. Fix broken SQL queries."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,
                max_tokens=500
            )
            
            fixed_query = response.choices[0].message.content.strip()
            fixed_query = fixed_query.replace("```sql", "").replace("```", "").strip()
            
            logger.info(f"🔧 Fixed SQL Query:\n{fixed_query}")
            
            return fixed_query
            
        except Exception as e:
            logger.error(f"❌ SQL Fix Error: {e}")
            raise SQLGeneratorError(f"Failed to fix SQL: {str(e)}")
    
    def generate_aggregate_query(self, user_question: str) -> str:
        """
        Generate aggregate/summary SQL query for hybrid analysis
        
        Args:
            user_question: The user's question
            
        Returns:
            SQL query focused on aggregates
        """
        
        try:
            prompt = f"""{self.schema_context}

USER QUESTION: {user_question}

Generate a PostgreSQL aggregate query that provides summary statistics relevant to this question.

Focus on:
1. COUNT by key dimensions (platform, process_area, status, priority, etc.)
2. Distribution analysis
3. Summary metrics

Return ONLY the SQL query.

AGGREGATE SQL QUERY:
"""
            
            deployment = self.config.AZURE_OPENAI_DEPLOYMENT if self.config else "gpt-4"
            
            response = self.client.chat.completions.create(
                model=deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a SQL expert specializing in aggregate queries."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,
                max_tokens=400
            )
            
            sql_query = response.choices[0].message.content.strip()
            sql_query = sql_query.replace("```sql", "").replace("```", "").strip()
            
            logger.info(f"📊 Generated Aggregate Query:\n{sql_query}")
            
            return sql_query
            
        except Exception as e:
            logger.error(f"❌ Aggregate Query Generation Error: {e}")
            raise SQLGeneratorError(f"Failed to generate aggregate query: {str(e)}")