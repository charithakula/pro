"""
Services Package - Hybrid RAG System v2.0

This package contains all business logic and service layer classes.
Services handle the core functionality separate from HTTP routes.

CRITICAL: This version does NOT raise on missing optional modules!
All imports are graceful - if a module doesn't exist, we log a warning and continue.
"""

import logging

logger = logging.getLogger(__name__)

print("\n" + "="*80)
print("INITIALIZING SERVICES PACKAGE v2.0 (Hybrid RAG)")
print("="*80 + "\n")

# ============================================================================
# HYBRID RAG SERVICES (PRIMARY - Must succeed!)
# ============================================================================

# Database module
try:
    from .database import (
        get_db_connection,
        get_db_session,
        init_db,
        clear_db,
        check_db_health
    )
    print("✓ Database module loaded")
    DATABASE_AVAILABLE = True
except ImportError as e:
    print(f"⚠ Database module not found: {e}")
    DATABASE_AVAILABLE = False
    get_db_connection = None
    get_db_session = None
    init_db = None
    clear_db = None
    check_db_health = None

# HybridRAGService
try:
    from .hybrid_rag_service import HybridRAGService
    print("✓ HybridRAGService loaded")
    HYBRID_RAG_AVAILABLE = True
except ImportError as e:
    print(f"⚠ HybridRAGService not found: {e}")
    HYBRID_RAG_AVAILABLE = False
    HybridRAGService = None

# DataImportService
try:
    from .data_import_service import DataImportService, DataImportError
    print("✓ DataImportService loaded")
    DATA_IMPORT_AVAILABLE = True
except ImportError as e:
    print(f"⚠ DataImportService not found: {e}")
    DATA_IMPORT_AVAILABLE = False
    DataImportService = None
    DataImportError = Exception

# QueryRouter
try:
    from .query_router import QueryRouter
    print("✓ QueryRouter loaded")
except ImportError as e:
    print(f"⚠ QueryRouter not found: {e}")
    QueryRouter = None

# SQLGenerator
try:
    from .sql_generator import SQLGenerator
    print("✓ SQLGenerator loaded")
except ImportError as e:
    print(f"⚠ SQLGenerator not found: {e}")
    SQLGenerator = None

# VectorSearch
try:
    from .vector_search import VectorSearch
    print("✓ VectorSearch loaded")
except ImportError as e:
    print(f"⚠ VectorSearch not found: {e}")
    VectorSearch = None

# Query Processors
try:
    from .query_processors import (
        DirectLLMProcessor,
        SQLFirstProcessor,
        HybridProcessor
    )
    print("✓ Query processors loaded")
except ImportError as e:
    print(f"⚠ Query processors not found: {e}")
    DirectLLMProcessor = None
    SQLFirstProcessor = None
    HybridProcessor = None

# ============================================================================
# LEGACY SERVICES (OPTIONAL - Graceful failure only!)
# ============================================================================

# FileService - OPTIONAL - DO NOT RAISE!
try:
    from .file_service import (
        ExcelDataService,
        FileServiceError
    )
    print("✓ FileService loaded")
    FILE_SERVICE_AVAILABLE = True
except ImportError as e:
    print(f"⚠ FileService optional module not found: {e}")
    FILE_SERVICE_AVAILABLE = False
    ExcelDataService = None
    FileServiceError = Exception

# ChatService - OPTIONAL - DO NOT RAISE!
try:
    from .chat_service import (
        ChatService,
        LLMService,
        SharePointService,
        ChatServiceError
    )
    print("✓ ChatService loaded")
    CHAT_SERVICE_AVAILABLE = True
except ImportError as e:
    print(f"⚠ ChatService optional module not found: {e}")
    CHAT_SERVICE_AVAILABLE = False
    ChatService = None
    LLMService = None
    SharePointService = None
    ChatServiceError = Exception

# ============================================================================
# PUBLIC API
# ============================================================================

__all__ = [
    # Database
    'get_db_connection',
    'get_db_session',
    'init_db',
    'clear_db',
    'check_db_health',
    'DATABASE_AVAILABLE',
    
    # Hybrid RAG Services
    'HybridRAGService',
    'HYBRID_RAG_AVAILABLE',
    
    # Data Import
    'DataImportService',
    'DataImportError',
    'DATA_IMPORT_AVAILABLE',
    
    # Query Routing
    'QueryRouter',
    'SQLGenerator',
    'VectorSearch',
    'DirectLLMProcessor',
    'SQLFirstProcessor',
    'HybridProcessor',
    
    # Legacy Services (Optional)
    'ExcelDataService',
    'FileServiceError',
    'FILE_SERVICE_AVAILABLE',
    
    'ChatService',
    'LLMService',
    'SharePointService',
    'ChatServiceError',
    'CHAT_SERVICE_AVAILABLE',
]

# Service version
__version__ = '2.0.0'

# ============================================================================
# INITIALIZATION SUMMARY
# ============================================================================

print("\n" + "="*80)
print("SERVICES INITIALIZATION SUMMARY")
print("="*80)
print(f"  🧠 Hybrid RAG: {'✓ ENABLED' if HYBRID_RAG_AVAILABLE else '✗ DISABLED'}")
print(f"  📊 Data Import: {'✓ ENABLED' if DATA_IMPORT_AVAILABLE else '✗ DISABLED'}")
print(f"  💾 Database: {'✓ ENABLED' if DATABASE_AVAILABLE else '✗ DISABLED'}")
print(f"  📁 File Service: {'✓ AVAILABLE' if FILE_SERVICE_AVAILABLE else '⚠ NOT AVAILABLE (optional)'}")
print(f"  💬 Chat Service: {'✓ AVAILABLE' if CHAT_SERVICE_AVAILABLE else '⚠ NOT AVAILABLE (optional)'}")
print("="*80 + "\n")

logger.info("✓ Services package initialized successfully (v2.0.0 - Hybrid RAG)")