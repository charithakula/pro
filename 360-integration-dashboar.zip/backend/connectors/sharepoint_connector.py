"""
360° Enterprise Dashboard - SharePoint Connector (Updated)
Uses Microsoft Graph API with MSAL for authentication
Replaces Office365-Python-Requests with direct Graph API calls
Configuration from config.py
"""

import logging
import requests
import msal
import os
from datetime import datetime
from typing import Dict, List, Optional, Any

logger = logging.getLogger(__name__)


class SharePointConnectorError(Exception):
    """Custom exception for SharePoint connector errors"""
    pass


class SharePointConnector:
    """
    SharePoint connector using Microsoft Graph API with MSAL authentication
    
    Configuration is loaded from Flask's config object (config.py)
    """
    
    # Microsoft Graph API base URL
    GRAPH_API_BASE = "https://graph.microsoft.com/v1.0"
    
    def __init__(self, config=None):
        """
        Initialize SharePoint connector with MSAL authentication
        
        Args:
            config: Flask configuration object (uses current_app.config if not provided)
        """
        try:
            # If no config provided, try to get from Flask
            if config is None:
                try:
                    from flask import current_app
                    config = current_app.config
                except RuntimeError:
                    raise SharePointConnectorError(
                        "No config provided and Flask application context not available"
                    )
            
            # Extract configuration from config object
            self.tenant_id = config.get('AZURE_TENANT_ID') or getattr(config, 'AZURE_TENANT_ID', None)
            self.client_id = config.get('SHAREPOINT_CLIENT_ID') or getattr(config, 'SHAREPOINT_CLIENT_ID', None)
            self.client_secret = config.get('SHAREPOINT_CLIENT_SECRET') or getattr(config, 'SHAREPOINT_CLIENT_SECRET', None)
            self.site_path = config.get('SHAREPOINT_SITE_PATH') or getattr(config, 'SHAREPOINT_SITE_PATH', None)
            self.cert_path = config.get('REQUESTS_CA_BUNDLE') or getattr(config, 'REQUESTS_CA_BUNDLE', None)
            self.timeout = config.get('SHAREPOINT_TIMEOUT') or getattr(config, 'SHAREPOINT_TIMEOUT', 30)
            self.retry_count = config.get('SHAREPOINT_RETRY_COUNT') or getattr(config, 'SHAREPOINT_RETRY_COUNT', 3)
            
            # Check if SharePoint is configured
            if not all([self.tenant_id, self.client_id, self.client_secret, self.site_path]):
                logger.warning("⚠ SharePoint configuration incomplete - SharePoint features will be limited")
                self.is_configured = False
                self.access_token = None
                self.site_id = None
                self.headers = {}
            else:
                self.is_configured = True
                self.access_token = None
                self.site_id = None
                self.headers = {}
                self._authenticate()
                logger.info("✓ SharePoint connector initialized successfully")
                logger.info(f"  - Site Path: {self.site_path}")
                logger.info(f"  - Timeout: {self.timeout}s")
                logger.info(f"  - Retry Count: {self.retry_count}")
        
        except SharePointConnectorError:
            raise
        except Exception as e:
            logger.error(f"✗ SharePoint connector initialization error: {e}")
            self.is_configured = False
            raise SharePointConnectorError(f"Failed to initialize SharePoint connector: {str(e)}")
    
    
    def _authenticate(self) -> bool:
        """
        Authenticate with Azure AD using MSAL (Microsoft Authentication Library)
        Acquires access token for Microsoft Graph API
        
        Returns:
            True if authentication successful, False otherwise
        """
        try:
            if not self.is_configured:
                return False
            
            # Initialize MSAL application
            authority = f"https://login.microsoftonline.com/{self.tenant_id}"
            app = msal.ConfidentialClientApplication(
                client_id=self.client_id,
                client_credential=self.client_secret,
                authority=authority
            )
            
            # Acquire token for Graph API
            scopes = ["https://graph.microsoft.com/.default"]
            result = app.acquire_token_for_client(scopes=scopes)
            
            if "access_token" not in result:
                logger.error(f"✗ Token acquisition failed: {result.get('error_description', 'Unknown error')}")
                self.is_configured = False
                return False
            
            # Store token and set authorization headers
            self.access_token = result["access_token"]
            self.headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }
            
            # Get site ID
            if not self._get_site_id():
                logger.error("✗ Failed to retrieve site ID")
                self.is_configured = False
                return False
            
            logger.info("✓ SharePoint authentication successful")
            return True
        
        except Exception as auth_err:
            logger.error(f"✗ SharePoint authentication error: {auth_err}")
            self.is_configured = False
            return False
    
    
    def _get_site_id(self) -> bool:
        """
        Get SharePoint site ID from site path
        
        Returns:
            True if site ID retrieved successfully
        """
        try:
            url = f"{self.GRAPH_API_BASE}/sites/root:/{self.site_path}"
            response = requests.get(
                url,
                headers=self.headers,
                verify=self.cert_path or True,
                timeout=self.timeout
            )
            response.raise_for_status()
            
            self.site_id = response.json().get("id")
            logger.info(f"✓ Retrieved site ID: {self.site_id}")
            return True
        
        except Exception as e:
            logger.error(f"✗ Error getting site ID: {e}")
            return False
    
    
    def _make_request(self, method: str, url: str, data: Optional[Dict] = None, 
                     retry: int = 0) -> Optional[Dict]:
        """
        Make HTTP request to Microsoft Graph API with retry logic
        Only GET method is supported for read-only access
        
        Args:
            method: HTTP method (only GET supported)
            url: Full URL for the request
            data: Optional request body (ignored for GET)
            retry: Current retry attempt
        
        Returns:
            Response JSON or None if failed
        """
        try:
            if method.upper() != "GET":
                raise SharePointConnectorError(f"Only GET method is supported. {method} is not allowed.")
            
            response = requests.get(
                url,
                headers=self.headers,
                verify=self.cert_path or True,
                timeout=self.timeout
            )
            
            response.raise_for_status()
            return response.json() if response.content else None
        
        except requests.exceptions.RequestException as req_err:
            if retry < self.retry_count:
                logger.warning(f"⚠ Request failed (attempt {retry + 1}/{self.retry_count}), retrying...")
                return self._make_request(method, url, data, retry + 1)
            
            logger.error(f"✗ Request failed after {self.retry_count} retries: {req_err}")
            return None
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check SharePoint connector health
        
        Returns:
            Dictionary with health status
        """
        try:
            if not self.is_configured or not self.site_id:
                return {
                    'status': 'unavailable',
                    'message': 'SharePoint not configured',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}"
                response = self._make_request("GET", url)
                
                if response:
                    return {
                        'status': 'healthy',
                        'message': 'Connected to SharePoint',
                        'site_name': response.get('displayName', 'Unknown'),
                        'site_id': self.site_id,
                        'timestamp': datetime.utcnow().isoformat()
                    }
                else:
                    return {
                        'status': 'unhealthy',
                        'message': 'Failed to reach SharePoint',
                        'timestamp': datetime.utcnow().isoformat()
                    }
            
            except Exception as health_err:
                logger.warning(f"⚠ SharePoint health check failed: {health_err}")
                return {
                    'status': 'unhealthy',
                    'message': str(health_err),
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        except Exception as e:
            logger.error(f"✗ SharePoint health check error: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_site_info(self) -> Dict[str, Any]:
        """
        Get SharePoint site information
        
        Returns:
            Dictionary with site information
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}"
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'Failed to retrieve site info'}
                
                site_info = {
                    'success': True,
                    'site_id': self.site_id,
                    'title': response.get('displayName', 'Unknown'),
                    'url': response.get('webUrl', 'Unknown'),
                    'created': response.get('createdDateTime', 'Unknown'),
                    'timestamp': datetime.utcnow().isoformat()
                }
                
                logger.info(f"✓ Retrieved SharePoint site info: {site_info['title']}")
                return site_info
            
            except Exception as site_err:
                logger.error(f"✗ Error getting site info: {site_err}")
                return {'success': False, 'error': str(site_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_site_info: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def get_lists(self) -> Dict[str, Any]:
        """
        Get all lists from SharePoint site
        
        Returns:
            Dictionary with list information
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured', 'lists': []}
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/lists"
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'Failed to retrieve lists', 'lists': []}
                
                list_info = []
                for lst in response.get('value', []):
                    list_info.append({
                        'id': lst.get('id', ''),
                        'title': lst.get('displayName', 'Unknown'),
                        'item_count': lst.get('displayName', ''),
                        'description': lst.get('description', ''),
                        'created': lst.get('createdDateTime', ''),
                        'last_modified': lst.get('lastModifiedDateTime', '')
                    })
                
                logger.info(f"✓ Retrieved {len(list_info)} SharePoint lists")
                
                return {
                    'success': True,
                    'lists': list_info,
                    'count': len(list_info),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as lists_err:
                logger.error(f"✗ Error getting lists: {lists_err}")
                return {'success': False, 'error': str(lists_err), 'lists': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_lists: {e}")
            return {'success': False, 'error': str(e), 'lists': []}
    
    
    def get_document_libraries(self) -> Dict[str, Any]:
        """
        Get all document libraries (Drives) from SharePoint site
        
        Returns:
            Dictionary with document library information
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured', 'libraries': []}
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives"
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'Failed to retrieve drives', 'libraries': []}
                
                doc_libraries = []
                for drive in response.get('value', []):
                    doc_libraries.append({
                        'id': drive.get('id', ''),
                        'title': drive.get('name', 'Unknown'),
                        'description': drive.get('description', ''),
                        'web_url': drive.get('webUrl', ''),
                        'quota': drive.get('quota', {}).get('remaining', 0)
                    })
                
                logger.info(f"✓ Retrieved {len(doc_libraries)} document libraries")
                
                return {
                    'success': True,
                    'libraries': doc_libraries,
                    'count': len(doc_libraries),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as lib_err:
                logger.error(f"✗ Error getting document libraries: {lib_err}")
                return {'success': False, 'error': str(lib_err), 'libraries': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_document_libraries: {e}")
            return {'success': False, 'error': str(e), 'libraries': []}
    
    
    def get_documents(self, library_id: str, folder_path: str = '') -> Dict[str, Any]:
        """
        Get documents from specific library (Drive)
        
        Args:
            library_id: ID of the document library (Drive)
            folder_path: Optional folder path within library
        
        Returns:
            Dictionary with document information
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured', 'documents': []}
            
            if not library_id:
                return {'success': False, 'error': 'Library ID is required', 'documents': []}
            
            try:
                # Remove leading/trailing slashes from folder path
                folder_path = folder_path.strip('/')
                
                if folder_path:
                    url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives/{library_id}/root:/{folder_path}:/children"
                else:
                    url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives/{library_id}/root/children"
                
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'Failed to retrieve documents', 'documents': []}
                
                documents = []
                for item in response.get('value', []):
                    # Skip folders, only include files
                    if 'file' in item:
                        documents.append({
                            'id': item.get('id', ''),
                            'name': item.get('name', 'Unknown'),
                            'size': item.get('size', 0),
                            'created': item.get('createdDateTime', ''),
                            'modified': item.get('lastModifiedDateTime', ''),
                            'created_by': item.get('createdBy', {}).get('user', {}).get('displayName', 'Unknown'),
                            'file_url': item.get('webUrl', ''),
                            'mime_type': item.get('file', {}).get('mimeType', '')
                        })
                
                logger.info(f"✓ Retrieved {len(documents)} documents from library {library_id}")
                
                return {
                    'success': True,
                    'library_id': library_id,
                    'documents': documents,
                    'count': len(documents),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as doc_err:
                logger.error(f"✗ Error getting documents: {doc_err}")
                return {'success': False, 'error': str(doc_err), 'documents': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_documents: {e}")
            return {'success': False, 'error': str(e), 'documents': []}
    
    
    def upload_document(self, library_id: str, file_name: str, file_content: bytes, 
                       folder_path: str = '') -> Dict[str, Any]:
        """
        Upload document to SharePoint library
        
        ⚠️ NOT SUPPORTED - Only GET method is allowed for read-only access
        
        Args:
            library_id: ID of the document library (Drive)
            file_name: Name of the file to upload
            file_content: Content of the file as bytes
            folder_path: Optional folder path within library
        
        Returns:
            Dictionary with error message
        """
        logger.warning("⚠ Upload operation attempted but disabled - only GET method is allowed")
        return {
            'success': False,
            'error': 'Upload operation is not allowed. Only GET method (read-only) is supported.',
            'timestamp': datetime.utcnow().isoformat()
        }
    
    
    def download_document(self, library_id: str, item_id: str) -> Dict[str, Any]:
        """
        Download document from SharePoint library
        
        Args:
            library_id: ID of the document library (Drive)
            item_id: ID of the file item to download
        
        Returns:
            Dictionary with download URL and metadata
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            if not library_id or not item_id:
                return {'success': False, 'error': 'Library ID and item ID are required'}
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives/{library_id}/items/{item_id}"
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'File not found'}
                
                # Get download URL
                download_url = response.get('@microsoft.graph.downloadUrl')
                
                logger.info(f"✓ Document retrieved: {response.get('name')} from {library_id}")
                
                return {
                    'success': True,
                    'file_name': response.get('name', 'Unknown'),
                    'library_id': library_id,
                    'file_id': item_id,
                    'download_url': download_url,
                    'web_url': response.get('webUrl', ''),
                    'size': response.get('size', 0),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as download_err:
                logger.error(f"✗ Error downloading document: {download_err}")
                return {'success': False, 'error': str(download_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in download_document: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def delete_document(self, library_id: str, item_id: str) -> Dict[str, Any]:
        """
        Delete document from SharePoint library
        
        ⚠️ NOT SUPPORTED - Only GET method is allowed for read-only access
        
        Args:
            library_id: ID of the document library (Drive)
            item_id: ID of the file item to delete
        
        Returns:
            Dictionary with error message
        """
        logger.warning("⚠ Delete operation attempted but disabled - only GET method is allowed")
        return {
            'success': False,
            'error': 'Delete operation is not allowed. Only GET method (read-only) is supported.',
            'timestamp': datetime.utcnow().isoformat()
        }
    
    
    def search_documents(self, search_term: str) -> Dict[str, Any]:
        """
        Search documents across SharePoint site
        
        Args:
            search_term: Term to search for
        
        Returns:
            Dictionary with search results
        """
        try:
            if not self.is_configured or not self.site_id:
                return {'success': False, 'error': 'SharePoint not configured', 'results': []}
            
            if not search_term:
                return {'success': False, 'error': 'Search term is required', 'results': []}
            
            try:
                url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drive/root/search(q='{search_term}')"
                response = self._make_request("GET", url)
                
                if not response:
                    return {'success': False, 'error': 'Search failed', 'results': []}
                
                results = []
                for item in response.get('value', []):
                    if 'file' in item:
                        results.append({
                            'id': item.get('id', ''),
                            'name': item.get('name', 'Unknown'),
                            'size': item.get('size', 0),
                            'modified': item.get('lastModifiedDateTime', ''),
                            'file_url': item.get('webUrl', ''),
                            'mime_type': item.get('file', {}).get('mimeType', '')
                        })
                
                logger.info(f"✓ Found {len(results)} documents matching '{search_term}'")
                
                return {
                    'success': True,
                    'search_term': search_term,
                    'results': results,
                    'count': len(results),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as search_err:
                logger.error(f"✗ Error searching documents: {search_err}")
                return {'success': False, 'error': str(search_err), 'results': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in search_documents: {e}")
            return {'success': False, 'error': str(e), 'results': []}
    
    
    def get_sharepoint_stats(self) -> Dict[str, Any]:
        """
        Get SharePoint site statistics
        
        Returns:
            Dictionary with site statistics
        """
        try:
            if not self.is_configured or not self.site_id:
                return {
                    'site_name': 'Unknown',
                    'total_libraries': 0,
                    'total_documents': 0,
                    'configured': False
                }
            
            try:
                # Get site info
                site_url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}"
                site_response = self._make_request("GET", site_url)
                
                # Get drives (libraries)
                drives_url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives"
                drives_response = self._make_request("GET", drives_url)
                
                doc_count = 0
                if drives_response:
                    for drive in drives_response.get('value', []):
                        drive_id = drive.get('id')
                        items_url = f"{self.GRAPH_API_BASE}/sites/{self.site_id}/drives/{drive_id}/root/children"
                        items_response = self._make_request("GET", items_url)
                        
                        if items_response:
                            for item in items_response.get('value', []):
                                if 'file' in item:
                                    doc_count += 1
                
                stats = {
                    'site_name': site_response.get('displayName', 'Unknown') if site_response else 'Unknown',
                    'site_id': self.site_id,
                    'total_libraries': len(drives_response.get('value', [])) if drives_response else 0,
                    'total_documents': doc_count,
                    'configured': True,
                    'last_updated': datetime.utcnow().isoformat()
                }
                
                logger.info(f"✓ Retrieved SharePoint statistics")
                return stats
            
            except Exception as stats_err:
                logger.error(f"✗ Error getting statistics: {stats_err}")
                return {
                    'site_name': 'Unknown',
                    'total_libraries': 0,
                    'total_documents': 0,
                    'configured': True,
                    'error': str(stats_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_sharepoint_stats: {e}")
            return {
                'site_name': 'Unknown',
                'total_libraries': 0,
                'total_documents': 0,
                'configured': False,
                'error': str(e)
            }


def get_sharepoint_connector(config=None) -> Optional[SharePointConnector]:
    """
    Factory function to get SharePoint connector instance
    
    Args:
        config: Flask configuration object (uses current_app.config if not provided)
    
    Returns:
        SharePointConnector instance or None if initialization fails
    """
    try:
        return SharePointConnector(config=config)
    except SharePointConnectorError as e:
        logger.error(f"✗ Failed to create SharePoint connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating SharePoint connector: {e}")
        return None