"""
Splunk Connector - Enterprise Integration
Handles Splunk search queries with multiple authentication options
Uses configuration from config.py instead of environment variables directly
"""

import time
import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from enum import Enum
import urllib3

logger = logging.getLogger(__name__)

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class AuthMethod(Enum):
    """Authentication method options"""
    USERNAME_PASSWORD = "username_password"
    BEARER_TOKEN = "bearer_token"


class SplunkConnectorError(Exception):
    """Custom exception for Splunk connector errors"""
    pass


class SplunkConnector:
    """
    Splunk connector for search queries with multiple authentication methods
    
    Configuration is loaded from Flask's config object (config.py)
    
    Authentication Options:
    1. Username/Password: Traditional session-based auth
    2. Bearer Token: Direct API access with pre-generated token
    """
    
    def __init__(self, config=None):
        """
        Initialize Splunk connector with configuration
        
        Args:
            config: Flask configuration object (uses current_app.config if not provided)
        """
        try:
            # If no config provided, try to get from Flask
            if config is None:
                try:
                    from flask import current_app
                    config = current_app.config
                except RuntimeError:
                    raise SplunkConnectorError(
                        "No config provided and Flask application context not available"
                    )
            
            # Extract configuration from config object
            self.host = config.get('SPLUNK_HOST') or getattr(config, 'SPLUNK_HOST', None)
            self.port = int(config.get('SPLUNK_PORT') or getattr(config, 'SPLUNK_PORT', 8089))
            self.scheme = config.get('SPLUNK_SCHEME') or getattr(config, 'SPLUNK_SCHEME', 'https')
            self.username = config.get('SPLUNK_USERNAME') or getattr(config, 'SPLUNK_USERNAME', None)
            self.password = config.get('SPLUNK_PASSWORD') or getattr(config, 'SPLUNK_PASSWORD', None)
            self.bearer_token = config.get('SPLUNK_BEARER_TOKEN') or getattr(config, 'SPLUNK_BEARER_TOKEN', None)
            self.token_type = config.get('SPLUNK_TOKEN_TYPE') or getattr(config, 'SPLUNK_TOKEN_TYPE', 'Splunk')
            self.timeout = int(config.get('SPLUNK_TIMEOUT') or getattr(config, 'SPLUNK_TIMEOUT', 30))
            self.verify_ssl = config.get('SPLUNK_VERIFY_SSL') or getattr(config, 'SPLUNK_VERIFY_SSL', False)
            self.max_retries = int(config.get('SPLUNK_MAX_RETRIES') or getattr(config, 'SPLUNK_MAX_RETRIES', 3))
            self.connection_cooldown = int(config.get('SPLUNK_CONNECTION_COOLDOWN') or getattr(config, 'SPLUNK_CONNECTION_COOLDOWN', 30))
            
            # Validate required configuration
            if not self.host:
                raise SplunkConnectorError("Splunk host (SPLUNK_HOST) is required")
            
            # Determine authentication method
            if self.bearer_token:
                self.auth_method = AuthMethod.BEARER_TOKEN
            elif self.username and self.password:
                self.auth_method = AuthMethod.USERNAME_PASSWORD
            else:
                logger.warning("⚠ Splunk authentication not fully configured - limited functionality")
                self.auth_method = AuthMethod.USERNAME_PASSWORD
            
            # Build base URL
            self.base_url = f"{self.scheme}://{self.host}:{self.port}"
            
            # Session management attributes
            self.session_key = None
            self.session_expiry = None
            self.last_connection_attempt = None
            self.connection_attempts = 0
            
            # Create requests session for connection pooling
            self.session = requests.Session()
            self.session.verify = self.verify_ssl
            
            # Track if connector is configured
            self.is_configured = bool(self.host)
            
            logger.info("✓ Splunk Connector initialized")
            logger.info(f"  - Host: {self.host}:{self.port}")
            logger.info(f"  - Auth Method: {self.auth_method.value}")
            logger.info(f"  - Timeout: {self.timeout}s")
            logger.info(f"  - SSL Verify: {self.verify_ssl}")
        
        except SplunkConnectorError:
            raise
        except Exception as e:
            logger.error(f"✗ Failed to initialize Splunk Connector: {e}")
            raise SplunkConnectorError(f"Initialization failed: {str(e)}")
    
    
    def should_attempt_connection(self) -> bool:
        """Check if we should attempt a connection based on cooldown"""
        if self.last_connection_attempt is None:
            return True
        return time.time() - self.last_connection_attempt > self.connection_cooldown
    
    
    def generate_session_key(self) -> bool:
        """
        Generate session key using username/password authentication
        
        Returns:
            True if session key generated successfully, False otherwise
        """
        if self.auth_method != AuthMethod.USERNAME_PASSWORD:
            logger.error("✗ Session key generation only available for username/password auth")
            return False
        
        if not self.username or not self.password:
            logger.warning("⚠ No credentials available for session generation")
            return False
        
        if not self.should_attempt_connection():
            logger.info("Session generation skipped due to cooldown")
            return False
        
        self.last_connection_attempt = time.time()
        auth_url = f"{self.base_url}/services/auth/login"
        
        try:
            auth_data = {
                'username': self.username,
                'password': self.password,
                'output_mode': 'json'
            }
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            logger.info(f"🔐 Generating Splunk session key")
            
            response = self.session.post(
                auth_url,
                data=auth_data,
                headers=headers,
                timeout=self.timeout
            )
            
            if response.status_code != 200:
                logger.error(f"✗ Authentication failed: {response.status_code}")
                return False
            
            auth_result = response.json()
            
            if 'sessionKey' in auth_result:
                self.session_key = auth_result['sessionKey']
                self.session_expiry = datetime.now() + timedelta(hours=1)
                logger.info(f"✓ Successfully generated session key")
                return True
            else:
                logger.error("✗ No session key in authentication response")
                return False
        
        except requests.exceptions.RequestException as e:
            logger.error(f"✗ Session generation request failed: {e}")
            return False
        except Exception as e:
            logger.error(f"✗ Unexpected session generation error: {e}")
            return False
    
    
    def is_session_valid(self) -> bool:
        """Check if current session is still valid"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return bool(self.bearer_token)
        
        if not self.session_key:
            return False
        
        if self.session_expiry and datetime.now() >= self.session_expiry:
            logger.info("Session expired, need to re-authenticate")
            return False
        
        return True
    
    
    def ensure_valid_session(self) -> bool:
        """Ensure we have valid authentication before making API calls"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return bool(self.bearer_token)
        
        if not self.is_session_valid():
            logger.info("Session invalid, generating new session...")
            return self.generate_session_key()
        return True
    
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get appropriate authentication headers based on auth method"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return {
                'Authorization': f'{self.token_type} {self.bearer_token}',
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        else:
            return {
                'Authorization': f'Splunk {self.session_key}',
                'Content-Type': 'application/x-www-form-urlencoded'
            }
    
    
    def test_connection(self) -> bool:
        """Test Splunk connection with a simple search"""
        try:
            if not self.is_configured:
                return False
            
            if not self.ensure_valid_session():
                return False
            
            search_url = f"{self.base_url}/services/search/jobs"
            
            # Simple test query
            search_data = {
                'search': 'search index=_internal | head 1',
                'output_mode': 'json',
                'exec_mode': 'blocking',
                'earliest_time': '-1m@m',
                'latest_time': 'now'
            }
            
            headers = self.get_auth_headers()
            
            logger.info("Testing Splunk connection")
            
            response = self.session.post(
                search_url,
                data=search_data,
                headers=headers,
                timeout=15
            )
            
            if response.status_code not in [200, 201]:
                logger.error(f"✗ Connection test failed: {response.status_code}")
                return False
            
            search_result = response.json()
            
            if 'sid' in search_result:
                logger.info("✓ Splunk connection test successful")
                return True
            else:
                logger.error("✗ Connection test failed - no SID returned")
                return False
        
        except Exception as e:
            logger.error(f"✗ Connection test failed: {e}")
            return False
    
    
    def execute_query(self, query: str, earliest_time: str = "-30d@d",
                     latest_time: str = "now", timeout: int = None) -> Dict[str, Any]:
        """
        Execute Splunk search query
        
        Args:
            query: Splunk search query
            earliest_time: Search start time (Splunk format)
            latest_time: Search end time (Splunk format)
            timeout: Query timeout in seconds
        
        Returns:
            Dictionary with query results
            {
                'success': bool,
                'results': List[Dict],
                'count': int,
                'job_sid': str,
                'timestamp': str,
                'error': str (if failed)
            }
        """
        if timeout is None:
            timeout = self.timeout
        
        if not self.is_configured:
            return {
                'success': False,
                'results': [],
                'error': 'Splunk not configured',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        if not self.ensure_valid_session():
            return {
                'success': False,
                'results': [],
                'error': 'No valid authentication',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        start_time = time.time()
        
        try:
            # Security validation
            dangerous_keywords = ['delete', 'drop', 'insert', 'update', 'create', 'alter']
            if any(keyword in query.lower() for keyword in dangerous_keywords):
                raise ValueError("Query contains potentially dangerous operations")
            
            # Ensure query starts with "search" command
            query = query.strip()
            if not query.lower().startswith('search '):
                query = f"search {query}"
            
            search_url = f"{self.base_url}/services/search/jobs"
            
            search_data = {
                'search': query,
                'output_mode': 'json',
                'exec_mode': 'blocking',
                'timeout': timeout,
                'earliest_time': earliest_time,
                'latest_time': latest_time,
                'max_count': 1000
            }
            
            headers = self.get_auth_headers()
            
            logger.info(f"🔍 Executing Splunk query")
            
            response = self.session.post(
                search_url,
                data=search_data,
                headers=headers,
                timeout=timeout + 5
            )
            
            if response.status_code not in [200, 201]:
                error_details = response.text[:500]
                logger.error(f"✗ Query execution failed: {response.status_code}")
                return {
                    'success': False,
                    'results': [],
                    'error': f'HTTP {response.status_code}: {error_details}',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            search_result = response.json()
            
            if 'sid' not in search_result:
                logger.error("✗ No SID in search response")
                return {
                    'success': False,
                    'results': [],
                    'error': 'No SID returned from search',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            job_sid = search_result['sid']
            logger.info(f"✓ Search job created: {job_sid}")
            
            # Get results using the SID
            results_url = f"{self.base_url}/services/search/jobs/{job_sid}/results"
            results_params = {
                'output_mode': 'json',
                'count': 1000
            }
            
            results_response = self.session.get(
                results_url,
                params=results_params,
                headers=headers,
                timeout=15
            )
            
            results_response.raise_for_status()
            results_data = results_response.json()
            
            results_list = results_data.get('results', [])
            execution_time = time.time() - start_time
            
            logger.info(f"✓ Query completed successfully ({len(results_list)} results, {execution_time:.2f}s)")
            
            return {
                'success': True,
                'results': results_list,
                'count': len(results_list),
                'job_sid': job_sid,
                'execution_time': execution_time,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except requests.exceptions.Timeout as e:
            execution_time = time.time() - start_time
            logger.error(f"✗ Query timeout after {execution_time:.2f}s")
            return {
                'success': False,
                'results': [],
                'error': f'Query timeout after {timeout}s',
                'execution_time': execution_time,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except requests.exceptions.HTTPError as e:
            execution_time = time.time() - start_time
            
            if e.response.status_code == 401:
                logger.warning("✗ Authentication error, clearing session")
                if self.auth_method == AuthMethod.USERNAME_PASSWORD:
                    self.session_key = None
                    self.session_expiry = None
            elif e.response.status_code == 403:
                logger.error("✗ Permission denied")
            else:
                logger.error(f"✗ HTTP error: {e}")
            
            return {
                'success': False,
                'results': [],
                'error': str(e),
                'execution_time': execution_time,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"✗ Error executing query: {e}")
            return {
                'success': False,
                'results': [],
                'error': str(e),
                'execution_time': execution_time,
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check Splunk connector health
        
        Returns:
            Dictionary with health status
        """
        try:
            if not self.is_configured:
                return {
                    'status': 'unavailable',
                    'message': 'Splunk not configured',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            if self.test_connection():
                return {
                    'status': 'healthy',
                    'message': 'Connected to Splunk',
                    'host': self.host,
                    'port': self.port,
                    'auth_method': self.auth_method.value,
                    'timestamp': datetime.utcnow().isoformat()
                }
            else:
                return {
                    'status': 'unhealthy',
                    'message': 'Connection test failed',
                    'host': self.host,
                    'port': self.port,
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        except Exception as e:
            logger.error(f"✗ Health check error: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_status(self) -> Dict[str, Any]:
        """Get current connector status"""
        status = {
            'configured': self.is_configured,
            'auth_method': self.auth_method.value,
            'host': self.host,
            'port': self.port,
            'base_url': self.base_url,
            'timeout': self.timeout,
            'verify_ssl': self.verify_ssl,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if self.auth_method == AuthMethod.USERNAME_PASSWORD:
            status.update({
                'has_session_key': bool(self.session_key),
                'session_expiry': self.session_expiry.isoformat() if self.session_expiry else None,
                'username': self.username
            })
        else:
            status.update({
                'has_bearer_token': bool(self.bearer_token),
                'token_type': self.token_type
            })
        
        return status


def get_splunk_connector(config=None) -> Optional[SplunkConnector]:
    """
    Factory function to get Splunk connector instance
    
    Args:
        config: Flask configuration object (uses current_app.config if not provided)
    
    Returns:
        SplunkConnector instance or None if initialization fails
    """
    try:
        return SplunkConnector(config=config)
    except SplunkConnectorError as e:
        logger.error(f"✗ Failed to create Splunk connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating Splunk connector: {e}")
        return None