"""
Diagnostic Script: Why is LLM not being called?
================================================
This script checks all the conditions required for LLM to work
"""

import os
import sys
from pathlib import Path

# Add backend to path
backend_path = Path(__file__).parent.parent / 'backend'
sys.path.insert(0, str(backend_path))

def check_azure_credentials():
    """Check if Azure credentials are configured"""
    print("\n" + "="*80)
    print("1️⃣  CHECKING AZURE CREDENTIALS")
    print("="*80)
    
    from dotenv import load_dotenv
    load_dotenv()
    
    checks = {
        'AZURE_OPENAI_API_KEY': os.getenv('AZURE_OPENAI_API_KEY'),
        'AZURE_OPENAI_ENDPOINT': os.getenv('AZURE_OPENAI_ENDPOINT'),
        'AZURE_OPENAI_DEPLOYMENT': os.getenv('AZURE_OPENAI_DEPLOYMENT'),
        'AZURE_OPENAI_API_VERSION': os.getenv('AZURE_OPENAI_API_VERSION')
    }
    
    for key, value in checks.items():
        if value:
            masked = value[:20] + '...' if len(str(value)) > 20 else value
            print(f"   ✅ {key}: {masked}")
        else:
            print(f"   ❌ {key}: NOT SET")
    
    missing = [k for k, v in checks.items() if not v]
    
    if missing:
        print(f"\n   ⚠️  MISSING: {', '.join(missing)}")
        print(f"   💡 Add these to your .env file:")
        for key in missing:
            print(f"      {key}=<value>")
        return False
    else:
        print(f"\n   ✅ All Azure credentials configured!")
        return True


def check_flask_config():
    """Check if Flask config has Azure settings"""
    print("\n" + "="*80)
    print("2️⃣  CHECKING FLASK CONFIGURATION")
    print("="*80)
    
    try:
        from app import app
        
        with app.app_context():
            checks = {
                'AZURE_OPENAI_API_KEY': app.config.get('AZURE_OPENAI_API_KEY'),
                'AZURE_OPENAI_ENDPOINT': app.config.get('AZURE_OPENAI_ENDPOINT'),
                'AZURE_OPENAI_DEPLOYMENT': app.config.get('AZURE_OPENAI_DEPLOYMENT'),
                'AZURE_OPENAI_API_VERSION': app.config.get('AZURE_OPENAI_API_VERSION'),
            }
            
            for key, value in checks.items():
                if value:
                    masked = str(value)[:20] + '...' if len(str(value)) > 20 else str(value)
                    print(f"   ✅ app.config['{key}']: {masked}")
                else:
                    print(f"   ❌ app.config['{key}']: NOT SET")
            
            missing = [k for k, v in checks.items() if not v]
            
            if missing:
                print(f"\n   ⚠️  PROBLEM: Flask config missing:")
                print(f"   ❌ {', '.join(missing)}")
                print(f"\n   💡 FIX: In app.py, make sure Config class has:")
                for key in missing:
                    print(f"      {key} = os.getenv('{key}', '')")
                return False
            else:
                print(f"\n   ✅ All Flask config settings loaded!")
                return True
    
    except Exception as e:
        print(f"   ❌ Error checking Flask config: {e}")
        return False


def check_openai_client():
    """Check if Azure OpenAI client is initialized"""
    print("\n" + "="*80)
    print("3️⃣  CHECKING AZURE OPENAI CLIENT")
    print("="*80)
    
    try:
        from app import app
        
        with app.app_context():
            # Check if client was created
            print("   Checking for Azure OpenAI client...")
            
            # Try importing directly
            try:
                from azure.ai.openai import AzureOpenAI
                print("   ✅ azure.ai.openai library available")
            except ImportError:
                print("   ❌ azure.ai.openai NOT INSTALLED")
                print("   💡 Install: pip install azure-ai-openai")
                return False
            
            # Check if client is created in app.py
            if hasattr(app, 'openai_client'):
                if app.openai_client:
                    print(f"   ✅ app.openai_client is initialized")
                    print(f"      Type: {type(app.openai_client)}")
                    return True
                else:
                    print(f"   ❌ app.openai_client exists but is None/False")
                    return False
            else:
                print(f"   ❌ app.openai_client NOT FOUND in app")
                print(f"   💡 FIX: In app.py, add:")
                print(f"""
                from azure.ai.openai import AzureOpenAI
                
                app.openai_client = AzureOpenAI(
                    api_key=app.config['AZURE_OPENAI_API_KEY'],
                    api_version=app.config['AZURE_OPENAI_API_VERSION'],
                    azure_endpoint=app.config['AZURE_OPENAI_ENDPOINT']
                )
                """)
                return False
    
    except Exception as e:
        print(f"   ❌ Error checking OpenAI client: {e}")
        return False


def check_hybrid_rag_service():
    """Check if RAG service has LLM enabled"""
    print("\n" + "="*80)
    print("4️⃣  CHECKING HYBRID RAG SERVICE")
    print("="*80)
    
    try:
        from app import app
        
        with app.app_context():
            print("   Initializing RAG service...")
            
            from services.hybrid_rag_service import HybridRAGService
            
            rag_service = HybridRAGService(
                db_connection=None,
                openai_client=app.openai_client if hasattr(app, 'openai_client') else None,
                config={'flask_config': app.config}
            )
            
            print(f"\n   RAG Service Status:")
            print(f"   ✅ Service initialized")
            print(f"   {'✅' if rag_service.llm_enabled else '❌'} LLM Enabled: {rag_service.llm_enabled}")
            print(f"   {'✅' if rag_service.use_local_embeddings else '❌'} Local Embeddings: {rag_service.use_local_embeddings if hasattr(rag_service, 'use_local_embeddings') else 'N/A'}")
            
            if not rag_service.llm_enabled:
                print(f"\n   ⚠️  LLM NOT ENABLED! Reasons:")
                if not hasattr(app, 'openai_client') or not app.openai_client:
                    print(f"      ❌ Azure OpenAI client not available")
                if not rag_service.rag_config.llm_enabled:
                    print(f"      ❌ LLM disabled in config")
                print(f"\n   💡 Solution: Check steps above (Azure client, credentials)")
            else:
                print(f"   ✅ LLM is properly enabled!")
            
            return rag_service.llm_enabled
    
    except Exception as e:
        print(f"   ❌ Error checking RAG service: {e}")
        import traceback
        traceback.print_exc()
        return False


def check_vector_embeddings():
    """Check if vector embeddings are available"""
    print("\n" + "="*80)
    print("5️⃣  CHECKING VECTOR EMBEDDINGS")
    print("="*80)
    
    try:
        from app import app
        
        with app.app_context():
            from services.hybrid_rag_service import HybridRAGService
            
            rag_service = HybridRAGService(
                db_connection=None,
                openai_client=app.openai_client if hasattr(app, 'openai_client') else None,
                config={'flask_config': app.config}
            )
            
            if hasattr(rag_service, 'vector_search') and rag_service.vector_search:
                print(f"   ✅ Vector search service available")
                print(f"   {'✅' if rag_service.vector_search.use_local_embeddings else '❌'} Local embeddings: {rag_service.vector_search.use_local_embeddings}")
            else:
                print(f"   ❌ Vector search service NOT available")
            
            return True
    
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False


def check_query_routing():
    """Check query routing logic"""
    print("\n" + "="*80)
    print("6️⃣  CHECKING QUERY ROUTING LOGIC")
    print("="*80)
    
    try:
        from app import app
        from services.hybrid_rag_service import HybridRAGService
        
        with app.app_context():
            rag_service = HybridRAGService(
                db_connection=None,
                openai_client=app.openai_client if hasattr(app, 'openai_client') else None,
                config={'flask_config': app.config}
            )
            
            # Check routing logic
            test_query = "Show me SAP interfaces"
            
            print(f"   Test Query: '{test_query}'")
            print(f"\n   Routing Decision:")
            
            # Check if greeting
            if hasattr(rag_service, '_is_greeting'):
                is_greeting = rag_service._is_greeting(test_query)
                print(f"   Is greeting? {is_greeting}")
            
            # Check intent
            if hasattr(rag_service, '_detect_query_intent'):
                intent = rag_service._detect_query_intent(test_query)
                print(f"   Query type: {intent.get('type')}")
                print(f"   Description: {intent.get('description')}")
            
            print(f"\n   LLM Will Be Called If:")
            print(f"   ✅ Query type is 'semantic_search'")
            print(f"   ✅ Vector search returns results")
            print(f"   ✅ LLM is enabled ({rag_service.llm_enabled})")
            print(f"   ✅ OpenAI client available")
            
            return True
    
    except Exception as e:
        print(f"   ❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all diagnostics"""
    print("\n")
    print("╔" + "="*78 + "╗")
    print("║" + " "*78 + "║")
    print("║" + "  DIAGNOSTIC: Why is LLM not being called?".center(78) + "║")
    print("║" + " "*78 + "║")
    print("╚" + "="*78 + "╝")
    
    results = []
    
    # Run all checks
    results.append(("Azure Credentials", check_azure_credentials()))
    results.append(("Flask Config", check_flask_config()))
    results.append(("OpenAI Client", check_openai_client()))
    results.append(("RAG Service", check_hybrid_rag_service()))
    results.append(("Vector Embeddings", check_vector_embeddings()))
    results.append(("Query Routing", check_query_routing()))
    
    # Summary
    print("\n" + "="*80)
    print("📊 DIAGNOSTIC SUMMARY")
    print("="*80)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"   {status}: {name}")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    print(f"\n   {passed}/{total} checks passed")
    
    if passed == total:
        print("\n   ✅ ALL CHECKS PASSED - LLM should be working!")
        print("\n   Next Steps:")
        print("   1. Try asking a question that triggers semantic search")
        print("   2. Query should return: 🔍 VECTOR_WITH_LLM badge")
        print("   3. Response should be LLM-formatted (not raw database)")
    else:
        print(f"\n   ⚠️  {total - passed} checks failed")
        print("   Please fix the issues above, then run this diagnostic again")
    
    print("\n" + "="*80)


if __name__ == '__main__':
    main()