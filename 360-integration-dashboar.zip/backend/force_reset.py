#!/usr/bin/env python
"""
Force Password Reset - Direct hash update
Bypasses set_password() method to ensure it works
"""

import sys
import os

backend_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_path)

try:
    from app import create_app, db, User
    from werkzeug.security import generate_password_hash, check_password_hash
    
    print("\n" + "=" * 80)
    print("🔐 FORCE PASSWORD RESET - Direct Hash Update")
    print("=" * 80)
    
    app = create_app()
    
    with app.app_context():
        print("\n1️⃣ Finding user...")
        user = User.query.filter_by(email='demo@example.com').first()
        
        if not user:
            print("❌ User not found!")
            sys.exit(1)
        
        print(f"✓ User: {user.email} (ID: {user.id})")
        print(f"  Old hash: {user.password[:50]}...\n")
        
        print("2️⃣ Generating new password hash...")
        new_hash = generate_password_hash('demo123')
        print(f"✓ New hash: {new_hash[:50]}...\n")
        
        print("3️⃣ Testing new hash...")
        test_result = check_password_hash(new_hash, 'demo123')
        if test_result:
            print("✓ Hash verification: SUCCESS\n")
        else:
            print("❌ Hash verification: FAILED\n")
            print("This is a serious issue - hash generation is broken!")
            sys.exit(1)
        
        print("4️⃣ Updating database...")
        user.password = new_hash
        db.session.commit()
        print("✓ Updated in PostgreSQL\n")
        
        print("5️⃣ Verifying update...")
        db.session.expire(user)
        user = User.query.filter_by(email='demo@example.com').first()
        
        verify = check_password_hash(user.password, 'demo123')
        if verify:
            print("✅ NEW hash in database: WORKS\n")
            print("=" * 80)
            print("✅ SUCCESS - Password reset complete!")
            print("=" * 80)
            print(f"\nLogin credentials:")
            print(f"  Email:    demo@example.com")
            print(f"  Password: demo123")
            print(f"\nGo to: http://localhost:5000/login\n")
        else:
            print("❌ NEW hash in database: DOESN'T WORK")
            print("\nThis means the password verification is broken!")
            print("Check if werkzeug is installed: pip install werkzeug")
            sys.exit(1)

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)