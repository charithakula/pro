#!/usr/bin/env python
"""
Reset Demo User Password - 360° Enterprise Dashboard
For PostgreSQL Database
"""

import sys
import os

# Add backend to path
backend_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_path)

try:
    from app import create_app, db, User
    
    print("=" * 70)
    print("🐘 PostgreSQL Password Reset Script")
    print("=" * 70)
    
    print("\n🔄 Creating app context...")
    app = create_app()
    
    with app.app_context():
        print("✓ App context created")
        
        print("\n🔍 Searching for demo user...")
        user = User.query.filter_by(email='demo@example.com').first()
        
        if not user:
            print("❌ Demo user not found!")
            print("\nAvailable users:")
            all_users = User.query.all()
            if all_users:
                for u in all_users:
                    print(f"  - {u.email}")
            else:
                print("  (None)")
            sys.exit(1)
        
        print(f"✓ Found user: {user.email}")
        
        print("\n🔐 Resetting password...")
        try:
            user.set_password('demo123')
            db.session.commit()
            print("✓ Password reset to: demo123")
        except Exception as pwd_err:
            print(f"❌ Error setting password: {pwd_err}")
            db.session.rollback()
            sys.exit(1)
        
        print("\n" + "=" * 70)
        print("✅ SUCCESS - Ready to login!")
        print("=" * 70)
        print(f"\nEmail:    demo@example.com")
        print(f"Password: demo123")
        print(f"\nGo to: http://localhost:5000/login")
        print("=" * 70 + "\n")

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)