"""
WSGI Entry Point

Used by Gunicorn/other WSGI servers for production deployment
"""

import os
from dotenv import load_dotenv

# Load environment
load_dotenv()

# Import app factory
from app import create_app, db

# Create application instance
application = create_app(os.getenv('FLASK_ENV', 'production'))

if __name__ == '__main__':
    application.run()