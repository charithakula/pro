"""
Simplified LLM Diagnostic - With Proper Encoding
=================================================
Handles UTF-8 and special characters in app.py
"""

import sys
import os
from pathlib import Path

print("\n" + "="*80)
print("SIMPLE LLM DIAGNOSTIC (Fixed Encoding)")
print("="*80)

# Step 1: Check if app.py exists
app_path = Path("app.py")
if not app_path.exists():
    print("\n❌ ERROR: app.py not found in current directory")
    print(f"   Current dir: {os.getcwd()}")
    print(f"   List files: {os.listdir('.')}")
    sys.exit(1)

print("\n✅ Found app.py")

# Step 2: Read app.py content with proper encoding
try:
    with open("app.py", "r", encoding='utf-8') as f:
        app_content = f.read()
except UnicodeDecodeError:
    print("\n⚠️  UTF-8 encoding failed, trying latin-1...")
    try:
        with open("app.py", "r", encoding='latin-1') as f:
            app_content = f.read()
    except:
        print("❌ Cannot read app.py - encoding issue")
        sys.exit(1)

print("✅ Successfully read app.py")

print("\n" + "="*80)
print("1️⃣  CHECKING FOR AZURE OPENAI CLIENT INITIALIZATION")
print("="*80)

# Check for openai_client initialization
if "app.openai_client" in app_content:
    print("\n✅ Found: app.openai_client = ...")
    
    # Find the lines
    lines = app_content.split('\n')
    for i, line in enumerate(lines, 1):
        if "app.openai_client" in line:
            print(f"   Line {i}: {line.strip()[:80]}")
else:
    print("\n❌ NOT FOUND: app.openai_client not initialized")
    print("   💡 Solution: Add this to app.py after app.config.from_object(Config):")
    print("""
    from azure.ai.openai import AzureOpenAI
    
    try:
        app.openai_client = AzureOpenAI(
            api_key=app.config['AZURE_OPENAI_API_KEY'],
            api_version=app.config['AZURE_OPENAI_API_VERSION'],
            azure_endpoint=app.config['AZURE_OPENAI_ENDPOINT']
        )
    except Exception as e:
        app.openai_client = None
    """)

print("\n" + "="*80)
print("2️⃣  CHECKING FOR LOAD_DOTENV()")
print("="*80)

if "load_dotenv()" in app_content:
    print("\n✅ Found: load_dotenv() is called")
    lines = app_content.split('\n')
    for i, line in enumerate(lines, 1):
        if "load_dotenv()" in line:
            print(f"   Line {i}: {line.strip()}")
else:
    print("\n❌ NOT FOUND: load_dotenv() not called")
    print("   💡 Add at TOP of app.py:")
    print("   from dotenv import load_dotenv")
    print("   load_dotenv()")

print("\n" + "="*80)
print("3️⃣  CHECKING FOR AZURE IMPORTS")
print("="*80)

if "from azure.ai.openai import AzureOpenAI" in app_content:
    print("\n✅ Found: Azure OpenAI import")
elif "from azure" in app_content:
    print("\n⚠️  Found: Some Azure import, but maybe not AzureOpenAI")
    lines = app_content.split('\n')
    for i, line in enumerate(lines, 1):
        if "from azure" in line:
            print(f"   Line {i}: {line.strip()}")
else:
    print("\n❌ NOT FOUND: Azure OpenAI import")
    print("   💡 Add to top of app.py:")
    print("   from azure.ai.openai import AzureOpenAI")

print("\n" + "="*80)
print("4️⃣  CHECKING FLASK CONFIG LOADING")
print("="*80)

if "app.config.from_object(Config)" in app_content or "app.config.from_object" in app_content:
    print("\n✅ Found: Flask config loading")
    lines = app_content.split('\n')
    for i, line in enumerate(lines, 1):
        if "app.config.from_object" in line:
            print(f"   Line {i}: {line.strip()}")
else:
    print("\n❌ NOT FOUND: Flask config loading")

print("\n" + "="*80)
print("5️⃣  CHECKING FOR SYNTAX ERRORS")
print("="*80)

try:
    compile(app_content, "app.py", "exec")
    print("\n✅ app.py has valid Python syntax")
except SyntaxError as e:
    print(f"\n❌ SYNTAX ERROR in app.py:")
    print(f"   Line {e.lineno}: {e.msg}")
    if e.text:
        print(f"   {e.text.strip()}")
    print(f"\n   💡 Fix the syntax error, then restart Flask")

print("\n" + "="*80)
print("6️⃣  CHECKING .env FILE")
print("="*80)

env_path = Path(".env")
if env_path.exists():
    print("\n✅ Found: .env file")
    
    try:
        with open(".env", "r", encoding='utf-8') as f:
            env_content = f.read()
    except UnicodeDecodeError:
        with open(".env", "r", encoding='latin-1') as f:
            env_content = f.read()
    
    checks = [
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_DEPLOYMENT",
        "AZURE_OPENAI_API_VERSION"
    ]
    
    for key in checks:
        if key in env_content:
            # Find the line
            for line in env_content.split('\n'):
                if key in line and "=" in line:
                    key_part, val = line.split("=", 1)
                    if val.strip():
                        masked = val.strip()[:20] + "..." if len(val.strip()) > 20 else val.strip()
                        print(f"   ✅ {key_part.strip()} = {masked}")
                    else:
                        print(f"   ❌ {key_part.strip()} = (EMPTY)")
                    break
        else:
            print(f"   ❌ {key} NOT FOUND in .env")
else:
    print("\n❌ .env file NOT FOUND")
    print("   Current directory:", os.getcwd())
    print("   Files in directory:", os.listdir(".")[:10])

print("\n" + "="*80)
print("📊 SUMMARY & NEXT STEPS")
print("="*80)

# Count checks
checks_passed = 0
checks_total = 0

items = [
    ("load_dotenv()", "load_dotenv()" in app_content),
    ("Azure import", "from azure.ai.openai import AzureOpenAI" in app_content),
    ("Flask config", "app.config.from_object" in app_content),
    ("OpenAI client init", "app.openai_client" in app_content),
]

for name, result in items:
    checks_total += 1
    if result:
        checks_passed += 1

print(f"\n Configuration Status: {checks_passed}/{checks_total} items found\n")

for name, result in items:
    status = "✅" if result else "❌"
    print(f"   {status} {name}")

print()

if checks_passed == checks_total:
    print("✅ ALL CHECKS PASSED!")
    print("\n   Your app.py should work with LLM!")
    print("\n   Next steps:")
    print("   1. Restart Flask: Ctrl+C, then python app.py")
    print("   2. Check logs for: ✅ Azure OpenAI initialized")
    print("   3. Test query: 'Show me SAP CPI'")
    print("   4. Should show: 🔍 VECTOR_WITH_LLM")
else:
    print(f"⚠️  {checks_total - checks_passed} item(s) missing from app.py\n")
    
    if "load_dotenv()" not in app_content:
        print("   ❌ MISSING: load_dotenv()")
        print("      Add at TOP of app.py: from dotenv import load_dotenv")
        print("      Then call: load_dotenv()\n")
    
    if "from azure.ai.openai import AzureOpenAI" not in app_content:
        print("   ❌ MISSING: Azure OpenAI import")
        print("      Add: from azure.ai.openai import AzureOpenAI\n")
    
    if "app.config.from_object" not in app_content:
        print("   ❌ MISSING: Flask config loading")
        print("      Add: app.config.from_object(Config)\n")
    
    if "app.openai_client" not in app_content:
        print("   ❌ MISSING: app.openai_client initialization")
        print("      Add after app.config.from_object(Config):")
        print("""      
      try:
          app.openai_client = AzureOpenAI(
              api_key=app.config['AZURE_OPENAI_API_KEY'],
              api_version=app.config['AZURE_OPENAI_API_VERSION'],
              azure_endpoint=app.config['AZURE_OPENAI_ENDPOINT']
          )
      except Exception as e:
          app.openai_client = None
        """)

print("\n" + "="*80)
print("📁 FILES PROVIDED IN /mnt/user-data/outputs/")
print("="*80)

print("""
   1. APP_PY_FIX_CODE.py
      → Copy the initialization code from here

   2. FIX_LLM_NOW_30_SECONDS.txt
      → Quick reference for the fix

   3. WHY_LLM_NOT_CALLING.md
      → Detailed explanation

Next: Add the missing code to app.py and restart Flask!
""")

print("="*80)