"""
360° Enterprise Dashboard - Flask Application v4.5.0
WITH HYBRID RAG SYSTEM - Intelligent AI Data Assistant
WITH PROFESSIONAL JWT AUTHENTICATION
WITH AZURE OPENAI CLIENT INITIALIZATION ✅ FIXED
Seamlessly integrated with Azure OpenAI + pgvector + PostgreSQL
Features: Direct LLM, SQL-First, and Hybrid query processing

CRITICAL: .env MUST BE LOADED FIRST (before any other imports)
"""

# ============================================================================
# STEP 1: LOAD ENVIRONMENT VARIABLES FIRST (BEFORE ALL OTHER IMPORTS)
# ============================================================================
from dotenv import load_dotenv
load_dotenv()

import os
import logging
import traceback
import contextlib
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, send_from_directory, send_file
from flask_cors import CORS
from werkzeug.exceptions import HTTPException
from werkzeug.utils import secure_filename
import io
from hashlib import sha256
from openai import AzureOpenAI

# ============================================================================
# STEP 2: VERIFY .env WAS LOADED (Debug check - optional but helpful)
# ============================================================================
logger = logging.getLogger(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Print .env verification (optional debug)
if os.getenv('DB_PORT'):
    logger.info(f"✓ Environment variables loaded successfully")
    logger.info(f"  Database: {os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}")
else:
    logger.warning("⚠ Warning: Some environment variables may not be loaded")

# ============================================================================
# CONDITIONAL IMPORTS - DATABASE
# ============================================================================

try:
    from models import db, init_models
    DB_AVAILABLE = True
except Exception as db_import_err:
    DB_AVAILABLE = False
    db = None
    logger.warning(f"⚠ Database models not available: {db_import_err}")

# ============================================================================
# IMPORT AUTHENTICATION SYSTEM
# ============================================================================

try:
    from auth.auth_models import db as auth_db
    from auth.auth import auth_bp
    AUTH_AVAILABLE = True
    logger.info("✓ Professional authentication system available")
except Exception as auth_import_err:
    AUTH_AVAILABLE = False
    auth_db = None
    auth_bp = None
    logger.warning(f"⚠ Authentication system not available: {auth_import_err}")

# ============================================================================
# IMPORT CUSTOM CONNECTORS
# ============================================================================

try:
    from connectors.db_connector import get_database_connector, DatabaseConnectorError
except Exception as connector_err:
    get_database_connector = None
    DatabaseConnectorError = Exception
    logger.warning(f"⚠ Database connector not available: {connector_err}")

try:
    from connectors.azure_openai_connector import get_azure_openai_connector, AzureOpenAIConnectorError
except Exception:
    get_azure_openai_connector = None
    AzureOpenAIConnectorError = Exception

try:
    from connectors.azure_storage_connector import get_azure_storage_connector, AzureStorageConnectorError
except Exception:
    get_azure_storage_connector = None
    AzureStorageConnectorError = Exception

try:
    from connectors.sharepoint_connector import get_sharepoint_connector, SharePointConnectorError
except Exception:
    get_sharepoint_connector = None
    SharePointConnectorError = Exception

# ============================================================================
# IMPORT HYBRID RAG SERVICES
# ============================================================================

HYBRID_RAG_SERVICES_AVAILABLE = False

try:
    from services.database import get_db_connection, get_db_session, init_db, check_db_health
    HYBRID_RAG_SERVICES_AVAILABLE = True
    logger.info("✓ Hybrid RAG database services available")
except Exception as services_err:
    logger.warning(f"⚠ Hybrid RAG services not available: {services_err}")
    HYBRID_RAG_SERVICES_AVAILABLE = False

try:
    from services.hybrid_rag_service import HybridRAGService
except Exception as rag_err:
    HybridRAGService = None
    logger.warning(f"⚠ HybridRAGService not available: {rag_err}")

try:
    from services.data_import_service import DataImportService
except Exception as import_err:
    DataImportService = None
    DataImportError = Exception
    logger.warning(f"⚠ DataImportService not available: {import_err}")

# ============================================================================
# IMPORT CHAT BLUEPRINT - DUAL STRATEGY
# ============================================================================

CHATBOT_AVAILABLE = False
HYBRID_RAG_AVAILABLE = False
chat_bp = None

logger.info("\n" + "="*80)
logger.info("ATTEMPTING TO IMPORT CHAT BLUEPRINT")
logger.info("="*80 + "\n")

# Strategy 1: Direct import from routes.chat
try:
    logger.info("Strategy 1: Importing directly from routes.chat...")
    from routes.chat import chat_bp
    CHATBOT_AVAILABLE = True
    HYBRID_RAG_AVAILABLE = True
    logger.info("✓ SUCCESS: Chat blueprint imported from routes.chat")
    logger.info("  🧠 Hybrid RAG Features: Intelligent Routing, pgvector, SQL Generation")
except Exception as direct_err:
    logger.warning(f"⚠ Strategy 1 failed: {direct_err}")
    
    # Strategy 2: Import from routes package (via __init__.py)
    try:
        logger.info("Strategy 2: Importing from routes package...")
        from routes import chat_bp
        CHATBOT_AVAILABLE = True
        HYBRID_RAG_AVAILABLE = True
        logger.info("✓ SUCCESS: Chat blueprint imported from routes package")
        logger.info("  🧠 Hybrid RAG Features: Intelligent Routing, pgvector, SQL Generation")
    except Exception as package_err:
        logger.error(f"✗ Strategy 2 failed: {package_err}")
        CHATBOT_AVAILABLE = False
        HYBRID_RAG_AVAILABLE = False
        chat_bp = None

logger.info("\n" + "="*80 + "\n")

# ============================================================================
# CUSTOM EXCEPTIONS
# ============================================================================

class DatabaseError(Exception):
    """Custom exception for database-related errors"""
    pass

class AuthenticationError(Exception):
    """Custom exception for authentication errors"""
    pass

class AIServiceError(Exception):
    """Custom exception for AI service errors"""
    pass

class StorageError(Exception):
    """Custom exception for storage service errors"""
    pass

class SplunkQueryError(Exception):
    """Custom exception for Splunk query errors"""
    pass

class SharePointError(Exception):
    """Custom exception for SharePoint errors"""
    pass

# ============================================================================
# IN-MEMORY STORAGE (FALLBACK)
# ============================================================================

class InMemoryStorage:
    """In-memory storage for when database is unavailable"""
    
    def __init__(self):
        self.users = {}
        self.next_user_id = 1
        
    def create_user(self, email, name, password_hash):
        """Create user in memory"""
        user_id = self.next_user_id
        self.next_user_id += 1
        
        self.users[user_id] = {
            'id': user_id,
            'email': email,
            'name': name,
            'password_hash': password_hash,
            'is_active': True,
            'created_at': datetime.utcnow(),
            'last_login': None
        }
        return self.users[user_id]
    
    def get_user_by_email(self, email):
        """Get user by email"""
        for user in self.users.values():
            if user['email'] == email:
                return user
        return None
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        return self.users.get(user_id)
    
    def update_user_login(self, user_id):
        """Update last login time"""
        if user_id in self.users:
            self.users[user_id]['last_login'] = datetime.utcnow()

# ============================================================================
# GLOBAL CONNECTORS & MODELS
# ============================================================================

db_connector = None
ai_connector = None
storage_connector = None
sharepoint_connector = None
openai_client = None  # ✅ GLOBAL AZURE OPENAI CLIENT
in_memory_storage = InMemoryStorage()

User = None
AzureIntegration = None
SharePointIntegration = None
AIInteraction = None
StorageFile = None
SplunkQuery = None

DATABASE_MODE = 'unavailable'

# ============================================================================
# FILE UPLOAD CONFIGURATION
# ============================================================================

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'py', 'js', 'java', 'cpp', 'c'}
MAX_FILE_SIZE = 10 * 1024 * 1024

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ============================================================================
# PASSWORD HASHING
# ============================================================================

def hash_password(password):
    """Simple password hashing for in-memory mode"""
    return sha256(password.encode()).hexdigest()

def verify_password(stored_hash, provided_password):
    """Verify password against hash"""
    return stored_hash == hash_password(provided_password)

# ============================================================================
# DECORATORS
# ============================================================================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            if 'user_id' not in session:
                return redirect(url_for('login_page'))
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"✗ Login required decorator error: {e}")
            return redirect(url_for('login_page'))
    return decorated_function

def api_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            if 'user_id' not in session:
                return jsonify({'error': 'Unauthorized', 'message': 'User session not found'}), 401
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"✗ API login required decorator error: {e}")
            return jsonify({'error': 'Authentication failed', 'message': str(e)}), 401
    return decorated_function

# ============================================================================
# DATABASE OPERATIONS (WITH FALLBACK)
# ============================================================================

def get_user_by_email(email):
    """Get user by email - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return User.query.filter_by(email=email).first()
        else:
            return in_memory_storage.get_user_by_email(email)
    except Exception as e:
        logger.warning(f"⚠ Error fetching user: {e}")
        return in_memory_storage.get_user_by_email(email)

def get_user_by_id(user_id):
    """Get user by ID - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return db.session.get(User, user_id)
        else:
            return in_memory_storage.get_user_by_id(user_id)
    except Exception as e:
        logger.warning(f"⚠ Error fetching user by ID: {e}")
        return in_memory_storage.get_user_by_id(user_id)

def create_user(email, name, password):
    """Create user - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            user = User(email=email, name=name, is_active=True)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return user
        else:
            password_hash = hash_password(password)
            return in_memory_storage.create_user(email, name, password_hash)
    except Exception as e:
        logger.error(f"✗ Error creating user: {e}")
        if DATABASE_MODE == 'available':
            try:
                db.session.rollback()
            except:
                pass
        password_hash = hash_password(password)
        return in_memory_storage.create_user(email, name, password_hash)

def verify_user_password(user, password):
    """Verify user password - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return user.check_password(password)
        else:
            return verify_password(user['password_hash'], password)
    except Exception as e:
        logger.warning(f"⚠ Error verifying password: {e}")
        return False

# ============================================================================
# APPLICATION FACTORY
# ============================================================================

def create_app(config_name='development'):
    """Create and configure Flask application"""
    
    global db_connector, ai_connector, storage_connector, sharepoint_connector, openai_client
    global User, AzureIntegration, SharePointIntegration, AIInteraction, StorageFile, SplunkQuery
    global DATABASE_MODE
    
    try:
        BACKEND_DIR = os.path.abspath(os.path.dirname(__file__))
        PROJECT_ROOT = os.path.dirname(BACKEND_DIR)
        FRONTEND_DIR = os.path.join(PROJECT_ROOT, 'frontend')
        
        logger.info(f"✓ Backend directory: {BACKEND_DIR}")
        logger.info(f"✓ Project root: {PROJECT_ROOT}")
        logger.info(f"✓ Frontend directory: {FRONTEND_DIR}")
        
        if not os.path.exists(FRONTEND_DIR):
            logger.warning(f"⚠ Frontend folder not found at: {FRONTEND_DIR}")
        else:
            logger.info(f"✓ Frontend folder verified!")
        
        app = Flask(
            __name__,
            template_folder=FRONTEND_DIR,
            static_folder=os.path.join(FRONTEND_DIR, 'assets'),
            static_url_path='/assets'
        )
        
        # ====================================================================
        # LOAD CONFIG FROM config.py
        # ====================================================================
        try:
            from config import get_config
            cfg = get_config(config_name)
            app.config.from_object(cfg)
            logger.info("✓ Config loaded from config.py")
            logger.info(f"  Database: {cfg.DB_HOST}:{cfg.DB_PORT}/{cfg.DB_NAME}")
            logger.info(f"  Azure OpenAI: {bool(cfg.AZURE_OPENAI_API_KEY)}")
        except Exception as config_err:
            logger.warning(f"⚠ Config loading error: {config_err}")

        # ====================================================================
        # DATABASE INITIALIZATION (ENHANCED FOR HYBRID RAG)
        # ====================================================================
        
        db_initialized = False
        
        if DB_AVAILABLE:
            try:
                logger.info("🔌 Initializing Database Connector for Hybrid RAG...")
                
                # CRITICAL: Get database connector (reads from .env now)
                db_connector = get_database_connector() if get_database_connector else None
                
                if db_connector:
                    logger.info(f"✓ Database Connector created")
                    logger.info(f"  Host: {db_connector.db_host}:{db_connector.db_port}")
                    logger.info(f"  Database: {db_connector.db_name}")
                    
                    conn_test = db_connector.test_connection()
                    if conn_test.get('connected'):
                        logger.info(f"✓ Database connection verified: {conn_test.get('version', 'Unknown version')}")
                        
                        try:
                            from sqlalchemy import text
                            with app.app_context() if hasattr(app, 'app_context') else contextlib.nullcontext():
                                result = db.session.execute(text("SELECT extname FROM pg_extension WHERE extname = 'vector'"))
                                has_pgvector = result.fetchone() is not None
                                if has_pgvector:
                                    logger.info("✓ pgvector extension detected - Hybrid RAG ready!")
                                else:
                                    logger.warning("⚠ pgvector not found - Run: CREATE EXTENSION vector;")
                        except:
                            logger.info("ℹ pgvector check skipped (will verify during setup)")
                        
                        db_initialized = True
                    else:
                        logger.warning(f"⚠ Database connection test failed: {conn_test.get('error', 'Unknown error')}")
                else:
                    logger.warning("⚠ Database connector not available")
            
            except Exception as db_init_err:
                logger.warning(f"⚠ Database connector initialization warning: {db_init_err}")
        else:
            logger.warning("⚠ Database models not available - using in-memory storage")
        
        # ====================================================================
        # CONFIGURE FLASK
        # ====================================================================
        
        if db_initialized and db_connector:
            try:
                db_config = db_connector.get_sqlalchemy_config()
                for key, value in db_config.items():
                    app.config[key] = value
                logger.info("✓ SQLAlchemy configuration applied")
            except Exception as db_config_err:
                logger.warning(f"⚠ Database configuration error: {db_config_err}")
                db_initialized = False
        
        if not db_initialized:
            app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
            app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        
        app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
        app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
        app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE
        
        # ====================================================================
        # INITIALIZE EXTENSIONS
        # ====================================================================
        
        try:
            if DB_AVAILABLE and db is not None:
                db.init_app(app)
                
                # Initialize auth_db if available
                if AUTH_AVAILABLE and auth_db is not None:
                    auth_db.init_app(app)
                    logger.info("✓ Authentication database initialized")
                
                CORS(app)
                logger.info("✓ Flask extensions initialized")
                
                with app.app_context():
                    try:
                        models = init_models(db)
                        globals()['User'] = models['User']
                        globals()['AzureIntegration'] = models['AzureIntegration']
                        globals()['SharePointIntegration'] = models['SharePointIntegration']
                        globals()['AIInteraction'] = models['AIInteraction']
                        globals()['StorageFile'] = models['StorageFile']
                        globals()['SplunkQuery'] = models['SplunkQuery']
                        
                        db.create_all()
                        logger.info("✓ Database tables created/verified successfully")
                        DATABASE_MODE = 'available'
                        
                        demo_email = 'demo@example.com'
                        existing_user = User.query.filter_by(email=demo_email).first()
                        if not existing_user:
                            demo_user = User(email=demo_email, name='Demo User', is_active=True)
                            demo_user.set_password('demo123')
                            db.session.add(demo_user)
                            db.session.commit()
                            logger.info(f"✓ Demo user created: {demo_email} / demo123")
                        
                    except Exception as models_err:
                        logger.warning(f"⚠ Models initialization error: {models_err}")
                        DATABASE_MODE = 'unavailable'
                        in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
            else:
                CORS(app)
                DATABASE_MODE = 'unavailable'
                logger.info("⚠ Using in-memory storage mode")
                in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
        
        except Exception as ext_err:
            logger.warning(f"⚠ Extension initialization warning: {ext_err}")
            CORS(app)
            DATABASE_MODE = 'unavailable'
            try:
                in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
            except:
                pass
        
        # ====================================================================
        # INITIALIZE HYBRID RAG SERVICES
        # ====================================================================
        
        if HYBRID_RAG_SERVICES_AVAILABLE:
            try:
                logger.info("🧠 Initializing Hybrid RAG Services...")
                
                try:
                    init_db()
                    logger.info("✓ Hybrid RAG database initialized")
                except Exception as rag_db_err:
                    logger.warning(f"⚠ RAG database initialization: {rag_db_err}")
                
                try:
                    rag_health = check_db_health()
                    if rag_health.get('status') == 'healthy':
                        logger.info("✓ Hybrid RAG database health: OK")
                    else:
                        logger.warning(f"⚠ Hybrid RAG health: {rag_health.get('status')}")
                except Exception as rag_health_err:
                    logger.warning(f"⚠ RAG health check: {rag_health_err}")
                
            except Exception as rag_init_err:
                logger.warning(f"⚠ Hybrid RAG services warning: {rag_init_err}")
        
        # ====================================================================
        # INITIALIZE AZURE OPENAI CLIENT ✅ NEW - CRITICAL FIX
        # ====================================================================
        
        try:
            logger.info("🤖 Creating Azure OpenAI Client for Hybrid RAG...")
            from openai import AzureOpenAI
            
            # Check if we have required credentials
            if (app.config.get('AZURE_OPENAI_API_KEY') and 
                app.config.get('AZURE_OPENAI_ENDPOINT') and 
                app.config.get('AZURE_OPENAI_DEPLOYMENT')):
                
                try:
                    # Create the Azure OpenAI client
                    openai_client = AzureOpenAI(
                        api_key=app.config['AZURE_OPENAI_API_KEY'],
                        api_version=app.config['AZURE_OPENAI_API_VERSION'],
                        azure_endpoint=app.config['AZURE_OPENAI_ENDPOINT']
                    )
                    
                    logger.info(f"✅ Azure OpenAI client created successfully!")
                    logger.info(f"   📝 Deployment: {app.config['AZURE_OPENAI_DEPLOYMENT']}")
                    logger.info(f"   🔗 API Version: {app.config['AZURE_OPENAI_API_VERSION']}")
                    logger.info(f"   🌐 Endpoint: {app.config['AZURE_OPENAI_ENDPOINT'][:50]}...")
                    
                    # Store in app.extensions for later use in routes
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['openai_client'] = openai_client
                    
                except Exception as client_create_err:
                    logger.error(f"❌ Failed to create OpenAI client: {client_create_err}")
                    logger.error(f"   💡 Check your Azure credentials:")
                    logger.error(f"      - AZURE_OPENAI_API_KEY")
                    logger.error(f"      - AZURE_OPENAI_ENDPOINT")
                    logger.error(f"      - AZURE_OPENAI_DEPLOYMENT")
                    openai_client = None
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['openai_client'] = None
            else:
                logger.warning("⚠️  Missing Azure OpenAI credentials in config!")
                logger.warning(f"   ❌ AZURE_OPENAI_API_KEY: {bool(app.config.get('AZURE_OPENAI_API_KEY'))}")
                logger.warning(f"   ❌ AZURE_OPENAI_ENDPOINT: {bool(app.config.get('AZURE_OPENAI_ENDPOINT'))}")
                logger.warning(f"   ❌ AZURE_OPENAI_DEPLOYMENT: {bool(app.config.get('AZURE_OPENAI_DEPLOYMENT'))}")
                logger.warning(f"   💡 Add to .env file:")
                logger.warning(f"      AZURE_OPENAI_API_KEY=your-key")
                logger.warning(f"      AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
                logger.warning(f"      AZURE_OPENAI_DEPLOYMENT=gpt-35-turbo")
                openai_client = None
                if not hasattr(app, 'extensions'):
                    app.extensions = {}
                app.extensions['openai_client'] = None

        except ImportError as import_err:
            logger.error(f"❌ OpenAI SDK not installed!")
            logger.error(f"   💡 Run: pip install openai")
            openai_client = None
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['openai_client'] = None
        except Exception as openai_init_err:
            logger.error(f"❌ Unexpected error initializing OpenAI: {openai_init_err}")
            import traceback
            logger.error(traceback.format_exc())
            openai_client = None
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['openai_client'] = None
        
        # ====================================================================
        # INITIALIZE AZURE OPENAI CONNECTOR ✅ PRODUCTION-READY
        # ====================================================================

        try:
            logger.info("🤖 Initializing Azure OpenAI Connector...")
            
            # Use the production-ready connector with proper validation
            if get_azure_openai_connector:
                ai_connector = get_azure_openai_connector(config=app.config)
                
                if ai_connector and ai_connector.is_available():
                    # Test the connection
                    test_result = ai_connector.test_connection()
                    
                    if test_result.get('status') == 'success':
                        logger.info("✅ Azure OpenAI Connector initialized and tested!")
                        logger.info(f"   🤖 Model: {ai_connector.deployment}")
                        logger.info(f"   📊 Max Tokens: {ai_connector.max_tokens}")
                        logger.info(f"   🌡️  Temperature: {'Supported' if ai_connector.model_config['supports_temperature'] else 'Fixed at 1.0'}")
                        
                        # Store in app.extensions
                        if not hasattr(app, 'extensions'):
                            app.extensions = {}
                        app.extensions['azure_openai_connector'] = ai_connector
                    else:
                        logger.warning(f"⚠ Azure OpenAI test failed: {test_result.get('message')}")
                        logger.warning(f"   💡 Missing or invalid credentials")
                        if not hasattr(app, 'extensions'):
                            app.extensions = {}
                        app.extensions['azure_openai_connector'] = None
                else:
                    logger.warning("⚠ Azure OpenAI Connector not available")
                    logger.warning(f"   Add to .env:")
                    logger.warning(f"   - AZURE_OPENAI_API_KEY")
                    logger.warning(f"   - AZURE_OPENAI_ENDPOINT")
                    logger.warning(f"   - AZURE_OPENAI_DEPLOYMENT")
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['azure_openai_connector'] = None
            else:
                logger.warning("⚠ Azure OpenAI connector module not found")
                if not hasattr(app, 'extensions'):
                    app.extensions = {}
                app.extensions['azure_openai_connector'] = None

        except Exception as openai_init_err:
            logger.warning(f"⚠ Azure OpenAI initialization: {openai_init_err}")
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['azure_openai_connector'] = None

        
        try:
            logger.info("💾 Initializing Azure Storage Connector...")
            storage_connector = get_azure_storage_connector() if get_azure_storage_connector else None
            if storage_connector:
                try:
                    storage_health = storage_connector.health_check()
                    if storage_health.get('status') == 'healthy':
                        logger.info("✓ Azure Storage service verified")
                except:
                    logger.warning("⚠ Azure Storage health check failed")
            else:
                logger.warning("⚠ Azure Storage connector not available - Storage features disabled")
        except Exception as storage_init_err:
            logger.warning(f"⚠ Azure Storage connector initialization warning: {storage_init_err}")
        
        try:
            logger.info("📄 Initializing SharePoint Connector...")
            sharepoint_connector = get_sharepoint_connector() if get_sharepoint_connector else None
            if sharepoint_connector:
                try:
                    sp_health = sharepoint_connector.health_check()
                    if sp_health.get('status') == 'healthy':
                        logger.info("✓ SharePoint service verified")
                except:
                    logger.warning("⚠ SharePoint health check failed")
            else:
                logger.warning("⚠ SharePoint connector not available - SharePoint features disabled")
        except Exception as sp_init_err:
            logger.warning(f"⚠ SharePoint connector initialization warning: {sp_init_err}")
        
        # ====================================================================
        # REGISTER BLUEPRINTS - AUTHENTICATION FIRST
        # ====================================================================
        
        # Register Authentication Blueprint FIRST
        if AUTH_AVAILABLE and auth_bp:
            try:
                app.register_blueprint(auth_bp)
                logger.info("✓ Professional Authentication blueprint registered")
                logger.info("  JWT tokens enabled")
                logger.info("  Endpoints:")
                logger.info("    POST /api/auth/register - User registration")
                logger.info("    POST /api/auth/login - User login (JWT)")
                logger.info("    POST /api/auth/logout - User logout")
                logger.info("    GET /api/auth/me - Get current user")
                logger.info("    POST /api/auth/forgot-password - Password reset")
                logger.info("    POST /api/auth/change-password - Change password")
            except Exception as auth_reg_err:
                logger.warning(f"⚠ Failed to register auth blueprint: {auth_reg_err}")
        else:
            logger.warning("⚠ Professional authentication not available - using basic auth")

        
        # ====================================================================
        # REGISTER SPLUNK BLUEPRINT
        # ====================================================================

        try:
            from routes.splunk import splunk_bp
            app.register_blueprint(splunk_bp)
            logger.info("✓ Splunk routes blueprint registered")
            logger.info("  📊 Splunk API Endpoints:")
            logger.info("     - POST /api/splunk/search - Execute search query")
            logger.info("     - POST /api/splunk/search/stats - Statistics aggregations")
            logger.info("     - POST /api/splunk/search/timechart - Time-series data")
            logger.info("     - POST /api/splunk/analytics/top-events - Top events analysis")
            logger.info("     - POST /api/splunk/analytics/index-stats - Index statistics")
            logger.info("     - GET /api/splunk/health - Service health")
            logger.info("     - GET /api/splunk/status - Connector status")
            logger.info("     - POST /api/splunk/test - Test connection")
        except ImportError as splunk_import_err:
            logger.warning(f"⚠ Splunk routes not found: {splunk_import_err}")
        except Exception as splunk_reg_err:
            logger.warning(f"⚠ Failed to register Splunk blueprint: {splunk_reg_err}")

        
        # ====================================================================
        # REGISTER DATABASE BLUEPRINT
        # ====================================================================

        try:
            from routes.generic_db_routes import db_bp
            app.register_blueprint(db_bp)
            logger.info("✓ Generic database API blueprint registered")
            logger.info("  📊 Endpoints:")
            logger.info("     - POST /api/db/aggregate - Aggregation queries (GROUP BY)")
            logger.info("     - POST /api/db/aggregate/chart - Chart.js formatted aggregation")
            logger.info("     - POST /api/db/stats - Statistical queries")
            logger.info("     - POST /api/db/records - Fetch records with filtering")
            logger.info("     - POST /api/db/query - Raw SQL queries (with validation)")
            logger.info("     - GET /api/db/health - Service health check")
        except Exception as db_reg_err:
            logger.warning(f"⚠ Failed to register database blueprint: {db_reg_err}")


        # ====================================================================
        # REGISTER SHAREPOINT BLUEPRINT
        # ====================================================================

        try:
            from routes.sharepoint import sharepoint_bp
            app.register_blueprint(sharepoint_bp)
            logger.info("✓ SharePoint routes blueprint registered")
            logger.info("  📄 SharePoint API Endpoints (GET-Only - Read-Only Access):")
            logger.info("     - GET /api/sharepoint/health")
            logger.info("     - GET /api/sharepoint/site-info")
            logger.info("     - GET /api/sharepoint/statistics")
            logger.info("     - GET /api/sharepoint/libraries")
            logger.info("     - GET /api/sharepoint/documents/<lib_id>")
            logger.info("     - GET /api/sharepoint/download/<lib_id>/<item_id>")
            logger.info("     - GET /api/sharepoint/search")
            logger.info("     - GET /api/sharepoint/lists")
            logger.info("  🔒 Security: Read-only access only (upload/delete disabled)")
        except ImportError as sharepoint_import_err:
            logger.warning(f"⚠ SharePoint routes not found: {sharepoint_import_err}")
        except Exception as sharepoint_reg_err:
            logger.warning(f"⚠ Failed to register SharePoint blueprint: {sharepoint_reg_err}")


        # Register Chat Blueprint
        if CHATBOT_AVAILABLE and chat_bp:
            try:
                app.register_blueprint(chat_bp)
                
                if HYBRID_RAG_AVAILABLE:
                    logger.info("✓ Hybrid RAG Chat blueprint registered")
                    logger.info("  🧠 Features: Intelligent Routing + pgvector + SQL Generation")
                    logger.info("  📍 Endpoints:")
                    logger.info("     - POST /chat/upload - Import Excel → PostgreSQL + Embeddings")
                    logger.info("     - POST /chat/send_message - Intelligent query processing")
                    logger.info("     - GET /chat/stats - Data statistics")
                    logger.info("     - GET /chat/health - System health check")
                else:
                    logger.info("✓ Standard chat blueprint registered")
                    logger.info("  Available at: /chat")
            
            except Exception as chat_reg_err:
                logger.warning(f"⚠ Failed to register chat blueprint: {chat_reg_err}")
        else:
            logger.warning("⚠ Chat blueprint not registered - feature unavailable")
        
        # ====================================================================
        # FRONTEND ROUTES
        # ====================================================================
        
        @app.route('/')
        def index():
            try:
                if 'user_id' in session:
                    return redirect(url_for('dashboard'))
                try:
                    return render_template('index.html')
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    index_path = os.path.join(FRONTEND_DIR, 'index.html')
                    if os.path.exists(index_path):
                        with open(index_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Index page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering index page: {e}")
                return jsonify({'error': 'Failed to load index page'}), 500
        
        @app.route('/login')
        def login_page():
            try:
                if 'user_id' in session:
                    return redirect(url_for('dashboard'))
                try:
                    return render_template('auth/login.html')
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    login_path = os.path.join(FRONTEND_DIR, 'auth', 'login.html')
                    if os.path.exists(login_path):
                        with open(login_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Login page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering login page: {e}")
                return jsonify({'error': 'Failed to load login page'}), 500
        
        @app.route('/dashboard')
        @login_required
        def dashboard():
            try:
                user = get_user_by_id(session['user_id'])
                
                if not user:
                    session.clear()
                    return redirect(url_for('login_page'))
                
                azure_integrations = []
                sharepoint_integrations = []
                
                if DATABASE_MODE == 'available':
                    try:
                        azure_integrations = AzureIntegration.query.filter_by(user_id=user.id).all()
                    except:
                        pass
                    
                    try:
                        sharepoint_integrations = SharePointIntegration.query.filter_by(user_id=user.id).all()
                    except:
                        pass
                
                try:
                    return render_template('dashboard_overview/index.html', 
                                         user=user,
                                         azure_integrations=azure_integrations,
                                         sharepoint_integrations=sharepoint_integrations,
                                         azure_count=len(azure_integrations),
                                         sharepoint_count=len(sharepoint_integrations))
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    dashboard_path = os.path.join(FRONTEND_DIR, 'dashboard_overview', 'index.html')
                    if os.path.exists(dashboard_path):
                        with open(dashboard_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Dashboard page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering dashboard: {e}")
                return jsonify({'error': 'Failed to load dashboard'}), 500
        
        # ====================================================================
        # ROUTES - FACTORY PATTERN
        # ====================================================================
        
        def create_route(route_path, template_path, page_title, prefix):
            """Factory function to create routes"""
            def route_handler():
                try:
                    user = get_user_by_id(session['user_id'])
                    try:
                        return render_template(template_path, user=user, page_title=page_title)
                    except Exception as template_err:
                        logger.warning(f"⚠ Template {template_path} not found via render_template: {template_err}")
                        
                        template_parts = template_path.split('/')
                        template_file = os.path.join(FRONTEND_DIR, *template_parts)
                        
                        if os.path.exists(template_file):
                            with open(template_file, 'r', encoding='utf-8') as f:
                                return f.read()
                        else:
                            return jsonify({
                                'error': f'Template not found: {template_path}',
                                'path': template_file
                            }), 404
                            
                except Exception as e:
                    logger.error(f"✗ Error rendering {page_title} page: {e}")
                    return jsonify({'error': f'Failed to load page: {str(e)}'}), 500
            
            unique_name = f'{prefix}_{route_path.replace("/", "_").replace("-", "_")}'
            route_handler.__name__ = unique_name
            route_handler = login_required(route_handler)
            app.add_url_rule(route_path, unique_name, route_handler)
        
        # Integration routes
        integration_routes = [
            ('/integrations/azure/apim', 'integrations/azure/apim.html', 'Azure API Management'),
            ('/integrations/azure/storage', 'integrations/azure/storage.html', 'Azure File Storage'),
            ('/integrations/azure/openai', 'integrations/azure/openai.html', 'Azure OpenAI'),
            ('/integrations/azure/postgresql', 'integrations/azure/postgresql.html', 'Azure PostgreSQL'),
            ('/integrations/mft', 'integrations/mft.html', 'Managed File Transfer'),
            ('/integrations/sap-cpi', 'integrations/sap-cpi.html', 'SAP Cloud Platform Integration'),
            ('/integrations/ibm-api-connect', 'integrations/ibm-api-connect.html', 'IBM API Connect'),
            ('/integrations/ibm-datapower', 'integrations/ibm-datapower.html', 'IBM DataPower'),
            ('/integrations/splunk', 'integrations/splunk.html', 'Splunk'),
            ('/integrations/sharepoint', 'integrations/sharepoint.html', 'SharePoint'),
            ('/integrations/api-gateway', 'integrations/api-gateway.html', 'API Gateway'),
            ('/integrations/excel', 'integrations/excel.html', 'Excel'),
        ]
        
        for route, template, title in integration_routes:
            create_route(route, template, title, 'integration')
        
        # Chat route
        chat_routes = [
            ('/chat', 'chat/chat.html', 'Chat'),
        ]
        
        for route, template, title in chat_routes:
            create_route(route, template, title, 'chat')
        
        # Data management routes
        data_routes = [
            ('/data-management/import', 'data_management/import.html', 'Import Data'),
            ('/data-management/tables', 'data_management/tables.html', 'Data Tables'),
            ('/data-management/sync-history', 'data_management/sync-history.html', 'Sync History'),
            ('/data-management/analytics', 'data_management/analytics.html', 'Data Analytics'),
        ]

        for route, template, title in data_routes:
            create_route(route, template, title, 'data')
        
        # Services routes
        services_routes = [
            ('/services/system-health', 'services_monitoring/system-health.html', 'System Health'),
            ('/services/reports', 'services_monitoring/reports.html', 'Reports'),
            ('/services/analytics', 'services_monitoring/services-analytics.html', 'Services Analytics'),
            ('/services/security', 'services_monitoring/security.html', 'Security'),
        ]
        
        for route, template, title in services_routes:
            create_route(route, template, title, 'service')
        
        # Resources routes
        resources_routes = [
            ('/resources/videos', 'resources/videos.html', 'Video Guides'),
            ('/resources/documentation', 'resources/documentation.html', 'Documentation'),
            ('/resources/faq', 'resources/faq.html', 'FAQ'),
            ('/resources/support', 'resources/support.html', 'Support'),
        ]
        
        for route, template, title in resources_routes:
            create_route(route, template, title, 'resource')
        
        # Account routes
        @app.route('/profile')
        @login_required
        def profile():
            try:
                user = get_user_by_id(session['user_id'])
                if not user:
                    session.clear()
                    return redirect(url_for('login_page'))
                return render_template('account/profile.html', user=user, page_title='Profile')
            except Exception as e:
                logger.error(f"✗ Error rendering profile page: {e}")
                return jsonify({'error': 'Failed to load page'}), 500
        
        @app.route('/settings')
        @login_required
        def settings():
            try:
                user = get_user_by_id(session['user_id'])
                if not user:
                    session.clear()
                    return redirect(url_for('login_page'))
                return render_template('account/settings.html', user=user, page_title='Settings')
            except Exception as e:
                logger.error(f"✗ Error rendering settings page: {e}")
                return jsonify({'error': 'Failed to load page'}), 500
        
        @app.route('/assets/<path:filename>')
        def serve_assets(filename):
            try:
                assets_path = os.path.join(FRONTEND_DIR, 'assets')
                return send_from_directory(assets_path, filename)
            except FileNotFoundError:
                logger.warning(f"⚠ Asset not found: {filename}")
                return jsonify({'error': 'Asset not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error serving asset {filename}: {e}")
                return jsonify({'error': 'Failed to serve asset'}), 500
        
        # ====================================================================
        # API ROUTES
        # ====================================================================
        
        @app.route('/api/debug/models')
        def debug_models():
            """Debug endpoint to check system status"""
            try:
                return jsonify({
                    'database_mode': DATABASE_MODE,
                    'user_model': str(User) if User else 'In-memory storage',
                    'db_available': DATABASE_MODE == 'available',
                    'in_memory_users': len(in_memory_storage.users),
                    'chatbot_available': CHATBOT_AVAILABLE,
                    'hybrid_rag_available': HYBRID_RAG_AVAILABLE,
                    'hybrid_rag_services': HYBRID_RAG_SERVICES_AVAILABLE,
                    'auth_available': AUTH_AVAILABLE,
                    'chat_bp': str(chat_bp) if chat_bp else 'None',
                    'openai_client_available': openai_client is not None,
                    'db_connector': {
                        'host': db_connector.db_host if db_connector else 'N/A',
                        'port': db_connector.db_port if db_connector else 'N/A',
                        'database': db_connector.db_name if db_connector else 'N/A'
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            except Exception as e:
                logger.error(f"Debug error: {e}")
                return jsonify({'error': str(e)}), 500
        
        @app.route('/api/auth/register', methods=['POST'])
        def register():
            try:
                data = request.get_json()
                
                if not data:
                    return jsonify({'error': 'No JSON data provided'}), 400
                
                required_fields = ['email', 'password', 'name']
                missing_fields = [f for f in required_fields if not data.get(f)]
                
                if missing_fields:
                    return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400
                
                email = data.get('email', '').strip()
                if '@' not in email or '.' not in email:
                    return jsonify({'error': 'Invalid email format'}), 400
                
                existing_user = get_user_by_email(email)
                if existing_user:
                    return jsonify({'error': 'Email already registered'}), 409
                
                user = create_user(email, data.get('name', '').strip(), data.get('password'))
                
                session['user_id'] = user.get('id') if isinstance(user, dict) else user.id
                session.permanent = True
                
                logger.info(f"✓ User registered: {email}")
                
                user_dict = user if isinstance(user, dict) else {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name
                }
                
                return jsonify({
                    'message': 'User registered successfully',
                    'user': user_dict
                }), 201
                
            except Exception as e:
                logger.error(f"✗ Unexpected error in registration: {e}")
                return jsonify({'error': 'Registration failed'}), 500
        
        @app.route('/api/auth/login', methods=['POST'])
        def login():
            try:
                data = request.get_json()
                
                if not data:
                    return jsonify({'error': 'No JSON data provided'}), 400
                
                email = data.get('email', '').strip()
                password = data.get('password', '')
                
                if not email or not password:
                    return jsonify({'error': 'Email and password are required'}), 400
                
                logger.info(f"🔍 Attempting login for: {email}")
                
                user = get_user_by_email(email)
                
                if not user:
                    logger.warning(f"⚠ User not found: {email}")
                    return jsonify({'error': 'Invalid email or password'}), 401
                
                if not verify_user_password(user, password):
                    logger.warning(f"⚠ Invalid password for user: {email}")
                    return jsonify({'error': 'Invalid email or password'}), 401
                
                is_active = user.get('is_active') if isinstance(user, dict) else user.is_active
                if not is_active:
                    logger.warning(f"⚠ Login attempt for inactive user: {email}")
                    return jsonify({'error': 'Account is inactive'}), 403
                
                try:
                    if DATABASE_MODE == 'available':
                        user_obj = User.query.get(user.id if hasattr(user, 'id') else user['id'])
                        user_obj.last_login = datetime.utcnow()
                        db.session.commit()
                    else:
                        in_memory_storage.update_user_login(user['id'])
                except Exception as update_err:
                    logger.warning(f"⚠ Failed to update last_login: {update_err}")
                
                user_id = user.get('id') if isinstance(user, dict) else user.id
                session['user_id'] = user_id
                session.permanent = True
                
                logger.info(f"✓ User logged in successfully: {email}")
                
                return jsonify({
                    'success': True,
                    'message': 'Login successful',
                    'user': {
                        'id': user_id,
                        'email': user.get('email') if isinstance(user, dict) else user.email,
                        'name': user.get('name') if isinstance(user, dict) else user.name
                    }
                }), 200
                
            except Exception as e:
                logger.error(f"✗ Unexpected error in login: {e}")
                return jsonify({'error': 'Login failed'}), 500
        
        @app.route('/api/auth/logout', methods=['POST'])
        @api_login_required
        def logout():
            try:
                user = get_user_by_id(session.get('user_id'))
                user_email = user.get('email') if isinstance(user, dict) else user.email if user else 'Unknown'
                
                session.clear()
                logger.info(f"✓ User logged out: {user_email}")
                return jsonify({'message': 'Logged out successfully'}), 200
            
            except Exception as e:
                logger.error(f"✗ Error during logout: {e}")
                return jsonify({'error': 'Logout failed'}), 500
        
        @app.route('/api/auth/me', methods=['GET'])
        @api_login_required
        def get_current_user():
            try:
                user = get_user_by_id(session['user_id'])
                
                if not user:
                    session.clear()
                    return jsonify({'error': 'User not found'}), 404
                
                if isinstance(user, dict):
                    return jsonify(user), 200
                else:
                    return jsonify(user.to_dict()), 200
            
            except Exception as e:
                logger.error(f"✗ Error fetching current user: {e}")
                return jsonify({'error': 'Failed to fetch user info'}), 500
        
        # ====================================================================
        # ERROR HANDLERS
        # ====================================================================
        
        @app.errorhandler(400)
        def bad_request(error):
            logger.warning(f"400 Bad Request: {error}")
            return jsonify({'error': 'Bad request'}), 400
        
        @app.errorhandler(404)
        def not_found(error):
            logger.warning(f"404 Not Found: {request.path}")
            return jsonify({'error': 'Resource not found'}), 404
        
        @app.errorhandler(500)
        def internal_error(error):
            logger.error(f"✗ Internal server error: {error}")
            try:
                if DATABASE_MODE == 'available':
                    db.session.rollback()
            except Exception as rollback_err:
                logger.warning(f"⚠ Failed to rollback: {rollback_err}")
            return jsonify({'error': 'Internal server error'}), 500
        
        # ====================================================================
        # HEALTH CHECK (ENHANCED FOR HYBRID RAG)
        # ====================================================================
        
        @app.route('/api/health')
        def health_check():
            """Comprehensive health check with Hybrid RAG status"""
            try:
                db_health = {'status': 'unavailable'}
                if DATABASE_MODE == 'available' and db_connector:
                    try:
                        db_health = db_connector.health_check()
                    except Exception as db_health_err:
                        logger.warning(f"⚠ Database health check error: {db_health_err}")
                
                rag_health = {}
                if HYBRID_RAG_SERVICES_AVAILABLE:
                    try:
                        rag_health = check_db_health()
                    except:
                        rag_health = {'status': 'unavailable'}
                
                overall_status = 'healthy' if DATABASE_MODE == 'available' else 'degraded'
                if db_health.get('status') != 'healthy':
                    overall_status = 'degraded'
                
                return jsonify({
                    'status': overall_status,
                    'database_mode': DATABASE_MODE,
                    'database': db_health if isinstance(db_health, dict) else {'status': 'unavailable'},
                    'hybrid_rag': rag_health,
                    'version': '4.5.0',
                    'features': {
                        'all_navigation_routes': True,
                        'fallback_mode': DATABASE_MODE == 'unavailable',
                        'chatbot_enabled': CHATBOT_AVAILABLE,
                        'hybrid_rag_enabled': HYBRID_RAG_AVAILABLE,
                        'hybrid_rag_services': HYBRID_RAG_SERVICES_AVAILABLE,
                        'intelligent_routing': HYBRID_RAG_AVAILABLE,
                        'pgvector_search': HYBRID_RAG_AVAILABLE,
                        'sql_generation': HYBRID_RAG_AVAILABLE,
                        'professional_auth': AUTH_AVAILABLE,
                        'azure_openai_client': openai_client is not None,
                        'processing_paths': 'Direct LLM, SQL-First, Hybrid' if HYBRID_RAG_AVAILABLE else 'Standard'
                    },
                    'routes': {
                        'total': 35,
                        'integrations': 12,
                        'data_management': 4,
                        'chat': 1,
                        'services': 4,
                        'resources': 4,
                        'account': 2,
                        'chatbot_api': '✓ Hybrid RAG System' if HYBRID_RAG_AVAILABLE else '✓ Standard Chat',
                        'auth_api': '✓ Professional JWT Auth' if AUTH_AVAILABLE else '✓ Basic Auth'
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            
            except Exception as e:
                logger.error(f"✗ Health check error: {e}")
                return jsonify({'status': 'unhealthy', 'error': str(e)}), 503
        
        # ====================================================================
        # INITIALIZATION SUMMARY
        # ====================================================================
        
        logger.info(f"✓ Application initialized successfully in {config_name} mode")
        logger.info(f"✓ Database mode: {DATABASE_MODE}")
        logger.info(f"✓ Version: 4.5.0 - WITH HYBRID RAG SYSTEM + PROFESSIONAL AUTH")
        logger.info(f"✓ Total routes: 35+ routes enabled")
        
        if AUTH_AVAILABLE:
            logger.info(f"✓ Professional Authentication: ENABLED ✓")
            logger.info(f"  🔐 JWT Tokens")
            logger.info(f"  👥 User Sessions")
            logger.info(f"  🔄 Password Reset")
            logger.info(f"  📊 Login Tracking")
        
        if HYBRID_RAG_AVAILABLE:
            logger.info(f"✓ Hybrid RAG: ENABLED ✓")
            logger.info(f"  🧠 Intelligent Query Routing")
            logger.info(f"  🔍 pgvector Semantic Search")
            logger.info(f"  📊 SQL Query Generation")
            logger.info(f"  🎯 3 Processing Paths: Direct LLM, SQL-First, Hybrid")
        elif CHATBOT_AVAILABLE:
            logger.info(f"✓ Standard Chat: ENABLED")
        else:
            logger.info(f"⚠ Chat: DISABLED")
        
        if openai_client is not None:
            logger.info(f"✓ Azure OpenAI Client: INITIALIZED ✓")
            logger.info(f"  🤖 LLM Features: ENABLED")
        else:
            logger.info(f"⚠ Azure OpenAI Client: NOT AVAILABLE")
        
        logger.info(f"✓ Features: RAG + Excel + Azure OpenAI Integration + Professional Auth")
        logger.info(f"✓ Database: {db_connector.db_host}:{db_connector.db_port}/{db_connector.db_name}" if db_connector else "✓ Database: In-memory fallback")
        
        return app
        
    except Exception as app_err:
        logger.critical(f"✗ CRITICAL - Application Factory Error: {type(app_err).__name__} - {app_err}")
        logger.debug(traceback.format_exc())
        raise

# ============================================================================
# APPLICATION ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    try:
        app = create_app('development')
        logger.info("🚀 Starting 360° Enterprise Dashboard v4.5.0")
        logger.info("✓ Mode: Development (with graceful database fallback)")
        logger.info("✓ Hybrid RAG System: READY")
        logger.info("✓ Professional Authentication: READY")
        logger.info("✓ Azure OpenAI Client: READY ✅")
        logger.info("✓ Chat URL: http://localhost:5000/chat")
        logger.info("✓ Upload Excel: POST /chat/upload")
        logger.info("✓ Ask Questions: POST /chat/send_message")
        logger.info("✓ Authentication: POST /api/auth/login or /api/auth/register")
        logger.info("✓ Listening on http://localhost:5000")
        app.run(debug=True, host='0.0.0.0', port=5000)
    except Exception as startup_err:
        logger.critical(f"✗ CRITICAL - Startup Error: {type(startup_err).__name__} - {startup_err}")
        logger.debug(traceback.format_exc())
        exit(1)