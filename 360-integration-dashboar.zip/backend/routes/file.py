"""
File Routes
Flask blueprint for file operations endpoints
Uses FileService for all file operations
"""

from flask import Blueprint, request, jsonify, current_app, send_file
import os
import logging
from datetime import datetime
from werkzeug.utils import secure_filename
import io
import pandas as pd

from services.file_service import ExcelDataService, FileServiceError

logger = logging.getLogger(__name__)

# Create blueprint
file_bp = Blueprint('file', __name__, url_prefix='/files')

# Allowed file extensions
ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}
UPLOAD_FOLDER = 'uploads'

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_file_service():
    """Get or create file service instance"""
    if not hasattr(current_app, 'file_service'):
        current_app.file_service = ExcelDataService()
    
    return current_app.file_service


# ============================================================================
# FILE OPERATIONS ROUTES
# ============================================================================

@file_bp.route('/upload', methods=['POST'])
def upload_file():
    """
    Handle file upload
    
    Request:
        POST /files/upload
        Content-Type: multipart/form-data
        file: <binary file data>
    
    Response:
        {
            "success": true,
            "message": "File uploaded successfully!",
            "file": {
                "name": "data.xlsx",
                "path": "uploads/data.xlsx",
                "sheets": ["Sheet1", "Sheet2"],
                "total_sheets": 2,
                "file_size": 65536,
                "sheet_details": [...]
            }
        }
    """
    if 'file' not in request.files:
        logger.warning("Upload request without file")
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        logger.warning("Upload request with empty filename")
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        logger.warning(f"Upload attempt with invalid file type: {file.filename}")
        return jsonify({
            'error': 'Only Excel (.xlsx, .xls) and CSV files are allowed'
        }), 400
    
    try:
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        # Get file service and load file
        file_service = get_file_service()
        
        if filename.endswith('.csv'):
            file_info = file_service.load_csv(filepath)
        else:
            file_info = file_service.load_file(filepath)
        
        logger.info(f"✓ File uploaded successfully: {filename}")
        
        return jsonify({
            'success': True,
            'message': 'File uploaded successfully!',
            'file': {
                'name': file_info['filename'],
                'path': filepath,
                'sheets': file_info['sheet_names'],
                'total_sheets': file_info['total_sheets'],
                'file_size': file_info['file_size'],
                'sheet_details': [
                    {
                        'name': sheet_name,
                        'rows': file_info['sheets'][sheet_name]['total_rows'],
                        'columns': file_info['sheets'][sheet_name]['columns'],
                        'column_count': file_info['sheets'][sheet_name]['total_columns'],
                        'preview': file_info['sheets'][sheet_name]['preview']
                    }
                    for sheet_name in file_info['sheet_names']
                ]
            },
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ File service error during upload: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Upload error: {e}")
        return jsonify({'error': f'Upload failed: {str(e)}'}), 500


@file_bp.route('/validate', methods=['POST'])
def validate_file():
    """
    Validate uploaded file
    
    Request:
        POST /files/validate
        {
            "filepath": "uploads/data.xlsx"
        }
    
    Response:
        {
            "success": true,
            "valid": true,
            "file_size": 65536,
            "rows": 100,
            "columns": 15,
            "can_parse": true
        }
    """
    data = request.get_json()
    filepath = data.get('filepath')
    
    if not filepath:
        return jsonify({'error': 'filepath required'}), 400
    
    try:
        file_service = get_file_service()
        validation = file_service.validate_file(filepath)
        
        logger.info(f"✓ File validated: {filepath}")
        
        return jsonify({
            'success': True,
            **validation,
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ Validation error: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Error validating file: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/info', methods=['GET'])
def get_file_info():
    """
    Get information about uploaded files
    
    Request:
        GET /files/info
    
    Response:
        {
            "has_data": true,
            "excel_files": [
                {
                    "name": "data.xlsx",
                    "path": "uploads/data.xlsx",
                    "file_size": 65536,
                    "sheets": [...]
                }
            ],
            "sharepoint_available": false
        }
    """
    try:
        file_service = get_file_service()
        
        # Get uploaded files
        excel_files = []
        if os.path.exists(UPLOAD_FOLDER):
            for file in os.listdir(UPLOAD_FOLDER):
                if allowed_file(file):
                    filepath = os.path.join(UPLOAD_FOLDER, file)
                    try:
                        summary = file_service.get_file_summary(filepath)
                        excel_files.append({
                            'name': file,
                            'path': filepath,
                            'file_size': summary.get('file_size'),
                            'sheets': summary.get('sheets', [])
                        })
                    except FileServiceError:
                        logger.warning(f"Could not load summary for: {file}")
                        continue
        
        logger.info(f"✓ Retrieved info for {len(excel_files)} files")
        
        return jsonify({
            'has_data': len(excel_files) > 0,
            'excel_files': excel_files,
            'total_files': len(excel_files),
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"✗ Error getting file info: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/sheet-details', methods=['POST'])
def get_sheet_details():
    """
    Get detailed information about a specific sheet
    
    Request:
        POST /files/sheet-details
        {
            "filepath": "uploads/data.xlsx",
            "sheet_name": "Employees"
        }
    
    Response:
        {
            "success": true,
            "sheet": "Employees",
            "rows": 100,
            "columns": ["ID", "Name", ...],
            "statistics": {...},
            "preview": [...]
        }
    """
    data = request.get_json()
    filepath = data.get('filepath')
    sheet_name = data.get('sheet_name')
    
    if not filepath or not sheet_name:
        return jsonify({'error': 'filepath and sheet_name required'}), 400
    
    try:
        file_service = get_file_service()
        details = file_service.get_sheet_statistics(filepath, sheet_name)
        
        logger.info(f"✓ Retrieved details for sheet: {sheet_name}")
        
        return jsonify({
            'success': True,
            **details
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ File service error: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Error getting sheet details: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/column-info', methods=['POST'])
def get_column_info():
    """
    Get detailed information about a column
    
    Request:
        POST /files/column-info
        {
            "filepath": "uploads/data.xlsx",
            "sheet_name": "Employees",
            "column_name": "Salary"
        }
    
    Response:
        {
            "success": true,
            "column": "Salary",
            "dtype": "int64",
            "total_values": 100,
            "statistics": {
                "min": 50000,
                "max": 150000,
                "mean": 85000
            }
        }
    """
    data = request.get_json()
    filepath = data.get('filepath')
    sheet_name = data.get('sheet_name')
    column_name = data.get('column_name')
    
    if not filepath or not sheet_name or not column_name:
        return jsonify({
            'error': 'filepath, sheet_name, and column_name required'
        }), 400
    
    try:
        file_service = get_file_service()
        info = file_service.get_column_info(filepath, sheet_name, column_name)
        
        logger.info(f"✓ Retrieved column info: {column_name}")
        
        return jsonify({
            'success': True,
            **info
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ File service error: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Error getting column info: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/search', methods=['POST'])
def search_data():
    """
    Search for data across sheets
    
    Request:
        POST /files/search
        {
            "filepath": "uploads/data.xlsx",
            "search_term": "John"
        }
    
    Response:
        {
            "success": true,
            "search_term": "John",
            "total_matches": 5,
            "matches": {
                "Employees": {
                    "matching_columns": ["Name"],
                    "matching_rows_count": 5
                }
            }
        }
    """
    data = request.get_json()
    filepath = data.get('filepath')
    search_term = data.get('search_term')
    
    if not filepath or not search_term:
        return jsonify({'error': 'filepath and search_term required'}), 400
    
    try:
        file_service = get_file_service()
        results = file_service.search_across_sheets(filepath, search_term)
        
        logger.info(f"✓ Search completed: '{search_term}' - {results['total_matches']} matches")
        
        return jsonify({
            'success': True,
            'search_term': search_term,
            'matches': results.get('matches', {}),
            'total_matches': results.get('total_matches', 0),
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ File service error: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Error searching data: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/export', methods=['POST'])
def export_sheet():
    """
    Export a sheet to CSV
    
    Request:
        POST /files/export
        {
            "filepath": "uploads/data.xlsx",
            "sheet_name": "Employees"
        }
    
    Response:
        {
            "success": true,
            "output_path": "uploads/Employees_export.csv",
            "rows_exported": 100
        }
    """
    data = request.get_json()
    filepath = data.get('filepath')
    sheet_name = data.get('sheet_name')
    
    if not filepath or not sheet_name:
        return jsonify({'error': 'filepath and sheet_name required'}), 400
    
    try:
        file_service = get_file_service()
        
        # Create temp file for export
        output_path = os.path.join(UPLOAD_FOLDER, f"{sheet_name}_export.csv")
        result = file_service.export_sheet_to_csv(filepath, sheet_name, output_path)
        
        logger.info(f"✓ Sheet exported: {sheet_name} -> {output_path}")
        
        return jsonify({
            'success': True,
            **result,
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except FileServiceError as e:
        logger.error(f"✗ File service error: {e}")
        return jsonify({'error': str(e)}), 400
    
    except Exception as e:
        logger.error(f"✗ Export error: {e}")
        return jsonify({'error': str(e)}), 500


@file_bp.route('/download-sample', methods=['GET'])
def download_sample():
    """
    Download sample Excel file for testing
    
    Request:
        GET /files/download-sample
    
    Response:
        Binary Excel file (xlsx)
    """
    try:
        # Create sample data with multiple sheets
        sample_data = {
            'Employees': {
                'Employee_ID': [101, 102, 103, 104, 105],
                'Name': ['John Doe', 'Jane Smith', 'Mike Johnson', 'Sarah Williams', 'Robert Brown'],
                'Department': ['IT', 'HR', 'Finance', 'IT', 'Sales'],
                'Position': ['Senior Developer', 'HR Manager', 'Analyst', 'Developer', 'Sales Executive'],
                'Salary': [85000, 75000, 65000, 70000, 60000],
                'Hire_Date': ['2020-01-15', '2019-03-20', '2021-06-10', '2022-02-05', '2020-09-12'],
                'Status': ['Active', 'Active', 'Active', 'Inactive', 'Active']
            },
            'Sales': {
                'Order_ID': [1001, 1002, 1003, 1004, 1005],
                'Customer': ['Acme Corp', 'Tech Inc', 'Global Ltd', 'Future Co', 'Modern Tech'],
                'Amount': [50000, 75000, 120000, 45000, 95000],
                'Date': ['2024-01-10', '2024-01-15', '2024-01-20', '2024-02-05', '2024-02-10'],
                'Status': ['Completed', 'Pending', 'Completed', 'Completed', 'Pending'],
                'Region': ['North', 'South', 'East', 'West', 'North']
            },
            'Performance': {
                'Quarter': ['Q1', 'Q2', 'Q3', 'Q4', 'Q1'],
                'Revenue': [500000, 650000, 720000, 800000, 550000],
                'Expenses': [350000, 420000, 480000, 520000, 380000],
                'Profit': [150000, 230000, 240000, 280000, 170000],
                'Growth%': [0, 15, 10.9, 16.7, -30.4],
                'Year': [2023, 2023, 2023, 2023, 2024]
            }
        }
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            for sheet_name, data in sample_data.items():
                df = pd.DataFrame(data)
                df.to_excel(writer, index=False, sheet_name=sheet_name)
        
        output.seek(0)
        
        logger.info("✓ Sample file generated")
        
        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name='sample_data_multi_sheet.xlsx'
        )
    
    except Exception as e:
        logger.error(f"✗ Error creating sample file: {e}")
        return jsonify({'error': 'Failed to generate sample file'}), 500


@file_bp.route('/clear-cache', methods=['POST'])
def clear_cache():
    """
    Clear cached files from memory
    
    Request:
        POST /files/clear-cache
        {
            "filepath": "uploads/data.xlsx"  # Optional, clears specific file
        }
    
    Response:
        {
            "success": true,
            "message": "Cache cleared",
            "cleared_files": 1
        }
    """
    data = request.get_json() or {}
    filepath = data.get('filepath')
    
    try:
        file_service = get_file_service()
        
        if filepath:
            file_service.clear_loaded_files(filepath)
            logger.info(f"✓ Cleared cache for: {filepath}")
            return jsonify({
                'success': True,
                'message': f'Cache cleared for {filepath}',
                'cleared_files': 1
            }), 200
        else:
            file_service.clear_loaded_files()
            logger.info("✓ Cleared all cached files")
            return jsonify({
                'success': True,
                'message': 'All cached files cleared',
                'cleared_files': len(file_service.loaded_files)
            }), 200
    
    except Exception as e:
        logger.error(f"✗ Error clearing cache: {e}")
        return jsonify({'error': str(e)}), 500


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@file_bp.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    logger.warning(f"404 Not Found: {request.path}")
    return jsonify({'error': 'Endpoint not found'}), 404


@file_bp.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    logger.error(f"500 Internal Server Error: {error}")
    return jsonify({'error': 'Internal server error'}), 500