"""
Routes Package

This package contains all Flask blueprints for the application.
Each blueprint handles a specific domain of functionality.

Blueprints:
- chat: Chat functionality with Hybrid RAG system
"""

import logging

logger = logging.getLogger(__name__)

print("\n" + "="*80)
print("INITIALIZING ROUTES PACKAGE")
print("="*80 + "\n")

# ============================================================================
# IMPORT CHAT BLUEPRINT FROM chat.py
# ============================================================================

try:
    from .chat import chat_bp
    print("✓ Chat blueprint (chat.py) imported successfully")
    CHAT_BLUEPRINT_AVAILABLE = True
except ImportError as e:
    print(f"✗ Failed to import chat blueprint: {e}")
    CHAT_BLUEPRINT_AVAILABLE = False
    chat_bp = None

# ============================================================================
# PUBLIC API
# ============================================================================

__all__ = [
    'chat_bp',
    'CHAT_BLUEPRINT_AVAILABLE',
]

print("\n" + "="*80)
print("ROUTES INITIALIZATION COMPLETE")
print("="*80)
print(f"  💬 Chat Blueprint: {'✓ LOADED' if CHAT_BLUEPRINT_AVAILABLE else '✗ FAILED'}")
print("="*80 + "\n")

if CHAT_BLUEPRINT_AVAILABLE:
    logger.info("✓ Routes package initialized - chat blueprint ready")
else:
    logger.warning("⚠ Routes package initialized - chat blueprint not available")