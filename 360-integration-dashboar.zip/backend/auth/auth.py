"""
Authentication API - Complete with Registration
Handles user authentication, login, logout, password reset, registration
"""

from flask import Blueprint, request, jsonify
from functools import wraps
from datetime import datetime, timedelta
import jwt
import secrets
import re
from auth_models import db, User, UserSession, PasswordResetToken, LoginAttempt

# Create Blueprint
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

# Configuration (should be in environment variables in production)
SECRET_KEY = 'your-secret-key-change-this-in-production'
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24
MAX_LOGIN_ATTEMPTS = 5
LOGIN_ATTEMPT_WINDOW_MINUTES = 15


# ==================== HELPER FUNCTIONS ====================

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def validate_password(password):
    """
    Validate password strength
    Rules: At least 8 characters
    """
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    return True, "Password is valid"


def generate_jwt_token(user_id, email):
    """Generate JWT token"""
    payload = {
        'user_id': user_id,
        'email': email,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
        'iat': datetime.utcnow()
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)
    return token


def verify_jwt_token(token):
    """Verify and decode JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[JWT_ALGORITHM])
        return payload, None
    except jwt.ExpiredSignatureError:
        return None, "Token has expired"
    except jwt.InvalidTokenError:
        return None, "Invalid token"


def get_client_info(request_obj):
    """Extract client IP and user agent"""
    ip_address = request_obj.remote_addr
    user_agent = request_obj.headers.get('User-Agent', '')[:255]
    return ip_address, user_agent


def check_login_attempts(email, ip_address):
    """Check if user has exceeded login attempts"""
    window_start = datetime.utcnow() - timedelta(minutes=LOGIN_ATTEMPT_WINDOW_MINUTES)
    
    failed_attempts = LoginAttempt.query.filter(
        LoginAttempt.email == email,
        LoginAttempt.success == False,
        LoginAttempt.attempted_at >= window_start
    ).count()
    
    return failed_attempts < MAX_LOGIN_ATTEMPTS, failed_attempts


def log_login_attempt(email, ip_address, user_agent, success, failure_reason=None):
    """Log login attempt"""
    attempt = LoginAttempt(
        email=email,
        ip_address=ip_address,
        user_agent=user_agent,
        success=success,
        failure_reason=failure_reason
    )
    db.session.add(attempt)
    db.session.commit()


def token_required(f):
    """Decorator to require valid JWT token"""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        # Get token from header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer TOKEN
            except IndexError:
                return jsonify({'success': False, 'message': 'Invalid token format'}), 401
        
        if not token:
            return jsonify({'success': False, 'message': 'Token is missing'}), 401
        
        # Verify token
        payload, error = verify_jwt_token(token)
        if error:
            return jsonify({'success': False, 'message': error}), 401
        
        # Check if session is active
        session = UserSession.query.filter_by(token=token, is_active=True).first()
        if not session or session.is_expired():
            return jsonify({'success': False, 'message': 'Session expired or invalid'}), 401
        
        # Update session activity
        session.update_activity()
        
        # Get user
        user = User.query.get(payload['user_id'])
        if not user or not user.is_active:
            return jsonify({'success': False, 'message': 'User not found or inactive'}), 401
        
        # Pass user to the route
        return f(user, *args, **kwargs)
    
    return decorated


# ==================== AUTHENTICATION ENDPOINTS ====================

@auth_bp.route('/register', methods=['POST'])
def register():
    """
    User Registration Endpoint
    POST /api/auth/register
    Body: {
        "email": "user@example.com",
        "password": "SecurePass123",
        "first_name": "John",
        "last_name": "Doe"
    }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        first_name = data.get('first_name', '').strip()
        last_name = data.get('last_name', '').strip()
        
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email and password are required'}), 400
        
        if not validate_email(email):
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        is_valid, message = validate_password(password)
        if not is_valid:
            return jsonify({'success': False, 'message': message}), 400
        
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return jsonify({'success': False, 'message': 'Email already registered'}), 409
        
        user = User(
            email=email,
            first_name=first_name,
            last_name=last_name,
            full_name=f"{first_name} {last_name}".strip()
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        token = generate_jwt_token(user.id, user.email)
        expires_at = datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
        
        ip_address, user_agent = get_client_info(request)
        
        session = UserSession(
            user_id=user.id,
            token=token,
            ip_address=ip_address,
            user_agent=user_agent,
            expires_at=expires_at
        )
        db.session.add(session)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Registration successful',
            'data': {
                'token': token,
                'user': user.to_dict(),
                'expires_at': expires_at.isoformat()
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/login', methods=['POST'])
def login():
    """
    User Login Endpoint
    POST /api/auth/login
    Body: { "email": "user@example.com", "password": "password123", "remember_me": false }
    """
    try:
        data = request.get_json()
        
        # Validate input
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        remember_me = data.get('remember_me', False)
        
        # Validate required fields
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email and password are required'}), 400
        
        # Validate email format
        if not validate_email(email):
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        # Get client info
        ip_address, user_agent = get_client_info(request)
        
        # Check login attempts
        can_attempt, failed_count = check_login_attempts(email, ip_address)
        if not can_attempt:
            log_login_attempt(email, ip_address, user_agent, False, 'Too many failed attempts')
            return jsonify({
                'success': False,
                'message': f'Too many failed login attempts. Please try again after {LOGIN_ATTEMPT_WINDOW_MINUTES} minutes.'
            }), 429
        
        # Find user
        user = User.query.filter_by(email=email).first()
        
        if not user:
            log_login_attempt(email, ip_address, user_agent, False, 'User not found')
            return jsonify({'success': False, 'message': 'Invalid email or password'}), 401
        
        # Check if user is active
        if not user.is_active:
            log_login_attempt(email, ip_address, user_agent, False, 'Account inactive')
            return jsonify({'success': False, 'message': 'Account is inactive. Please contact administrator.'}), 403
        
        # Verify password
        if not user.check_password(password):
            log_login_attempt(email, ip_address, user_agent, False, 'Invalid password')
            return jsonify({'success': False, 'message': 'Invalid email or password'}), 401
        
        # Generate JWT token
        token = generate_jwt_token(user.id, user.email)
        
        # Calculate expiration
        expiration_hours = JWT_EXPIRATION_HOURS * 7 if remember_me else JWT_EXPIRATION_HOURS
        expires_at = datetime.utcnow() + timedelta(hours=expiration_hours)
        
        # Create session
        session = UserSession(
            user_id=user.id,
            token=token,
            ip_address=ip_address,
            user_agent=user_agent,
            expires_at=expires_at
        )
        db.session.add(session)
        
        # Update user last login
        user.update_last_login()
        
        # Log successful attempt
        log_login_attempt(email, ip_address, user_agent, True)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Login successful',
            'data': {
                'token': token,
                'user': user.to_dict(),
                'expires_at': expires_at.isoformat()
            }
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(user):
    """
    User Logout Endpoint
    POST /api/auth/logout
    Headers: { "Authorization": "Bearer TOKEN" }
    """
    try:
        # Get token from header
        auth_header = request.headers.get('Authorization')
        token = auth_header.split(" ")[1]
        
        # Find and deactivate session
        session = UserSession.query.filter_by(token=token, is_active=True).first()
        if session:
            session.is_active = False
            db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Logout successful'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/verify', methods=['GET'])
@token_required
def verify_token(user):
    """
    Verify Token Endpoint
    GET /api/auth/verify
    Headers: { "Authorization": "Bearer TOKEN" }
    """
    return jsonify({
        'success': True,
        'message': 'Token is valid',
        'data': {
            'user': user.to_dict()
        }
    }), 200


@auth_bp.route('/me', methods=['GET'])
@token_required
def get_current_user(user):
    """
    Get Current User Endpoint
    GET /api/auth/me
    Headers: { "Authorization": "Bearer TOKEN" }
    """
    return jsonify({
        'success': True,
        'data': {
            'user': user.to_dict()
        }
    }), 200


@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    """
    Forgot Password Endpoint
    POST /api/auth/forgot-password
    Body: { "email": "user@example.com" }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        
        if not email:
            return jsonify({'success': False, 'message': 'Email is required'}), 400
        
        if not validate_email(email):
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        # Find user
        user = User.query.filter_by(email=email).first()
        
        # Always return success for security (don't reveal if email exists)
        if user and user.is_active:
            # Generate reset token
            reset_token = secrets.token_urlsafe(32)
            expires_at = datetime.utcnow() + timedelta(hours=1)
            
            password_reset = PasswordResetToken(
                user_id=user.id,
                token=reset_token,
                expires_at=expires_at
            )
            db.session.add(password_reset)
            db.session.commit()
            
            # TODO: Send email with reset link
            # send_password_reset_email(user.email, reset_token)
        
        return jsonify({
            'success': True,
            'message': 'If the email exists, a password reset link has been sent'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/reset-password', methods=['POST'])
def reset_password():
    """
    Reset Password Endpoint
    POST /api/auth/reset-password
    Body: { "token": "reset-token", "new_password": "newpassword123" }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        token = data.get('token', '')
        new_password = data.get('new_password', '')
        
        if not token or not new_password:
            return jsonify({'success': False, 'message': 'Token and new password are required'}), 400
        
        # Validate password
        is_valid, message = validate_password(new_password)
        if not is_valid:
            return jsonify({'success': False, 'message': message}), 400
        
        # Find reset token
        reset_token = PasswordResetToken.query.filter_by(token=token).first()
        
        if not reset_token or reset_token.is_expired():
            return jsonify({'success': False, 'message': 'Invalid or expired reset token'}), 400
        
        # Get user
        user = User.query.get(reset_token.user_id)
        if not user:
            return jsonify({'success': False, 'message': 'User not found'}), 404
        
        # Update password
        user.set_password(new_password)
        
        # Mark token as used
        reset_token.mark_as_used()
        
        # Deactivate all user sessions
        UserSession.query.filter_by(user_id=user.id, is_active=True).update({'is_active': False})
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Password reset successful. Please login with your new password.'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password(user):
    """
    Change Password Endpoint (for logged-in users)
    POST /api/auth/change-password
    Headers: { "Authorization": "Bearer TOKEN" }
    Body: { "current_password": "oldpass", "new_password": "newpass" }
    """
    try:
        data = request.get_json()
        
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')
        
        if not current_password or not new_password:
            return jsonify({'success': False, 'message': 'Current and new password are required'}), 400
        
        # Verify current password
        if not user.check_password(current_password):
            return jsonify({'success': False, 'message': 'Current password is incorrect'}), 401
        
        # Validate new password
        is_valid, message = validate_password(new_password)
        if not is_valid:
            return jsonify({'success': False, 'message': message}), 400
        
        # Update password
        user.set_password(new_password)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/sessions', methods=['GET'])
@token_required
def get_user_sessions(user):
    """
    Get User's Active Sessions
    GET /api/auth/sessions
    Headers: { "Authorization": "Bearer TOKEN" }
    """
    try:
        sessions = UserSession.query.filter_by(
            user_id=user.id,
            is_active=True
        ).all()
        
        return jsonify({
            'success': True,
            'data': {
                'sessions': [s.to_dict() for s in sessions]
            }
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/sessions/<int:session_id>', methods=['DELETE'])
@token_required
def delete_session(user, session_id):
    """
    Delete/Logout Specific Session
    DELETE /api/auth/sessions/<session_id>
    Headers: { "Authorization": "Bearer TOKEN" }
    """
    try:
        session = UserSession.query.filter_by(
            id=session_id,
            user_id=user.id
        ).first()
        
        if not session:
            return jsonify({'success': False, 'message': 'Session not found'}), 404
        
        session.is_active = False
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Session deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500