"""
Splunk Query Model - 360° Enterprise Dashboard
Handles Splunk query repository and execution tracking
"""

from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def create_splunk_query_model(db):
    """Factory function to create SplunkQuery model"""
    
    class SplunkQuery(db.Model):
        """Splunk queries repository and execution tracking"""
        __tablename__ = 'splunk_queries'
        
        id = db.Column(db.Integer, primary_key=True)
        query_name = db.Column(db.String(255), unique=True, nullable=False)
        query_description = db.Column(db.Text)
        query_text = db.Column(db.Text, nullable=False)
        query_category = db.Column(db.String(100))
        environment = db.Column(db.String(50), default='prod')
        is_active = db.Column(db.Boolean, default=True)
        execution_timeout_seconds = db.Column(db.Integer, default=300)
        created_by = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'))
        updated_by = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'))
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
        last_executed_at = db.Column(db.DateTime)
        execution_count = db.Column(db.Integer, default=0)
        last_execution_status = db.Column(db.String(20))
        last_execution_error = db.Column(db.Text)
        
        def to_dict(self):
            """Convert query to dictionary"""
            try:
                return {
                    'id': self.id,
                    'query_name': self.query_name,
                    'query_description': self.query_description,
                    'query_text': self.query_text,
                    'query_category': self.query_category,
                    'environment': self.environment,
                    'is_active': self.is_active,
                    'execution_timeout_seconds': self.execution_timeout_seconds,
                    'execution_count': self.execution_count,
                    'last_executed_at': self.last_executed_at.isoformat() if self.last_executed_at else None,
                    'last_execution_status': self.last_execution_status,
                    'last_execution_error': self.last_execution_error,
                    'created_at': self.created_at.isoformat() if self.created_at else None,
                    'updated_at': self.updated_at.isoformat() if self.updated_at else None
                }
            except Exception as e:
                logger.error(f"✗ Error converting SplunkQuery to dict: {e}")
                return {}
        
        def to_dict_summary(self):
            """Convert query to summary dictionary (lighter payload)"""
            try:
                return {
                    'id': self.id,
                    'query_name': self.query_name,
                    'query_category': self.query_category,
                    'environment': self.environment,
                    'is_active': self.is_active,
                    'execution_count': self.execution_count,
                    'last_execution_status': self.last_execution_status
                }
            except Exception as e:
                logger.error(f"✗ Error converting SplunkQuery to summary dict: {e}")
                return {}
        
        def log_execution(self, status, error_message=None, tokens_used=0):
            """Log query execution"""
            try:
                self.last_executed_at = datetime.utcnow()
                self.last_execution_status = status
                self.last_execution_error = error_message
                self.execution_count += 1
                logger.info(f"✓ Logged execution for query: {self.query_name} - Status: {status}")
            except Exception as e:
                logger.error(f"✗ Error logging query execution: {e}")
        
        def __repr__(self):
            return f"<SplunkQuery {self.query_name}>"
    
    return SplunkQuery