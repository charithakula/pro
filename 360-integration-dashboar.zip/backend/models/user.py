"""
User Model - 360° Enterprise Dashboard (FIXED v2)
Handles user account management and authentication
Fixed to match actual SplunkQuery foreign keys (created_by, updated_by)
"""

from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import logging

logger = logging.getLogger(__name__)


class AuthenticationError(Exception):
    """Custom exception for authentication errors"""
    pass


def create_user_model(db):
    """Factory function to create User model with database instance"""
    
    class User(db.Model):
        """User model for account management"""
        __tablename__ = 'users'
        
        id = db.Column(db.Integer, primary_key=True)
        email = db.Column(db.String(120), unique=True, nullable=False)
        password = db.Column(db.String(255), nullable=False)
        name = db.Column(db.String(120), nullable=False)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        last_login = db.Column(db.DateTime)
        is_active = db.Column(db.Boolean, default=True)
        
        # Relationships - FIXED to match actual foreign keys in other models
        azure_integrations = db.relationship(
            'AzureIntegration', 
            backref='user', 
            lazy=True, 
            cascade='all, delete-orphan',
            foreign_keys='AzureIntegration.user_id'
        )
        sharepoint_integrations = db.relationship(
            'SharePointIntegration', 
            backref='user', 
            lazy=True, 
            cascade='all, delete-orphan',
            foreign_keys='SharePointIntegration.user_id'
        )
        ai_interactions = db.relationship(
            'AIInteraction', 
            backref='user', 
            lazy=True, 
            cascade='all, delete-orphan',
            foreign_keys='AIInteraction.user_id'
        )
        storage_files = db.relationship(
            'StorageFile', 
            backref='user', 
            lazy=True, 
            cascade='all, delete-orphan',
            foreign_keys='StorageFile.user_id'
        )
        # FIXED: Changed from creator_id to created_by (actual SplunkQuery column)
        splunk_queries_created = db.relationship(
            'SplunkQuery', 
            backref='creator', 
            lazy=True, 
            foreign_keys='SplunkQuery.created_by',
            primaryjoin='User.id==SplunkQuery.created_by'
        )
        splunk_queries_updated = db.relationship(
            'SplunkQuery', 
            lazy=True, 
            foreign_keys='SplunkQuery.updated_by',
            primaryjoin='User.id==SplunkQuery.updated_by'
        )
        
        def set_password(self, password):
            """Hash and set user password"""
            try:
                if not password or len(password) < 6:
                    raise ValueError("Password must be at least 6 characters long")
                self.password = generate_password_hash(password)
                logger.info(f"✓ Password set for user: {self.email}")
            except Exception as e:
                logger.error(f"✗ Password hashing error: {e}")
                raise AuthenticationError(f"Failed to set password: {str(e)}")
        
        def check_password(self, password):
            """Verify user password"""
            try:
                result = check_password_hash(self.password, password)
                logger.info(f"✓ Password check for {self.email}: {result}")
                return result
            except Exception as e:
                logger.error(f"✗ Password verification error: {e}")
                return False
        
        def to_dict(self):
            """Convert user to dictionary"""
            try:
                return {
                    'id': self.id,
                    'email': self.email,
                    'name': self.name,
                    'created_at': self.created_at.isoformat() if self.created_at else None,
                    'last_login': self.last_login.isoformat() if self.last_login else None,
                    'is_active': self.is_active
                }
            except Exception as e:
                logger.error(f"✗ Error converting user to dict: {e}")
                return {}
        
        def __repr__(self):
            return f"<User {self.email}>"
    
    return User