#!/usr/bin/env python
"""
Nuclear Option - Delete and Recreate Demo User
Use if all other password resets fail
"""

import sys
import os

backend_path = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, backend_path)

try:
    from app import create_app, db, User
    
    print("\n" + "=" * 80)
    print("☢️  NUCLEAR OPTION - Delete & Recreate User")
    print("=" * 80)
    
    app = create_app()
    
    with app.app_context():
        print("\n⚠️  WARNING: This will DELETE the demo user!")
        confirm = input("Continue? (type 'yes' to confirm): ").strip().lower()
        
        if confirm != 'yes':
            print("Cancelled.")
            sys.exit(0)
        
        print("\n1️⃣ Deleting old user...")
        user = User.query.filter_by(email='demo@example.com').first()
        
        if user:
            user_id = user.id
            db.session.delete(user)
            db.session.commit()
            print(f"✓ Deleted user ID {user_id}")
        else:
            print("✓ User didn't exist (already deleted)")
        
        print("\n2️⃣ Creating new demo user...")
        new_user = User(
            email='demo@example.com',
            name='Demo User',
            is_active=True
        )
        
        print("✓ Setting password...")
        new_user.set_password('demo123')
        
        print("✓ Adding to database...")
        db.session.add(new_user)
        db.session.commit()
        
        new_id = new_user.id
        new_hash = new_user.password
        
        print(f"\n3️⃣ Verifying...")
        print(f"✓ New user ID: {new_id}")
        print(f"✓ Hash: {new_hash[:50]}...")
        
        # Test the password
        print("\n4️⃣ Testing password...")
        db.session.expire(new_user)
        user = User.query.filter_by(email='demo@example.com').first()
        
        if user.check_password('demo123'):
            print("✅ Password check: SUCCESS")
            print("\n" + "=" * 80)
            print("✅ SUCCESS - Demo user recreated!")
            print("=" * 80)
            print(f"\nLogin credentials:")
            print(f"  Email:    demo@example.com")
            print(f"  Password: demo123")
            print(f"\nGo to: http://localhost:5000/login\n")
        else:
            print("❌ Password check: FAILED")
            print("Even the recreated user has password issues!")
            print("This indicates a deeper problem with password hashing.")
            sys.exit(1)

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)