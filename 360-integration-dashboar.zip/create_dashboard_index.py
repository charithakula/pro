#!/usr/bin/env python
"""
360° Enterprise Dashboard - Create Dashboard Template
Creates frontend/dashboard_overview/index.html
Run this script from the project root directory
"""

import os

def create_dashboard_file():
    """Create dashboard overview/index.html"""
    
    # Create directory if it doesn't exist
    dashboard_dir = 'frontend/dashboard_overview'
    os.makedirs(dashboard_dir, exist_ok=True)
    
    # Dashboard HTML content (from document 9)
    dashboard_html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>360° Enterprise Dashboard - Enhanced UI</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary: #005841;
            --secondary: #003d2e;
            --accent: #ffc32e;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffa726;
            --info: #29b6f6;
            --dark: #333;
            --light: #f5f7fa;
            --border: #e0e8e4;
            --gradient-primary: linear-gradient(135deg, #005841 0%, #003d2e 100%);
            --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.06);
            --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.08);
            --shadow-lg: 0 12px 32px rgba(0, 0, 0, 0.12);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            color: var(--dark);
            min-height: 100vh;
            padding-top: 90px;
        }

        /* LOADING OVERLAY */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .loading-overlay.active {
            display: flex;
        }

        .spinner {
            width: 60px;
            height: 60px;
            border: 5px solid var(--light);
            border-top: 5px solid var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* TOAST NOTIFICATIONS */
        .toast-container {
            position: fixed;
            top: 110px;
            right: 20px;
            z-index: 9998;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .toast {
            background: white;
            border-radius: 12px;
            padding: 16px 20px;
            min-width: 320px;
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid var(--primary);
            animation: slideInRight 0.4s ease;
            position: relative;
            overflow: hidden;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .toast.success {
            border-left-color: var(--success);
        }

        .toast.error {
            border-left-color: var(--danger);
        }

        .toast.warning {
            border-left-color: var(--warning);
        }

        .toast.info {
            border-left-color: var(--info);
        }

        .toast-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        .toast.success .toast-icon {
            background: rgba(40, 167, 69, 0.1);
            color: var(--success);
        }

        .toast.error .toast-icon {
            background: rgba(220, 53, 69, 0.1);
            color: var(--danger);
        }

        .toast.warning .toast-icon {
            background: rgba(255, 167, 38, 0.1);
            color: var(--warning);
        }

        .toast.info .toast-icon {
            background: rgba(41, 182, 246, 0.1);
            color: var(--info);
        }

        .toast-content {
            flex: 1;
        }

        .toast-title {
            font-weight: 700;
            font-size: 0.95rem;
            margin-bottom: 4px;
            color: var(--dark);
        }

        .toast-message {
            font-size: 0.85rem;
            color: #64748b;
        }

        .toast-close {
            width: 28px;
            height: 28px;
            border: none;
            background: transparent;
            color: #94a3b8;
            cursor: pointer;
            border-radius: 6px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .toast-close:hover {
            background: rgba(0, 0, 0, 0.05);
            color: var(--dark);
        }

        .toast-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            background: currentColor;
            animation: progressBar 3s linear forwards;
        }

        @keyframes progressBar {
            from { width: 100%; }
            to { width: 0%; }
        }

        /* NAVIGATION - Enhanced */
        .nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 90px;
            z-index: 1000;
            background: rgba(250, 251, 255, 0.95);
            backdrop-filter: blur(40px);
            border-bottom: 2px solid var(--accent);
            box-shadow: var(--shadow-md);
        }

        .nav-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 40px;
            width: 100%;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            font-weight: 900;
            font-size: 1.5rem;
            color: var(--primary);
            transition: var(--transition);
        }

        .logo:hover {
            transform: scale(1.05);
        }

        .logo i {
            font-size: 2rem;
            animation: float 3s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-left: auto;
        }

        .action-btn {
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .logout-btn {
            background: transparent;
            color: var(--danger);
            border: 2px solid var(--danger);
        }

        .logout-btn:hover {
            background: var(--danger);
            color: white;
            transform: translateY(-2px);
        }

        .chat-btn {
            background: var(--gradient-primary);
            color: white;
            position: relative;
        }

        .chat-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 88, 65, 0.3);
        }

        /* MAIN CONTENT - Enhanced */
        .main-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            animation: fadeInDown 0.6s ease;
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 900;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .page-title i {
            color: var(--primary);
            font-size: 3rem;
            animation: float 3s ease-in-out infinite;
        }

        /* ENHANCED METRICS */
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
            animation: fadeInUp 0.6s ease 0.2s both;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .metric-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            border-top: 4px solid var(--accent);
            border-left: 4px solid var(--primary);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        .metric-card:hover {
            transform: translateY(-8px);
            box-shadow: var(--shadow-lg);
        }

        .metric-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
        }

        .metric-label {
            font-size: 0.85rem;
            color: #64748b;
            font-weight: 600;
        }

        .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            background: rgba(0, 88, 65, 0.1);
            color: var(--primary);
        }

        .metric-value {
            font-size: 2.5rem;
            font-weight: 900;
            color: var(--primary);
            margin-bottom: 8px;
        }

        .metric-footer {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.8rem;
            color: #64748b;
        }

        .metric-trend {
            display: flex;
            align-items: center;
            gap: 4px;
            font-weight: 600;
        }

        .metric-trend.up {
            color: var(--success);
        }

        .metric-trend.down {
            color: var(--danger);
        }

        /* SECTION HEADER */
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            margin-top: 40px;
        }

        .section-title {
            font-size: 1.5rem;
            font-weight: 900;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .section-title i {
            color: var(--accent);
        }

        /* INTEGRATIONS GRID */
        .integrations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        .integration-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            border-left: 4px solid var(--primary);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .integration-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-lg);
        }

        .integration-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .integration-icon {
            font-size: 2.5rem;
        }

        .integration-name {
            font-weight: 700;
            font-size: 1.1rem;
            color: var(--primary);
        }

        .integration-status {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(40, 167, 69, 0.1);
            color: var(--success);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 700;
            margin-bottom: 12px;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: currentColor;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }

        .integration-details {
            font-size: 0.85rem;
            color: #64748b;
            line-height: 1.8;
            margin-bottom: 16px;
        }

        .btn {
            padding: 10px 14px;
            border: 1px solid var(--border);
            background: white;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 600;
            transition: var(--transition);
            text-decoration: none;
            text-align: center;
            width: 100%;
        }

        .btn:hover {
            background: rgba(0, 88, 65, 0.05);
            border-color: var(--primary);
            color: var(--primary);
        }

        .btn-primary {
            background: var(--gradient-primary);
            color: white;
            border: none;
        }

        .btn-primary:hover {
            box-shadow: 0 4px 12px rgba(0, 88, 65, 0.3);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-left: auto;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
        }

        @media (max-width: 768px) {
            body {
                padding-top: 70px;
            }

            .nav {
                height: 70px;
            }

            .main-content {
                padding: 20px;
            }

            .page-title {
                font-size: 1.8rem;
            }

            .metrics-grid {
                grid-template-columns: 1fr;
            }

            .integrations-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- LOADING OVERLAY -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="spinner"></div>
    </div>

    <!-- TOAST CONTAINER -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- NAVIGATION -->
    <nav class="nav">
        <div class="nav-container">
            <a href="/" class="logo">
                <i class="fas fa-cube"></i>
                <span>360°</span>
            </a>

            <div class="user-info">
                <div>
                    <div style="font-weight: 600; color: var(--dark);" id="userName">Welcome, User</div>
                    <div style="font-size: 0.85rem; color: #64748b;" id="userEmail">user@example.com</div>
                </div>
                <div class="user-avatar" id="userAvatar">U</div>
                <button class="action-btn logout-btn" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
        </div>
    </nav>

    <!-- MAIN CONTENT -->
    <div class="main-content">
        <div class="page-header">
            <div class="page-title">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </div>
        </div>

        <!-- METRICS -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-label">Active Integrations</div>
                    <div class="metric-icon">
                        <i class="fas fa-plug"></i>
                    </div>
                </div>
                <div class="metric-value">12</div>
                <div class="metric-footer">
                    <span class="metric-trend up"><i class="fas fa-arrow-up"></i> 8.5%</span>
                    <span>vs last month</span>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-label">Data Tables</div>
                    <div class="metric-icon">
                        <i class="fas fa-table"></i>
                    </div>
                </div>
                <div class="metric-value">45</div>
                <div class="metric-footer">
                    <span class="metric-trend up"><i class="fas fa-arrow-up"></i> 12%</span>
                    <span>vs last month</span>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-label">Total Records</div>
                    <div class="metric-icon">
                        <i class="fas fa-database"></i>
                    </div>
                </div>
                <div class="metric-value">2.4M</div>
                <div class="metric-footer">
                    <span class="metric-trend up"><i class="fas fa-arrow-up"></i> 15%</span>
                    <span>vs last month</span>
                </div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <div class="metric-label">Sync Success</div>
                    <div class="metric-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                </div>
                <div class="metric-value">99.7%</div>
                <div class="metric-footer">
                    <span class="metric-trend up"><i class="fas fa-arrow-up"></i> 0.3%</span>
                    <span>vs last month</span>
                </div>
            </div>
        </div>

        <!-- INTEGRATIONS -->
        <div class="section-header">
            <div class="section-title">
                <i class="fas fa-link"></i>
                Connected Integrations
            </div>
        </div>

        <div class="integrations-grid">
            <div class="integration-card">
                <div class="integration-header">
                    <div class="integration-icon">☁️</div>
                    <div>
                        <div class="integration-name">Microsoft Azure</div>
                        <div class="integration-status">
                            <span class="status-dot"></span>
                            Connected
                        </div>
                    </div>
                </div>
                <div class="integration-details">
                    <strong>Subscription:</strong> Enterprise<br>
                    <strong>Resources:</strong> 24 active<br>
                    <strong>Last Sync:</strong> 2 min ago
                </div>
                <button class="btn btn-primary" onclick="showToast('success', 'Azure', 'Opening portal...')">
                    <i class="fas fa-external-link-alt"></i> Open Portal
                </button>
            </div>

            <div class="integration-card">
                <div class="integration-header">
                    <div class="integration-icon">📁</div>
                    <div>
                        <div class="integration-name">SharePoint Online</div>
                        <div class="integration-status">
                            <span class="status-dot"></span>
                            Connected
                        </div>
                    </div>
                </div>
                <div class="integration-details">
                    <strong>Sites:</strong> 8 active<br>
                    <strong>Documents:</strong> 1,250<br>
                    <strong>Last Sync:</strong> 5 min ago
                </div>
                <button class="btn btn-primary" onclick="showToast('success', 'SharePoint', 'Opening sites...')">
                    <i class="fas fa-folder-open"></i> Browse Sites
                </button>
            </div>

            <div class="integration-card">
                <div class="integration-header">
                    <div class="integration-icon">📊</div>
                    <div>
                        <div class="integration-name">Reports & Analytics</div>
                        <div class="integration-status">
                            <span class="status-dot"></span>
                            Active
                        </div>
                    </div>
                </div>
                <div class="integration-details">
                    <strong>Status:</strong> Running<br>
                    <strong>Reports:</strong> 12 generated<br>
                    <strong>Updated:</strong> Daily
                </div>
                <button class="btn btn-primary" onclick="showToast('success', 'Reports', 'Loading...')">
                    <i class="fas fa-chart-bar"></i> View Reports
                </button>
            </div>
        </div>
    </div>

    <script>
        // Toast notifications
        function showToast(type, title, message) {
            const container = document.getElementById('toastContainer');
            const icons = {
                success: 'fa-check-circle',
                error: 'fa-times-circle'
            };
            
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;
            toast.innerHTML = `
                <div class="toast-icon">
                    <i class="fas ${icons[type]}"></i>
                </div>
                <div class="toast-content">
                    <div class="toast-title">${title}</div>
                    <div class="toast-message">${message}</div>
                </div>
            `;
            
            container.appendChild(toast);
            setTimeout(() => toast.remove(), 3000);
        }

        // Logout
        async function logout() {
            try {
                await fetch('/api/auth/logout', { method: 'POST' });
                window.location.href = '/';
            } catch (error) {
                console.error('Logout error:', error);
            }
        }

        // Load user info
        async function loadUserInfo() {
            try {
                const response = await fetch('/api/auth/me');
                if (response.ok) {
                    const user = await response.json();
                    document.getElementById('userName').textContent = `Welcome, ${user.name}`;
                    document.getElementById('userEmail').textContent = user.email;
                    document.getElementById('userAvatar').textContent = user.name.charAt(0).toUpperCase();
                }
            } catch (error) {
                console.error('Error loading user:', error);
            }
        }

        // Initialize
        window.addEventListener('load', loadUserInfo);
    </script>
</body>
</html>
"""
    
    # Write to file
    file_path = os.path.join(dashboard_dir, 'index.html')
    
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(dashboard_html)
        
        print("✓ Created: frontend/dashboard_overview/index.html")
        return True
    except Exception as e:
        print(f"✗ Failed to create dashboard file: {e}")
        return False

if __name__ == '__main__':
    import sys
    
    print("\n" + "="*70)
    print("360° Enterprise Dashboard - Create Dashboard Template")
    print("="*70 + "\n")
    
    print(f"Project Root: {os.getcwd()}\n")
    
    if create_dashboard_file():
        print("\n✓ Dashboard template created successfully!")
        print("\nNow you can run the app:")
        print("  cd backend")
        print("  python app.py")
        print("\nThen visit: http://localhost:5000")
        print("\nLogin with:")
        print("  Email: demo@example.com")
        print("  Password: demo123\n")
        sys.exit(0)
    else:
        print("\n✗ Failed to create dashboard template\n")
        sys.exit(1)