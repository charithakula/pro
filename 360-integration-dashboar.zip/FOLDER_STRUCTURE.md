# 📁 COMPLETE FOLDER STRUCTURE - Hybrid RAG System

## Project Directory Tree

```
your-project/
│
├── backend/                                 # Backend Flask application
│   │
│   ├── app.py                              # ✅ UPDATED Main Flask app with Hybrid RAG
│   │
│   ├── config.py                           # ✅ EXISTING Configuration management
│   │
│   ├── models.py                           # ✅ EXISTING Database models
│   │
│   ├── requirements.txt                    # ✅ UPDATED Python dependencies
│   │
│   ├── .env                                # ⚙️ Environment variables (create from .env.example)
│   │
│   ├── setup_database.py                  # 🆕 NEW Database initialization script
│   │
│   ├── uploads/                            # 📁 Uploaded Excel files
│   │   └── (user uploaded files)
│   │
│   ├── logs/                               # 📁 Application logs
│   │   └── app.log
│   │
│   ├── connectors/                         # 🔌 External service connectors
│   │   ├── __init__.py
│   │   ├── database_connector.py           # ✅ EXISTING DB connector (uses config.py)
│   │   ├── azure_openai_connector.py       # ✅ EXISTING Azure OpenAI
│   │   ├── azure_storage_connector.py      # ✅ EXISTING Azure Storage
│   │   ├── sharepoint_connector.py         # ✅ EXISTING SharePoint
│   │   └── splunk_connector.py             # ✅ EXISTING Splunk
│   │
│   ├── services/                           # 🧠 NEW Business logic layer (Hybrid RAG)
│   │   ├── __init__.py
│   │   ├── hybrid_rag_service.py           # 🆕 Main orchestrator
│   │   ├── query_router.py                 # 🆕 Intelligent routing
│   │   ├── sql_generator.py                # 🆕 NL → SQL conversion
│   │   ├── vector_search.py                # 🆕 pgvector semantic search
│   │   ├── query_processors.py             # 🆕 3 processing paths
│   │   ├── data_import_service.py          # 🆕 Excel → PostgreSQL import
│   │   ├── chat_service.py                 # ✅ EXISTING (optional, for backward compatibility)
│   │   └── file_service.py                 # ✅ EXISTING (optional, for file operations)
│   │
│   ├── routes/                             # 🛣️ Flask blueprints
│   │   ├── __init__.py
│   │   ├── chat_routes_hybrid.py           # 🆕 NEW Hybrid RAG chat endpoints
│   │   └── chat.py                         # ✅ EXISTING (old chat routes - kept as fallback)
│   │
│   └── utils/                              # 🛠️ Utility functions
│       ├── __init__.py
│       └── helpers.py
│
├── frontend/                                # Frontend templates and assets
│   │
│   ├── index.html                          # Landing page
│   │
│   ├── auth/                               # Authentication pages
│   │   ├── login.html
│   │   └── register.html
│   │
│   ├── dashboard_overview/                 # Dashboard
│   │   └── index.html
│   │
│   ├── chat/                               # 💬 Chat interface
│   │   └── chat.html                       # Chat UI (works with Hybrid RAG)
│   │
│   ├── integrations/                       # Integration pages
│   │   ├── azure/
│   │   │   ├── apim.html
│   │   │   ├── storage.html
│   │   │   ├── openai.html
│   │   │   └── postgresql.html
│   │   ├── mft.html
│   │   ├── sap-cpi.html
│   │   ├── ibm-api-connect.html
│   │   ├── ibm-datapower.html
│   │   ├── splunk.html
│   │   ├── sharepoint.html
│   │   ├── api-gateway.html
│   │   └── excel.html
│   │
│   ├── data_management/                    # Data management pages
│   │   ├── import.html
│   │   ├── tables.html
│   │   ├── sync-history.html
│   │   └── analytics.html
│   │
│   ├── services_monitoring/                # Services monitoring
│   │   ├── system-health.html
│   │   ├── reports.html
│   │   ├── services-analytics.html
│   │   └── security.html
│   │
│   ├── resources/                          # Resources pages
│   │   ├── videos.html
│   │   ├── documentation.html
│   │   ├── faq.html
│   │   └── support.html
│   │
│   ├── account/                            # Account pages
│   │   ├── profile.html
│   │   └── settings.html
│   │
│   └── assets/                             # Static assets
│       ├── css/
│       │   └── styles.css
│       ├── js/
│       │   └── main.js
│       └── images/
│           └── logo.png
│
└── docs/                                    # 📚 Documentation
    ├── README_HYBRID_RAG.md                # 🆕 Comprehensive guide
    ├── QUICK_START.md                      # 🆕 Quick setup
    ├── ARCHITECTURE.md                     # 🆕 System architecture
    └── IMPLEMENTATION_SUMMARY.md           # 🆕 Implementation summary
```

---

## Detailed Breakdown

### 🆕 NEW Files (Hybrid RAG System)

#### Core Services (`backend/services/`)
```
services/
├── hybrid_rag_service.py      # Main orchestrator (200 lines)
│   ├── Initializes all components
│   ├── Entry point: process_question()
│   └── Health checks
│
├── query_router.py             # Intelligent routing (150 lines)
│   ├── Classifies question types
│   ├── Estimates data size & tokens
│   └── Decides processing path
│
├── sql_generator.py            # NL → SQL (180 lines)
│   ├── Generates SQL from questions
│   ├── Fixes broken queries
│   └── Creates aggregate queries
│
├── vector_search.py            # pgvector search (170 lines)
│   ├── Creates embeddings (3 types)
│   ├── Similarity search
│   └── Hybrid search (vector + SQL)
│
├── query_processors.py         # Processing paths (250 lines)
│   ├── DirectLLMProcessor
│   ├── SQLFirstProcessor
│   └── HybridProcessor
│
└── data_import_service.py      # Excel import (200 lines)
    ├── Imports Excel → PostgreSQL
    ├── Creates embeddings
    └── Provides statistics
```

#### Routes (`backend/routes/`)
```
routes/
├── chat_routes_hybrid.py       # 🆕 NEW Hybrid RAG endpoints (250 lines)
│   ├── POST /chat/upload       # Import Excel → DB + embeddings
│   ├── POST /chat/send_message # Intelligent query processing
│   ├── GET /chat/stats         # Data statistics
│   ├── GET /chat/health        # Health check
│   └── POST /chat/clear_data   # Clear database
│
└── chat.py                     # ✅ EXISTING Standard chat (fallback)
```

#### Setup & Config
```
backend/
├── setup_database.py           # 🆕 NEW Database initialization
│   ├── Creates tables
│   ├── Enables pgvector
│   └── Creates indexes
│
├── app.py                      # ✅ UPDATED Main Flask app
│   ├── Imports chat_routes_hybrid.py
│   ├── Graceful fallback to standard chat
│   └── All existing routes preserved
│
└── requirements.txt            # ✅ UPDATED Dependencies
    ├── pgvector==0.2.4
    ├── openai==1.6.1
    └── (all existing packages)
```

---

## File Sizes & Line Counts

| File | Lines | Purpose |
|------|-------|---------|
| `hybrid_rag_service.py` | ~200 | Main orchestrator |
| `query_router.py` | ~150 | Intelligent routing |
| `sql_generator.py` | ~180 | SQL generation |
| `vector_search.py` | ~170 | Semantic search |
| `query_processors.py` | ~250 | 3 processing paths |
| `data_import_service.py` | ~200 | Excel import |
| `chat_routes_hybrid.py` | ~250 | API endpoints |
| `setup_database.py` | ~150 | DB initialization |
| **Total New Code** | **~1,550 lines** | |

---

## Database Tables

```
PostgreSQL Database: dashboard_360
│
├── integration_interfaces          # 🆕 NEW Main data table
│   ├── id (SERIAL PRIMARY KEY)
│   ├── interface_platform (TEXT)
│   ├── interface_id (TEXT)
│   ├── interface_name (TEXT)
│   ├── interface_description (TEXT)
│   ├── ... (44 columns total)
│   └── created_at (TIMESTAMP)
│
├── interface_embeddings            # 🆕 NEW Vector embeddings
│   ├── id (SERIAL PRIMARY KEY)
│   ├── interface_id (FK)
│   ├── content_type (TEXT)         # 'description', 'metadata', 'technical'
│   ├── content (TEXT)
│   ├── embedding (vector(1536))    # OpenAI ada-002
│   └── created_at (TIMESTAMP)
│
└── (Your existing tables)          # ✅ PRESERVED
    ├── users
    ├── azure_integrations
    ├── sharepoint_integrations
    └── ...
```

---

## Configuration Files

### Environment Variables (`.env`)
```bash
# PostgreSQL (Enhanced for Hybrid RAG)
DB_TYPE=postgresql
DB_HOST=localhost
DB_PORT=5432
DB_NAME=dashboard_360
DB_USER=dashboard_user
DB_PASSWORD=your_password

# Azure OpenAI (Required for Hybrid RAG)
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_DEPLOYMENT=gpt-4                    # For completions
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# SQLAlchemy
SQLALCHEMY_POOL_SIZE=10
SQLALCHEMY_POOL_RECYCLE=3600

# Flask
SECRET_KEY=your-secret-key
DEBUG=True
```

---

## API Endpoints Map

### Hybrid RAG Endpoints (NEW)
```
POST   /chat/upload              # Upload Excel → PostgreSQL + embeddings
POST   /chat/send_message        # Intelligent query processing
GET    /chat/stats               # Data statistics
GET    /chat/health              # System health
POST   /chat/clear_data          # Clear database
```

### Existing Endpoints (PRESERVED)
```
# Authentication
POST   /api/auth/register
POST   /api/auth/login
POST   /api/auth/logout
GET    /api/auth/me

# Dashboard
GET    /
GET    /login
GET    /dashboard
GET    /profile
GET    /settings

# Integrations (12 routes)
GET    /integrations/azure/apim
GET    /integrations/azure/storage
GET    /integrations/azure/openai
GET    /integrations/azure/postgresql
GET    /integrations/mft
GET    /integrations/sap-cpi
GET    /integrations/ibm-api-connect
GET    /integrations/ibm-datapower
GET    /integrations/splunk
GET    /integrations/sharepoint
GET    /integrations/api-gateway
GET    /integrations/excel

# Data Management (4 routes)
GET    /data-management/import
GET    /data-management/tables
GET    /data-management/sync-history
GET    /data-management/analytics

# Services (4 routes)
GET    /services/system-health
GET    /services/reports
GET    /services/analytics
GET    /services/security

# Resources (4 routes)
GET    /resources/videos
GET    /resources/documentation
GET    /resources/faq
GET    /resources/support

# Health & Debug
GET    /api/health
GET    /api/debug/models
```

---

## Installation Order

```bash
# 1. Place new files
backend/
├── services/              # Create folder, add 6 new files
├── routes/                # Add chat_routes_hybrid.py
├── setup_database.py      # Add database setup script
├── app.py                 # Replace with updated version
└── requirements.txt       # Update with new dependencies

# 2. Install dependencies
pip install -r requirements.txt

# 3. Setup database
python setup_database.py

# 4. Configure
cp .env.example .env
# Edit .env with credentials

# 5. Run
python app.py
```

---

## Key Integration Points

### How It All Connects

```
app.py (Main Flask App)
    │
    ├─► Imports: routes/chat_routes_hybrid.py
    │       │
    │       └─► Uses: services/hybrid_rag_service.py
    │               │
    │               ├─► services/query_router.py
    │               ├─► services/sql_generator.py
    │               ├─► services/vector_search.py
    │               ├─► services/query_processors.py
    │               └─► services/data_import_service.py
    │
    ├─► Uses: connectors/database_connector.py
    │       (Existing connector, uses config.py)
    │
    ├─► Uses: connectors/azure_openai_connector.py
    │       (Existing connector, uses config.py)
    │
    └─► Models: models.py
            (Existing models preserved)
```

---

## What You DON'T Need to Change

✅ **Keep As-Is:**
- `config.py` - Already has all DB/Azure configs
- `models.py` - Your existing models
- `connectors/` - All existing connectors
- `frontend/` - All templates and assets
- Authentication routes
- All dashboard routes
- All integration routes

---

## What Changes

🔄 **Update:**
- `app.py` - Replace with new version (imports Hybrid RAG)
- `requirements.txt` - Add pgvector and updated openai

➕ **Add:**
- `services/` folder with 6 new files
- `routes/chat_routes_hybrid.py`
- `setup_database.py`

---

## Storage Requirements

```
Code Size:
- New Python files: ~50 KB
- Documentation: ~100 KB
- Total: ~150 KB

Database:
- Per row: ~2 KB (data + 3 embeddings)
- 1,000 rows: ~2 MB
- 10,000 rows: ~20 MB
- 100,000 rows: ~200 MB
```

---

**🎯 Bottom Line:** 
- Add 7 new files (~1,550 lines)
- Update 2 existing files
- Keep everything else as-is
- Zero breaking changes to existing functionality
