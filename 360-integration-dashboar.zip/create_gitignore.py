gitignore_content = """# Virtual Environment
venv/
env/
ENV/
.venv/

# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
pip-wheel-metadata/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# Database
*.db
*.sqlite
*.sqlite3
instance/

# Environment
.env
.env.local
.env.*.local
.venv

# IDE
.vscode/
.idea/
*.swp
*.swo
*~
.project
.pydevproject
.settings/
*.sublime-project
*.sublime-workspace

# Logs
*.log
logs/
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# OS
.DS_Store
Thumbs.db
.AppleDouble
.LSOverride

# Testing
.pytest_cache/
.coverage
htmlcov/
.tox/

# Node (if using frontend tools)
node_modules/
dist/
.next/

# IDE Extensions
*.code-workspace

# Temporary files
*.tmp
*.bak
*.swp
*~

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/

# Flask stuff:
instance/
.webassets-cache

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/
"""

with open('.gitignore', 'w') as f:
    f.write(gitignore_content)

print("✓ .gitignore created successfully!")