/**
 * SPLUNK DASHBOARD INTEGRATION - FINAL VERSION
 * ============================================
 * 
 * Fully functional SplunkDashboardLoader for:
 * - Splunk internal logs (_internal index)
 * - HTTP access logs (splunkd_ui_access.log)
 * - Real-time dashboard updates
 * - Automatic 30-second refresh
 * - Graceful fallback to hardcoded values
 * 
 * @version 2.0.0
 * @date 2025-12-01
 */

class SplunkDashboardLoader {
    constructor() {
        this.splunkEndpoint = '/api/splunk';
        this.refreshInterval = 30000;  // 30 seconds
        this.timeout = 10000;          // 10 seconds
        this.isAvailable = false;
        
        console.log('🚀 SPLUNK DASHBOARD LOADER INITIALIZING');
    }
    
    /**
     * Initialize the Splunk dashboard loader
     */
    async init() {
        console.log('📊 Initializing Splunk Dashboard Loader...');
        
        // Check Splunk health
        await this.checkSplunkHealth();
        
        // Load initial metrics
        await this.loadAllMetrics();
        
        // Set up auto-refresh every 30 seconds
        setInterval(() => this.loadAllMetrics(), this.refreshInterval);
        
        console.log('✅ Splunk Dashboard Loader ready');
    }
    
    /**
     * Check if Splunk is healthy and reachable
     */
    async checkSplunkHealth() {
        try {
            const response = await fetch(`${this.splunkEndpoint}/health`, {
                method: 'GET',
                timeout: this.timeout
            });
            
            if (response.ok) {
                const health = await response.json();
                this.isAvailable = health.status === 'healthy';
                
                if (this.isAvailable) {
                    console.log('✅ Splunk is HEALTHY');
                } else {
                    console.log('⚠️ Splunk health check failed');
                }
            } else {
                this.isAvailable = false;
                console.log('⚠️ Splunk health endpoint returned', response.status);
            }
        } catch (error) {
            this.isAvailable = false;
            console.log('⚠️ Splunk not available:', error.message);
        }
    }
    
    /**
     * Load all metrics in parallel
     */
    async loadAllMetrics() {
        if (!this.isAvailable) {
            console.log('ℹ️ Splunk unavailable, using hardcoded values');
            return;
        }
        
        console.log('🚀 Loading all Splunk metrics...');
        
        try {
            await Promise.all([
                this.loadAPILatency(),
                this.loadErrorRate(),
                this.loadThroughput(),
                this.loadResponseTime(),
                this.loadDataPowerMetrics(),
                this.loadAPIUsageTrend()
            ]);
            console.log('✅ All metrics loaded successfully');
        } catch (error) {
            console.error('❌ Error loading metrics:', error);
        }
    }
    
    /**
     * Load API Latency (average elapsed time)
     */
    async loadAPILatency() {
        try {
            console.log('📊 Loading API Latency...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | stats avg(elapsed) as avg_latency',
                    earliest_time: '-1h',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    const latency = Math.round(parseFloat(result.results[0].avg_latency) || 0);
                    this.updateStatCard('latency', latency + 'ms');
                    console.log('✅ API Latency:', latency + 'ms');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ API Latency error:', error.message);
        }
        console.log('ℹ️ Using fallback: API Latency = 156ms');
    }
    
    /**
     * Load Error Rate (HTTP 4xx/5xx responses)
     */
    async loadErrorRate() {
        try {
            console.log('📊 Loading Error Rate...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | stats count(eval(status>=400)) as errors, count as total | eval error_rate=round((errors/total)*100, 2)',
                    earliest_time: '-24h',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    const errorRate = parseFloat(result.results[0].error_rate) || 0;
                    this.updateStatCard('error', errorRate + '%');
                    console.log('✅ Error Rate:', errorRate + '%');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ Error Rate error:', error.message);
        }
        console.log('ℹ️ Using fallback: Error Rate = 0.32%');
    }
    
    /**
     * Load Throughput (peak requests per second)
     */
    async loadThroughput() {
        try {
            console.log('📊 Loading Throughput...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | timechart count as requests span=1m | eval req_per_sec=round(requests/60, 0) | stats max(req_per_sec) as peak_throughput',
                    earliest_time: '-1h',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    const throughput = Math.round(parseFloat(result.results[0].peak_throughput) || 0);
                    this.updateStatCard('throughput', throughput.toLocaleString() + ' req/s');
                    console.log('✅ Throughput:', throughput + ' req/s');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ Throughput error:', error.message);
        }
        console.log('ℹ️ Using fallback: Throughput = 8,450 req/s');
    }
    
    /**
     * Load Response Time (average elapsed time)
     */
    async loadResponseTime() {
        try {
            console.log('📊 Loading Response Time...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | stats avg(elapsed) as response_time',
                    earliest_time: '-1h',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    const responseTime = Math.round(parseFloat(result.results[0].response_time) || 0);
                    this.updateStatCard('response', responseTime + 'ms');
                    console.log('✅ Response Time:', responseTime + 'ms');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ Response Time error:', error.message);
        }
        console.log('ℹ️ Using fallback: Response Time = 287ms');
    }
    
    /**
     * Load HTTP Methods distribution
     */
    async loadDataPowerMetrics() {
        try {
            console.log('📊 Loading HTTP Methods...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | stats count BY method',
                    earliest_time: '-1h',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    console.log('  Parsed methods:', result.results);
                    this.updateMethodCards(result.results);
                    console.log('✅ HTTP Methods:', result.results.length, 'methods found');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ HTTP Methods error:', error.message);
        }
        console.log('ℹ️ Using fallback: 3 hardcoded cards');
    }
    
    /**
     * Load 90-day API usage trend
     */
    async loadAPIUsageTrend() {
        try {
            console.log('📊 Loading 90-Day Trend...');
            
            const response = await fetch(`${this.splunkEndpoint}/search`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    query: 'search index=_internal source="C:\\\\Program Files\\\\Splunk\\\\var\\\\log\\\\splunk\\\\splunkd_ui_access.log" sourcetype=splunkd_ui_access | timechart count as requests, avg(elapsed) as avg_latency span=15d | eval requests=round(requests/1000, 1), avg_latency=round(avg_latency, 0)',
                    earliest_time: '-90d',
                    latest_time: 'now'
                }),
                timeout: this.timeout
            });
            
            if (response.ok) {
                const result = await response.json();
                console.log('  Raw response:', result);
                
                if (result.success && result.results?.length > 0) {
                    this.updateTrendChart(result.results);
                    console.log('✅ 90-Day Trend:', result.results.length, 'data points');
                    return;
                }
            } else {
                const errorData = await response.json();
                console.error('❌ API returned error:', errorData);
            }
        } catch (error) {
            console.error('❌ 90-Day Trend error:', error.message);
        }
        console.log('ℹ️ Using fallback: hardcoded 90-day trend');
    }
    
    /**
     * Update a stat card with a new value
     */
    updateStatCard(statName, value) {
        const card = document.querySelector(`[data-stat="${statName}"]`);
        if (card) {
            const valueEl = card.querySelector('.stat-value');
            if (valueEl) {
                valueEl.textContent = value;
                console.log(`  ✓ Updated ${statName}: ${value}`);
            }
        } else {
            console.warn(`⚠️ Stat card [data-stat="${statName}"] not found`);
        }
    }
    
    /**
     * Update method cards with HTTP method distribution
     */
    updateMethodCards(methodData) {
        const grid = document.querySelector('.datapower-grid');
        if (!grid) {
            console.warn('⚠️ .datapower-grid not found in DOM');
            return;
        }
        
        console.log('🔄 Creating method cards for:', methodData);
        grid.innerHTML = '';
        
        methodData.forEach((data, index) => {
            const method = data.method || 'UNKNOWN';
            const count = parseInt(data.count) || 0;
            
            console.log(`  Card ${index}: ${method} = ${count} requests`);
            
            const card = document.createElement('div');
            card.className = 'datapower-card';
            
            // Calculate bar width (normalize to 1000)
            const barWidth = Math.min((count / 1000) * 100, 100);
            
            card.innerHTML = `
                <div class="datapower-header">
                    <h3>${method}</h3>
                    <span class="health-badge healthy">Active</span>
                </div>
                <div class="metric-item">
                    <div class="metric-label">Requests (1h)</div>
                    <div class="metric-value">${count.toLocaleString()}</div>
                    <div class="metric-bar">
                        <div class="metric-bar-fill" style="width: ${barWidth}%; background: linear-gradient(90deg, #2d8659, #40b89f);"></div>
                    </div>
                </div>
            `;
            grid.appendChild(card);
        });
        
        console.log(`✅ Created ${methodData.length} method cards`);
    }
    
    /**
     * Update the trend chart with 90-day data
     */
    updateTrendChart(trendData) {
        if (window.chartInstances && window.chartInstances.trendChart) {
            const chart = window.chartInstances.trendChart;
            
            // Extract labels and data
            const labels = trendData.map(d => d._time || '');
            const requestsData = trendData.map(d => parseFloat(d.requests) || 0);
            const latencyData = trendData.map(d => parseFloat(d.avg_latency) || 0);
            
            // Update chart
            chart.data.labels = labels;
            chart.data.datasets[0].data = requestsData;
            chart.data.datasets[1].data = latencyData;
            chart.update();
            
            console.log(`  ✓ Updated trend chart with ${trendData.length} data points`);
        } else {
            console.warn('⚠️ Trend chart not initialized - window.chartInstances.trendChart not found');
        }
    }
}

// Initialize on document load
document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 Dashboard HTML loaded');
    
    // Small delay to ensure all DOM elements are ready
    setTimeout(() => {
        const loader = new SplunkDashboardLoader();
        loader.init();
    }, 500);
});

// Also support manual initialization if needed
if (typeof window !== 'undefined') {
    window.initSplunkDashboard = () => {
        const loader = new SplunkDashboardLoader();
        loader.init();
    };
}