"""
360° Enterprise Dashboard - SharePoint Connector
Handles SharePoint integration, document retrieval, and site management
"""

import os
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from office365.sharepoint.client_context import ClientContext
from office365.runtime.auth.authentication_context import AuthenticationContext
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)


class SharePointConnectorError(Exception):
    """Custom exception for SharePoint connector errors"""
    pass


class SharePointConnector:
    """SharePoint connector for document and site management"""
    
    def __init__(self):
        """Initialize SharePoint connector"""
        try:
            self.sharepoint_url = os.getenv('SHAREPOINT_SITE_URL')
            self.client_id = os.getenv('SHAREPOINT_CLIENT_ID')
            self.client_secret = os.getenv('SHAREPOINT_CLIENT_SECRET')
            self.tenant_id = os.getenv('AZURE_TENANT_ID')
            
            if not all([self.sharepoint_url, self.client_id, self.client_secret, self.tenant_id]):
                logger.warning("⚠ SharePoint configuration incomplete - SharePoint features will be limited")
                self.is_configured = False
            else:
                self.is_configured = True
                self.ctx = None
                self._authenticate()
                logger.info("✓ SharePoint connector initialized successfully")
        
        except Exception as e:
            logger.error(f"✗ SharePoint connector initialization error: {e}")
            self.is_configured = False
            raise SharePointConnectorError(f"Failed to initialize SharePoint connector: {str(e)}")
    
    
    def _authenticate(self):
        """Authenticate with SharePoint using client credentials"""
        try:
            if not self.is_configured:
                return
            
            # Using Office365-Python-Requests for authentication
            auth_url = f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token"
            auth_context = AuthenticationContext(auth_url)
            
            # Get authentication token
            if auth_context.acquire_token_for_user(self.client_id, self.client_secret):
                self.ctx = ClientContext(self.sharepoint_url, auth_context)
                logger.info("✓ SharePoint authentication successful")
                return True
            else:
                logger.error("✗ SharePoint authentication failed")
                self.is_configured = False
                return False
        
        except Exception as auth_err:
            logger.error(f"✗ SharePoint authentication error: {auth_err}")
            self.is_configured = False
            return False
    
    
    def health_check(self) -> Dict[str, Any]:
        """Check SharePoint connector health"""
        try:
            if not self.is_configured:
                return {
                    'status': 'unavailable',
                    'message': 'SharePoint not configured',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            try:
                # Try to get web properties
                web = self.ctx.web
                web.load()
                self.ctx.execute_query()
                
                return {
                    'status': 'healthy',
                    'message': 'Connected to SharePoint',
                    'site_url': self.sharepoint_url,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as health_err:
                logger.warning(f"⚠ SharePoint health check failed: {health_err}")
                return {
                    'status': 'unhealthy',
                    'message': str(health_err),
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        except Exception as e:
            logger.error(f"✗ SharePoint health check error: {e}")
            return {
                'status': 'error',
                'message': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    
    def get_site_info(self) -> Dict[str, Any]:
        """Get SharePoint site information"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            try:
                web = self.ctx.web
                web.load()
                self.ctx.execute_query()
                
                site_info = {
                    'success': True,
                    'title': web.properties.get('Title', 'Unknown'),
                    'url': web.properties.get('Url', self.sharepoint_url),
                    'created': web.properties.get('Created', 'Unknown'),
                    'last_modified': web.properties.get('LastItemModifiedDate', 'Unknown'),
                    'language': web.properties.get('Language', 'Unknown'),
                    'timestamp': datetime.utcnow().isoformat()
                }
                
                logger.info(f"✓ Retrieved SharePoint site info: {site_info['title']}")
                return site_info
            
            except Exception as site_err:
                logger.error(f"✗ Error getting site info: {site_err}")
                return {'success': False, 'error': str(site_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_site_info: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def get_lists(self) -> Dict[str, Any]:
        """Get all lists from SharePoint site"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured', 'lists': []}
            
            try:
                lists = self.ctx.web.lists
                lists.load()
                self.ctx.execute_query()
                
                list_info = []
                for lst in lists:
                    list_info.append({
                        'id': str(lst.properties.get('Id', '')),
                        'title': lst.properties.get('Title', 'Unknown'),
                        'item_count': lst.properties.get('ItemCount', 0),
                        'description': lst.properties.get('Description', ''),
                        'created': lst.properties.get('Created', ''),
                        'last_modified': lst.properties.get('LastItemModifiedDate', '')
                    })
                
                logger.info(f"✓ Retrieved {len(list_info)} SharePoint lists")
                
                return {
                    'success': True,
                    'lists': list_info,
                    'count': len(list_info),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as lists_err:
                logger.error(f"✗ Error getting lists: {lists_err}")
                return {'success': False, 'error': str(lists_err), 'lists': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_lists: {e}")
            return {'success': False, 'error': str(e), 'lists': []}
    
    
    def get_document_libraries(self) -> Dict[str, Any]:
        """Get all document libraries from SharePoint site"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured', 'libraries': []}
            
            try:
                libraries_result = self.ctx.web.lists
                libraries_result.load()
                self.ctx.execute_query()
                
                doc_libraries = []
                for lib in libraries_result:
                    # Filter for document libraries
                    if lib.properties.get('BaseTemplate') == 101:  # Document Library template
                        doc_libraries.append({
                            'id': str(lib.properties.get('Id', '')),
                            'title': lib.properties.get('Title', 'Unknown'),
                            'item_count': lib.properties.get('ItemCount', 0),
                            'description': lib.properties.get('Description', ''),
                            'relative_url': lib.properties.get('RootFolder', {}).get('Url', '')
                        })
                
                logger.info(f"✓ Retrieved {len(doc_libraries)} document libraries")
                
                return {
                    'success': True,
                    'libraries': doc_libraries,
                    'count': len(doc_libraries),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as lib_err:
                logger.error(f"✗ Error getting document libraries: {lib_err}")
                return {'success': False, 'error': str(lib_err), 'libraries': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_document_libraries: {e}")
            return {'success': False, 'error': str(e), 'libraries': []}
    
    
    def get_documents(self, library_title: str, folder_path: str = '') -> Dict[str, Any]:
        """Get documents from specific library"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured', 'documents': []}
            
            if not library_title:
                return {'success': False, 'error': 'Library title is required', 'documents': []}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                items = lib.items
                items.load()
                self.ctx.execute_query()
                
                documents = []
                for item in items:
                    # Only include file items
                    if item.properties.get('FileRef'):
                        documents.append({
                            'id': item.properties.get('ID', ''),
                            'name': item.properties.get('FileLeafRef', 'Unknown'),
                            'size': item.properties.get('FileSizeDisplay', 0),
                            'created': item.properties.get('Created', ''),
                            'modified': item.properties.get('Modified', ''),
                            'created_by': item.properties.get('Author', {}).get('Title', 'Unknown'),
                            'file_url': item.properties.get('FileRef', '')
                        })
                
                logger.info(f"✓ Retrieved {len(documents)} documents from {library_title}")
                
                return {
                    'success': True,
                    'library': library_title,
                    'documents': documents,
                    'count': len(documents),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as doc_err:
                logger.error(f"✗ Error getting documents: {doc_err}")
                return {'success': False, 'error': str(doc_err), 'documents': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_documents: {e}")
            return {'success': False, 'error': str(e), 'documents': []}
    
    
    def upload_document(self, library_title: str, file_name: str, file_content: bytes) -> Dict[str, Any]:
        """Upload document to SharePoint library"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            if not library_title or not file_name or not file_content:
                return {'success': False, 'error': 'Library title, file name, and content are required'}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                target_folder = lib.root_folder
                
                # Upload file
                file_item = target_folder.upload_file(file_name, file_content).execute_query()
                
                logger.info(f"✓ Document uploaded successfully: {file_name} to {library_title}")
                
                return {
                    'success': True,
                    'file_name': file_name,
                    'library': library_title,
                    'file_url': file_item.properties.get('ServerRelativeUrl', ''),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as upload_err:
                logger.error(f"✗ Error uploading document: {upload_err}")
                return {'success': False, 'error': str(upload_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in upload_document: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def download_document(self, library_title: str, file_name: str) -> Dict[str, Any]:
        """Download document from SharePoint library"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            if not library_title or not file_name:
                return {'success': False, 'error': 'Library title and file name are required'}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                items = lib.items
                items.filter(f"FileLeafRef eq '{file_name}'")
                items.load()
                self.ctx.execute_query()
                
                if not items:
                    return {'success': False, 'error': f'File not found: {file_name}'}
                
                file_item = items[0]
                file_url = file_item.properties.get('FileRef', '')
                
                logger.info(f"✓ Document retrieved: {file_name} from {library_title}")
                
                return {
                    'success': True,
                    'file_name': file_name,
                    'library': library_title,
                    'file_url': file_url,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as download_err:
                logger.error(f"✗ Error downloading document: {download_err}")
                return {'success': False, 'error': str(download_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in download_document: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def delete_document(self, library_title: str, file_name: str) -> Dict[str, Any]:
        """Delete document from SharePoint library"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured'}
            
            if not library_title or not file_name:
                return {'success': False, 'error': 'Library title and file name are required'}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                items = lib.items
                items.filter(f"FileLeafRef eq '{file_name}'")
                items.load()
                self.ctx.execute_query()
                
                if not items:
                    return {'success': False, 'error': f'File not found: {file_name}'}
                
                file_item = items[0]
                file_item.delete_object()
                self.ctx.execute_query()
                
                logger.info(f"✓ Document deleted: {file_name} from {library_title}")
                
                return {
                    'success': True,
                    'file_name': file_name,
                    'library': library_title,
                    'message': 'Document deleted successfully',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as delete_err:
                logger.error(f"✗ Error deleting document: {delete_err}")
                return {'success': False, 'error': str(delete_err)}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in delete_document: {e}")
            return {'success': False, 'error': str(e)}
    
    
    def search_documents(self, library_title: str, search_term: str) -> Dict[str, Any]:
        """Search documents in SharePoint library"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured', 'results': []}
            
            if not library_title or not search_term:
                return {'success': False, 'error': 'Library title and search term are required', 'results': []}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                items = lib.items
                items.filter(f"contains(FileLeafRef, '{search_term}')")
                items.load()
                self.ctx.execute_query()
                
                results = []
                for item in items:
                    if item.properties.get('FileRef'):
                        results.append({
                            'id': item.properties.get('ID', ''),
                            'name': item.properties.get('FileLeafRef', 'Unknown'),
                            'size': item.properties.get('FileSizeDisplay', 0),
                            'modified': item.properties.get('Modified', ''),
                            'file_url': item.properties.get('FileRef', '')
                        })
                
                logger.info(f"✓ Found {len(results)} documents matching '{search_term}'")
                
                return {
                    'success': True,
                    'search_term': search_term,
                    'library': library_title,
                    'results': results,
                    'count': len(results),
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as search_err:
                logger.error(f"✗ Error searching documents: {search_err}")
                return {'success': False, 'error': str(search_err), 'results': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in search_documents: {e}")
            return {'success': False, 'error': str(e), 'results': []}
    
    
    def get_shared_links(self, library_title: str, file_name: str) -> Dict[str, Any]:
        """Get shared links for a document"""
        try:
            if not self.is_configured:
                return {'success': False, 'error': 'SharePoint not configured', 'links': []}
            
            if not library_title or not file_name:
                return {'success': False, 'error': 'Library title and file name are required', 'links': []}
            
            try:
                lib = self.ctx.web.lists.get_by_title(library_title)
                items = lib.items
                items.filter(f"FileLeafRef eq '{file_name}'")
                items.load()
                self.ctx.execute_query()
                
                if not items:
                    return {'success': False, 'error': f'File not found: {file_name}', 'links': []}
                
                file_item = items[0]
                
                # Generate share links (simplified for this example)
                file_url = file_item.properties.get('FileRef', '')
                
                share_links = {
                    'edit_link': f"{self.sharepoint_url}/sites/edit?file={file_url}",
                    'view_link': f"{self.sharepoint_url}/sites/view?file={file_url}",
                    'download_link': f"{self.sharepoint_url}/sites/download?file={file_url}"
                }
                
                logger.info(f"✓ Generated share links for {file_name}")
                
                return {
                    'success': True,
                    'file_name': file_name,
                    'links': share_links,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            except Exception as share_err:
                logger.error(f"✗ Error getting shared links: {share_err}")
                return {'success': False, 'error': str(share_err), 'links': []}
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_shared_links: {e}")
            return {'success': False, 'error': str(e), 'links': []}
    
    
    def get_sharepoint_stats(self) -> Dict[str, Any]:
        """Get SharePoint site statistics"""
        try:
            if not self.is_configured:
                return {
                    'site_name': 'Unknown',
                    'total_libraries': 0,
                    'total_documents': 0,
                    'storage_used': 0
                }
            
            try:
                # Get site info
                web = self.ctx.web
                web.load()
                self.ctx.execute_query()
                
                # Get libraries
                lists = self.ctx.web.lists
                lists.load()
                self.ctx.execute_query()
                
                doc_count = 0
                for lst in lists:
                    if lst.properties.get('BaseTemplate') == 101:  # Document Library
                        doc_count += lst.properties.get('ItemCount', 0)
                
                stats = {
                    'site_name': web.properties.get('Title', 'Unknown'),
                    'site_url': self.sharepoint_url,
                    'total_libraries': len(lists),
                    'total_documents': doc_count,
                    'last_updated': datetime.utcnow().isoformat()
                }
                
                logger.info(f"✓ Retrieved SharePoint statistics")
                return stats
            
            except Exception as stats_err:
                logger.error(f"✗ Error getting statistics: {stats_err}")
                return {
                    'site_name': 'Unknown',
                    'total_libraries': 0,
                    'total_documents': 0,
                    'error': str(stats_err)
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in get_sharepoint_stats: {e}")
            return {
                'site_name': 'Unknown',
                'total_libraries': 0,
                'total_documents': 0,
                'error': str(e)
            }


# ============================================================================
# GLOBAL CONNECTOR INSTANCE
# ============================================================================

_sharepoint_connector = None


def get_sharepoint_connector() -> Optional[SharePointConnector]:
    """Get or create SharePoint connector instance (singleton pattern)"""
    global _sharepoint_connector
    
    try:
        if _sharepoint_connector is None:
            _sharepoint_connector = SharePointConnector()
        return _sharepoint_connector
    
    except SharePointConnectorError as e:
        logger.error(f"✗ Failed to get SharePoint connector: {e}")
        return None
    
    except Exception as e:
        logger.error(f"✗ Unexpected error getting SharePoint connector: {e}")
        return None