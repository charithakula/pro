import zipfile
import os

def zip_project(folder_path, output_zip):
    """
    Create a clean ZIP of the project excluding unnecessary files.
    """
    # Directories to exclude
    exclude_dirs = {
        '__pycache__',
        'venv',
        '.venv',
        # 'env',
        # '.env.local',
        # '.vscode',
        '.idea',
        '.git',
        'node_modules',
        '.pytest_cache',
        '.mypy_cache',
        'htmlcov',
        '.tox',
        'dist',
        'build',
        '*.egg-info',
        'logs',
        '.vs',
        'instance',
    }

    # File patterns to exclude
    exclude_files = {
        # '.env',
        # '.env.local',
        # '.env.production',
        '.DS_Store',
        'Thumbs.db',
        '*.pyc',
        '*.pyo',
        '*.pyd',
        '*.so',
        '*.db',
        '*.sqlite',
        '*.sqlite3',
        '*.log',
        '*.zip',
        '*.tar.gz',
        '*.rar',
        '.gitignore',
        '.dockerignore',
        'nul',  # Windows special file
        'con',  # Windows special file
        'prn',  # Windows special file
        'aux',  # Windows special file
    }

    # File extensions to exclude
    exclude_extensions = {
        '.pyc', '.pyo', '.pyd', '.so', '.dll',
        '.log', '.db', '.sqlite', '.sqlite3',
        '.zip', '.tar', '.gz', '.rar', '.7z',
        '.exe', '.bin', '.o', '.a',
    }

    files_added = 0
    files_skipped = 0

    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(folder_path):
            # Filter out excluded directories (modify in place)
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]

            for file in files:
                # Skip excluded files
                if file.lower() in exclude_files:
                    files_skipped += 1
                    continue

                # Skip files with excluded extensions
                _, ext = os.path.splitext(file)
                if ext.lower() in exclude_extensions:
                    files_skipped += 1
                    continue

                # Skip hidden files (starting with .)
                if file.startswith('.'):
                    files_skipped += 1
                    continue

                # Skip Windows special files
                base_name = os.path.splitext(file)[0].lower()
                if base_name in {'nul', 'con', 'prn', 'aux', 'com1', 'com2', 'lpt1', 'lpt2'}:
                    files_skipped += 1
                    continue

                filepath = os.path.join(root, file)

                # Skip if file doesn't exist or is a special file
                try:
                    if not os.path.isfile(filepath):
                        files_skipped += 1
                        continue

                    # Try to get file size to ensure it's accessible
                    os.path.getsize(filepath)

                    arcname = os.path.relpath(filepath, start=folder_path)

                    # Skip if relative path calculation fails
                    if arcname.startswith('..'):
                        files_skipped += 1
                        continue

                    zipf.write(filepath, arcname)
                    files_added += 1

                except (OSError, ValueError) as e:
                    print(f"  Skipping: {file} ({e})")
                    files_skipped += 1
                    continue

    return files_added, files_skipped


if __name__ == "__main__":
    # Use the current project folder
    folder_to_zip = os.getcwd()
    project_name = os.path.basename(folder_to_zip)
    output_zip = os.path.join(os.path.dirname(folder_to_zip), f"{project_name}.zip")

    print(f"Creating ZIP from: {folder_to_zip}")
    print(f"Output: {output_zip}")
    print()

    added, skipped = zip_project(folder_to_zip, output_zip)

    print()
    print(f"Done!")
    print(f"  Files added: {added}")
    print(f"  Files skipped: {skipped}")
    print(f"  ZIP created: {output_zip}")
