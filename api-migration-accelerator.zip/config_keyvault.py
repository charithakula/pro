"""
Production Configuration File with Azure Key Vault Integration
All environment variables use API_ prefix for consistency

Usage:
    1. Set API_KEYVAULT_URL to enable Key Vault
    2. Or use .env file with API_ prefixed variables
    3. Key Vault secrets use hyphens (API-DB-PASSWORD)
    4. Environment variables use underscores (API_DB_PASSWORD)
"""
import os
from datetime import timedelta
from typing import Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ==========================================
# KEY VAULT INTEGRATION
# ==========================================
def get_secret(name: str, default: Optional[str] = None) -> Optional[str]:
    """
    Get configuration value from Key Vault or environment.
    All keys should use API_ prefix.
    """
    try:
        from connectors.azure_keyvault_connector import get_config
        return get_config(name, default)
    except ImportError:
        # Fall back to environment variable if Key Vault not available
        return os.getenv(name, default)


def get_secret_bool(name: str, default: bool = False) -> bool:
    """Get config as boolean"""
    value = get_secret(name)
    if value is None:
        return default
    return str(value).lower() in ('true', '1', 'yes', 'on')


def get_secret_int(name: str, default: int = 0) -> int:
    """Get config as integer"""
    value = get_secret(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


class BaseConfig:
    """Base configuration with API_ prefix - shared across all environments"""

    # ==========================================
    # ENVIRONMENT
    # ==========================================
    ENV = get_secret('API_ENV', 'development')

    # ==========================================
    # KEY VAULT CONFIGURATION
    # ==========================================
    KEYVAULT_URL = get_secret('API_KEYVAULT_URL')
    KEYVAULT_CLIENT_ID = get_secret('API_KEYVAULT_CLIENT_ID')
    KEYVAULT_TENANT_ID = get_secret('API_KEYVAULT_TENANT_ID')
    # Note: API_KEYVAULT_CLIENT_SECRET should only be in Key Vault or secure env

    # ==========================================
    # FLASK CONFIGURATION
    # ==========================================
    SECRET_KEY = get_secret('API_SECRET_KEY', 'dev-secret-key-change-this')
    DEBUG = get_secret_bool('API_DEBUG', False)
    TESTING = False

    # ==========================================
    # SERVER CONFIGURATION
    # ==========================================
    HOST = get_secret('API_HOST', '0.0.0.0')
    PORT = get_secret_int('API_PORT', 5000)

    # ==========================================
    # DATABASE CONFIGURATION (API_ prefix)
    # ==========================================
    DATABASE_URL = get_secret('API_DATABASE_URL')

    # Build DATABASE_URL if not provided
    if not DATABASE_URL:
        DB_TYPE = get_secret('API_DB_TYPE', 'sqlite').lower()

        if DB_TYPE == 'postgresql':
            DB_HOST = get_secret('API_DB_HOST', 'localhost')
            DB_PORT = get_secret('API_DB_PORT', '5432')
            DB_NAME = get_secret('API_DB_NAME', 'api_migration_db')
            DB_USER = get_secret('API_DB_USER', 'api_user')
            DB_PASSWORD = get_secret('API_DB_PASSWORD', '')
            DB_SCHEMA = get_secret('API_DB_SCHEMA', 'api')

            # Include schema in connection options
            DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?options=-csearch_path%3D{DB_SCHEMA}"
        else:
            # Default to SQLite
            DATABASE_URL = 'sqlite:///migrations.db'

    SQLALCHEMY_DATABASE_URI = DATABASE_URL
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Database connection pooling
    if DATABASE_URL and 'postgresql' in DATABASE_URL.lower():
        SQLALCHEMY_ENGINE_OPTIONS = {
            'pool_size': get_secret_int('API_DB_POOL_SIZE', 10),
            'max_overflow': get_secret_int('API_DB_MAX_OVERFLOW', 20),
            'pool_timeout': get_secret_int('API_DB_POOL_TIMEOUT', 30),
            'pool_recycle': get_secret_int('API_DB_POOL_RECYCLE', 3600),
            'pool_pre_ping': True,
            'echo': DEBUG
        }
    else:
        SQLALCHEMY_ENGINE_OPTIONS = {}

    # ==========================================
    # FILE HANDLING
    # ==========================================
    UPLOAD_FOLDER = get_secret('API_UPLOAD_FOLDER', 'static/uploads')
    CONVERTED_FOLDER = get_secret('API_CONVERTED_FOLDER', 'static/converted')
    MAX_CONTENT_LENGTH = get_secret_int('API_MAX_CONTENT_LENGTH', 16 * 1024 * 1024)
    ALLOWED_EXTENSIONS = set(get_secret('API_ALLOWED_EXTENSIONS', 'json,yaml,yml').split(','))

    # ==========================================
    # LOGGING CONFIGURATION
    # ==========================================
    LOG_LEVEL = get_secret('API_LOG_LEVEL', 'INFO')
    LOG_FILE = get_secret('API_LOG_FILE', 'logs/app.log')
    STRUCTURED_LOGGING = get_secret_bool('API_STRUCTURED_LOGGING', True)

    # ==========================================
    # SESSION CONFIGURATION
    # ==========================================
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)
    SESSION_COOKIE_SECURE = get_secret_bool('API_SESSION_COOKIE_SECURE', True)
    SESSION_COOKIE_HTTPONLY = get_secret_bool('API_SESSION_COOKIE_HTTPONLY', True)
    SESSION_COOKIE_SAMESITE = get_secret('API_SESSION_COOKIE_SAMESITE', 'Lax')
    SESSION_COOKIE_NAME = get_secret('API_SESSION_COOKIE_NAME', 'api_migration_session')

    # ==========================================
    # SECURITY CONFIGURATION
    # ==========================================
    SECURITY_HEADERS_ENABLED = get_secret_bool('API_SECURITY_HEADERS_ENABLED', True)
    CORS_ALLOWED_ORIGINS = get_secret('API_CORS_ALLOWED_ORIGINS', '*').split(',')

    # ==========================================
    # RATE LIMITING
    # ==========================================
    RATELIMIT_ENABLED = get_secret_bool('API_RATELIMIT_ENABLED', True)
    RATELIMIT_DEFAULT_PER_MINUTE = get_secret_int('API_RATELIMIT_DEFAULT_PER_MINUTE', 60)
    RATELIMIT_DEFAULT_PER_HOUR = get_secret_int('API_RATELIMIT_DEFAULT_PER_HOUR', 1000)

    # ==========================================
    # TIMEOUTS (in seconds)
    # ==========================================
    REQUEST_TIMEOUT_SECONDS = get_secret_int('API_REQUEST_TIMEOUT_SECONDS', 30)
    DATABASE_TIMEOUT_SECONDS = get_secret_int('API_DATABASE_TIMEOUT_SECONDS', 10)
    OPENAI_TIMEOUT_SECONDS = get_secret_int('API_OPENAI_TIMEOUT_SECONDS', 60)
    STORAGE_TIMEOUT_SECONDS = get_secret_int('API_STORAGE_TIMEOUT_SECONDS', 10)
    APIM_TIMEOUT_SECONDS = get_secret_int('API_APIM_TIMEOUT_SECONDS', 30)

    # ==========================================
    # AZURE AUTHENTICATION (API_ prefix)
    # ==========================================
    AZURE_CLIENT_ID = get_secret('API_AZURE_CLIENT_ID')
    AZURE_CLIENT_SECRET = get_secret('API_AZURE_CLIENT_SECRET')
    AZURE_TENANT_ID = get_secret('API_AZURE_TENANT_ID')
    AZURE_SUBSCRIPTION_ID = get_secret('API_AZURE_SUBSCRIPTION_ID')

    # ==========================================
    # AZURE OPENAI CONFIGURATION (API_ prefix)
    # ==========================================
    AZURE_OPENAI_ENDPOINT = get_secret('API_OPENAI_ENDPOINT')
    AZURE_OPENAI_API_KEY = get_secret('API_OPENAI_API_KEY')
    AZURE_OPENAI_DEPLOYMENT = get_secret('API_OPENAI_DEPLOYMENT', 'gpt-4o-mini')
    AZURE_OPENAI_VERSION = get_secret('API_OPENAI_VERSION', '2024-08-01-preview')

    # ==========================================
    # AZURE API MANAGEMENT (API_ prefix)
    # ==========================================
    AZURE_APIM_RESOURCE_GROUP = get_secret('API_APIM_RESOURCE_GROUP')
    AZURE_APIM_SERVICE_NAME = get_secret('API_APIM_SERVICE_NAME')
    AZURE_APIM_API_KEY = get_secret('API_APIM_API_KEY')
    AZURE_APIM_BASE_URL = get_secret('API_APIM_BASE_URL', 'https://management.azure.com')

    # ==========================================
    # AZURE STORAGE (API_ prefix)
    # ==========================================
    AZURE_STORAGE_CONNECTION_STRING = get_secret('API_STORAGE_CONNECTION_STRING')
    AZURE_STORAGE_ACCOUNT_NAME = get_secret('API_STORAGE_ACCOUNT_NAME')
    AZURE_STORAGE_ACCOUNT_KEY = get_secret('API_STORAGE_ACCOUNT_KEY')
    AZURE_STORAGE_CONTAINER_NAME = get_secret('API_STORAGE_CONTAINER_NAME', 'api-migration')
    AZURE_STORAGE_VERIFY_SSL = get_secret_bool('API_STORAGE_VERIFY_SSL', True)

    # ==========================================
    # SSL CONFIGURATION
    # ==========================================
    VERIFY_SSL = get_secret_bool('API_VERIFY_SSL', True)
    CA_BUNDLE_PATH = get_secret('API_CA_BUNDLE_PATH')

    # ==========================================
    # CACHE CONFIGURATION
    # ==========================================
    CACHE_TYPE = get_secret('API_CACHE_TYPE', 'SimpleCache')
    CACHE_DEFAULT_TIMEOUT = get_secret_int('API_CACHE_DEFAULT_TIMEOUT', 300)
    CACHE_REDIS_URL = get_secret('API_REDIS_URL')

    # ==========================================
    # IBM API CONNECT (API_ prefix)
    # ==========================================
    IBM_API_CONNECT_URL = get_secret('API_IBM_URL')
    IBM_API_CONNECT_USERNAME = get_secret('API_IBM_USERNAME')
    IBM_API_CONNECT_PASSWORD = get_secret('API_IBM_PASSWORD')
    IBM_API_CONNECT_ORG = get_secret('API_IBM_ORG')
    IBM_API_CONNECT_CATALOG = get_secret('API_IBM_CATALOG')

    # ==========================================
    # HEALTH & MONITORING
    # ==========================================
    HEALTH_CHECK_INTERVAL_SECONDS = get_secret_int('API_HEALTH_CHECK_INTERVAL', 300)
    HEALTH_CHECK_TIMEOUT_SECONDS = get_secret_int('API_HEALTH_CHECK_TIMEOUT', 30)

    # ==========================================
    # HELPER METHODS
    # ==========================================
    @classmethod
    def get_ssl_config(cls):
        """Get SSL configuration as dict"""
        if cls.CA_BUNDLE_PATH:
            return {'verify': cls.CA_BUNDLE_PATH}
        return {'verify': cls.VERIFY_SSL}


class DevelopmentConfig(BaseConfig):
    """Development configuration"""
    DEBUG = True
    ENV = 'development'


class ProductionConfig(BaseConfig):
    """Production configuration"""
    DEBUG = False
    ENV = 'production'
    SESSION_COOKIE_SECURE = True


class TestingConfig(BaseConfig):
    """Testing configuration"""
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


# Configuration mapping
config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}


def get_config(env: str = None):
    """Get configuration class based on environment"""
    if env is None:
        env = os.getenv('API_ENV', 'development')
    return config_map.get(env, DevelopmentConfig)
