"""
Azure API Management Connector Test Script
============================================
Test script to validate Azure APIM connection independently from the web app.

Setup:
    1. Copy .env.example to .env and fill in Azure credentials
    2. Run: python tests/test_apim_connector.py

Requirements:
    pip install azure-identity azure-mgmt-apimanagement python-dotenv

Service Principal Requirements:
    - API Management Service Contributor role on APIM instance
    - OR Contributor role on the Resource Group containing APIM
"""

import os
import sys
import time
import json
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def print_header(title: str):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def print_result(test_name: str, success: bool, message: str = "", details: dict = None):
    """Print test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"\n{status} | {test_name}")
    if message:
        print(f"       {message}")
    if details:
        for key, value in details.items():
            print(f"       {key}: {value}")


def test_configuration():
    """Test 1: Validate Azure configuration"""
    print_header("TEST 1: Configuration Validation")

    config = {
        # Azure Authentication
        'client_id': os.getenv('API_AZURE_CLIENT_ID'),
        'client_secret': os.getenv('API_AZURE_CLIENT_SECRET'),
        'tenant_id': os.getenv('API_AZURE_TENANT_ID'),
        'subscription_id': os.getenv('API_AZURE_SUBSCRIPTION_ID'),
        # APIM Configuration
        'resource_group': os.getenv('API_APIM_RESOURCE_GROUP'),
        'service_name': os.getenv('API_APIM_SERVICE_NAME'),
        # SSL
        'verify_ssl': os.getenv('API_VERIFY_SSL', 'True'),
    }

    print("\nAzure Authentication:")
    print(f"  Client ID:       {'SET' if config['client_id'] else 'NOT SET'}")
    print(f"  Client Secret:   {'SET' if config['client_secret'] else 'NOT SET'}")
    print(f"  Tenant ID:       {config['tenant_id'] or 'NOT SET'}")
    print(f"  Subscription ID: {config['subscription_id'] or 'NOT SET'}")

    print("\nAPIM Configuration:")
    print(f"  Resource Group:  {config['resource_group'] or 'NOT SET'}")
    print(f"  Service Name:    {config['service_name'] or 'NOT SET'}")

    print("\nSSL Configuration:")
    print(f"  Verify SSL:      {config['verify_ssl']}")

    # Check required fields
    auth_ready = all([
        config['client_id'],
        config['client_secret'],
        config['tenant_id'],
        config['subscription_id']
    ])

    apim_ready = all([
        config['resource_group'],
        config['service_name']
    ])

    ready = auth_ready and apim_ready

    print_result(
        "Configuration Check",
        ready,
        "All required configuration present" if ready else "Missing configuration",
        {
            'Auth Ready': auth_ready,
            'APIM Ready': apim_ready
        }
    )

    return ready, config


def test_sdk_import():
    """Test 2: Verify Azure SDK installation"""
    print_header("TEST 2: Azure SDK Import")

    results = {}

    # Test azure-identity
    try:
        from azure.identity import ClientSecretCredential
        results['azure-identity'] = True
        print("  ✅ azure-identity imported successfully")
    except ImportError as e:
        results['azure-identity'] = False
        print(f"  ❌ azure-identity import failed: {e}")

    # Test azure-mgmt-apimanagement
    try:
        from azure.mgmt.apimanagement import ApiManagementClient
        results['azure-mgmt-apimanagement'] = True
        print("  ✅ azure-mgmt-apimanagement imported successfully")
    except ImportError as e:
        results['azure-mgmt-apimanagement'] = False
        print(f"  ❌ azure-mgmt-apimanagement import failed: {e}")

    all_imported = all(results.values())
    print_result(
        "Azure SDK Import",
        all_imported,
        "All required packages available" if all_imported else "Missing packages"
    )

    if not all_imported:
        print("\n  Install missing packages with:")
        print("    pip install azure-identity azure-mgmt-apimanagement")

    return all_imported


def test_authentication():
    """Test 3: Azure Service Principal authentication"""
    print_header("TEST 3: Service Principal Authentication")

    client_id = os.getenv('API_AZURE_CLIENT_ID')
    client_secret = os.getenv('API_AZURE_CLIENT_SECRET')
    tenant_id = os.getenv('API_AZURE_TENANT_ID')

    if not all([client_id, client_secret, tenant_id]):
        print_result("Authentication", False, "Missing credentials")
        return None

    try:
        from azure.identity import ClientSecretCredential

        start_time = time.time()

        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )

        # Get a token to verify credential works
        # Using management scope for APIM operations
        token = credential.get_token("https://management.azure.com/.default")

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "Service Principal Authentication",
            True,
            f"Token acquired in {elapsed:.0f}ms",
            {
                'Token Expires': datetime.fromtimestamp(token.expires_on).isoformat()
            }
        )

        return credential

    except Exception as e:
        print_result("Service Principal Authentication", False, str(e))

        error_msg = str(e).lower()
        if 'unauthorized' in error_msg or 'invalid' in error_msg:
            print("\n  SOLUTION: Verify Service Principal credentials:")
            print("    - Client ID matches App Registration Application ID")
            print("    - Client Secret is valid and not expired")
            print("    - Tenant ID is correct")
        elif 'not found' in error_msg:
            print("\n  SOLUTION: App Registration may not exist or is deleted")

        return None


def test_apim_client_creation(credential):
    """Test 4: Create APIM client"""
    print_header("TEST 4: APIM Client Creation")

    if not credential:
        print_result("APIM Client", False, "No credential available")
        return None

    subscription_id = os.getenv('API_AZURE_SUBSCRIPTION_ID')

    try:
        from azure.mgmt.apimanagement import ApiManagementClient

        start_time = time.time()

        client = ApiManagementClient(
            credential=credential,
            subscription_id=subscription_id
        )

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "APIM Client Creation",
            True,
            f"Client created in {elapsed:.0f}ms",
            {
                'Subscription': subscription_id[:8] + '...' if subscription_id else 'N/A'
            }
        )

        return client

    except Exception as e:
        print_result("APIM Client Creation", False, str(e))
        return None


def test_apim_connection(client):
    """Test 5: Test connection to APIM service"""
    print_header("TEST 5: APIM Connection Test")

    if not client:
        print_result("APIM Connection", False, "No client available")
        return False

    resource_group = os.getenv('API_APIM_RESOURCE_GROUP')
    service_name = os.getenv('API_APIM_SERVICE_NAME')

    try:
        start_time = time.time()

        # Get APIM service details
        service = client.api_management_service.get(
            resource_group_name=resource_group,
            service_name=service_name
        )

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "APIM Connection",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'Service Name': service.name,
                'Location': service.location,
                'SKU': f"{service.sku.name} ({service.sku.capacity} unit(s))",
                'State': service.provisioning_state,
                'Gateway URL': service.gateway_url
            }
        )

        return True

    except Exception as e:
        error_msg = str(e)
        print_result("APIM Connection", False, error_msg[:200])

        if 'ResourceNotFound' in error_msg:
            print(f"\n  SOLUTION: APIM service '{service_name}' not found in resource group '{resource_group}'")
            print("    - Verify API_APIM_SERVICE_NAME and API_APIM_RESOURCE_GROUP")
        elif 'AuthorizationFailed' in error_msg:
            print("\n  SOLUTION: Service Principal lacks permission")
            print("    - Assign 'API Management Service Contributor' role")
            print("    - Or assign 'Contributor' role on the Resource Group")

        return False


def test_list_apis(client):
    """Test 6: List APIs in APIM"""
    print_header("TEST 6: List APIs")

    if not client:
        print_result("List APIs", False, "No client available")
        return []

    resource_group = os.getenv('API_APIM_RESOURCE_GROUP')
    service_name = os.getenv('API_APIM_SERVICE_NAME')

    try:
        start_time = time.time()

        apis = list(client.api.list_by_service(
            resource_group_name=resource_group,
            service_name=service_name
        ))

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "List APIs",
            True,
            f"Found {len(apis)} API(s) in {elapsed:.0f}ms"
        )

        if apis:
            print("\n  APIs Found:")
            for api in apis[:10]:  # Show first 10
                print(f"    - {api.display_name} ({api.name})")
                print(f"      Path: /{api.path}")
                print(f"      Protocols: {', '.join(api.protocols or [])}")

            if len(apis) > 10:
                print(f"    ... and {len(apis) - 10} more")

        return apis

    except Exception as e:
        print_result("List APIs", False, str(e)[:200])
        return []


def test_list_products(client):
    """Test 7: List Products in APIM"""
    print_header("TEST 7: List Products")

    if not client:
        print_result("List Products", False, "No client available")
        return []

    resource_group = os.getenv('API_APIM_RESOURCE_GROUP')
    service_name = os.getenv('API_APIM_SERVICE_NAME')

    try:
        start_time = time.time()

        products = list(client.product.list_by_service(
            resource_group_name=resource_group,
            service_name=service_name
        ))

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "List Products",
            True,
            f"Found {len(products)} product(s) in {elapsed:.0f}ms"
        )

        if products:
            print("\n  Products Found:")
            for product in products[:10]:
                print(f"    - {product.display_name} ({product.name})")
                print(f"      State: {product.state}")
                print(f"      Subscription Required: {product.subscription_required}")

        return products

    except Exception as e:
        print_result("List Products", False, str(e)[:200])
        return []


def test_connector_class():
    """Test 8: Test the actual AzureAPIMConnector class"""
    print_header("TEST 8: AzureAPIMConnector Class")

    try:
        from connectors.azure_apim_connector import AzureAPIMConnector

        print("\n  Creating connector instance...")
        connector = AzureAPIMConnector()

        # Check if available
        print(f"  Connector available: {connector.is_available}")

        if not connector.is_available:
            print_result(
                "AzureAPIMConnector Class",
                False,
                "Connector not available - client initialization failed"
            )
            return False

        # Test connection
        print("  Testing connection...")
        result = connector.test_connection()

        if result['status'] == 'success':
            print_result(
                "AzureAPIMConnector Class",
                True,
                result.get('message', 'Connected'),
                {
                    'Service': result.get('service_name', 'N/A'),
                    'API Count': result.get('api_count', 0)
                }
            )

            # Test list APIs
            print("\n  Listing APIs via connector...")
            apis = connector.list_apis(use_cache=False)
            print(f"    Found {len(apis)} API(s)")

            # Show cache stats
            cache_stats = connector.get_cache_stats()
            print(f"\n  Cache Status:")
            print(f"    Enabled: {cache_stats['cache_enabled']}")
            print(f"    Type: {cache_stats['cache_type']}")

            return True
        else:
            print_result(
                "AzureAPIMConnector Class",
                False,
                result.get('message', 'Connection failed')
            )
            return False

    except ImportError as e:
        print_result("AzureAPIMConnector Class", False, f"Import error: {e}")
        return False
    except Exception as e:
        print_result("AzureAPIMConnector Class", False, str(e))
        return False


def test_api_export(client, apis):
    """Test 9: Export API specification"""
    print_header("TEST 9: Export API Specification")

    if not client or not apis:
        print_result("API Export", False, "No client or APIs available")
        return False

    resource_group = os.getenv('API_APIM_RESOURCE_GROUP')
    service_name = os.getenv('API_APIM_SERVICE_NAME')

    # Pick first API to export
    test_api = apis[0]

    try:
        start_time = time.time()

        # Export API spec
        export_result = client.api_export.get(
            resource_group_name=resource_group,
            service_name=service_name,
            api_id=test_api.name,
            format='openapi+json'
        )

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "API Export",
            True,
            f"Exported '{test_api.display_name}' in {elapsed:.0f}ms",
            {
                'API ID': test_api.name,
                'Format': 'OpenAPI 3.0 JSON'
            }
        )

        # Parse and show basic info
        if export_result.value:
            try:
                spec = json.loads(export_result.value)
                print(f"\n  Exported Specification:")
                print(f"    OpenAPI Version: {spec.get('openapi', spec.get('swagger', 'Unknown'))}")
                print(f"    Title: {spec.get('info', {}).get('title', 'N/A')}")
                print(f"    Paths: {len(spec.get('paths', {}))}")
            except:
                print(f"    Raw length: {len(export_result.value)} chars")

        return True

    except Exception as e:
        print_result("API Export", False, str(e)[:200])
        return False


def run_all_tests():
    """Run all APIM connector tests"""
    print("\n" + "=" * 70)
    print(" AZURE API MANAGEMENT CONNECTOR TEST SUITE")
    print(" Testing connection from local environment (outside Azure Web App)")
    print("=" * 70)

    results = {}

    # Test 1: Configuration
    has_config, config = test_configuration()
    results['configuration'] = has_config

    if not has_config:
        print("\n" + "=" * 70)
        print(" TESTS ABORTED: Missing Azure configuration")
        print("=" * 70)
        print("\nSetup Instructions:")
        print("  1. Create .env file in project root")
        print("  2. Add the following configuration:")
        print("\n  # Azure Service Principal")
        print("  API_AZURE_CLIENT_ID=your-app-client-id")
        print("  API_AZURE_CLIENT_SECRET=your-app-client-secret")
        print("  API_AZURE_TENANT_ID=your-tenant-id")
        print("  API_AZURE_SUBSCRIPTION_ID=your-subscription-id")
        print("\n  # APIM Configuration")
        print("  API_APIM_RESOURCE_GROUP=your-resource-group")
        print("  API_APIM_SERVICE_NAME=your-apim-service-name")
        print("\n  NOTE: Service Principal needs 'API Management Service Contributor'")
        print("        or 'Contributor' role on the Resource Group.")
        return results

    # Test 2: SDK Import
    results['sdk_import'] = test_sdk_import()
    if not results['sdk_import']:
        return results

    # Test 3: Authentication
    credential = test_authentication()
    results['authentication'] = credential is not None

    if not credential:
        return results

    # Test 4: Client Creation
    client = test_apim_client_creation(credential)
    results['client_creation'] = client is not None

    if not client:
        return results

    # Test 5: Connection
    results['connection'] = test_apim_connection(client)

    if not results['connection']:
        return results

    # Test 6: List APIs
    apis = test_list_apis(client)
    results['list_apis'] = len(apis) >= 0  # Pass even if no APIs

    # Test 7: List Products
    products = test_list_products(client)
    results['list_products'] = len(products) >= 0

    # Test 8: Connector Class
    results['connector_class'] = test_connector_class()

    # Test 9: Export API (if APIs exist)
    if apis:
        results['api_export'] = test_api_export(client, apis)
    else:
        print("\n  Skipping API Export test - no APIs available")
        results['api_export'] = None

    # Final Summary
    print("\n" + "=" * 70)
    print(" TEST SUMMARY")
    print("=" * 70)

    total_tests = len([v for v in results.values() if v is not None])
    passed_tests = sum(1 for v in results.values() if v is True)

    print(f"\n  Total Tests:  {total_tests}")
    print(f"  Passed:       {passed_tests}")
    print(f"  Failed:       {total_tests - passed_tests}")
    print(f"  Success Rate: {(passed_tests/total_tests)*100:.0f}%" if total_tests > 0 else "N/A")

    print("\n  Results:")
    for test, result in results.items():
        if result is None:
            status = "⏭️"
            msg = "skipped"
        elif result:
            status = "✅"
            msg = "passed"
        else:
            status = "❌"
            msg = "failed"
        print(f"    {status} {test}: {msg}")

    print("\n" + "=" * 70)

    if passed_tests == total_tests:
        print(" ALL TESTS PASSED - Azure APIM is properly configured!")
    else:
        print(" SOME TESTS FAILED - Check configuration and permissions")

    print("=" * 70 + "\n")

    return results


if __name__ == "__main__":
    run_all_tests()
