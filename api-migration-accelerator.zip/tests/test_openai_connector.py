"""
Azure OpenAI Connector Test Script
===================================
Test script to validate Azure OpenAI connection independently from the web app.

Setup:
    1. Copy .env.example to .env and fill in Azure OpenAI credentials
    2. Run: python tests/test_openai_connector.py

Requirements:
    pip install openai azure-identity python-dotenv

Authentication Methods:
    - API Key (recommended for testing)
    - Azure Entra ID (Service Principal / Managed Identity)
"""

import os
import sys
import time
import json
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def print_header(title: str):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def print_result(test_name: str, success: bool, message: str = "", details: dict = None):
    """Print test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"\n{status} | {test_name}")
    if message:
        print(f"       {message}")
    if details:
        for key, value in details.items():
            print(f"       {key}: {value}")


def test_configuration():
    """Test 1: Validate Azure OpenAI configuration"""
    print_header("TEST 1: Configuration Validation")

    config = {
        'endpoint': os.getenv('API_OPENAI_ENDPOINT'),
        'api_key': os.getenv('API_OPENAI_API_KEY'),
        'deployment': os.getenv('API_OPENAI_DEPLOYMENT'),
        'version': os.getenv('API_OPENAI_VERSION'),
        # Optional Entra ID
        'client_id': os.getenv('API_AZURE_CLIENT_ID'),
        'client_secret': os.getenv('API_AZURE_CLIENT_SECRET'),
        'tenant_id': os.getenv('API_AZURE_TENANT_ID'),
    }

    print("\nAzure OpenAI Configuration:")
    print(f"  Endpoint:    {config['endpoint'] or 'NOT SET'}")
    print(f"  API Key:     {'SET (length: ' + str(len(config['api_key'])) + ')' if config['api_key'] else 'NOT SET'}")
    print(f"  Deployment:  {config['deployment'] or 'NOT SET'}")
    print(f"  API Version: {config['version'] or 'NOT SET'}")

    print("\nEntra ID Configuration (Optional):")
    print(f"  Client ID:     {'SET' if config['client_id'] else 'NOT SET'}")
    print(f"  Client Secret: {'SET' if config['client_secret'] else 'NOT SET'}")
    print(f"  Tenant ID:     {'SET' if config['tenant_id'] else 'NOT SET'}")

    # Determine auth method
    if config['api_key']:
        auth_method = "API Key"
        has_auth = True
    elif all([config['client_id'], config['client_secret'], config['tenant_id']]):
        auth_method = "Entra ID (Service Principal)"
        has_auth = True
    else:
        auth_method = "None"
        has_auth = False

    # Check required OpenAI config
    has_openai_config = all([
        config['endpoint'],
        config['deployment'],
        config['version']
    ])

    ready = has_auth and has_openai_config

    print(f"\n  Authentication Method: {auth_method}")

    print_result(
        "Configuration Check",
        ready,
        f"Using: {auth_method}" if ready else "Missing configuration",
        {
            'Auth Ready': has_auth,
            'OpenAI Config Ready': has_openai_config
        }
    )

    return ready, config


def test_sdk_import():
    """Test 2: Verify OpenAI SDK installation"""
    print_header("TEST 2: OpenAI SDK Import")

    results = {}

    # Test openai
    try:
        from openai import AzureOpenAI
        results['openai'] = True
        print("  ✅ openai (AzureOpenAI) imported successfully")

        # Check version
        import openai
        print(f"     Version: {openai.__version__}")
    except ImportError as e:
        results['openai'] = False
        print(f"  ❌ openai import failed: {e}")

    # Test azure-identity (optional)
    try:
        from azure.identity import DefaultAzureCredential
        results['azure-identity'] = True
        print("  ✅ azure-identity imported successfully")
    except ImportError as e:
        results['azure-identity'] = False
        print(f"  ⚠️  azure-identity not available (optional): {e}")

    all_required = results.get('openai', False)
    print_result(
        "OpenAI SDK Import",
        all_required,
        "Required packages available" if all_required else "Missing packages"
    )

    if not all_required:
        print("\n  Install required packages with:")
        print("    pip install openai")

    return all_required


def test_api_key_authentication():
    """Test 3: API Key authentication"""
    print_header("TEST 3: API Key Authentication")

    endpoint = os.getenv('API_OPENAI_ENDPOINT')
    api_key = os.getenv('API_OPENAI_API_KEY')
    version = os.getenv('API_OPENAI_VERSION')

    if not api_key:
        print_result("API Key Auth", False, "API_OPENAI_API_KEY not set - skipping")
        return None

    if not endpoint:
        print_result("API Key Auth", False, "API_OPENAI_ENDPOINT not set")
        return None

    try:
        from openai import AzureOpenAI

        start_time = time.time()

        client = AzureOpenAI(
            azure_endpoint=endpoint,
            api_key=api_key,
            api_version=version,
            timeout=30.0,
            max_retries=2
        )

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "API Key Authentication",
            True,
            f"Client created in {elapsed:.0f}ms",
            {
                'Endpoint': endpoint[:50] + '...' if len(endpoint) > 50 else endpoint,
                'API Version': version
            }
        )

        return client

    except Exception as e:
        print_result("API Key Authentication", False, str(e))
        return None


def test_entra_id_authentication():
    """Test 4: Entra ID (Service Principal) authentication"""
    print_header("TEST 4: Entra ID Authentication")

    endpoint = os.getenv('API_OPENAI_ENDPOINT')
    version = os.getenv('API_OPENAI_VERSION')
    client_id = os.getenv('API_AZURE_CLIENT_ID')
    client_secret = os.getenv('API_AZURE_CLIENT_SECRET')
    tenant_id = os.getenv('API_AZURE_TENANT_ID')

    if not all([client_id, client_secret, tenant_id]):
        print_result("Entra ID Auth", False, "Service Principal credentials not set - skipping")
        return None

    try:
        from openai import AzureOpenAI
        from azure.identity import ClientSecretCredential, get_bearer_token_provider

        start_time = time.time()

        # Create credential
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )

        # Create token provider for Azure OpenAI
        token_provider = get_bearer_token_provider(
            credential,
            "https://cognitiveservices.azure.com/.default"
        )

        # Create client
        client = AzureOpenAI(
            azure_endpoint=endpoint,
            azure_ad_token_provider=token_provider,
            api_version=version,
            timeout=30.0,
            max_retries=2
        )

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "Entra ID Authentication",
            True,
            f"Client created in {elapsed:.0f}ms",
            {
                'Auth Method': 'ClientSecretCredential',
                'Scope': 'cognitiveservices.azure.com'
            }
        )

        return client

    except ImportError as e:
        print_result("Entra ID Auth", False, f"azure-identity not installed: {e}")
        return None
    except Exception as e:
        print_result("Entra ID Auth", False, str(e))
        return None


def test_chat_completion(client):
    """Test 5: Chat completion API call"""
    print_header("TEST 5: Chat Completion")

    if not client:
        print_result("Chat Completion", False, "No client available")
        return False

    deployment = os.getenv('API_OPENAI_DEPLOYMENT')

    if not deployment:
        print_result("Chat Completion", False, "API_OPENAI_DEPLOYMENT not set")
        return False

    # Model configuration based on deployment name
    MODEL_CONFIGS = {
        'gpt-5-mini': {'use_max_completion_tokens': True, 'max': 500},
        'gpt-5': {'use_max_completion_tokens': True, 'max': 500},
        'gpt-4o-mini': {'use_max_completion_tokens': False, 'max': 500},
        'gpt-4o': {'use_max_completion_tokens': False, 'max': 500},
        'gpt-4': {'use_max_completion_tokens': False, 'max': 500},
        'gpt-35-turbo': {'use_max_completion_tokens': False, 'max': 500},
    }

    # Get model config
    deployment_lower = deployment.lower()
    model_config = None
    for model_name, config in MODEL_CONFIGS.items():
        if model_name in deployment_lower:
            model_config = config
            break

    if not model_config:
        model_config = {'use_max_completion_tokens': False, 'max': 500}

    print(f"\n  Deployment: {deployment}")
    print(f"  Max Token Param: {'max_completion_tokens' if model_config['use_max_completion_tokens'] else 'max_tokens'}")

    try:
        start_time = time.time()

        # Build parameters based on model
        params = {
            "model": deployment,
            "messages": [
                {"role": "system", "content": "You are a helpful assistant. Respond briefly."},
                {"role": "user", "content": "Say 'Azure OpenAI connection successful!' in exactly those words."}
            ],
            "stream": False
        }

        # Add max tokens parameter
        if model_config['use_max_completion_tokens']:
            params['max_completion_tokens'] = model_config['max']
        else:
            params['max_tokens'] = model_config['max']
            params['temperature'] = 0.7

        response = client.chat.completions.create(**params)

        elapsed = (time.time() - start_time) * 1000

        content = response.choices[0].message.content
        usage = response.usage

        print_result(
            "Chat Completion",
            True,
            f"Response received in {elapsed:.0f}ms",
            {
                'Model': response.model,
                'Prompt Tokens': usage.prompt_tokens,
                'Completion Tokens': usage.completion_tokens,
                'Total Tokens': usage.total_tokens
            }
        )

        print(f"\n  Response: {content}")

        return True

    except Exception as e:
        error_msg = str(e)
        print_result("Chat Completion", False, error_msg[:200])

        if 'DeploymentNotFound' in error_msg:
            print(f"\n  SOLUTION: Deployment '{deployment}' not found")
            print("    - Check API_OPENAI_DEPLOYMENT matches your Azure deployment name")
        elif 'InvalidAPIKey' in error_msg or 'Unauthorized' in error_msg:
            print("\n  SOLUTION: Invalid API key")
            print("    - Check API_OPENAI_API_KEY is correct")
        elif 'RateLimitExceeded' in error_msg:
            print("\n  SOLUTION: Rate limit exceeded")
            print("    - Wait a moment and try again")
        elif 'max_tokens' in error_msg or 'max_completion_tokens' in error_msg:
            print("\n  SOLUTION: Token parameter issue")
            print(f"    - Model {deployment} may require different parameters")

        return False


def test_streaming(client):
    """Test 6: Streaming response"""
    print_header("TEST 6: Streaming Response")

    if not client:
        print_result("Streaming", False, "No client available")
        return False

    deployment = os.getenv('API_OPENAI_DEPLOYMENT')

    # Model config for streaming
    deployment_lower = deployment.lower()
    use_max_completion = any(m in deployment_lower for m in ['gpt-5-mini', 'gpt-5'])

    try:
        start_time = time.time()

        params = {
            "model": deployment,
            "messages": [
                {"role": "user", "content": "Count from 1 to 5."}
            ],
            "stream": True
        }

        if use_max_completion:
            params['max_completion_tokens'] = 100
        else:
            params['max_tokens'] = 100

        stream = client.chat.completions.create(**params)

        chunks = []
        first_chunk_time = None

        for chunk in stream:
            if first_chunk_time is None:
                first_chunk_time = (time.time() - start_time) * 1000

            if chunk.choices and chunk.choices[0].delta.content:
                chunks.append(chunk.choices[0].delta.content)

        elapsed = (time.time() - start_time) * 1000
        full_response = ''.join(chunks)

        print_result(
            "Streaming Response",
            True,
            f"Stream completed in {elapsed:.0f}ms",
            {
                'Time to First Token': f"{first_chunk_time:.0f}ms",
                'Chunks Received': len(chunks)
            }
        )

        print(f"\n  Response: {full_response}")

        return True

    except Exception as e:
        print_result("Streaming Response", False, str(e)[:200])
        return False


def test_connector_class():
    """Test 7: Test the actual AzureOpenAIConnector class"""
    print_header("TEST 7: AzureOpenAIConnector Class")

    try:
        from connectors.azure_openai_connector import AzureOpenAIConnector

        print("\n  Creating connector instance...")
        connector = AzureOpenAIConnector()

        # Check availability
        print(f"  Connector initialized: {connector.is_initialized}")
        print(f"  Connector available: {connector.is_available}")

        if not connector.is_available:
            print_result(
                "AzureOpenAIConnector Class",
                False,
                f"Connector not available: {connector._initialization_error}"
            )
            return False

        # Test connection
        print("  Testing connection...")
        result = connector.test_connection()

        if result['status'] == 'success':
            print_result(
                "AzureOpenAIConnector Class",
                True,
                result.get('message', 'Connected'),
                {
                    'Model': result.get('model', 'N/A'),
                    'Auth Method': result.get('auth_method', 'N/A')
                }
            )

            # Test conversion capability
            print("\n  Testing specification parsing...")
            test_spec = json.dumps({
                "swagger": "2.0",
                "info": {"title": "Test API", "version": "1.0.0"},
                "paths": {}
            })

            try:
                parsed, format_type = connector.parse_api_spec(test_spec)
                print(f"    Parsed spec: {format_type.upper()}")
                print(f"    Title: {parsed.get('info', {}).get('title')}")
            except Exception as e:
                print(f"    Parse failed: {e}")

            return True
        else:
            print_result(
                "AzureOpenAIConnector Class",
                False,
                result.get('message', 'Connection failed')
            )
            return False

    except ImportError as e:
        print_result("AzureOpenAIConnector Class", False, f"Import error: {e}")
        return False
    except Exception as e:
        print_result("AzureOpenAIConnector Class", False, str(e))
        return False


def test_spec_conversion(client):
    """Test 8: Test OpenAPI specification conversion"""
    print_header("TEST 8: OpenAPI Spec Conversion")

    if not client:
        print_result("Spec Conversion", False, "No client available")
        return False

    # Simple Swagger 2.0 spec for testing
    swagger_spec = {
        "swagger": "2.0",
        "info": {
            "title": "Test API",
            "version": "1.0.0",
            "description": "A test API for conversion"
        },
        "host": "api.example.com",
        "basePath": "/v1",
        "schemes": ["https"],
        "paths": {
            "/users": {
                "get": {
                    "summary": "Get users",
                    "responses": {
                        "200": {
                            "description": "Success"
                        }
                    }
                }
            }
        }
    }

    try:
        from connectors.azure_openai_connector import AzureOpenAIConnector

        connector = AzureOpenAIConnector()

        if not connector.is_available:
            print_result("Spec Conversion", False, "Connector not available")
            return False

        print("\n  Converting Swagger 2.0 to OpenAPI 3.0...")
        start_time = time.time()

        result = connector.convert_specification(
            spec_content=json.dumps(swagger_spec),
            target_format='json',
            target_version='3.0',
            use_cache=False
        )

        elapsed = (time.time() - start_time) * 1000

        if result['status'] == 'success':
            converted = result.get('converted_spec', {})

            print_result(
                "Spec Conversion",
                True,
                f"Conversion completed in {elapsed:.0f}ms",
                {
                    'Source Version': result.get('source_version'),
                    'Target Version': result.get('target_version'),
                    'AI Used': result.get('ai_conversion_used', False),
                    'Paths Count': len(converted.get('paths', {}))
                }
            )

            # Show converted spec info
            print(f"\n  Converted Spec:")
            print(f"    OpenAPI: {converted.get('openapi', 'N/A')}")
            print(f"    Title: {converted.get('info', {}).get('title', 'N/A')}")
            print(f"    Servers: {len(converted.get('servers', []))}")

            return True
        else:
            print_result("Spec Conversion", False, result.get('message', 'Conversion failed'))
            return False

    except Exception as e:
        print_result("Spec Conversion", False, str(e)[:200])
        return False


def run_all_tests():
    """Run all OpenAI connector tests"""
    print("\n" + "=" * 70)
    print(" AZURE OPENAI CONNECTOR TEST SUITE")
    print(" Testing connection from local environment (outside Azure Web App)")
    print("=" * 70)

    results = {}

    # Test 1: Configuration
    has_config, config = test_configuration()
    results['configuration'] = has_config

    if not has_config:
        print("\n" + "=" * 70)
        print(" TESTS ABORTED: Missing Azure OpenAI configuration")
        print("=" * 70)
        print("\nSetup Instructions:")
        print("  1. Create .env file in project root")
        print("  2. Add the following configuration:")
        print("\n  # Azure OpenAI (API Key)")
        print("  API_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
        print("  API_OPENAI_API_KEY=your-api-key")
        print("  API_OPENAI_DEPLOYMENT=gpt-4o-mini")
        print("  API_OPENAI_VERSION=2024-08-01-preview")
        print("\n  # OR Azure OpenAI (Entra ID)")
        print("  API_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
        print("  API_AZURE_CLIENT_ID=your-app-client-id")
        print("  API_AZURE_CLIENT_SECRET=your-app-client-secret")
        print("  API_AZURE_TENANT_ID=your-tenant-id")
        print("  API_OPENAI_DEPLOYMENT=gpt-4o-mini")
        print("  API_OPENAI_VERSION=2024-08-01-preview")
        return results

    # Test 2: SDK Import
    results['sdk_import'] = test_sdk_import()
    if not results['sdk_import']:
        return results

    # Test 3-4: Authentication
    client = None

    # Try API Key first
    client = test_api_key_authentication()
    if client:
        results['auth'] = 'api_key'
    else:
        # Try Entra ID
        client = test_entra_id_authentication()
        if client:
            results['auth'] = 'entra_id'

    results['authentication'] = client is not None

    if not client:
        print("\n" + "=" * 70)
        print(" AUTHENTICATION TESTS FAILED")
        print("=" * 70)
        return results

    # Test 5: Chat Completion
    results['chat_completion'] = test_chat_completion(client)

    # Test 6: Streaming
    results['streaming'] = test_streaming(client)

    # Test 7: Connector Class
    results['connector_class'] = test_connector_class()

    # Test 8: Spec Conversion
    results['spec_conversion'] = test_spec_conversion(client)

    # Final Summary
    print("\n" + "=" * 70)
    print(" TEST SUMMARY")
    print("=" * 70)

    total_tests = len([v for v in results.values() if v is not None and v is not False and not isinstance(v, str)])
    passed_tests = sum(1 for v in results.values() if v is True)

    print(f"\n  Total Tests:  {total_tests}")
    print(f"  Passed:       {passed_tests}")
    print(f"  Failed:       {total_tests - passed_tests}")
    print(f"  Success Rate: {(passed_tests/total_tests)*100:.0f}%" if total_tests > 0 else "N/A")

    print("\n  Results:")
    for test, result in results.items():
        if isinstance(result, str):
            status = "ℹ️"
            msg = result
        elif result is True:
            status = "✅"
            msg = "passed"
        elif result is False:
            status = "❌"
            msg = "failed"
        else:
            status = "⏭️"
            msg = "skipped"
        print(f"    {status} {test}: {msg}")

    print("\n" + "=" * 70)

    if passed_tests >= total_tests - 1:  # Allow 1 failure
        print(" TESTS PASSED - Azure OpenAI is properly configured!")
    else:
        print(" SOME TESTS FAILED - Check configuration and credentials")

    print("=" * 70 + "\n")

    return results


if __name__ == "__main__":
    run_all_tests()
