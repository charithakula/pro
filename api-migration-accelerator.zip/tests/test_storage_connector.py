"""
Azure Storage Connector Test Script
====================================
Test script to validate Azure Blob Storage connection independently from the web app.

Setup:
    1. Copy .env.example to .env and fill in Azure Storage credentials
    2. Run: python tests/test_storage_connector.py

Supports:
    - Connection string authentication
    - Account name + key authentication
    - Service Principal with Storage Blob Data Contributor role
    - Cross-resource-group access (Storage in different RG than Web App)

Requirements:
    pip install azure-storage-blob azure-identity python-dotenv
"""

import os
import sys
import time
import json
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def print_header(title: str):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def print_result(test_name: str, success: bool, message: str = "", details: dict = None):
    """Print test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"\n{status} | {test_name}")
    if message:
        print(f"       {message}")
    if details:
        for key, value in details.items():
            print(f"       {key}: {value}")


def test_configuration():
    """Test 1: Validate configuration"""
    print_header("TEST 1: Configuration Validation")

    config = {
        'connection_string': os.getenv('API_STORAGE_CONNECTION_STRING'),
        'account_name': os.getenv('API_STORAGE_ACCOUNT_NAME'),
        'account_key': os.getenv('API_STORAGE_ACCOUNT_KEY'),
        'container_name': os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads'),
        'verify_ssl': os.getenv('API_STORAGE_VERIFY_SSL', 'True'),
    }

    print("\nConfiguration Status:")
    print(f"  Connection String: {'SET (length: ' + str(len(config['connection_string'])) + ')' if config['connection_string'] else 'NOT SET'}")
    print(f"  Account Name:      {config['account_name'] or 'NOT SET'}")
    print(f"  Account Key:       {'SET (length: ' + str(len(config['account_key'])) + ')' if config['account_key'] else 'NOT SET'}")
    print(f"  Container Name:    {config['container_name']}")
    print(f"  SSL Verify:        {config['verify_ssl']}")

    # Determine auth method
    if config['connection_string']:
        auth_method = "Connection String"
        has_auth = True
    elif config['account_name'] and config['account_key']:
        auth_method = "Account Name + Key"
        has_auth = True
    elif config['account_name']:
        auth_method = "DefaultAzureCredential (Service Principal/Managed Identity)"
        has_auth = True
    else:
        auth_method = "None"
        has_auth = False

    print(f"\n  Authentication Method: {auth_method}")

    print_result(
        "Configuration Check",
        has_auth,
        f"Using: {auth_method}",
        {'Container': config['container_name']}
    )

    return has_auth, config


def test_sdk_import():
    """Test 2: Verify Azure SDK installation"""
    print_header("TEST 2: Azure SDK Import")

    try:
        from azure.storage.blob import BlobServiceClient, ContainerClient
        print_result("azure-storage-blob import", True, "BlobServiceClient available")
        return True
    except ImportError as e:
        print_result("azure-storage-blob import", False, str(e))
        print("\n  Install with: pip install azure-storage-blob")
        return False


def test_connection_string_auth():
    """Test 3: Connection string authentication"""
    print_header("TEST 3: Connection String Authentication")

    connection_string = os.getenv('API_STORAGE_CONNECTION_STRING')
    if not connection_string:
        print_result("Connection String Auth", False, "API_STORAGE_CONNECTION_STRING not set - skipping")
        return None

    try:
        from azure.storage.blob import BlobServiceClient

        verify_ssl = os.getenv('API_STORAGE_VERIFY_SSL', 'True').lower() == 'true'

        start_time = time.time()

        if verify_ssl:
            client = BlobServiceClient.from_connection_string(connection_string)
        else:
            client = BlobServiceClient.from_connection_string(
                connection_string,
                connection_verify=False
            )

        # Test connection by getting account info
        account_info = client.get_account_information()
        elapsed = (time.time() - start_time) * 1000

        print_result(
            "Connection String Auth",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'SKU': account_info.get('sku_name', 'N/A'),
                'Account Kind': account_info.get('account_kind', 'N/A')
            }
        )
        return client

    except Exception as e:
        print_result("Connection String Auth", False, str(e))
        return None


def test_account_key_auth():
    """Test 4: Account name + key authentication"""
    print_header("TEST 4: Account Name + Key Authentication")

    account_name = os.getenv('API_STORAGE_ACCOUNT_NAME')
    account_key = os.getenv('API_STORAGE_ACCOUNT_KEY')

    if not account_name or not account_key:
        print_result("Account Key Auth", False, "Account name or key not set - skipping")
        return None

    try:
        from azure.storage.blob import BlobServiceClient

        start_time = time.time()

        account_url = f"https://{account_name}.blob.core.windows.net"
        client = BlobServiceClient(account_url=account_url, credential=account_key)

        # Test connection
        account_info = client.get_account_information()
        elapsed = (time.time() - start_time) * 1000

        print_result(
            "Account Key Auth",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'Account URL': account_url,
                'SKU': account_info.get('sku_name', 'N/A')
            }
        )
        return client

    except Exception as e:
        print_result("Account Key Auth", False, str(e))
        return None


def test_default_credential_auth():
    """Test 5: DefaultAzureCredential (Service Principal / Managed Identity)"""
    print_header("TEST 5: DefaultAzureCredential Authentication")

    account_name = os.getenv('API_STORAGE_ACCOUNT_NAME')

    if not account_name:
        print_result("DefaultAzureCredential Auth", False, "API_STORAGE_ACCOUNT_NAME not set - skipping")
        return None

    # Check if Service Principal credentials are available
    client_id = os.getenv('API_AZURE_CLIENT_ID')
    client_secret = os.getenv('API_AZURE_CLIENT_SECRET')
    tenant_id = os.getenv('API_AZURE_TENANT_ID')

    print("\n  Service Principal Configuration:")
    print(f"    Client ID:     {'SET' if client_id else 'NOT SET'}")
    print(f"    Client Secret: {'SET' if client_secret else 'NOT SET'}")
    print(f"    Tenant ID:     {'SET' if tenant_id else 'NOT SET'}")

    if not all([client_id, client_secret, tenant_id]):
        print("\n  NOTE: Service Principal not fully configured.")
        print("        For cross-resource-group access, ensure the App Registration")
        print("        has 'Storage Blob Data Contributor' role on the Storage Account.")

    try:
        from azure.storage.blob import BlobServiceClient
        from azure.identity import DefaultAzureCredential, ClientSecretCredential

        start_time = time.time()
        account_url = f"https://{account_name}.blob.core.windows.net"

        # Try ClientSecretCredential first if configured
        if all([client_id, client_secret, tenant_id]):
            print("\n  Using ClientSecretCredential...")
            credential = ClientSecretCredential(
                tenant_id=tenant_id,
                client_id=client_id,
                client_secret=client_secret
            )
        else:
            print("\n  Using DefaultAzureCredential...")
            credential = DefaultAzureCredential()

        client = BlobServiceClient(account_url=account_url, credential=credential)

        # Test by listing containers (requires Storage Blob Data Contributor)
        containers = list(client.list_containers(max_results=1))
        elapsed = (time.time() - start_time) * 1000

        print_result(
            "DefaultAzureCredential Auth",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'Account URL': account_url,
                'Containers Found': len(containers)
            }
        )
        return client

    except Exception as e:
        error_msg = str(e)
        print_result("DefaultAzureCredential Auth", False, error_msg[:200])

        if 'AuthorizationPermissionMismatch' in error_msg:
            print("\n  SOLUTION: Add 'Storage Blob Data Contributor' role to the Service Principal")
            print("            on the Storage Account in Azure Portal.")
        elif 'AuthenticationFailed' in error_msg:
            print("\n  SOLUTION: Check Service Principal credentials in .env file")

        return None


def test_container_operations(client):
    """Test 6: Container operations"""
    print_header("TEST 6: Container Operations")

    if not client:
        print_result("Container Operations", False, "No client available - skipping")
        return None

    container_name = os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads')

    try:
        start_time = time.time()
        container_client = client.get_container_client(container_name)

        # Check if container exists
        try:
            props = container_client.get_container_properties()
            exists = True
            print(f"\n  Container '{container_name}' exists")
            print(f"    Last Modified: {props.last_modified}")
            print(f"    Lease Status: {props.lease.status if props.lease else 'N/A'}")
        except Exception:
            exists = False
            print(f"\n  Container '{container_name}' does not exist")

            # Try to create it
            print(f"  Creating container '{container_name}'...")
            container_client = client.create_container(container_name)
            print(f"  Container created successfully!")

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "Container Operations",
            True,
            f"Container '{container_name}' ready in {elapsed:.0f}ms"
        )
        return container_client

    except Exception as e:
        print_result("Container Operations", False, str(e))
        return None


def test_blob_operations(container_client):
    """Test 7: Blob CRUD operations"""
    print_header("TEST 7: Blob CRUD Operations")

    if not container_client:
        print_result("Blob Operations", False, "No container client - skipping")
        return False

    test_blob_name = f"test/connection_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    test_content = json.dumps({
        "test": True,
        "timestamp": datetime.now().isoformat(),
        "message": "Azure Storage Connection Test"
    }, indent=2)

    results = {}

    # Test Upload
    try:
        print(f"\n  1. Uploading test blob: {test_blob_name}")
        start_time = time.time()

        blob_client = container_client.get_blob_client(test_blob_name)
        blob_client.upload_blob(test_content.encode('utf-8'), overwrite=True)

        elapsed = (time.time() - start_time) * 1000
        results['upload'] = {'success': True, 'time_ms': elapsed}
        print(f"     Upload successful ({elapsed:.0f}ms)")

    except Exception as e:
        results['upload'] = {'success': False, 'error': str(e)}
        print(f"     Upload failed: {e}")

    # Test Download
    try:
        print(f"\n  2. Downloading test blob")
        start_time = time.time()

        download_stream = blob_client.download_blob()
        downloaded_content = download_stream.readall().decode('utf-8')

        elapsed = (time.time() - start_time) * 1000

        # Verify content
        content_match = downloaded_content == test_content
        results['download'] = {'success': content_match, 'time_ms': elapsed}
        print(f"     Download successful ({elapsed:.0f}ms)")
        print(f"     Content verification: {'PASS' if content_match else 'FAIL'}")

    except Exception as e:
        results['download'] = {'success': False, 'error': str(e)}
        print(f"     Download failed: {e}")

    # Test List
    try:
        print(f"\n  3. Listing blobs with prefix 'test/'")
        start_time = time.time()

        blobs = list(container_client.list_blobs(name_starts_with='test/'))

        elapsed = (time.time() - start_time) * 1000
        results['list'] = {'success': True, 'time_ms': elapsed, 'count': len(blobs)}
        print(f"     Found {len(blobs)} blob(s) ({elapsed:.0f}ms)")

    except Exception as e:
        results['list'] = {'success': False, 'error': str(e)}
        print(f"     List failed: {e}")

    # Test Delete
    try:
        print(f"\n  4. Deleting test blob")
        start_time = time.time()

        blob_client.delete_blob()

        elapsed = (time.time() - start_time) * 1000
        results['delete'] = {'success': True, 'time_ms': elapsed}
        print(f"     Delete successful ({elapsed:.0f}ms)")

    except Exception as e:
        results['delete'] = {'success': False, 'error': str(e)}
        print(f"     Delete failed: {e}")

    # Summary
    all_passed = all(r.get('success', False) for r in results.values())
    print_result(
        "Blob CRUD Operations",
        all_passed,
        f"Upload: {'OK' if results.get('upload', {}).get('success') else 'FAIL'}, "
        f"Download: {'OK' if results.get('download', {}).get('success') else 'FAIL'}, "
        f"List: {'OK' if results.get('list', {}).get('success') else 'FAIL'}, "
        f"Delete: {'OK' if results.get('delete', {}).get('success') else 'FAIL'}"
    )

    return all_passed


def test_connector_class():
    """Test 8: Test the actual AzureStorageConnector class"""
    print_header("TEST 8: AzureStorageConnector Class")

    try:
        from connectors.azure_storage_connector import AzureStorageConnector, get_storage_connector

        # Reset any existing instance for clean test
        AzureStorageConnector.reset_instance()

        # Get connector instance
        print("\n  Getting connector instance...")
        connector = get_storage_connector()

        # Test connection
        print("  Testing connection...")
        result = connector.test_connection()

        if result['success']:
            print_result(
                "AzureStorageConnector Class",
                True,
                result.get('message', 'Connected'),
                {
                    'Storage Type': result.get('storage_type', 'unknown'),
                    'Account': result.get('account_name', 'N/A'),
                    'Container': result.get('container_name', 'N/A')
                }
            )

            # Get storage stats
            print("\n  Getting storage statistics...")
            stats = connector.get_storage_stats()
            if stats['success']:
                print(f"    Total Files: {stats['total_files']}")
                print(f"    Total Size: {stats['total_size_mb']} MB")

            return True
        else:
            print_result(
                "AzureStorageConnector Class",
                False,
                result.get('message', 'Connection failed')
            )
            return False

    except ImportError as e:
        print_result("AzureStorageConnector Class", False, f"Import error: {e}")
        return False
    except Exception as e:
        print_result("AzureStorageConnector Class", False, str(e))
        return False


def run_all_tests():
    """Run all storage connector tests"""
    print("\n" + "=" * 70)
    print(" AZURE STORAGE CONNECTOR TEST SUITE")
    print(" Testing connection from local environment (outside Azure Web App)")
    print("=" * 70)

    results = {}

    # Test 1: Configuration
    has_config, config = test_configuration()
    results['configuration'] = has_config

    if not has_config:
        print("\n" + "=" * 70)
        print(" TESTS ABORTED: No Azure Storage configuration found")
        print("=" * 70)
        print("\nSetup Instructions:")
        print("  1. Create .env file in project root")
        print("  2. Add one of the following configurations:")
        print("\n  Option A - Connection String:")
        print("    API_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=https;...")
        print("    API_STORAGE_CONTAINER_NAME=uploads")
        print("\n  Option B - Account Key:")
        print("    API_STORAGE_ACCOUNT_NAME=yourstorageaccount")
        print("    API_STORAGE_ACCOUNT_KEY=your-storage-key")
        print("    API_STORAGE_CONTAINER_NAME=uploads")
        print("\n  Option C - Service Principal (for cross-resource-group):")
        print("    API_STORAGE_ACCOUNT_NAME=yourstorageaccount")
        print("    API_AZURE_CLIENT_ID=your-app-client-id")
        print("    API_AZURE_CLIENT_SECRET=your-app-client-secret")
        print("    API_AZURE_TENANT_ID=your-tenant-id")
        print("    API_STORAGE_CONTAINER_NAME=uploads")
        print("\n  NOTE: For Option C, ensure the App Registration has")
        print("        'Storage Blob Data Contributor' role on the Storage Account.")
        return results

    # Test 2: SDK Import
    results['sdk_import'] = test_sdk_import()
    if not results['sdk_import']:
        return results

    # Test 3-5: Authentication methods
    client = None

    # Try connection string first
    client = test_connection_string_auth()
    if client:
        results['auth'] = 'connection_string'

    # Try account key if connection string failed
    if not client:
        client = test_account_key_auth()
        if client:
            results['auth'] = 'account_key'

    # Try DefaultAzureCredential if others failed
    if not client:
        client = test_default_credential_auth()
        if client:
            results['auth'] = 'default_credential'

    if not client:
        results['connection'] = False
        print("\n" + "=" * 70)
        print(" CONNECTION TESTS FAILED")
        print("=" * 70)
        return results

    results['connection'] = True

    # Test 6: Container operations
    container_client = test_container_operations(client)
    results['container'] = container_client is not None

    # Test 7: Blob operations
    if container_client:
        results['blob_operations'] = test_blob_operations(container_client)

    # Test 8: Connector class
    results['connector_class'] = test_connector_class()

    # Final Summary
    print("\n" + "=" * 70)
    print(" TEST SUMMARY")
    print("=" * 70)

    total_tests = len(results)
    passed_tests = sum(1 for v in results.values() if v and v is not False)

    print(f"\n  Total Tests:  {total_tests}")
    print(f"  Passed:       {passed_tests}")
    print(f"  Failed:       {total_tests - passed_tests}")
    print(f"  Success Rate: {(passed_tests/total_tests)*100:.0f}%")

    print("\n  Results:")
    for test, result in results.items():
        status = "✅" if result and result is not False else "❌"
        print(f"    {status} {test}")

    print("\n" + "=" * 70)

    if passed_tests == total_tests:
        print(" ALL TESTS PASSED - Azure Storage is properly configured!")
    else:
        print(" SOME TESTS FAILED - Check configuration and permissions")

    print("=" * 70 + "\n")

    return results


if __name__ == "__main__":
    run_all_tests()
