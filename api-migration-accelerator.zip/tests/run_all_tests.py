"""
Combined Test Runner - All Connector Tests
============================================
Run all connector tests in sequence to validate the complete setup.

Usage:
    python tests/run_all_tests.py [--quick] [--verbose]

Options:
    --quick     Skip slow tests (streaming, conversion)
    --verbose   Show detailed output

Requirements:
    All connector dependencies must be installed:
    pip install azure-storage-blob azure-identity azure-mgmt-apimanagement openai psycopg2-binary sqlalchemy python-dotenv
"""

import os
import sys
import argparse
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def print_banner():
    """Print test suite banner"""
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + " " * 68 + "║")
    print("║" + "  API MIGRATION ACCELERATOR - CONNECTOR TEST SUITE".center(68) + "║")
    print("║" + f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}".center(68) + "║")
    print("║" + " " * 68 + "║")
    print("╚" + "═" * 68 + "╝")
    print()


def print_section(title: str):
    """Print section header"""
    print("\n")
    print("┌" + "─" * 68 + "┐")
    print("│" + f"  {title}".ljust(68) + "│")
    print("└" + "─" * 68 + "┘")


def run_test_module(module_name: str, description: str):
    """Run a test module and return results"""
    print_section(description)

    try:
        if module_name == 'storage':
            from tests.test_storage_connector import run_all_tests
        elif module_name == 'apim':
            from tests.test_apim_connector import run_all_tests
        elif module_name == 'openai':
            from tests.test_openai_connector import run_all_tests
        elif module_name == 'database':
            from tests.test_database_connector import run_all_tests
        else:
            print(f"  Unknown test module: {module_name}")
            return None

        start_time = time.time()
        results = run_all_tests()
        elapsed = time.time() - start_time

        return {
            'module': module_name,
            'results': results,
            'elapsed': elapsed,
            'success': all(v for v in results.values() if v is not None and v is not False)
        }

    except ImportError as e:
        print(f"\n  ❌ Failed to import test module: {e}")
        return {
            'module': module_name,
            'results': {},
            'elapsed': 0,
            'success': False,
            'error': str(e)
        }
    except Exception as e:
        print(f"\n  ❌ Error running tests: {e}")
        return {
            'module': module_name,
            'results': {},
            'elapsed': 0,
            'success': False,
            'error': str(e)
        }


def print_final_summary(all_results: dict):
    """Print final summary of all tests"""
    print("\n")
    print("╔" + "═" * 68 + "╗")
    print("║" + "  FINAL TEST SUMMARY".center(68) + "║")
    print("╠" + "═" * 68 + "╣")

    total_tests = 0
    passed_tests = 0
    failed_modules = []

    for module, data in all_results.items():
        if data is None:
            continue

        results = data.get('results', {})
        module_tests = len([v for v in results.values() if v is not None])
        module_passed = sum(1 for v in results.values() if v is True)

        total_tests += module_tests
        passed_tests += module_passed

        status = "✅" if data.get('success') else "❌"
        elapsed = data.get('elapsed', 0)

        print(f"║  {status} {module.upper():<15} {module_passed}/{module_tests} tests passed ({elapsed:.1f}s)".ljust(68) + "║")

        if not data.get('success'):
            failed_modules.append(module)

    print("╠" + "═" * 68 + "╣")
    print(f"║  Total: {passed_tests}/{total_tests} tests passed".ljust(68) + "║")

    if total_tests > 0:
        success_rate = (passed_tests / total_tests) * 100
        print(f"║  Success Rate: {success_rate:.0f}%".ljust(68) + "║")

    print("╚" + "═" * 68 + "╝")

    if failed_modules:
        print("\n  Failed Modules:")
        for module in failed_modules:
            print(f"    ❌ {module}")
    else:
        print("\n  ✅ All connector tests passed!")

    print()


def check_prerequisites():
    """Check if all required packages are installed"""
    print_section("Checking Prerequisites")

    packages = {
        'dotenv': ('python-dotenv', 'Environment variables'),
        'sqlalchemy': ('SQLAlchemy', 'Database ORM'),
    }

    optional_packages = {
        'azure.storage.blob': ('azure-storage-blob', 'Azure Blob Storage'),
        'azure.identity': ('azure-identity', 'Azure Authentication'),
        'azure.mgmt.apimanagement': ('azure-mgmt-apimanagement', 'Azure APIM'),
        'openai': ('openai', 'Azure OpenAI'),
        'psycopg2': ('psycopg2-binary', 'PostgreSQL'),
    }

    missing_required = []
    missing_optional = []

    print("\n  Required Packages:")
    for module, (name, description) in packages.items():
        try:
            __import__(module)
            print(f"    ✅ {name}: {description}")
        except ImportError:
            print(f"    ❌ {name}: {description} - NOT INSTALLED")
            missing_required.append(name)

    print("\n  Optional Packages (for specific connectors):")
    for module, (name, description) in optional_packages.items():
        try:
            __import__(module)
            print(f"    ✅ {name}: {description}")
        except ImportError:
            print(f"    ⚠️  {name}: {description} - NOT INSTALLED")
            missing_optional.append(name)

    if missing_required:
        print(f"\n  ❌ Missing required packages. Install with:")
        print(f"     pip install {' '.join(missing_required)}")
        return False

    if missing_optional:
        print(f"\n  ⚠️  Some optional packages missing. Install with:")
        print(f"     pip install {' '.join(missing_optional)}")

    return True


def check_configuration():
    """Check environment configuration"""
    print_section("Checking Configuration")

    config_groups = {
        'Database': [
            ('API_DB_TYPE', os.getenv('API_DB_TYPE', 'sqlite')),
            ('API_DB_HOST', os.getenv('API_DB_HOST')),
        ],
        'Azure Storage': [
            ('API_STORAGE_CONNECTION_STRING', os.getenv('API_STORAGE_CONNECTION_STRING')),
            ('API_STORAGE_ACCOUNT_NAME', os.getenv('API_STORAGE_ACCOUNT_NAME')),
        ],
        'Azure APIM': [
            ('API_APIM_SERVICE_NAME', os.getenv('API_APIM_SERVICE_NAME')),
            ('API_APIM_RESOURCE_GROUP', os.getenv('API_APIM_RESOURCE_GROUP')),
        ],
        'Azure OpenAI': [
            ('API_OPENAI_ENDPOINT', os.getenv('API_OPENAI_ENDPOINT')),
            ('API_OPENAI_DEPLOYMENT', os.getenv('API_OPENAI_DEPLOYMENT')),
        ],
        'Azure Auth': [
            ('API_AZURE_CLIENT_ID', os.getenv('API_AZURE_CLIENT_ID')),
            ('API_AZURE_TENANT_ID', os.getenv('API_AZURE_TENANT_ID')),
        ],
    }

    configured = {}

    for group, vars in config_groups.items():
        has_config = any(v for _, v in vars)
        configured[group] = has_config

        status = "✅" if has_config else "⚠️ "
        print(f"\n  {status} {group}:")
        for var_name, var_value in vars:
            if var_value:
                display = var_value[:30] + '...' if len(str(var_value)) > 30 else var_value
                print(f"      {var_name}: {display}")
            else:
                print(f"      {var_name}: NOT SET")

    return configured


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Run all connector tests')
    parser.add_argument('--quick', action='store_true', help='Skip slow tests')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    parser.add_argument('--only', type=str, help='Run only specific test (storage/apim/openai/database)')
    args = parser.parse_args()

    print_banner()

    # Check prerequisites
    if not check_prerequisites():
        print("\n  ❌ Prerequisites not met. Please install missing packages.")
        sys.exit(1)

    # Check configuration
    configured = check_configuration()

    # Determine which tests to run
    tests_to_run = []

    if args.only:
        tests_to_run = [(args.only, f"{args.only.upper()} Connector Tests")]
    else:
        # Add tests based on configuration
        if configured.get('Database'):
            tests_to_run.append(('database', 'Database Connector Tests'))

        if configured.get('Azure Storage'):
            tests_to_run.append(('storage', 'Azure Storage Connector Tests'))

        if configured.get('Azure APIM') and configured.get('Azure Auth'):
            tests_to_run.append(('apim', 'Azure APIM Connector Tests'))

        if configured.get('Azure OpenAI'):
            tests_to_run.append(('openai', 'Azure OpenAI Connector Tests'))

    if not tests_to_run:
        print("\n  ⚠️  No connectors configured. Please set environment variables in .env file.")
        print("\n  Available tests:")
        print("    - database:  Set API_DB_TYPE, API_DB_HOST, etc.")
        print("    - storage:   Set API_STORAGE_CONNECTION_STRING or API_STORAGE_ACCOUNT_NAME")
        print("    - apim:      Set API_APIM_SERVICE_NAME, API_AZURE_CLIENT_ID, etc.")
        print("    - openai:    Set API_OPENAI_ENDPOINT, API_OPENAI_DEPLOYMENT, etc.")
        sys.exit(1)

    print(f"\n  Running {len(tests_to_run)} test suite(s)...")

    # Run tests
    all_results = {}
    start_time = time.time()

    for module, description in tests_to_run:
        result = run_test_module(module, description)
        all_results[module] = result

    total_elapsed = time.time() - start_time

    # Print final summary
    print_final_summary(all_results)

    print(f"  Total time: {total_elapsed:.1f} seconds")
    print()

    # Exit with appropriate code
    all_passed = all(
        data.get('success', False)
        for data in all_results.values()
        if data is not None
    )

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
