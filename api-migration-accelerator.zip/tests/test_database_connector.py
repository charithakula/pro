"""
Database Connector Test Script
===============================
Test script to validate PostgreSQL/SQLite database connection independently from the web app.

Setup:
    1. Copy .env.example to .env and fill in database credentials
    2. Run: python tests/test_database_connector.py

Requirements:
    pip install psycopg2-binary sqlalchemy python-dotenv

For Azure PostgreSQL:
    - Ensure firewall allows your IP address
    - Use SSL mode 'require' for Azure PostgreSQL
"""

import os
import sys
import time
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

# Load environment variables
load_dotenv()


def print_header(title: str):
    """Print formatted header"""
    print("\n" + "=" * 70)
    print(f" {title}")
    print("=" * 70)


def print_result(test_name: str, success: bool, message: str = "", details: dict = None):
    """Print test result"""
    status = "✅ PASS" if success else "❌ FAIL"
    print(f"\n{status} | {test_name}")
    if message:
        print(f"       {message}")
    if details:
        for key, value in details.items():
            print(f"       {key}: {value}")


def test_configuration():
    """Test 1: Validate database configuration"""
    print_header("TEST 1: Configuration Validation")

    config = {
        'db_type': os.getenv('API_DB_TYPE', 'sqlite'),
        'db_host': os.getenv('API_DB_HOST'),
        'db_port': os.getenv('API_DB_PORT', '5432'),
        'db_name': os.getenv('API_DB_NAME'),
        'db_user': os.getenv('API_DB_USER'),
        'db_password': os.getenv('API_DB_PASSWORD'),
        'db_schema': os.getenv('API_DB_SCHEMA', 'public'),
        'db_sslmode': os.getenv('API_DB_SSLMODE', ''),
        'database_url': os.getenv('API_DATABASE_URL'),
    }

    print("\nDatabase Configuration:")
    print(f"  Type:     {config['db_type']}")
    print(f"  Host:     {config['db_host'] or 'NOT SET'}")
    print(f"  Port:     {config['db_port']}")
    print(f"  Database: {config['db_name'] or 'NOT SET'}")
    print(f"  User:     {config['db_user'] or 'NOT SET'}")
    print(f"  Password: {'SET' if config['db_password'] else 'NOT SET'}")
    print(f"  Schema:   {config['db_schema']}")
    print(f"  SSL Mode: {config['db_sslmode'] or 'NOT SET (default)'}")

    # Check if DATABASE_URL is directly provided
    if config['database_url']:
        print(f"\n  DATABASE_URL: SET (using direct URL)")
        has_config = True
    elif config['db_type'] == 'sqlite':
        print(f"\n  Using SQLite (local file)")
        has_config = True
    elif config['db_type'] == 'postgresql':
        has_config = all([
            config['db_host'],
            config['db_name'],
            config['db_user'],
            config['db_password']
        ])
    else:
        has_config = False

    print_result(
        "Configuration Check",
        has_config,
        f"Database type: {config['db_type'].upper()}",
        {'Schema': config['db_schema']}
    )

    return has_config, config


def test_sdk_import():
    """Test 2: Verify database drivers installation"""
    print_header("TEST 2: Database Driver Import")

    results = {}

    # Test SQLAlchemy
    try:
        import sqlalchemy
        results['sqlalchemy'] = True
        print(f"  ✅ SQLAlchemy {sqlalchemy.__version__} imported successfully")
    except ImportError as e:
        results['sqlalchemy'] = False
        print(f"  ❌ SQLAlchemy import failed: {e}")

    # Test psycopg2 (PostgreSQL driver)
    try:
        import psycopg2
        results['psycopg2'] = True
        print(f"  ✅ psycopg2 {psycopg2.__version__} imported successfully")
    except ImportError as e:
        results['psycopg2'] = False
        print(f"  ⚠️  psycopg2 not available (needed for PostgreSQL): {e}")

    all_required = results.get('sqlalchemy', False)
    print_result(
        "Database Driver Import",
        all_required,
        "SQLAlchemy available" if all_required else "Missing packages"
    )

    if not results.get('psycopg2'):
        print("\n  For PostgreSQL support, install:")
        print("    pip install psycopg2-binary")

    return all_required


def build_connection_url(config: dict) -> str:
    """Build database connection URL from config"""
    if config.get('database_url'):
        return config['database_url']

    db_type = config.get('db_type', 'sqlite').lower()

    if db_type == 'sqlite':
        return 'sqlite:///migrations.db'

    if db_type == 'postgresql':
        host = config.get('db_host', 'localhost')
        port = config.get('db_port', '5432')
        name = config.get('db_name', 'api_migration_db')
        user = config.get('db_user', 'postgres')
        password = config.get('db_password', '')
        schema = config.get('db_schema', 'public')
        sslmode = config.get('db_sslmode', '')

        # Build URL with schema
        url = f"postgresql://{user}:{password}@{host}:{port}/{name}?options=-csearch_path%3D{schema}"

        # Add SSL mode if specified
        if sslmode:
            url += f"&sslmode={sslmode}"

        return url

    return 'sqlite:///migrations.db'


def test_direct_connection(config: dict):
    """Test 3: Direct PostgreSQL connection (without SQLAlchemy)"""
    print_header("TEST 3: Direct PostgreSQL Connection")

    if config.get('db_type', 'sqlite').lower() != 'postgresql':
        print_result("Direct Connection", False, "Not using PostgreSQL - skipping")
        return None

    try:
        import psycopg2
    except ImportError:
        print_result("Direct Connection", False, "psycopg2 not installed")
        return None

    try:
        start_time = time.time()

        # Build connection parameters
        conn_params = {
            'host': config.get('db_host'),
            'port': config.get('db_port', '5432'),
            'dbname': config.get('db_name'),
            'user': config.get('db_user'),
            'password': config.get('db_password'),
        }

        # Add SSL mode for Azure
        sslmode = config.get('db_sslmode')
        if sslmode:
            conn_params['sslmode'] = sslmode

        # Connect
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()

        # Test query
        cursor.execute('SELECT version();')
        version = cursor.fetchone()[0]

        elapsed = (time.time() - start_time) * 1000

        # Get more info
        cursor.execute('SELECT current_database(), current_schema(), current_user;')
        db_info = cursor.fetchone()

        cursor.close()
        conn.close()

        print_result(
            "Direct PostgreSQL Connection",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'Database': db_info[0],
                'Schema': db_info[1],
                'User': db_info[2],
                'Version': version[:50] + '...' if len(version) > 50 else version
            }
        )

        return True

    except Exception as e:
        error_msg = str(e)
        print_result("Direct PostgreSQL Connection", False, error_msg[:200])

        if 'could not connect' in error_msg.lower():
            print("\n  SOLUTION: Check network/firewall settings")
            print("    - For Azure PostgreSQL, add your IP to firewall rules")
        elif 'password authentication failed' in error_msg.lower():
            print("\n  SOLUTION: Check database credentials")
        elif 'database' in error_msg.lower() and 'does not exist' in error_msg.lower():
            print("\n  SOLUTION: Database doesn't exist - create it first")
        elif 'ssl' in error_msg.lower():
            print("\n  SOLUTION: SSL configuration issue")
            print("    - For Azure PostgreSQL, set API_DB_SSLMODE=require")

        return False


def test_sqlalchemy_connection(config: dict):
    """Test 4: SQLAlchemy connection"""
    print_header("TEST 4: SQLAlchemy Connection")

    try:
        from sqlalchemy import create_engine, text
        from sqlalchemy.pool import NullPool
    except ImportError as e:
        print_result("SQLAlchemy Connection", False, f"Import error: {e}")
        return None

    url = build_connection_url(config)
    db_type = config.get('db_type', 'sqlite').lower()

    print(f"\n  Connection URL: {url[:50]}..." if len(url) > 50 else f"\n  Connection URL: {url}")

    try:
        start_time = time.time()

        # Create engine with appropriate options
        engine_options = {'poolclass': NullPool}

        if db_type == 'postgresql':
            engine_options['connect_args'] = {'connect_timeout': 10}

        engine = create_engine(url, **engine_options)

        # Test connection
        with engine.connect() as conn:
            if db_type == 'postgresql':
                result = conn.execute(text('SELECT version(), current_database(), current_schema();'))
                row = result.fetchone()
                version = row[0]
                database = row[1]
                schema = row[2]
            else:
                result = conn.execute(text('SELECT sqlite_version();'))
                row = result.fetchone()
                version = f"SQLite {row[0]}"
                database = 'local file'
                schema = 'N/A'

        elapsed = (time.time() - start_time) * 1000

        print_result(
            "SQLAlchemy Connection",
            True,
            f"Connected in {elapsed:.0f}ms",
            {
                'Database': database,
                'Schema': schema,
                'Engine': db_type.upper()
            }
        )

        return engine

    except Exception as e:
        print_result("SQLAlchemy Connection", False, str(e)[:200])
        return None


def test_schema_existence(engine, config: dict):
    """Test 5: Check if schema exists"""
    print_header("TEST 5: Schema Existence")

    if not engine:
        print_result("Schema Check", False, "No engine available")
        return False

    db_type = config.get('db_type', 'sqlite').lower()
    schema = config.get('db_schema', 'public')

    if db_type != 'postgresql':
        print_result("Schema Check", True, "SQLite doesn't use schemas - skipping")
        return True

    try:
        from sqlalchemy import text

        with engine.connect() as conn:
            # Check if schema exists
            result = conn.execute(text(
                "SELECT schema_name FROM information_schema.schemata WHERE schema_name = :schema"
            ), {'schema': schema})
            exists = result.fetchone() is not None

            if exists:
                # Get tables in schema
                result = conn.execute(text(
                    "SELECT table_name FROM information_schema.tables WHERE table_schema = :schema"
                ), {'schema': schema})
                tables = [row[0] for row in result.fetchall()]

                print_result(
                    "Schema Check",
                    True,
                    f"Schema '{schema}' exists",
                    {'Tables Found': len(tables)}
                )

                if tables:
                    print(f"\n  Tables in schema '{schema}':")
                    for table in tables[:10]:
                        print(f"    - {table}")
                    if len(tables) > 10:
                        print(f"    ... and {len(tables) - 10} more")

                return True
            else:
                print_result(
                    "Schema Check",
                    False,
                    f"Schema '{schema}' does not exist"
                )
                print(f"\n  SOLUTION: Create the schema with:")
                print(f"    CREATE SCHEMA IF NOT EXISTS {schema};")
                return False

    except Exception as e:
        print_result("Schema Check", False, str(e)[:200])
        return False


def test_table_operations(engine, config: dict):
    """Test 6: Table CRUD operations"""
    print_header("TEST 6: Table Operations")

    if not engine:
        print_result("Table Operations", False, "No engine available")
        return False

    db_type = config.get('db_type', 'sqlite').lower()
    schema = config.get('db_schema', 'public') if db_type == 'postgresql' else None

    try:
        from sqlalchemy import text, MetaData, Table, Column, String, DateTime, Integer
        from datetime import datetime

        test_table_name = '_connection_test_'

        with engine.connect() as conn:
            # Create test table
            print("\n  1. Creating test table...")

            if db_type == 'postgresql':
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS {schema}.{test_table_name} (
                        id SERIAL PRIMARY KEY,
                        test_value VARCHAR(100),
                        created_at TIMESTAMP DEFAULT NOW()
                    )
                """))
            else:
                conn.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS {test_table_name} (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        test_value TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    )
                """))
            conn.commit()
            print("     Table created successfully")

            # Insert test data
            print("  2. Inserting test data...")
            test_value = f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

            if db_type == 'postgresql':
                conn.execute(text(f"""
                    INSERT INTO {schema}.{test_table_name} (test_value)
                    VALUES (:value)
                """), {'value': test_value})
            else:
                conn.execute(text(f"""
                    INSERT INTO {test_table_name} (test_value)
                    VALUES (:value)
                """), {'value': test_value})
            conn.commit()
            print("     Data inserted successfully")

            # Select test data
            print("  3. Selecting test data...")
            if db_type == 'postgresql':
                result = conn.execute(text(f"""
                    SELECT id, test_value, created_at FROM {schema}.{test_table_name}
                    ORDER BY id DESC LIMIT 1
                """))
            else:
                result = conn.execute(text(f"""
                    SELECT id, test_value, created_at FROM {test_table_name}
                    ORDER BY id DESC LIMIT 1
                """))
            row = result.fetchone()
            print(f"     Retrieved: ID={row[0]}, Value={row[1]}")

            # Cleanup - drop test table
            print("  4. Cleaning up test table...")
            if db_type == 'postgresql':
                conn.execute(text(f"DROP TABLE IF EXISTS {schema}.{test_table_name}"))
            else:
                conn.execute(text(f"DROP TABLE IF EXISTS {test_table_name}"))
            conn.commit()
            print("     Test table dropped")

        print_result(
            "Table Operations",
            True,
            "CREATE, INSERT, SELECT, DROP all successful"
        )
        return True

    except Exception as e:
        print_result("Table Operations", False, str(e)[:200])
        return False


def test_flask_sqlalchemy():
    """Test 7: Test Flask-SQLAlchemy configuration"""
    print_header("TEST 7: Flask-SQLAlchemy Configuration")

    try:
        from config import BaseConfig

        db_url = BaseConfig.SQLALCHEMY_DATABASE_URI
        db_type = BaseConfig.get_database_type()
        is_prod = BaseConfig.is_production_db()

        print(f"\n  Configuration from config.py:")
        print(f"    Database Type: {db_type}")
        print(f"    Is Production: {is_prod}")
        print(f"    URL: {db_url[:50]}..." if len(db_url) > 50 else f"    URL: {db_url}")

        if 'postgresql' in db_url:
            engine_opts = BaseConfig.SQLALCHEMY_ENGINE_OPTIONS
            print(f"    Pool Size: {engine_opts.get('pool_size', 'N/A')}")
            print(f"    Max Overflow: {engine_opts.get('max_overflow', 'N/A')}")

        print_result(
            "Flask-SQLAlchemy Config",
            True,
            f"Using {db_type.upper()}"
        )
        return True

    except Exception as e:
        print_result("Flask-SQLAlchemy Config", False, str(e))
        return False


def test_migration_tables(engine, config: dict):
    """Test 8: Check for application tables"""
    print_header("TEST 8: Application Tables Check")

    if not engine:
        print_result("Application Tables", False, "No engine available")
        return False

    db_type = config.get('db_type', 'sqlite').lower()
    schema = config.get('db_schema', 'public') if db_type == 'postgresql' else None

    expected_tables = [
        'migration_records',
        'api_specifications',
        'users',
        'settings'
    ]

    try:
        from sqlalchemy import text

        with engine.connect() as conn:
            if db_type == 'postgresql':
                result = conn.execute(text("""
                    SELECT table_name FROM information_schema.tables
                    WHERE table_schema = :schema
                """), {'schema': schema})
            else:
                result = conn.execute(text("""
                    SELECT name FROM sqlite_master WHERE type='table'
                """))

            existing_tables = [row[0] for row in result.fetchall()]

        found_tables = []
        missing_tables = []

        for table in expected_tables:
            if table in existing_tables:
                found_tables.append(table)
            else:
                missing_tables.append(table)

        if found_tables:
            print("\n  Found Application Tables:")
            for table in found_tables:
                print(f"    ✅ {table}")

        if missing_tables:
            print("\n  Missing Application Tables:")
            for table in missing_tables:
                print(f"    ⚠️  {table}")

        has_tables = len(found_tables) > 0

        print_result(
            "Application Tables",
            has_tables,
            f"Found {len(found_tables)}/{len(expected_tables)} expected tables",
            {
                'Found': len(found_tables),
                'Missing': len(missing_tables)
            }
        )

        if missing_tables:
            print("\n  NOTE: Missing tables will be created when the app starts")

        return has_tables

    except Exception as e:
        print_result("Application Tables", False, str(e)[:200])
        return False


def run_all_tests():
    """Run all database connector tests"""
    print("\n" + "=" * 70)
    print(" DATABASE CONNECTOR TEST SUITE")
    print(" Testing connection from local environment (outside Azure Web App)")
    print("=" * 70)

    results = {}

    # Test 1: Configuration
    has_config, config = test_configuration()
    results['configuration'] = has_config

    if not has_config:
        print("\n" + "=" * 70)
        print(" TESTS ABORTED: Missing database configuration")
        print("=" * 70)
        print("\nSetup Instructions:")
        print("  1. Create .env file in project root")
        print("  2. Add the following configuration:")
        print("\n  # SQLite (Default)")
        print("  API_DB_TYPE=sqlite")
        print("\n  # OR PostgreSQL")
        print("  API_DB_TYPE=postgresql")
        print("  API_DB_HOST=your-server.postgres.database.azure.com")
        print("  API_DB_PORT=5432")
        print("  API_DB_NAME=your_database")
        print("  API_DB_USER=your_user")
        print("  API_DB_PASSWORD=your_password")
        print("  API_DB_SCHEMA=api")
        print("  API_DB_SSLMODE=require  # Required for Azure PostgreSQL")
        return results

    # Test 2: SDK Import
    results['sdk_import'] = test_sdk_import()
    if not results['sdk_import']:
        return results

    # Test 3: Direct PostgreSQL Connection
    if config.get('db_type', 'sqlite').lower() == 'postgresql':
        results['direct_connection'] = test_direct_connection(config)
    else:
        results['direct_connection'] = None

    # Test 4: SQLAlchemy Connection
    engine = test_sqlalchemy_connection(config)
    results['sqlalchemy_connection'] = engine is not None

    if not engine:
        return results

    # Test 5: Schema Existence
    results['schema_check'] = test_schema_existence(engine, config)

    # Test 6: Table Operations
    results['table_operations'] = test_table_operations(engine, config)

    # Test 7: Flask-SQLAlchemy Config
    results['flask_config'] = test_flask_sqlalchemy()

    # Test 8: Application Tables
    results['app_tables'] = test_migration_tables(engine, config)

    # Cleanup
    if engine:
        engine.dispose()

    # Final Summary
    print("\n" + "=" * 70)
    print(" TEST SUMMARY")
    print("=" * 70)

    total_tests = len([v for v in results.values() if v is not None])
    passed_tests = sum(1 for v in results.values() if v is True)

    print(f"\n  Total Tests:  {total_tests}")
    print(f"  Passed:       {passed_tests}")
    print(f"  Failed:       {total_tests - passed_tests}")
    print(f"  Success Rate: {(passed_tests/total_tests)*100:.0f}%" if total_tests > 0 else "N/A")

    print("\n  Results:")
    for test, result in results.items():
        if result is None:
            status = "⏭️"
            msg = "skipped"
        elif result:
            status = "✅"
            msg = "passed"
        else:
            status = "❌"
            msg = "failed"
        print(f"    {status} {test}: {msg}")

    print("\n" + "=" * 70)

    if passed_tests == total_tests:
        print(" ALL TESTS PASSED - Database is properly configured!")
    else:
        print(" SOME TESTS FAILED - Check configuration and connectivity")

    print("=" * 70 + "\n")

    return results


if __name__ == "__main__":
    run_all_tests()
