# 🤖 AZURE OPENAI CONNECTOR - COMPREHENSIVE DOCUMENTATION

## Table of Contents
1. [Overview](#overview)
2. [Model-Aware Parameters](#model-aware-parameters)
3. [Architecture](#architecture)
4. [Authentication](#authentication)
5. [API Conversion](#api-conversion)
6. [Conversion Process](#conversion-process)
7. [Advanced Features](#advanced-features)
8. [Error Handling](#error-handling)
9. [Configuration](#configuration)
10. [Usage Examples](#usage-examples)
11. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

The **Azure OpenAI Connector** is an intelligent module that uses **Azure's OpenAI service** to automatically convert, normalize, and enhance API specifications. It's particularly powerful for converting **OpenAPI 2.0 (Swagger)** to **OpenAPI 3.0** format.

### What It Does:
✅ **Converts APIs** between OpenAPI versions (2.0 ↔ 3.0)  
✅ **Uses AI** for intelligent spec transformation  
✅ **Validates specs** for Azure APIM compatibility  
✅ **Normalizes specs** across different formats (JSON/YAML)  
✅ **Handles large specs** with smart chunking and retries  
✅ **Supports multiple models** with model-aware parameters  

### Key Innovation - Model-Aware Parameters:
```python
# ✅ NEW: Different models need different parameters
gpt-5-mini         → max_completion_tokens (no temperature)
gpt-4o-mini        → max_tokens + temperature
gpt-4, gpt-4-turbo → max_tokens + temperature
```

---

## 🔧 Model-Aware Parameters

### What Are Model-Aware Parameters?

Different AI models accept different parameters. Azure's OpenAI API requires you to adapt your parameters based on the model you're using.

### MODEL_CONFIGS Dictionary

```python
MODEL_CONFIGS = {
    'gpt-5-mini': {
        'use_max_completion_tokens': True,     # ← Use THIS parameter
        'supports_temperature': False,          # ← DON'T use temperature
        'supports_top_p': False,
        'supports_frequency_penalty': False,
        'supports_presence_penalty': False,
        'default_max': 8000,                    # Max output tokens
    },
    'gpt-4o-mini': {
        'use_max_completion_tokens': False,    # ← Use max_tokens instead
        'supports_temperature': True,           # ← DO use temperature
        'supports_top_p': True,
        'supports_frequency_penalty': True,
        'supports_presence_penalty': True,
        'default_max': 800,
    },
    'gpt-4o': {
        'use_max_completion_tokens': False,
        'supports_temperature': True,
        'supports_top_p': True,
        'supports_frequency_penalty': True,
        'supports_presence_penalty': True,
        'default_max': 4000,
    },
    'gpt-4': {...},
    'gpt-35-turbo': {...}
}
```

### Parameter Building Process

```python
def _build_chat_completion_params(
    deployment: str,                    # Model name
    messages: list,                     # Chat messages
    temperature: float = 0.7,           # Creativity (0-1)
    max_tokens: int = None              # Max output length
) -> Dict[str, Any]:
    """Build model-aware parameters"""
```

**Step-by-step process:**

```
1. Get model configuration
   ↓
2. Determine which max_tokens parameter to use
   ├─ gpt-5-mini: max_completion_tokens
   └─ others: max_tokens
   ↓
3. Add temperature (if supported)
   ↓
4. Add top_p, frequency_penalty, presence_penalty (if supported)
   ↓
5. Return complete parameters dict
```

### Example: Building Parameters for Different Models

**For GPT-5-mini:**
```python
params = connector._build_chat_completion_params(
    deployment='gpt-5-mini',
    messages=[{"role": "user", "content": "Convert this spec"}],
    temperature=0.7,
    max_tokens=8000
)

# Result:
{
    "model": "gpt-5-mini",
    "messages": [...],
    "stream": False,
    "max_completion_tokens": 8000  # ← NOT max_tokens
}
```

**For GPT-4o-mini:**
```python
params = connector._build_chat_completion_params(
    deployment='gpt-4o-mini',
    messages=[...],
    temperature=0.7,
    max_tokens=800
)

# Result:
{
    "model": "gpt-4o-mini",
    "messages": [...],
    "stream": False,
    "max_tokens": 800,           # ← NOT max_completion_tokens
    "temperature": 0.7,
    "top_p": 0.95,
    "frequency_penalty": 0,
    "presence_penalty": 0
}
```

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────┐
│    Azure OpenAI Connector               │
├─────────────────────────────────────────┤
│                                         │
│  Authentication Layer                   │
│  ├─ API Key (Primary)                   │
│  └─ Entra ID / Managed Identity         │
│                                         │
│  Model Management Layer                 │
│  ├─ MODEL_CONFIGS dictionary            │
│  ├─ _get_model_config()                 │
│  └─ _build_chat_completion_params()     │
│                                         │
│  Conversion Layer                       │
│  ├─ Universal Converter                 │
│  ├─ OpenAPI 2.0 → 3.0                  │
│  ├─ OpenAPI 3.0 → 2.0                  │
│  └─ Format Conversion (JSON/YAML)      │
│                                         │
│  Validation Layer                       │
│  ├─ OpenAPI Validation                  │
│  ├─ Azure APIM Compatibility            │
│  ├─ Reference Path Fixing               │
│  └─ Component Creation                  │
│                                         │
│  Error Handling Layer                   │
│  ├─ Retry Logic                         │
│  ├─ Fallback Converters                 │
│  └─ Debug Information                   │
│                                         │
└─────────────────────────────────────────┘
         │
         ▼
    Azure OpenAI API
         │
    Returns AI-generated
    OpenAPI 3.0 spec
```

---

## 🔐 Authentication

### Two Authentication Methods

#### Method 1: API Key (Recommended for Development)

```python
os.environ['AZURE_OPENAI_API_KEY'] = 'your-api-key'
os.environ['AZURE_OPENAI_ENDPOINT'] = 'https://your-resource.openai.azure.com/'
os.environ['AZURE_OPENAI_VERSION'] = '2024-02-15-preview'
```

**Flow:**
```
1. Check for AZURE_OPENAI_API_KEY
2. Create AzureOpenAI client with API key
3. Use for all OpenAI API calls
```

#### Method 2: Entra ID / Managed Identity (Recommended for Production)

```python
# No explicit credentials needed
# Azure SDK automatically uses:
# 1. Environment variables
# 2. Managed Identity (if running on Azure)
# 3. Azure CLI credentials
# 4. System credentials
```

**Flow:**
```
1. Check for DefaultAzureCredential
2. Get bearer token provider
3. Create AzureOpenAI client with token provider
4. Tokens auto-refreshed as needed
```

### Initialization Process

```python
def __init__(self):
    """Initialize Azure OpenAI client"""
    self.config = BaseConfig
    self._client = None
    self.is_initialized = False
    self._initialization_error = None
    
    try:
        self._initialize_client()
    except Exception as e:
        self._initialization_error = str(e)

def _initialize_client(self) -> bool:
    """Initialize with validation and fallback"""
    
    # Step 1: Validate configuration
    validation = ConfigValidator.validate_all()
    if not validation['valid']:
        logger.error(f"Config errors: {validation['errors']}")
        return False
    
    # Step 2: Try API key authentication
    if api_key:
        client = self._init_with_api_key(AzureOpenAI)
    else:
        # Step 3: Fall back to Entra ID
        client = self._init_with_entra_id(AzureOpenAI)
    
    # Step 4: Verify success
    if client:
        self.is_initialized = True
        return True
    
    return False
```

---

## 📋 API Conversion

### Supported Conversions

```
1. OpenAPI 2.0 → OpenAPI 3.0 (Most Common)
   └─ Uses Azure OpenAI for intelligent conversion
   
2. OpenAPI 3.0 → OpenAPI 2.0 (Downgrade)
   └─ Uses programmatic fallback (lossy)
   
3. JSON ↔ YAML Format Conversion
   └─ Uses YAML library
   
4. Normalization
   └─ Cleans up and validates existing specs
```

### Universal Converter

```python
def convert_specification(
    spec_content: str,           # Input spec (JSON or YAML)
    target_format: str = 'json', # Output format (json or yaml)
    target_version: str = 'auto',# Target version (2.0, 3.0, auto)
    include_debug: bool = False  # Include debug info
) -> Dict[str, Any]:
    """Universal converter - handles all scenarios"""
```

**Returns:**
```python
{
    'status': 'success',                    # success or error
    'converted_spec': {...},                # Converted spec dict
    'converted_content': '{"openapi": ...}',# Converted spec as string
    'source_format': 'json',                # Original format
    'source_version': '2.0',                # Original version
    'target_format': 'json',                # Output format
    'target_version': '3.0',                # Output version
    'conversion_type': 'version_upgrade',   # Type of conversion
    'ai_conversion_used': True,             # Was AI used?
    'conversion_metadata': {...}            # Details
}
```

---

## 🔄 Conversion Process

### OpenAPI 2.0 → 3.0 Conversion (with AI)

```
1. PARSE INPUT
   ├─ Detect format (JSON/YAML)
   ├─ Parse content
   └─ Detect OpenAPI version
                ▼
2. VALIDATE INPUT
   ├─ Check required fields
   ├─ Verify structure
   └─ Log input characteristics
                ▼
3. AI CONVERSION (if available)
   ├─ Create optimized prompt
   ├─ Call Azure OpenAI
   ├─ Extract JSON from response
   ├─ Validate result
   └─ Retry on failure (up to 3x)
                ▼
4. AZURE APIM COMPATIBILITY
   ├─ Fix $ref paths
   ├─ Create missing components
   ├─ Fix request/response structure
   └─ Add servers section
                ▼
5. FORMAT CONVERSION
   ├─ JSON → YAML (if needed)
   └─ Apply formatting
                ▼
6. RETURN RESULT
   ├─ Success: converted spec + metadata
   └─ Error: error message + diagnostics
```

### Key Transformation Examples

#### Example 1: Host/BasePath to Servers
```python
# OpenAPI 2.0
{
  "host": "api.example.com",
  "basePath": "/v1",
  "schemes": ["https"]
}

# OpenAPI 3.0
{
  "servers": [
    {
      "url": "https://api.example.com/v1",
      "description": "Default server"
    }
  ]
}
```

#### Example 2: Definitions to Components/Schemas
```python
# OpenAPI 2.0
{
  "definitions": {
    "User": {
      "type": "object",
      "properties": {
        "id": {"type": "string"}
      }
    }
  }
}

# OpenAPI 3.0
{
  "components": {
    "schemas": {
      "User": {
        "type": "object",
        "properties": {
          "id": {"type": "string"}
        }
      }
    }
  }
}
```

#### Example 3: Body Parameters to RequestBody
```python
# OpenAPI 2.0
{
  "parameters": [
    {
      "name": "body",
      "in": "body",
      "schema": {"$ref": "#/definitions/User"}
    }
  ]
}

# OpenAPI 3.0
{
  "requestBody": {
    "content": {
      "application/json": {
        "schema": {"$ref": "#/components/schemas/User"}
      }
    }
  }
}
```

---

## ⚙️ Advanced Features

### Feature 1: Large Spec Handling

```python
def _create_optimized_conversion_prompt(self, spec: Dict) -> str:
    """Handle large specs by summarizing for AI"""
    
    # If spec is too large:
    # 1. Extract metadata (title, version, etc.)
    # 2. Include first N paths and definitions
    # 3. Include count of remaining items
    # 4. Ask AI to generate complete spec based on sample
```

**Example:**
```python
# Original: 5000 endpoints
# Summarized: 3 sample endpoints + stats
# AI generates complete spec with all 5000 endpoints
```

### Feature 2: Retry Logic with Backoff

```python
# Retry strategy:
# ├─ Attempt 1: Immediate
# ├─ Attempt 2: Wait 2 seconds
# ├─ Attempt 3: Wait 4 seconds (or 60s if rate-limited)
# └─ Final: Fall back to programmatic converter
```

### Feature 3: Reference Path Fixing

```python
# Fixes all variations of broken $ref paths:
"$ref": "/definitions/User"        → "#/components/schemas/User"
"$ref": "#/definitions/User"       → "#/components/schemas/User"
"$ref": "/responses/NotFound"      → "#/components/responses/NotFound"
"$ref": "/parameters/PageSize"     → "#/components/parameters/PageSize"
```

### Feature 4: Missing Component Creation

When a spec references components that don't exist, the connector creates stubs:

```python
# Referenced but missing: User, NotFound, PageSize
# Connector creates:

components:
  schemas:
    User:
      type: object
      properties:
        id:
          type: string
  
  responses:
    NotFound:
      description: Not Found
      content:
        application/json:
          schema:
            type: object
  
  parameters:
    PageSize:
      name: page-size
      in: query
      schema:
        type: integer
```

### Feature 5: Debug Information

```python
result = connector.convert_specification(
    spec_content,
    include_debug=True
)

# Returns additional debugging data:
{
    'raw_openai_response': '{"openapi": "3.0.0", ...}',
    'cleaned_json': '{"openapi": "3.0.0", ...}',
    'cleaning_issues': []
}
```

---

## 🚨 Error Handling

### Error Categories

#### 1. Configuration Errors
```python
# Missing environment variables
AZURE_OPENAI_ENDPOINT
AZURE_OPENAI_API_KEY (or Entra ID)
AZURE_OPENAI_VERSION
AZURE_OPENAI_DEPLOYMENT
```

**Solution:**
```bash
export AZURE_OPENAI_ENDPOINT="https://your.openai.azure.com/"
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_VERSION="2024-02-15-preview"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o-mini"
```

#### 2. Authentication Errors
```python
# Invalid API key
# Expired credentials
# Insufficient permissions
```

**Solution:**
```bash
# Verify API key
az account show

# Refresh credentials
az login

# Check permissions in Azure Portal
```

#### 3. Model Errors
```python
# Unsupported model specified
# Model quota exceeded
# Model deployment not found
```

**Solution:**
```python
# Check available models
connector._get_model_config('gpt-4o-mini')

# Use fallback programmatic converter
result = connector._convert_2_to_3(spec)
```

#### 4. Timeout Errors
```python
# API call took too long
# Network timeout
# Large spec causing timeout
```

**Solution:**
```python
# Automatically retries with backoff
# Falls back to programmatic converter on final timeout
```

#### 5. JSON Parsing Errors
```python
# AI response not valid JSON
# Malformed spec
# Invalid JSON structure
```

**Solution:**
```python
# Connector automatically:
# 1. Extracts JSON from markdown code blocks
# 2. Finds matching braces
# 3. Validates structure
# 4. Retries if invalid
```

### Error Handling Strategy

```
User Error
    │
    ▼
Try preferred method (AI if available)
    │
    ├─ Success → Return result
    │
    └─ Failure
       ├─ Retry 1-3 times with backoff
       └─ Still failing?
          ├─ Fall back to programmatic converter
          ├─ If still failing → Return error
          └─ Log detailed diagnostics
```

---

## ⚙️ Configuration

### Environment Variables

```bash
# Azure OpenAI Service
export AZURE_OPENAI_ENDPOINT="https://your-resource.openai.azure.com/"
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_VERSION="2024-02-15-preview"
export AZURE_OPENAI_DEPLOYMENT="gpt-4o-mini"

# Entra ID (optional - instead of API key)
export AZURE_SUBSCRIPTION_ID="sub-id"
export AZURE_TENANT_ID="tenant-id"

# Optional: Timeout settings
export AZURE_OPENAI_TIMEOUT="120"
export AZURE_OPENAI_MAX_RETRIES="3"
```

### Getting Configuration Values

```bash
# Get endpoint and version
az cognitiveservices account show \
  --resource-group your-rg \
  --name your-resource \
  --query "properties.endpoint"

# Get API key
az cognitiveservices account keys list \
  --resource-group your-rg \
  --name your-resource \
  --query "key1"

# Get available deployments
az cognitiveservices account deployment list \
  --resource-group your-rg \
  --name your-resource
```

---

## 💡 Usage Examples

### Example 1: Simple Conversion

```python
from connectors import AzureOpenAIConnector

connector = AzureOpenAIConnector()

# Read OpenAPI 2.0 spec
with open('swagger.json') as f:
    spec_content = f.read()

# Convert to OpenAPI 3.0
result = connector.convert_specification(spec_content)

if result['status'] == 'success':
    # Save converted spec
    with open('openapi-3.0.json', 'w') as f:
        f.write(result['converted_content'])
    
    print(f"✓ Converted: {result['source_version']} → {result['target_version']}")
    print(f"✓ Paths: {result['conversion_metadata']['original_paths_count']}")
```

### Example 2: Format Conversion

```python
# Convert YAML to JSON
result = connector.convert_specification(
    yaml_spec_content,
    target_format='json',  # Output as JSON
    target_version='auto'  # Keep same version
)

# Convert JSON to YAML
result = connector.convert_specification(
    json_spec_content,
    target_format='yaml',  # Output as YAML
    target_version='auto'
)
```

### Example 3: With Debug Info

```python
result = connector.convert_specification(
    spec_content,
    include_debug=True
)

print(f"Raw OpenAI response: {result['raw_openai_response'][:500]}")
print(f"Cleaning issues: {result['cleaning_issues']}")
print(f"Conversion metadata: {result['conversion_metadata']}")
```

### Example 4: Large Spec Handling

```python
# Connector automatically handles large specs
large_spec_content = open('large-api.json').read()

result = connector.convert_specification(large_spec_content)

# Connector will:
# 1. Detect it's too large
# 2. Create optimized prompt with summary
# 3. Ask AI to generate complete spec
# 4. Return full spec
```

### Example 5: Backward Compatibility Methods

```python
# Old method names still work
result = connector.convert_openapi_2_to_3(spec_content)

# Or
result = connector.universal_openapi_converter(spec_content)
```

### Example 6: Test Connection

```python
result = connector.test_connection()

if result['status'] == 'success':
    print(f"✓ Connected to {result['model']}")
    print(f"  Auth: {result['auth_method']}")
    print(f"  Response: {result['response']}")
else:
    print(f"✗ Connection failed: {result['message']}")
```

---

## 🔧 Troubleshooting

### Problem 1: "AZURE_OPENAI_DEPLOYMENT is gpt-5-mini"

**Symptom:**
```
API Error: Invalid model 'gpt-5-mini'
```

**Cause:**
- `gpt-5-mini` doesn't exist in real Azure OpenAI
- Should be `gpt-4o-mini` or `gpt-4`

**Solution:**
```bash
# Check available models in Azure Portal
# Or use:
export AZURE_OPENAI_DEPLOYMENT="gpt-4o-mini"
export AZURE_OPENAI_DEPLOYMENT="gpt-4"
export AZURE_OPENAI_DEPLOYMENT="gpt-35-turbo"
```

### Problem 2: "Invalid Parameter: max_tokens"

**Symptom:**
```
Invalid parameter: 'max_tokens' not supported for this model
```

**Cause:**
- Using `max_tokens` with `gpt-5-mini` (which needs `max_completion_tokens`)
- Model-aware parameters not applied

**Solution:**
```python
# Connector automatically fixes this
# But if manual call:
params = connector._build_chat_completion_params(
    deployment='gpt-5-mini',
    messages=[...],
    max_tokens=8000
)
# ✓ Will use max_completion_tokens instead
```

### Problem 3: "Timeout After 30 Seconds"

**Symptom:**
```
Timeout: Request did not complete within 30 seconds
```

**Cause:**
- Large spec size
- Slow network
- Azure service latency

**Solution:**
```python
# Connector automatically:
# 1. Retries with backoff
# 2. Summarizes large specs
# 3. Falls back to programmatic converter

# Or increase timeout:
export AZURE_OPENAI_TIMEOUT="300"
```

### Problem 4: "$ref Paths Still Broken"

**Symptom:**
```
Invalid reference: "$ref": "/definitions/User"
```

**Cause:**
- Reference fixing didn't catch all formats
- Complex nested structures

**Solution:**
```python
# Connector includes comprehensive fix:
# 1. String replacements
# 2. Regex patterns
# 3. JSON traversal
# 4. Verification check

# If still issues, check Azure APIM validation:
validation = connector.validate_openapi_for_apim(spec)
print(validation['issues'])
```

### Problem 5: "Missing Required Schema"

**Symptom:**
```
Referenced schema "User" does not exist
```

**Cause:**
- Spec has broken references
- Missing component definitions

**Solution:**
```python
# Connector automatically creates stubs:
# 1. Finds all $ref references
# 2. Checks if they exist
# 3. Creates stub components

# Verify stubs were created:
result = connector.convert_specification(spec)
print(result['conversion_metadata'])
```

---

## 📊 Data Flow Diagram

```
Input: OpenAPI Spec (any format/version)
       │
       ▼
┌──────────────────────────┐
│  Parse & Validate Input  │
├──────────────────────────┤
│  Detect format (JSON/YAML)
│  Detect version (2.0/3.0)
└────────────┬─────────────┘
             │
             ▼
┌──────────────────────────┐
│  Determine Conversion    │
├──────────────────────────┤
│  Is AI needed?
│  └─ 2.0 → 3.0: YES
│  └─ 3.0 → 2.0: NO
│  └─ Format only: NO
└────────────┬─────────────┘
             │
         ┌───┴────┐
         │         │
    AI Available?  │
         │         │
    ┌────┴─────────┴──────────┐
    │                         │
   YES                       NO
    │                         │
    ▼                         ▼
AI Convert            Programmatic Convert
(Max 3 retries)       (Deterministic)
    │                         │
    └────────────┬────────────┘
                 │
                 ▼
    ┌─────────────────────────┐
    │  Azure APIM Fixes       │
    ├─────────────────────────┤
    │  Fix $ref paths
    │  Create missing stubs
    │  Fix request/response
    │  Add servers
    └────────────┬────────────┘
                 │
                 ▼
    ┌─────────────────────────┐
    │  Format Conversion      │
    ├─────────────────────────┤
    │  JSON/YAML as needed
    └────────────┬────────────┘
                 │
                 ▼
Output: Converted Spec + Metadata
```

---

## ✨ Key Features Summary

✅ **Universal Converter**
- Handles all OpenAPI versions and formats
- Intelligent routing between AI and programmatic methods

✅ **Model-Aware Parameters**
- Automatic parameter adaptation per model
- No manual configuration needed

✅ **Intelligent Error Recovery**
- Automatic retries with exponential backoff
- Rate limit handling
- Graceful fallback to programmatic converter

✅ **Large Spec Support**
- Automatic spec summarization
- Chunking for large specifications

✅ **Azure APIM Compatibility**
- Automatic reference path fixing
- Missing component creation
- Request/response structure validation

✅ **Comprehensive Logging**
- Debug information available
- Detailed error messages
- Conversion metadata included

✅ **Production Ready**
- Timeout handling
- Connection pooling
- Retry logic
- Error recovery