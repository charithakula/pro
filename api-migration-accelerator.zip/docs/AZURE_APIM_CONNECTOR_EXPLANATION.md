# 🔗 AZURE API MANAGEMENT CONNECTOR - COMPREHENSIVE DOCUMENTATION

## Table of Contents
1. [Overview](#overview)
2. [SSL Certificate Configuration](#ssl-certificate-configuration)
3. [Core Components](#core-components)
4. [Authentication Flow](#authentication-flow)
5. [API Operations](#api-operations)
6. [OpenAPI Validation](#openapi-validation)
7. [Error Handling](#error-handling)
8. [Usage Examples](#usage-examples)
9. [Configuration Guide](#configuration-guide)
10. [Troubleshooting](#troubleshooting)

---

## 🎯 Overview

The **Azure API Management Connector** is a specialized module that bridges your Flask application with **Azure API Management (APIM)** service. It handles all CRUD operations and provides intelligent API deployment capabilities.

### What It Does:
✅ **Deploys APIs** to Azure APIM from OpenAPI specifications  
✅ **Manages API Lifecycle** (create, read, update, delete)  
✅ **Creates Products** and groups APIs together  
✅ **Validates OpenAPI** specs for APIM compatibility  
✅ **Handles SSL Certificates** for private networks  
✅ **Provides URLs** for management and developer portals  

### File Location:
```
connectors/
└── azure_apim_connector.py
```

### Import:
```python
from connectors import AzureAPIMConnector

connector = AzureAPIMConnector()
if connector.is_available:
    result = connector.create_api_from_openapi(spec, api_id)
```

---

## 🔒 SSL Certificate Configuration

### What is SSL Certificate Configuration?

SSL (Secure Sockets Layer) certificates ensure encrypted communication with Azure services. In some environments (private networks, corporate proxies), special certificate handling is needed.

### SSLConfig Class

```python
class SSLConfig:
    """Manages SSL/TLS certificate configuration"""
    
    VERIFY_SSL = True                    # Verify SSL certificates
    CA_BUNDLE_PATH = None                # Path to custom CA certificate
    CLIENT_CERT_PATH = None              # Path to client certificate
    CLIENT_KEY_PATH = None               # Path to client private key
```

### Configuration Methods

#### 1. Default SSL Verification (Recommended)
```bash
# No environment variables needed
# Uses system's default CA certificates
export VERIFY_SSL=True
python app.py
```

#### 2. Custom CA Certificate (Private Networks)
```bash
# For corporate proxies or internal CAs
export VERIFY_SSL=True
export CA_BUNDLE_PATH=/etc/ssl/certs/ca-bundle.crt
python app.py
```

#### 3. Client Certificate Authentication
```bash
# For mutual TLS (mTLS) requirements
export VERIFY_SSL=True
export CA_BUNDLE_PATH=/path/to/ca-cert.pem
export CLIENT_CERT_PATH=/path/to/client-cert.pem
export CLIENT_KEY_PATH=/path/to/client-key.pem
python app.py
```

#### 4. Disable SSL Verification (Testing Only)
```bash
# ⚠️ NOT RECOMMENDED FOR PRODUCTION
# Only for development and testing with self-signed certificates
export VERIFY_SSL=False
python app.py
```

### Getting SSL Configuration

```python
@staticmethod
def get_cert_config() -> Dict[str, Any]:
    """Returns certificate configuration for requests"""
    config = {}
    
    # Verify SSL (default: True)
    if not SSLConfig.VERIFY_SSL:
        config['verify'] = False  # Skip verification
    elif SSLConfig.CA_BUNDLE_PATH:
        config['verify'] = SSLConfig.CA_BUNDLE_PATH  # Custom CA
    else:
        config['verify'] = True  # System default
    
    # Add client certificates if provided
    if SSLConfig.CLIENT_CERT_PATH and SSLConfig.CLIENT_KEY_PATH:
        config['cert'] = (CLIENT_CERT_PATH, CLIENT_KEY_PATH)
    
    return config
```

### Configuring Environment

```python
@staticmethod
def configure_environment():
    """Setup SSL environment variables and settings"""
    
    # Suppress SSL warnings if disabled
    if not SSLConfig.VERIFY_SSL:
        urllib3.disable_warnings()
        logger.warning("SSL verification disabled")
    
    # Set environment variables for all libraries
    if SSLConfig.CA_BUNDLE_PATH:
        os.environ['REQUESTS_CA_BUNDLE'] = SSLConfig.CA_BUNDLE_PATH
        os.environ['CURL_CA_BUNDLE'] = SSLConfig.CA_BUNDLE_PATH
```

---

## 🏗️ Core Components

### 1. AzureAPIMConnector Class

Main class that handles all APIM operations:

```python
class AzureAPIMConnector:
    """Main connector to Azure API Management service"""
    
    def __init__(self):
        """Initialize with SSL configuration"""
        self.config = BaseConfig
        self._credential = None      # Azure credentials
        self._client = None          # APIM client
        self._initialize_client()
```

**Instance Variables:**
- `self.config`: Configuration object with Azure credentials
- `self._credential`: Azure authentication token
- `self._client`: Azure APIM SDK client

**Key Properties:**
```python
@property
def is_available(self) -> bool:
    """Check if Azure APIM service is available"""
    return self._client is not None
```

### 2. Credential Management

```python
def _initialize_client(self) -> bool:
    """Initialize Azure APIM client with credentials"""
    
    # Create service principal credential
    self._credential = ClientSecretCredential(
        tenant_id=self.config.AZURE_TENANT_ID,
        client_id=self.config.AZURE_CLIENT_ID,
        client_secret=self.config.AZURE_CLIENT_SECRET
    )
    
    # Create APIM client
    self._client = ApiManagementClient(
        credential=self._credential,
        subscription_id=self.config.AZURE_SUBSCRIPTION_ID
    )
```

**Flow:**
1. Takes credentials from environment variables
2. Creates Azure credential object
3. Initializes APIM client
4. Returns True if successful

### 3. Configuration Validation

```python
def _initialize_client(self) -> bool:
    """Validates required configuration before initializing"""
    
    missing_config = (
        self.config.validate_azure_config() +    # Core Azure settings
        self.config.validate_apim_config()       # APIM-specific settings
    )
    
    if missing_config:
        logger.error(f"Missing: {missing_config}")
        return False
```

**Required Configuration:**
```python
AZURE_TENANT_ID          # Azure tenant ID
AZURE_CLIENT_ID          # Service principal client ID
AZURE_CLIENT_SECRET      # Service principal secret
AZURE_SUBSCRIPTION_ID    # Azure subscription ID
AZURE_APIM_RESOURCE_GROUP   # Resource group name
AZURE_APIM_SERVICE_NAME  # APIM service name
```

---

## 🔐 Authentication Flow

```
User Request (Flask app)
      │
      ▼
AzureAPIMConnector initialized
      │
      ▼
_initialize_client() called
      │
      ├─ Validate configuration
      │  ├─ Check required env vars
      │  └─ Log configuration
      │
      ├─ Create Azure credential
      │  ├─ ClientSecretCredential with tenant/client ID/secret
      │  └─ Token acquired from Azure AD
      │
      ├─ Initialize APIM client
      │  ├─ Connect to Azure Management API
      │  └─ Ready for operations
      │
      └─ Set is_available = True
           │
           ▼
      Return client ready for API operations
           │
           ▼
      Make authenticated requests to Azure APIM
           │
           ├─ Authorization: Bearer {token}
           ├─ Content-Type: application/json
           └─ All requests authenticated
```

---

## 📋 API Operations

### 1. Test Connection

```python
def test_connection(self) -> Dict[str, Any]:
    """Test if connected to Azure APIM"""
```

**What it does:**
1. Checks if client is initialized
2. Makes test query to list APIs
3. Returns connection status

**Returns:**
```python
{
    'status': 'success',           # or 'error'
    'message': 'Connected',
    'service_name': 'my-apim',
    'api_count': 15,               # Number of existing APIs
    'ssl_config': {...}            # SSL configuration used
}
```

**Example:**
```python
connector = AzureAPIMConnector()
result = connector.test_connection()

if result['status'] == 'success':
    print(f"✓ Connected to {result['service_name']}")
    print(f"  Found {result['api_count']} APIs")
else:
    print(f"✗ Connection failed: {result['message']}")
```

### 2. Create API from OpenAPI

```python
def create_api_from_openapi(
    self, 
    openapi_spec: Dict[str, Any], 
    api_id: Optional[str] = None
) -> Dict[str, Any]:
    """Deploy new API to Azure APIM"""
```

**Process:**
1. **Validate** OpenAPI spec for APIM compatibility
2. **Fix** any validation issues
3. **Extract** API metadata (title, version, etc.)
4. **Generate** API ID if not provided
5. **Create** API in Azure APIM
6. **Return** deployment details

**Request:**
```python
openapi_spec = {
    "openapi": "3.0.0",
    "info": {
        "title": "User API",
        "version": "1.0.0",
        "description": "User management API"
    },
    "paths": {...}
}

result = connector.create_api_from_openapi(
    openapi_spec,
    api_id="user-api"
)
```

**Response:**
```python
{
    'status': 'success',
    'api_id': 'user-api',
    'display_name': 'User API',
    'path': 'user-api',
    'service_url': 'https://api.example.com',
    'api_version': '1.0.0',
    'message': 'API user-api created successfully',
    'validation_issues_fixed': [
        'Moved definitions to components/schemas',
        'Fixed $ref validation errors'
    ]
}
```

### 3. List APIs

```python
def list_apis(self) -> List[Dict[str, Any]]:
    """Get all APIs in APIM service"""
```

**Returns:**
```python
[
    {
        'id': 'user-api',
        'display_name': 'User API',
        'description': 'User management',
        'service_url': 'https://api.example.com',
        'path': 'users',
        'protocols': ['https'],
        'api_version': '1.0.0',
        'subscription_required': True,
        'is_current': True
    },
    {...}
]
```

**Example:**
```python
apis = connector.list_apis()
for api in apis:
    print(f"{api['display_name']} ({api['id']})")
```

### 4. Get API Details

```python
def get_api(self, api_id: str) -> Optional[Dict[str, Any]]:
    """Get specific API information"""
```

**Example:**
```python
api = connector.get_api("user-api")
if api:
    print(f"API: {api['display_name']}")
    print(f"Service URL: {api['service_url']}")
    print(f"Protocols: {api['protocols']}")
```

### 5. Update API

```python
def update_api(
    self, 
    api_id: str, 
    openapi_spec: Dict[str, Any]
) -> Dict[str, Any]:
    """Update existing API with new specification"""
```

**Process:**
1. Validates new spec
2. Extracts updated metadata
3. Updates API in APIM
4. Returns update confirmation

**Example:**
```python
new_spec = {...}  # Updated OpenAPI spec
result = connector.update_api("user-api", new_spec)

if result['status'] == 'success':
    print(f"✓ API {result['api_id']} updated")
```

### 6. Delete API

```python
def delete_api(self, api_id: str) -> Dict[str, Any]:
    """Delete API from APIM"""
```

**Example:**
```python
result = connector.delete_api("user-api")
if result['status'] == 'success':
    print(f"✓ API deleted: {result['api_id']}")
```

### 7. Create Product

```python
def create_product(
    self, 
    product_name: str, 
    api_ids: List[str], 
    description: str = ""
) -> Dict[str, Any]:
    """Create APIM product and associate APIs"""
```

**What it does:**
1. Creates a product (collection of APIs)
2. Associates provided API IDs with product
3. Sets product as published

**Example:**
```python
result = connector.create_product(
    product_name="User Services",
    api_ids=["user-api", "auth-api"],
    description="APIs for user management and authentication"
)

if result['status'] == 'success':
    print(f"✓ Product created: {result['product_id']}")
    print(f"  Associated {result['api_count']} APIs")
```

### 8. Export API

```python
def export_api(
    self, 
    api_id: str, 
    export_format: str = 'openapi+json'
) -> Dict[str, Any]:
    """Export API specification from APIM"""
```

**Example:**
```python
result = connector.export_api("user-api")
if result['status'] == 'success':
    spec = result['specification']
    print(f"✓ Exported {result['format']} format")
```

### 9. Get URLs

```python
def get_api_management_url(self, api_id: str) -> str:
    """Get Azure portal management URL"""

def get_developer_portal_url(self) -> str:
    """Get developer portal URL"""
```

**Example:**
```python
mgmt_url = connector.get_api_management_url("user-api")
portal_url = connector.get_developer_portal_url()

print(f"Manage API: {mgmt_url}")
print(f"Developer Portal: {portal_url}")
```

---

## ✅ OpenAPI Validation

### What is OpenAPI Validation?

Azure APIM has specific requirements for OpenAPI specifications. The connector automatically validates and fixes common issues.

### Common Issues Fixed

#### 1. Invalid $ref Paths
```python
# ❌ BEFORE (Swagger 2.0 format)
"$ref": "/definitions/User"
"$ref": "#/definitions/User"

# ✅ AFTER (OpenAPI 3.0 format)
"$ref": "#/components/schemas/User"
```

#### 2. Missing Components Section
```python
# ✅ Automatically adds if missing
spec['components'] = {
    'schemas': {...}
}
```

#### 3. Invalid Body Parameters
```python
# ❌ OpenAPI 2.0 (not allowed)
"parameters": [{"in": "body", "schema": {...}}]

# ✅ OpenAPI 3.0 (correct)
"requestBody": {"content": {"application/json": {...}}}
```

#### 4. Schema in Responses
```python
# ❌ BEFORE
"responses": {
    "200": {"schema": {...}}
}

# ✅ AFTER
"responses": {
    "200": {
        "content": {
            "application/json": {
                "schema": {...}
            }
        }
    }
}
```

#### 5. Missing Servers
```python
# ✅ Automatically adds default server
"servers": [
    {"url": "https://api.example.com", "description": "Default"}
]
```

### Validation Function

```python
def validate_openapi_for_apim(
    self, 
    spec: Dict[str, Any]
) -> Dict[str, Any]:
    """Validate and fix OpenAPI spec for APIM"""
    
    issues = []  # List of issues found
    
    # Check required fields
    if 'openapi' not in spec:
        issues.append("Missing 'openapi' version")
        spec['openapi'] = '3.0.0'
    
    # Fix $ref paths
    # Fix body parameters
    # Add missing components
    # ... more fixes ...
    
    return {
        'valid': len(issues) == 0,
        'issues': issues,
        'spec': spec  # Fixed specification
    }
```

**Example:**
```python
validation = connector.validate_openapi_for_apim(spec)

if not validation['valid']:
    print(f"Issues found: {len(validation['issues'])}")
    for issue in validation['issues']:
        print(f"  - {issue}")

fixed_spec = validation['spec']  # Use fixed spec
```

---

## ⚠️ Error Handling

### SSL Certificate Errors

**When it occurs:**
- Network has custom SSL certificate
- Corporate proxy intercepting HTTPS
- Self-signed certificates in private network

**Error message:**
```
SSL: CERTIFICATE_VERIFY_FAILED
```

**Solution:**
```bash
# Option 1: Disable verification (testing only)
export VERIFY_SSL=False

# Option 2: Add CA certificate (recommended)
export CA_BUNDLE_PATH=/path/to/ca-cert.pem
export VERIFY_SSL=True

# Option 3: Use client certificate
export CLIENT_CERT_PATH=/path/to/client-cert.pem
export CLIENT_KEY_PATH=/path/to/client-key.pem
```

### Authentication Errors

**When it occurs:**
- Invalid Azure credentials
- Expired service principal secret
- Insufficient permissions

**Error message:**
```
AuthenticationError: Invalid credentials
```

**Solution:**
```bash
# Verify environment variables
echo $AZURE_CLIENT_ID
echo $AZURE_TENANT_ID
# Check service principal permissions in Azure Portal
```

### Configuration Errors

**When it occurs:**
- Missing required environment variables
- Invalid resource group or service name

**Error message:**
```
Missing Azure APIM configuration: [...]
```

**Solution:**
```bash
# Verify all required variables
export AZURE_CLIENT_ID=<your-client-id>
export AZURE_CLIENT_SECRET=<your-secret>
export AZURE_TENANT_ID=<your-tenant-id>
export AZURE_SUBSCRIPTION_ID=<your-subscription-id>
export AZURE_APIM_RESOURCE_GROUP=<resource-group>
export AZURE_APIM_SERVICE_NAME=<apim-service-name>
```

### OpenAPI Validation Errors

**When it occurs:**
- Invalid OpenAPI spec format
- Missing required fields

**Solution:**
```python
# Validation automatically fixes most issues
validation = connector.validate_openapi_for_apim(spec)

if validation['issues']:
    print(f"Fixed {len(validation['issues'])} issues")
    
# Use the fixed spec
fixed_spec = validation['spec']
```

---

## 💡 Usage Examples

### Example 1: Simple API Deployment

```python
from connectors import AzureAPIMConnector
import json

# Initialize connector
connector = AzureAPIMConnector()

# Check if available
if not connector.is_available:
    print("✗ Azure APIM not available")
    exit(1)

# Test connection
test = connector.test_connection()
print(f"Connection: {test['status']}")

# Load OpenAPI specification
with open('api-spec.json') as f:
    spec = json.load(f)

# Deploy API
result = connector.create_api_from_openapi(spec, "my-api")

if result['status'] == 'success':
    print(f"✓ API deployed: {result['api_id']}")
    print(f"  Management: {connector.get_api_management_url(result['api_id'])}")
    print(f"  Portal: {connector.get_developer_portal_url()}")
```

### Example 2: Batch API Deployment

```python
import glob

connector = AzureAPIMConnector()

spec_files = glob.glob("specs/*.json")

for spec_file in spec_files:
    with open(spec_file) as f:
        spec = json.load(f)
    
    result = connector.create_api_from_openapi(spec)
    
    if result['status'] == 'success':
        print(f"✓ Deployed: {result['api_id']}")
    else:
        print(f"✗ Failed: {result['message']}")
```

### Example 3: Create Product from Multiple APIs

```python
connector = AzureAPIMConnector()

# Create product with multiple APIs
result = connector.create_product(
    product_name="Payment Services",
    api_ids=["payment-api", "billing-api", "invoice-api"],
    description="All payment-related APIs"
)

if result['status'] == 'success':
    print(f"✓ Product created: {result['product_id']}")
```

### Example 4: Update API with New Specification

```python
connector = AzureAPIMConnector()

# Load new spec
with open('updated-spec.json') as f:
    new_spec = json.load(f)

# Update existing API
result = connector.update_api("payment-api", new_spec)

if result['status'] == 'success':
    print(f"✓ API updated: {result['api_id']}")
```

### Example 5: Export and Backup API

```python
connector = AzureAPIMConnector()

# Export API
result = connector.export_api("payment-api")

if result['status'] == 'success':
    # Save backup
    with open(f"backup-payment-api.json", 'w') as f:
        json.dump(result['specification'], f, indent=2)
    
    print(f"✓ API exported and backed up")
```

---

## ⚙️ Configuration Guide

### Required Environment Variables

```bash
# Azure Credentials
export AZURE_CLIENT_ID="xxxx-xxxx-xxxx-xxxx"
export AZURE_CLIENT_SECRET="your-secret-here"
export AZURE_TENANT_ID="xxxx-xxxx-xxxx-xxxx"
export AZURE_SUBSCRIPTION_ID="xxxx-xxxx-xxxx-xxxx"

# API Management Service
export AZURE_APIM_RESOURCE_GROUP="my-resource-group"
export AZURE_APIM_SERVICE_NAME="my-apim-service"

# SSL Configuration (Optional)
export VERIFY_SSL="True"
export CA_BUNDLE_PATH="/etc/ssl/certs/ca-bundle.crt"
export CLIENT_CERT_PATH="/path/to/client-cert.pem"
export CLIENT_KEY_PATH="/path/to/client-key.pem"
```

### Getting Azure Credentials

```bash
# 1. Login to Azure
az login

# 2. Create service principal
az ad sp create-for-rbac --name myAppName --role Contributor

# This returns:
# - appId (AZURE_CLIENT_ID)
# - password (AZURE_CLIENT_SECRET)
# - tenant (AZURE_TENANT_ID)

# 3. Get subscription ID
az account show --query "id"

# 4. Get APIM details
az apim list --resource-group my-rg --query "[].{name:name, resourceGroup:resourceGroup}"
```

### SSL Certificate Paths

#### Windows
```bash
export CA_BUNDLE_PATH="C:\\Users\\%USERNAME%\\AppData\\Local\\mitmproxy\\mitmproxy-ca.pem"
```

#### macOS
```bash
export CA_BUNDLE_PATH="/usr/local/etc/openssl/cert.pem"
```

#### Linux
```bash
export CA_BUNDLE_PATH="/etc/ssl/certs/ca-bundle.crt"
# or
export CA_BUNDLE_PATH="/etc/ssl/certs/ca-certificates.crt"
```

---

## 🔧 Troubleshooting

### Problem: SSL Certificate Error

**Symptom:**
```
SSL: CERTIFICATE_VERIFY_FAILED
```

**Diagnosis:**
```bash
# Test SSL connectivity
curl -v https://management.azure.com

# Check certificate
openssl s_client -connect management.azure.com:443
```

**Solutions:**
```bash
# Solution 1: Disable verification (testing only)
export VERIFY_SSL=False

# Solution 2: Find CA certificate
find /etc -name "ca-bundle.crt" 2>/dev/null

# Solution 3: Export certificate from browser
# 1. Open https://management.azure.com in browser
# 2. Click lock icon → Certificate
# 3. Export to PEM format
# 4. Set CA_BUNDLE_PATH environment variable

# Solution 4: Use mitmproxy certificate
export CA_BUNDLE_PATH="~/.mitmproxy/mitmproxy-ca.pem"
```

### Problem: Authentication Failed

**Symptom:**
```
AuthenticationError: Invalid credentials
```

**Diagnosis:**
```bash
# Verify credentials
az account show
az identity
```

**Solutions:**
```bash
# Verify all environment variables
env | grep AZURE

# Re-authenticate
az logout
az login

# Verify service principal permissions
az role assignment list --assignee $AZURE_CLIENT_ID
```

### Problem: API Creation Failed

**Symptom:**
```
Failed to create API: API already exists
```

**Solutions:**
```bash
# List existing APIs
connector.list_apis()

# Use different API ID
result = connector.create_api_from_openapi(spec, "new-api-id")

# Or update existing
result = connector.update_api("existing-id", spec)
```

### Problem: Invalid OpenAPI Specification

**Symptom:**
```
OpenAPI spec validation failed
```

**Diagnosis:**
```python
# Validate spec
validation = connector.validate_openapi_for_apim(spec)

print(f"Issues: {validation['issues']}")
print(f"Fixed: {len(validation['issues'])} issues")
```

**Solutions:**
```python
# Use validated spec
if not validation['valid']:
    print("Fixing issues...")

fixed_spec = validation['spec']  # Automatically fixed
result = connector.create_api_from_openapi(fixed_spec)
```

---

## 📊 Operation Flow Diagram

```
User Request
     │
     ▼
AzureAPIMConnector.operation()
     │
     ├─ Check is_available
     │  └─ Return error if not initialized
     │
     ├─ Validate input parameters
     │  └─ Return error if invalid
     │
     ├─ Call Azure SDK method
     │  ├─ Send authenticated request
     │  ├─ SSL certificates applied
     │  └─ Handle Azure response
     │
     ├─ Process result
     │  ├─ Extract relevant data
     │  ├─ Format response
     │  └─ Log operation
     │
     └─ Return result
        ├─ Success: operation details
        └─ Error: error message and diagnostics
```

---

## ✨ Key Features Summary

✅ **Production Ready**
- Comprehensive error handling
- SSL certificate support
- Detailed logging

✅ **Secure**
- Service principal authentication
- Certificate validation
- Secure credential storage

✅ **Reliable**
- Automatic OpenAPI validation and fixing
- Graceful error recovery
- Connection testing

✅ **User-Friendly**
- Clear error messages
- Helpful diagnostics
- URL generation for portal access

✅ **Enterprise**
- Support for private networks
- Custom SSL certificates
- Batch operations support