#!/bin/bash

################################################################################
# Azure Migration Script - Environment Variables to Web App & Secrets to Key Vault
# 
# Purpose: Migrate environment variables from .env file to Azure Web App
#          and sensitive secrets to Azure Key Vault
#
# Usage: ./migrate_to_azure.sh --env-file .env --app-name myapp --resource-group myrg --key-vault mykv
#
# Prerequisites:
#   - Azure CLI installed: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli
#   - Logged in: az login
#   - Proper permissions in Azure subscription
################################################################################

set -e

# ============================================================================
# COLOR CODES & OUTPUT FUNCTIONS
# ============================================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
    echo -e "\n${BLUE}╔════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║  $1${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════╝${NC}\n"
}

print_section() {
    echo -e "\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ ${NC}$1"
}

print_success() {
    echo -e "${GREEN}✓ ${NC}$1"
}

print_warning() {
    echo -e "${YELLOW}⚠ ${NC}$1"
}

print_error() {
    echo -e "${RED}✗ ${NC}$1"
}

print_debug() {
    if [[ "$VERBOSE" == "true" ]]; then
        echo -e "${BLUE}→ ${NC}$1"
    fi
}

# ============================================================================
# CONFIGURATION VARIABLES
# ============================================================================

ENV_FILE=".env"
APP_NAME=""
RESOURCE_GROUP=""
KEY_VAULT_NAME=""
DRY_RUN=false
VERBOSE=false
SKIP_CONFIRMATION=false

# Secrets that MUST go to Key Vault (sensitive data - DO NOT log)
SECRETS=(
    "AZURE_CLIENT_SECRET"
    "AZURE_OPENAI_API_KEY"
    "DB_PASSWORD"
    "FLASK_SECRET_KEY"
    "SECRET_KEY"
    "MAIL_PASSWORD"
)

# Variables that should go to Web App (non-sensitive config)
APP_VARIABLES=(
    "AZURE_CLIENT_ID"
    "AZURE_TENANT_ID"
    "AZURE_SUBSCRIPTION_ID"
    "AZURE_APIM_RESOURCE_GROUP"
    "AZURE_APIM_SERVICE_NAME"
    "AZURE_APIM_BASE_URL"
    "AZURE_OPENAI_ENDPOINT"
    "AZURE_OPENAI_DEPLOYMENT"
    "AZURE_OPENAI_VERSION"
    "DATABASE_URL"
    "DB_TYPE"
    "DB_HOST"
    "DB_PORT"
    "DB_NAME"
    "DB_USER"
    "DB_SSLMODE"
    "DB_POOL_SIZE"
    "DB_MAX_OVERFLOW"
    "DB_POOL_TIMEOUT"
    "DB_POOL_RECYCLE"
    "DB_POOL_PRE_PING"
    "FLASK_DEBUG"
    "FLASK_ENV"
    "FLASK_HOST"
    "FLASK_PORT"
    "SESSION_PERMANENT"
    "SESSION_TYPE"
    "PERMANENT_SESSION_LIFETIME"
    "UPLOAD_FOLDER"
    "MAX_CONTENT_LENGTH"
    "ALLOWED_EXTENSIONS"
    "FILE_RETENTION_DAYS"
    "CLEANUP_ENABLED"
    "LOG_LEVEL"
    "LOG_FILE"
    "LOG_MAX_BYTES"
    "LOG_BACKUP_COUNT"
    "LOG_FORMAT"
    "LOG_SQL_QUERIES"
    "LOG_HTTP_REQUESTS"
    "LOG_MIGRATION_DETAILS"
    "CORS_ORIGINS"
    "CORS_ALLOW_CREDENTIALS"
    "RATELIMIT_ENABLED"
    "RATELIMIT_DEFAULT"
    "RATELIMIT_STORAGE_URL"
    "SECURITY_HEADERS_ENABLED"
    "FORCE_HTTPS"
    "CONVERSION_TIMEOUT"
    "MAX_CONCURRENT_MIGRATIONS"
    "RETRY_ATTEMPTS"
    "RETRY_DELAY"
    "PREFER_AI_CONVERSION"
    "FALLBACK_ON_AI_FAILURE"
    "AI_CONVERSION_TIMEOUT"
    "STRICT_VALIDATION"
    "VALIDATE_BEFORE_MIGRATION"
    "SAVE_INVALID_SPECS"
    "HEALTH_CHECK_INTERVAL"
    "CONNECTION_TIMEOUT"
    "HEALTH_CHECK_ENABLED"
    "METRICS_ENABLED"
    "PERFORMANCE_MONITORING"
    "CACHE_TYPE"
    "CACHE_DEFAULT_TIMEOUT"
    "CACHE_REDIS_URL"
    "MAIL_SERVER"
    "MAIL_PORT"
    "MAIL_USE_TLS"
    "MAIL_USERNAME"
    "SEND_COMPLETION_EMAILS"
    "ADMIN_EMAIL"
    "TESTING"
    "MOCK_EXTERNAL_SERVICES"
    "SKIP_AUTH_IN_TESTING"
    "ENABLE_DEBUG_TOOLBAR"
    "PROFILE_REQUESTS"
    "DEVELOPMENT_MODE"
)

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

print_usage() {
    cat << EOF
${BLUE}Azure Migration Script${NC} - Migrate Environment Variables to Azure

${CYAN}USAGE:${NC}
    ./migrate_to_azure.sh [OPTIONS]

${CYAN}OPTIONS:${NC}
    -e, --env-file FILE           Path to .env file (default: .env)
    -a, --app-name NAME           Azure Web App name (required)
    -r, --resource-group GROUP    Azure Resource Group name (required)
    -k, --key-vault NAME          Azure Key Vault name (required)
    -d, --dry-run                 Show what would be done without making changes
    -y, --yes                     Skip confirmation prompts
    -v, --verbose                 Verbose output
    -h, --help                    Show this help message

${CYAN}EXAMPLE:${NC}
    ./migrate_to_azure.sh \\
        --env-file .env \\
        --app-name my-api-app \\
        --resource-group my-resource-group \\
        --key-vault my-key-vault

${CYAN}NOTES:${NC}
    • Secrets are migrated to Azure Key Vault for secure storage
    • Variables are set as Web App application settings
    • Database passwords and API keys are automatically identified as secrets
    • Use --dry-run to preview changes without applying them

EOF
}

parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -e|--env-file)
                ENV_FILE="$2"
                shift 2
                ;;
            -a|--app-name)
                APP_NAME="$2"
                shift 2
                ;;
            -r|--resource-group)
                RESOURCE_GROUP="$2"
                shift 2
                ;;
            -k|--key-vault)
                KEY_VAULT_NAME="$2"
                shift 2
                ;;
            -d|--dry-run)
                DRY_RUN=true
                shift
                ;;
            -y|--yes)
                SKIP_CONFIRMATION=true
                shift
                ;;
            -v|--verbose)
                VERBOSE=true
                shift
                ;;
            -h|--help)
                print_usage
                exit 0
                ;;
            *)
                print_error "Unknown option: $1"
                print_usage
                exit 1
                ;;
        esac
    done
}

validate_requirements() {
    print_section "Validating Requirements"
    
    # Check if .env file exists
    if [[ ! -f "$ENV_FILE" ]]; then
        print_error ".env file not found: $ENV_FILE"
        exit 1
    fi
    print_success ".env file found: $ENV_FILE"
    
    # Check required parameters
    if [[ -z "$APP_NAME" ]]; then
        print_error "Web App name is required (use --app-name)"
        exit 1
    fi
    
    if [[ -z "$RESOURCE_GROUP" ]]; then
        print_error "Resource group is required (use --resource-group)"
        exit 1
    fi
    
    if [[ -z "$KEY_VAULT_NAME" ]]; then
        print_error "Key Vault name is required (use --key-vault)"
        exit 1
    fi
    
    # Check if Azure CLI is installed
    if ! command -v az &> /dev/null; then
        print_error "Azure CLI is not installed"
        print_info "Install from: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    fi
    print_success "Azure CLI is installed"
    
    # Check if logged in to Azure
    if ! az account show &> /dev/null; then
        print_error "Not logged in to Azure"
        print_info "Run: az login"
        exit 1
    fi
    print_success "Logged in to Azure"
    
    # Verify Web App exists
    if ! az webapp show --name "$APP_NAME" --resource-group "$RESOURCE_GROUP" &> /dev/null; then
        print_error "Web App not found: $APP_NAME in resource group: $RESOURCE_GROUP"
        exit 1
    fi
    print_success "Web App found: $APP_NAME"
    
    # Verify Key Vault exists
    if ! az keyvault show --name "$KEY_VAULT_NAME" --resource-group "$RESOURCE_GROUP" &> /dev/null; then
        print_error "Key Vault not found: $KEY_VAULT_NAME in resource group: $RESOURCE_GROUP"
        exit 1
    fi
    print_success "Key Vault found: $KEY_VAULT_NAME"
}

is_secret() {
    local key=$1
    for secret in "${SECRETS[@]}"; do
        if [[ "$key" == "$secret" ]]; then
            return 0
        fi
    done
    return 1
}

read_env_file() {
    print_section "Reading Environment Variables"
    
    declare -gA ENV_VARS
    declare -gA ENV_SECRETS
    
    while IFS='=' read -r key value; do
        # Skip empty lines and comments
        [[ -z "$key" || "$key" == \#* ]] && continue
        
        # Remove leading/trailing whitespace
        key=$(echo "$key" | xargs)
        value=$(echo "$value" | xargs)
        
        # Skip if value is empty
        if [[ -z "$value" ]]; then
            print_debug "Skipping empty variable: $key"
            continue
        fi
        
        if is_secret "$key"; then
            ENV_SECRETS["$key"]="$value"
            print_debug "Secret: $key"
        else
            ENV_VARS["$key"]="$value"
            print_debug "Variable: $key"
        fi
    done < "$ENV_FILE"
    
    print_success "Read ${#ENV_VARS[@]} variables and ${#ENV_SECRETS[@]} secrets"
}

show_migration_summary() {
    print_section "Migration Summary"
    
    echo -e "${CYAN}Variables to migrate to Web App: ${#ENV_VARS[@]}${NC}"
    if [[ "$VERBOSE" == "true" ]]; then
        for key in "${!ENV_VARS[@]}"; do
            echo "  • $key"
        done
    fi
    
    echo -e "\n${CYAN}Secrets to migrate to Key Vault: ${#ENV_SECRETS[@]}${NC}"
    if [[ "$VERBOSE" == "true" ]]; then
        for key in "${!ENV_SECRETS[@]}"; do
            echo "  • $key (***hidden***)"
        done
    fi
    
    echo -e "\n${CYAN}Azure Resources:${NC}"
    echo "  • Web App: $APP_NAME"
    echo "  • Resource Group: $RESOURCE_GROUP"
    echo "  • Key Vault: $KEY_VAULT_NAME"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        echo -e "\n${YELLOW}DRY RUN MODE - No changes will be made${NC}"
    fi
}

confirm_migration() {
    if [[ "$SKIP_CONFIRMATION" == "true" ]]; then
        return 0
    fi
    
    echo -e "\n${YELLOW}Ready to migrate ${#ENV_VARS[@]} variables and ${#ENV_SECRETS[@]} secrets?${NC}"
    read -p "Continue? (yes/no): " -r response
    
    if [[ "$response" != "yes" ]]; then
        print_warning "Migration cancelled"
        exit 0
    fi
}

migrate_secrets_to_keyvault() {
    print_section "Migrating Secrets to Key Vault"
    
    local count=0
    local failed=0
    
    for key in "${!ENV_SECRETS[@]}"; do
        value="${ENV_SECRETS[$key]}"
        
        # Convert key name to Key Vault format (replace underscores with hyphens)
        kv_key=$(echo "$key" | tr '[:upper:]_' '[:lower:]-')
        
        print_info "Migrating secret: $key → $kv_key"
        
        if [[ "$DRY_RUN" == "true" ]]; then
            print_debug "Would set secret: $kv_key in Key Vault: $KEY_VAULT_NAME"
        else
            if az keyvault secret set \
                --vault-name "$KEY_VAULT_NAME" \
                --name "$kv_key" \
                --value "$value" \
                &> /dev/null; then
                print_success "Secret migrated: $kv_key"
                ((count++))
            else
                print_error "Failed to migrate secret: $key"
                ((failed++))
            fi
        fi
    done
    
    if [[ "$DRY_RUN" != "true" ]]; then
        echo -e "\n${CYAN}Summary:${NC} $count secrets migrated, $failed failed"
        if [[ $failed -gt 0 ]]; then
            return 1
        fi
    fi
}

migrate_variables_to_webapp() {
    print_section "Migrating Variables to Web App"
    
    local count=0
    local failed=0
    
    # Build settings string for az webapp config appsettings set command
    local settings=()
    
    for key in "${!ENV_VARS[@]}"; do
        value="${ENV_VARS[$key]}"
        
        print_info "Preparing variable: $key"
        print_debug "Value length: ${#value} characters"
        
        settings+=("$key=$value")
    done
    
    if [[ "$DRY_RUN" == "true" ]]; then
        print_debug "Would set ${#settings[@]} variables on Web App"
        for setting in "${settings[@]}"; do
            echo "  • ${setting%=*}"
        done
    else
        print_info "Setting ${#settings[@]} variables on Web App: $APP_NAME"
        
        if az webapp config appsettings set \
            --name "$APP_NAME" \
            --resource-group "$RESOURCE_GROUP" \
            --settings "${settings[@]}" \
            &> /dev/null; then
            print_success "All variables migrated to Web App"
            count=${#settings[@]}
        else
            print_error "Failed to set variables on Web App"
            failed=${#settings[@]}
        fi
        
        echo -e "\n${CYAN}Summary:${NC} $count variables set, $failed failed"
        if [[ $failed -gt 0 ]]; then
            return 1
        fi
    fi
}

create_keyvault_references() {
    print_section "Creating Key Vault References (Optional)"
    
    print_info "For enhanced security, you can update Web App settings to reference Key Vault secrets"
    print_info "Format: @Microsoft.KeyVault(SecretUri=https://{vault-name}.vault.azure.net/secrets/{secret-name}/)"
    
    echo -e "\n${CYAN}Example command to set Key Vault references:${NC}"
    
    for key in "${!ENV_SECRETS[@]}"; do
        kv_key=$(echo "$key" | tr '[:upper:]_' '[:lower:]-')
        echo "  az webapp config appsettings set \\"
        echo "      --name $APP_NAME \\"
        echo "      --resource-group $RESOURCE_GROUP \\"
        echo "      --settings $key=\"@Microsoft.KeyVault(SecretUri=https://${KEY_VAULT_NAME}.vault.azure.net/secrets/${kv_key}/)\" \\"
    done
    
    print_info "This requires proper managed identity configuration on the Web App"
}

verify_migration() {
    print_section "Verifying Migration"
    
    if [[ "$DRY_RUN" == "true" ]]; then
        print_info "Dry run mode - verification skipped"
        return
    fi
    
    print_info "Verifying Web App settings..."
    local app_settings=$(az webapp config appsettings list \
        --name "$APP_NAME" \
        --resource-group "$RESOURCE_GROUP" | jq length)
    print_success "Web App has $app_settings application settings"
    
    print_info "Verifying Key Vault secrets..."
    local kv_secrets=$(az keyvault secret list \
        --vault-name "$KEY_VAULT_NAME" | jq length)
    print_success "Key Vault has $kv_secrets secrets"
}

generate_migration_report() {
    print_section "Migration Report"
    
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local report_file="migration_report_$(date '+%Y%m%d_%H%M%S').txt"
    
    cat > "$report_file" << EOF
========================================
AZURE MIGRATION REPORT
========================================

Timestamp: $timestamp
Environment File: $ENV_FILE
Web App: $APP_NAME
Resource Group: $RESOURCE_GROUP
Key Vault: $KEY_VAULT_NAME

DRY RUN: $DRY_RUN

------------ VARIABLES MIGRATED -----------
Total Variables: ${#ENV_VARS[@]}

EOF
    
    for key in "${!ENV_VARS[@]}"; do
        echo "  $key" >> "$report_file"
    done
    
    cat >> "$report_file" << EOF

------------ SECRETS MIGRATED -----------
Total Secrets: ${#ENV_SECRETS[@]}

EOF
    
    for key in "${!ENV_SECRETS[@]}"; do
        echo "  $key → $(echo "$key" | tr '[:upper:]_' '[:lower:]-')" >> "$report_file"
    done
    
    cat >> "$report_file" << EOF

------------ CONFIGURATION CHECKLIST -----------
[ ] Verify all variables in Web App Application Settings
[ ] Verify all secrets in Key Vault
[ ] Test application with new configuration
[ ] Update application to reference Key Vault secrets (optional)
[ ] Backup original .env file
[ ] Remove .env file from production (after verification)
[ ] Rotate credentials periodically

========================================
EOF
    
    print_success "Migration report saved: $report_file"
}

show_next_steps() {
    print_section "Next Steps"
    
    cat << EOF
${CYAN}1. Verify Configuration:${NC}
   • Check Web App Settings: 
     az webapp config appsettings list --name $APP_NAME --resource-group $RESOURCE_GROUP
   
   • Check Key Vault Secrets:
     az keyvault secret list --vault-name $KEY_VAULT_NAME

${CYAN}2. Optional - Use Key Vault References:${NC}
   For better security, update settings to reference Key Vault:
   az webapp config appsettings set \\
       --name $APP_NAME \\
       --resource-group $RESOURCE_GROUP \\
       --settings KEY_NAME="@Microsoft.KeyVault(SecretUri=https://${KEY_VAULT_NAME}.vault.azure.net/secrets/secret-name/)"

${CYAN}3. Configure Managed Identity:${NC}
   az webapp identity assign --name $APP_NAME --resource-group $RESOURCE_GROUP

${CYAN}4. Grant Key Vault Access:${NC}
   az keyvault set-policy --name $KEY_VAULT_NAME \\
       --object-id <webapp-managed-identity-id> \\
       --secret-permissions get list

${CYAN}5. Test Application:${NC}
   • Restart Web App to load new settings
   • Test application functionality
   • Monitor application logs

${CYAN}6. Cleanup:${NC}
   • Backup and remove .env file from production
   • Remove .env from version control
   • Update documentation with new configuration process

EOF
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    print_header "Azure Environment Variables Migration"
    
    # Parse arguments
    parse_arguments "$@"
    
    # Validate requirements
    validate_requirements
    
    # Read environment file
    read_env_file
    
    # Show summary
    show_migration_summary
    
    # Confirm migration
    confirm_migration
    
    # Perform migration
    migrate_secrets_to_keyvault || exit 1
    migrate_variables_to_webapp || exit 1
    
    # Verify migration
    verify_migration
    
    # Show Key Vault references option
    create_keyvault_references
    
    # Generate report
    generate_migration_report
    
    # Show next steps
    show_next_steps
    
    if [[ "$DRY_RUN" == "true" ]]; then
        print_warning "DRY RUN COMPLETE - No changes were made to Azure resources"
    else
        print_success "Migration completed successfully!"
    fi
}

# Run main function
main "$@"
