/**
 * Main JavaScript file for API Migration Tool
 * Contains global utilities and common functionality
 */

// Global application object
window.ApiMigrationTool = {
    config: {
        apiBaseUrl: '/api',
        maxFileSize: 16 * 1024 * 1024, // 16MB
        allowedExtensions: ['json', 'yaml', 'yml', 'txt'],
        pollInterval: 2000, // 2 seconds
        maxRetries: 3
    },
    
    // Current state
    state: {
        isLoading: false,
        currentMigration: null,
        notifications: []
    }
};

// Utility Functions
const Utils = {
    /**
     * Format file size in human readable format
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    /**
     * Format duration in seconds to human readable format
     */
    formatDuration(seconds) {
        if (seconds < 60) {
            return `${Math.round(seconds)}s`;
        } else if (seconds < 3600) {
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = Math.round(seconds % 60);
            return `${minutes}m ${remainingSeconds}s`;
        } else {
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            return `${hours}h ${minutes}m`;
        }
    },

    /**
     * Format datetime string
     */
    formatDateTime(dateString, options = {}) {
        if (!dateString) return 'Unknown';
        
        const date = new Date(dateString);
        const defaultOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        
        return date.toLocaleDateString('en-US', { ...defaultOptions, ...options });
    },

    /**
     * Validate file extension
     */
    isValidFileExtension(filename) {
        if (!filename) return false;
        
        const extension = filename.split('.').pop().toLowerCase();
        return ApiMigrationTool.config.allowedExtensions.includes(extension);
    },

    /**
     * Validate file size
     */
    isValidFileSize(fileSize) {
        return fileSize <= ApiMigrationTool.config.maxFileSize;
    },

    /**
     * Generate unique ID
     */
    generateId(prefix = 'id') {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    },

    /**
     * Debounce function
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Deep clone object
     */
    deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    },

    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
};

// API Helper Functions
const API = {
    /**
     * Make HTTP request with error handling
     */
    async request(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
            ...options
        };

        try {
            const response = await fetch(`${ApiMigrationTool.config.apiBaseUrl}${url}`, defaultOptions);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || `HTTP ${response.status}: ${response.statusText}`);
            }

            return data;
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    },

    /**
     * GET request
     */
    async get(url, params = {}) {
        const searchParams = new URLSearchParams(params);
        const queryString = searchParams.toString();
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        
        return this.request(fullUrl);
    },

    /**
     * POST request
     */
    async post(url, data = {}) {
        return this.request(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    },

    /**
     * PUT request
     */
    async put(url, data = {}) {
        return this.request(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },

    /**
     * DELETE request
     */
    async delete(url) {
        return this.request(url, {
            method: 'DELETE'
        });
    },

    /**
     * Upload file
     */
    async uploadFile(file, onProgress = null) {
        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch(`${ApiMigrationTool.config.apiBaseUrl}/upload`, {
                method: 'POST',
                body: formData
            });

            return await response.json();
        } catch (error) {
            console.error('File upload failed:', error);
            throw error;
        }
    }
};

// Loading and Progress Management
const Loading = {
    /**
     * Show global loading overlay
     */
    show(message = 'Loading...') {
        ApiMigrationTool.state.isLoading = true;
        
        let overlay = document.getElementById('loading-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loading-overlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
                <div class="text-center">
                    <div class="spinner-border text-primary mb-3" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div id="loading-message">${message}</div>
                </div>
            `;
            document.body.appendChild(overlay);
        } else {
            overlay.style.display = 'flex';
            document.getElementById('loading-message').textContent = message;
        }
    },

    /**
     * Hide global loading overlay
     */
    hide() {
        ApiMigrationTool.state.isLoading = false;
        
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    },

    /**
     * Update loading message
     */
    updateMessage(message) {
        const messageElement = document.getElementById('loading-message');
        if (messageElement) {
            messageElement.textContent = message;
        }
    }
};

// Progress Bar Management
const Progress = {
    /**
     * Show progress modal
     */
    show(title = 'Processing...', message = 'Please wait...') {
        const modal = document.getElementById('progressModal');
        if (modal) {
            document.getElementById('progress-title').textContent = title;
            document.getElementById('progress-message').innerHTML = `<small class="text-muted">${message}</small>`;
            document.getElementById('progress-bar').style.width = '0%';
            document.getElementById('progress-bar').setAttribute('aria-valuenow', '0');
            
            const progressModal = new bootstrap.Modal(modal, {
                backdrop: 'static',
                keyboard: false
            });
            progressModal.show();
            
            // Store modal instance globally for access
            window.currentProgressModal = progressModal;
        }
    },

    /**
     * Update progress
     */
    update(percentage, message = null) {
        const progressBar = document.getElementById('progress-bar');
        if (progressBar) {
            progressBar.style.width = `${percentage}%`;
            progressBar.setAttribute('aria-valuenow', percentage.toString());
            
            if (percentage >= 100) {
                progressBar.classList.remove('progress-bar-animated');
            } else {
                progressBar.classList.add('progress-bar-animated');
            }
        }
        
        if (message) {
            const messageElement = document.getElementById('progress-message');
            if (messageElement) {
                messageElement.innerHTML = `<small class="text-muted">${message}</small>`;
            }
        }
    },

    /**
     * Hide progress modal
     */
    hide() {
        if (window.currentProgressModal) {
            window.currentProgressModal.hide();
            window.currentProgressModal = null;
        } else {
            const modal = document.getElementById('progressModal');
            if (modal) {
                const progressModal = bootstrap.Modal.getInstance(modal);
                if (progressModal) {
                    progressModal.hide();
                }
            }
        }
    },

    /**
     * Show completion state
     */
    complete(message = 'Process completed successfully!') {
        this.update(100, message);
        
        // Show close button
        const footer = document.querySelector('#progressModal .modal-footer');
        if (footer) {
            footer.classList.remove('d-none');
        }
        
        // Remove animated stripe after a short delay
        setTimeout(() => {
            const progressBar = document.getElementById('progress-bar');
            if (progressBar) {
                progressBar.classList.remove('progress-bar-animated', 'progress-bar-striped');
            }
        }, 1000);
    },

    /**
     * Show error state
     */
    error(message = 'An error occurred during processing.') {
        const progressBar = document.getElementById('progress-bar');
        if (progressBar) {
            progressBar.classList.remove('progress-bar-animated', 'progress-bar-striped');
            progressBar.classList.add('bg-danger');
        }
        
        this.update(100, message);
        
        // Show close button
        const footer = document.querySelector('#progressModal .modal-footer');
        if (footer) {
            footer.classList.remove('d-none');
        }
    }
};

// Notification System
const Notifications = {
    /**
     * Show notification
     */
    show(message, type = 'info', duration = 5000) {
        const notification = {
            id: Utils.generateId('notification'),
            message: message,
            type: type,
            timestamp: new Date()
        };
        
        ApiMigrationTool.state.notifications.push(notification);
        
        // Create notification element
        const notificationElement = this.createElement(notification);
        
        // Add to page
        let container = document.getElementById('notification-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'position-fixed top-0 end-0 p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }
        
        container.appendChild(notificationElement);
        
        // Show with animation
        setTimeout(() => {
            notificationElement.classList.add('show');
        }, 100);
        
        // Auto-hide
        if (duration > 0) {
            setTimeout(() => {
                this.hide(notification.id);
            }, duration);
        }
        
        return notification.id;
    },

    /**
     * Create notification element
     */
    createElement(notification) {
        const div = document.createElement('div');
        div.id = notification.id;
        div.className = `toast align-items-center text-bg-${this.getBootstrapType(notification.type)} border-0`;
        div.setAttribute('role', 'alert');
        div.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="bi bi-${this.getIcon(notification.type)} me-2"></i>
                    ${Utils.escapeHtml(notification.message)}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="Notifications.hide('${notification.id}')"></button>
            </div>
        `;
        
        return div;
    },

    /**
     * Hide notification
     */
    hide(notificationId) {
        const element = document.getElementById(notificationId);
        if (element) {
            element.classList.remove('show');
            setTimeout(() => {
                element.remove();
            }, 300);
        }
        
        // Remove from state
        ApiMigrationTool.state.notifications = ApiMigrationTool.state.notifications.filter(
            n => n.id !== notificationId
        );
    },

    /**
     * Get Bootstrap type for notification
     */
    getBootstrapType(type) {
        const mapping = {
            'success': 'success',
            'error': 'danger',
            'warning': 'warning',
            'info': 'info'
        };
        return mapping[type] || 'info';
    },

    /**
     * Get icon for notification type
     */
    getIcon(type) {
        const mapping = {
            'success': 'check-circle',
            'error': 'exclamation-circle',
            'warning': 'exclamation-triangle',
            'info': 'info-circle'
        };
        return mapping[type] || 'info-circle';
    },

    /**
     * Show success notification
     */
    success(message, duration = 5000) {
        return this.show(message, 'success', duration);
    },

    /**
     * Show error notification
     */
    error(message, duration = 8000) {
        return this.show(message, 'error', duration);
    },

    /**
     * Show warning notification
     */
    warning(message, duration = 6000) {
        return this.show(message, 'warning', duration);
    },

    /**
     * Show info notification
     */
    info(message, duration = 5000) {
        return this.show(message, 'info', duration);
    }
};

// Error Handling
const ErrorHandler = {
    /**
     * Handle and display error
     */
    handle(error, context = '') {
        console.error('Error occurred:', error, 'Context:', context);
        
        let message = 'An unexpected error occurred';
        
        if (error.message) {
            message = error.message;
        } else if (typeof error === 'string') {
            message = error;
        }
        
        // Show error notification
        Notifications.error(message);
        
        // Hide loading states
        Loading.hide();
        Progress.hide();
        
        // Log error for debugging
        this.log(error, context);
    },

    /**
     * Log error for debugging
     */
    log(error, context) {
        const errorInfo = {
            timestamp: new Date().toISOString(),
            error: error.toString(),
            stack: error.stack,
            context: context,
            url: window.location.href,
            userAgent: navigator.userAgent
        };
        
        console.error('Detailed error info:', errorInfo);
        
        // In production, you might want to send this to a logging service
        // API.post('/errors', errorInfo).catch(() => {}); // Silent fail
    }
};

// File Handling
const FileHandler = {
    /**
     * Validate file before upload
     */
    validateFile(file) {
        const errors = [];
        
        if (!file) {
            errors.push('No file selected');
            return { valid: false, errors };
        }
        
        if (!Utils.isValidFileExtension(file.name)) {
            errors.push(`Invalid file type. Allowed types: ${ApiMigrationTool.config.allowedExtensions.join(', ')}`);
        }
        
        if (!Utils.isValidFileSize(file.size)) {
            errors.push(`File too large. Maximum size: ${Utils.formatFileSize(ApiMigrationTool.config.maxFileSize)}`);
        }
        
        return {
            valid: errors.length === 0,
            errors
        };
    },

    /**
     * Read file as text
     */
    readAsText(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => resolve(e.target.result);
            reader.onerror = () => reject(new Error('Failed to read file'));
            
            reader.readAsText(file);
        });
    },

    /**
     * Download content as file
     */
    download(content, filename, mimeType = 'application/json') {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
    }
};

// Theme Management
const Theme = {
    /**
     * Get current theme
     */
    get() {
        return localStorage.getItem('theme') || 'auto';
    },

    /**
     * Set theme
     */
    set(theme) {
        localStorage.setItem('theme', theme);
        this.apply();
    },

    /**
     * Apply current theme
     */
    apply() {
        const theme = this.get();
        const html = document.documentElement;
        
        if (theme === 'dark') {
            html.setAttribute('data-bs-theme', 'dark');
        } else if (theme === 'light') {
            html.setAttribute('data-bs-theme', 'light');
        } else {
            // Auto theme - follow system preference
            html.removeAttribute('data-bs-theme');
        }
    },

    /**
     * Toggle between light and dark themes
     */
    toggle() {
        const current = this.get();
        let newTheme;
        
        if (current === 'light') {
            newTheme = 'dark';
        } else if (current === 'dark') {
            newTheme = 'auto';
        } else {
            newTheme = 'light';
        }
        
        this.set(newTheme);
    }
};

// Migration Status Polling
const MigrationPoller = {
    intervals: new Map(),

    /**
     * Start polling for migration status
     */
    start(migrationId, callback, interval = ApiMigrationTool.config.pollInterval) {
        // Clear existing interval if any
        this.stop(migrationId);

        const poll = async () => {
            try {
                const status = await API.get(`/migrations/${migrationId}`);
                callback(status);

                // Stop polling if migration is complete
                if (status.status === 'completed' || status.status === 'failed') {
                    this.stop(migrationId);
                }
            } catch (error) {
                console.error('Failed to poll migration status:', error);
                callback({ status: 'error', message: error.message });
                this.stop(migrationId);
            }
        };

        const intervalId = setInterval(poll, interval);
        this.intervals.set(migrationId, intervalId);

        // Initial poll
        poll();
    },

    /**
     * Stop polling for migration status
     */
    stop(migrationId) {
        const intervalId = this.intervals.get(migrationId);
        if (intervalId) {
            clearInterval(intervalId);
            this.intervals.delete(migrationId);
        }
    },

    /**
     * Stop all polling
     */
    stopAll() {
        this.intervals.forEach(intervalId => clearInterval(intervalId));
        this.intervals.clear();
    }
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    // Apply theme
    Theme.apply();
    
    // Listen for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        if (Theme.get() === 'auto') {
            Theme.apply();
        }
    });
    
    // Global error handler
    window.addEventListener('error', function(event) {
        ErrorHandler.log(event.error, 'Global error handler');
    });
    
    // Unhandled promise rejection handler
    window.addEventListener('unhandledrejection', function(event) {
        ErrorHandler.log(event.reason, 'Unhandled promise rejection');
    });
    
    // Clean up polling on page unload
    window.addEventListener('beforeunload', function() {
        MigrationPoller.stopAll();
    });
    
    console.log('API Migration Tool initialized');
});

// Global keyboard shortcuts
document.addEventListener('keydown', function(event) {
    // Ctrl/Cmd + K for global search (if implemented)
    if ((event.ctrlKey || event.metaKey) && event.key === 'k') {
        event.preventDefault();
        // Trigger search modal or focus search input
        const searchInput = document.querySelector('input[type="search"], #search-input');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Escape to close modals or cancel operations
    if (event.key === 'Escape') {
        // Close any open notifications
        ApiMigrationTool.state.notifications.forEach(notification => {
            Notifications.hide(notification.id);
        });
    }
});

// Expose utilities globally
window.Utils = Utils;
window.API = API;
window.Loading = Loading;
window.Progress = Progress;
window.Notifications = Notifications;
window.ErrorHandler = ErrorHandler;
window.FileHandler = FileHandler;
window.Theme = Theme;
window.MigrationPoller = MigrationPoller;

// ============================================================================
// WRAPPER FUNCTIONS FOR BACKWARD COMPATIBILITY
// ============================================================================

/**
 * Global wrapper functions to match the function calls in upload.html
 * These functions call the appropriate methods from the Progress object
 */

function showProgress(title, message, percentage = 0) {
    Progress.show(title, message);
    if (percentage > 0) {
        Progress.update(percentage);
    }
}

function hideProgress() {
    Progress.hide();
}

function updateProgress(percentage, message = null) {
    Progress.update(percentage, message);
}

function showProgressDetails(details) {
    const detailsElement = document.getElementById('progress-details');
    if (detailsElement) {
        detailsElement.innerHTML = details;
        detailsElement.classList.remove('d-none');
    }
}

// Export wrapper functions to global scope
window.showProgress = showProgress;
window.hideProgress = hideProgress;
window.updateProgress = updateProgress;
window.showProgressDetails = showProgressDetails;