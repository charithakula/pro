"""
Conversion Blueprint - FINAL CORRECT VERSION
Uses: save_converted_file() from EnhancedFileHandler

✅ OPTIMIZED: Uses lazy loading for services to speed up startup
"""

from flask import Blueprint, request, jsonify
import logging
import json
import yaml
import traceback
from datetime import datetime
from auth import login_required, admin_required, has_permission
from utils import generate_id
from pydantic import BaseModel, Field
from typing import Optional

logger = logging.getLogger(__name__)

conversion_bp = Blueprint('conversion', __name__, url_prefix='/api/convert')

# ✅ LAZY LOADING - Don't initialize at module level
_conversion_service = None
_file_handler = None
_cache = None


def _get_conversion_service():
    """Lazy load conversion service on first use"""
    global _conversion_service
    if _conversion_service is None:
        from services.conversion_service import ConversionService
        _conversion_service = ConversionService()
        logger.info("✅ Conversion blueprint: conversion_service lazy loaded")
    return _conversion_service


def _get_file_handler():
    """Lazy load file handler on first use"""
    global _file_handler
    if _file_handler is None:
        try:
            from utils.enhanced_file_handler_with_azure import EnhancedFileHandler
            _file_handler = EnhancedFileHandler()
            logger.info("✅ Conversion blueprint: file_handler lazy loaded")
        except Exception as e:
            logger.warning(f"Conversion blueprint: file_handler initialization failed: {e}")
            _file_handler = False  # Mark as failed
    return _file_handler if _file_handler is not False else None


def _get_db():
    """Lazy load database module"""
    from models.database import db, MigrationRecord, MigrationLog, APISpecification, now_pst
    return db, MigrationRecord, MigrationLog, APISpecification, now_pst

class ConversionRequestSchema(BaseModel):
    spec_content: str = Field(..., description="OpenAPI specification content")
    source_format: Optional[str] = Field(default='auto', description="Source format (auto, json, yaml)")
    include_debug: Optional[bool] = Field(default=False, description="Include debug information")
    conversion_type: Optional[str] = Field(default='swagger2-to-openapi3', description="Conversion type (swagger2-to-openapi3, swagger2-to-swagger2)")
    fast_mode: Optional[bool] = Field(default=False, description="Use fast programmatic conversion instead of AI")


def set_conversion_cache(cache):
    global _cache
    _cache = cache
    logger.info("✅ Conversion blueprint: cache reference set")


def create_migration_record_safe(migration_record_data):
    try:
        db, MigrationRecord, MigrationLog, APISpecification, now_pst = _get_db()
        migration_record = MigrationRecord(**migration_record_data)
        db.session.add(migration_record)
        db.session.commit()
        logger.info(f"Created migration record: {migration_record.migration_id}")
        return migration_record
    except Exception as e:
        logger.warning(f"Failed to create migration record: {e}")
        db, _, _, _, _ = _get_db()
        db.session.rollback()
        return None


def add_migration_log(migration_id: str, level: str, stage: str, message: str, details: dict = None):
    """Add a migration log entry"""
    try:
        db, MigrationRecord, MigrationLog, APISpecification, now_pst = _get_db()
        log_entry = MigrationLog(
            migration_id=migration_id,
            level=level,
            stage=stage,
            message=message,
            details=details
        )
        db.session.add(log_entry)
        db.session.commit()
        logger.debug(f"Added migration log: [{level}] {stage} - {message}")
        return True
    except Exception as e:
        logger.warning(f"Failed to add migration log: {e}")
        db, _, _, _, _ = _get_db()
        db.session.rollback()
        return False


def update_migration_record_safe(migration_record, **updates):
    try:
        db, MigrationRecord, MigrationLog, APISpecification, now_pst = _get_db()
        for key, value in updates.items():
            if hasattr(migration_record, key):
                setattr(migration_record, key, value)
        migration_record.updated_at = now_pst()
        db.session.commit()
        return True
    except Exception as e:
        logger.warning(f"Failed to update migration record: {e}")
        db, _, _, _, _ = _get_db()
        db.session.rollback()
        return False


def create_api_specification_safe(spec_data: dict, original_spec: dict, converted_spec: dict = None):
    """Create an API Specification record in the database"""
    try:
        db, MigrationRecord, MigrationLog, APISpecification, now_pst = _get_db()

        # Determine which spec to store (prefer converted if available)
        spec_to_store = converted_spec if converted_spec else original_spec

        # Extract metadata from the spec
        info = spec_to_store.get('info', {})

        # Determine format (OpenAPI version)
        if 'openapi' in spec_to_store:
            spec_format = f"openapi-{spec_to_store.get('openapi', '3.0')}"
        elif 'swagger' in spec_to_store:
            spec_format = f"swagger-{spec_to_store.get('swagger', '2.0')}"
        else:
            spec_format = 'unknown'

        # Count paths and operations
        paths = spec_to_store.get('paths', {})
        paths_count = len(paths)
        operations_count = 0
        for path_item in paths.values():
            if isinstance(path_item, dict):
                operations_count += sum(1 for method in path_item.keys()
                                       if method.lower() in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options'])

        # Count definitions/schemas
        if 'definitions' in spec_to_store:
            definitions_count = len(spec_to_store.get('definitions', {}))
        elif 'components' in spec_to_store and 'schemas' in spec_to_store.get('components', {}):
            definitions_count = len(spec_to_store['components']['schemas'])
        else:
            definitions_count = 0

        # Count security schemes
        if 'securityDefinitions' in spec_to_store:
            security_count = len(spec_to_store.get('securityDefinitions', {}))
        elif 'components' in spec_to_store and 'securitySchemes' in spec_to_store.get('components', {}):
            security_count = len(spec_to_store['components']['securitySchemes'])
        else:
            security_count = 0

        api_spec = APISpecification(
            api_id=spec_data.get('api_id', generate_id()),
            name=info.get('title', spec_data.get('name', 'Unknown API')),
            version=info.get('version', spec_data.get('version', '1.0.0')),
            description=info.get('description', ''),
            format=spec_format,
            specification=spec_to_store,
            source_platform=spec_data.get('source_platform', 'file_upload'),
            original_filename=spec_data.get('original_filename'),
            file_size=spec_data.get('file_size'),
            is_valid=spec_data.get('is_valid', True),
            validation_errors=spec_data.get('validation_errors'),
            validation_warnings=spec_data.get('validation_warnings'),
            paths_count=paths_count,
            operations_count=operations_count,
            definitions_count=definitions_count,
            security_schemes_count=security_count
        )

        db.session.add(api_spec)
        db.session.commit()
        logger.info(f"✅ Created API specification: {api_spec.name} (ID: {api_spec.api_id})")
        return api_spec
    except Exception as e:
        logger.warning(f"Failed to create API specification: {e}")
        db, _, _, _, _ = _get_db()
        db.session.rollback()
        return None


def extract_api_info(spec: dict) -> dict:
    try:
        info = spec.get('info', {})
        return {
            'title': info.get('title', 'Unknown API'),
            'version': info.get('version', '1.0.0'),
            'description': info.get('description', ''),
            'format': spec.get('swagger', spec.get('openapi', 'Unknown')),
            'paths_count': len(spec.get('paths', {})),
            'definitions_count': len(spec.get('definitions', spec.get('components', {}).get('schemas', {}))),
            'operations_count': sum(
                len([op for op in path_item.values() if isinstance(op, dict) and op.get('responses')])
                for path_item in spec.get('paths', {}).values()
                if isinstance(path_item, dict)
            )
        }
    except Exception as e:
        logger.warning(f"Failed to extract API info: {e}")
        return {'title': 'Unknown API', 'version': '1.0.0', 'description': '', 'format': 'Unknown',
                'paths_count': 0, 'definitions_count': 0, 'operations_count': 0}


@conversion_bp.route('', methods=['POST'])
@admin_required  # ✅ Only admin users can run conversions
def convert_api():
    """Convert OpenAPI specification (admin only)"""
    migration_record = None
    
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No JSON data provided'}), 400
        
        logger.info("=== CONVERSION REQUEST RECEIVED ===")
        
        try:
            request_data = ConversionRequestSchema(**data)
        except Exception as e:
            return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
        
        migration_id = generate_id()
        logger.info(f"Generated migration ID: {migration_id}")
        
        try:
            spec_content = request_data.spec_content.strip()
            if spec_content.startswith('{'):
                original_spec = json.loads(spec_content)
            else:
                original_spec = yaml.safe_load(spec_content)
            api_info = extract_api_info(original_spec)
            original_file_size = len(spec_content)
        except Exception as e:
            logger.warning(f"Failed to parse spec: {e}")
            api_info = {'title': 'Unknown API', 'version': '1.0.0', 'format': 'unknown'}
            original_spec = {}
            original_file_size = len(request_data.spec_content) if request_data.spec_content else 0

        # Generate original filename based on API title
        api_title_safe = api_info.get('title', 'api').replace(' ', '_').replace('/', '_')[:50]
        original_filename = f"{api_title_safe}.json"

        migration_record_data = {
            'migration_id': migration_id,
            'original_api_id': api_info.get('title', 'unknown').replace(' ', '_'),
            'api_name': api_info.get('title', 'Unknown API'),
            'api_version': api_info.get('version', '1.0.0'),
            'status': 'in_progress',
            'source_platform': 'file_upload',
            'target_platform': 'azure_apim',
            'start_time': datetime.now(),
            'original_filename': original_filename,
            'file_size': original_file_size,
            'conversion_method': 'pending',
            'ai_conversion_used': False,
            'migration_metadata': {
                'original_format': api_info.get('format', 'unknown'),
                'paths_count': api_info.get('paths_count', 0),
                'operations_count': api_info.get('operations_count', 0)
            }
        }
        
        migration_record = create_migration_record_safe(migration_record_data)

        # Log: Migration started
        add_migration_log(
            migration_id=migration_id,
            level='INFO',
            stage='initialization',
            message=f"Starting migration for API: {api_info.get('title', 'Unknown')}",
            details={'api_info': api_info, 'source_format': request_data.source_format}
        )

        conversion_start_time = datetime.now()
        try:
            logger.info("Starting conversion...")

            # Log: Conversion started
            add_migration_log(
                migration_id=migration_id,
                level='INFO',
                stage='conversion',
                message='Starting API specification conversion'
            )
            
            import inspect
            convert_sig = inspect.signature(_get_conversion_service().convert_specification)
            supports_debug = 'include_debug' in convert_sig.parameters
            supports_conversion_type = 'conversion_type' in convert_sig.parameters
            supports_fast_mode = 'fast_mode' in convert_sig.parameters

            # Log fast mode status
            if request_data.fast_mode:
                logger.info("FAST MODE enabled - using programmatic conversion")
            else:
                logger.info("AI MODE - using Azure OpenAI for conversion")

            if supports_debug and supports_conversion_type and supports_fast_mode:
                conversion_result = _get_conversion_service().convert_specification(
                    request_data.spec_content,
                    request_data.source_format,
                    include_debug=request_data.include_debug,
                    conversion_type=request_data.conversion_type,
                    fast_mode=request_data.fast_mode
                )
            elif supports_debug and supports_conversion_type:
                conversion_result = _get_conversion_service().convert_specification(
                    request_data.spec_content,
                    request_data.source_format,
                    include_debug=request_data.include_debug,
                    conversion_type=request_data.conversion_type
                )
            elif supports_debug:
                conversion_result = _get_conversion_service().convert_specification(
                    request_data.spec_content,
                    request_data.source_format,
                    include_debug=request_data.include_debug
                )
            else:
                conversion_result = _get_conversion_service().convert_specification(
                    request_data.spec_content,
                    request_data.source_format
                )
            
            conversion_end_time = datetime.now()
            conversion_time = (conversion_end_time - conversion_start_time).total_seconds()
            
            logger.info(f"Conversion completed with status: {conversion_result.get('status')}")
            
            if migration_record:
                update_data = {}
                if conversion_result.get('status') == 'success':
                    # Get converted filename from result
                    converted_file_path = conversion_result.get('converted_file_path', '')
                    converted_file_obj = conversion_result.get('converted_file', {})

                    # Try to get filename from multiple sources
                    if converted_file_path:
                        converted_filename = converted_file_path.split('/')[-1]
                    elif converted_file_obj.get('filename'):
                        converted_filename = converted_file_obj.get('filename')
                    else:
                        converted_filename = f"converted_{migration_id}.json"

                    # Get file size from conversion result (check converted_file object first)
                    converted_spec = conversion_result.get('converted_spec') or conversion_result.get('specification')
                    file_size = converted_file_obj.get('file_size') or conversion_result.get('file_size')
                    if not file_size and converted_spec:
                        file_size = len(json.dumps(converted_spec))

                    # Get validation results
                    validation = conversion_result.get('validation', {})
                    validation_results = validation if isinstance(validation, dict) else {}

                    update_data.update({
                        'status': 'completed',
                        'end_time': conversion_end_time,
                        'completion_time': conversion_time,
                        'conversion_time': conversion_time,  # Also set conversion_time field
                        'conversion_method': 'ai_powered' if conversion_result.get('ai_conversion_used') else 'programmatic',
                        'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                        'converted_filename': converted_filename,
                        'file_size': file_size,
                        'validation_results': validation_results,  # Store in dedicated column
                        'conversion_notes': f"Conversion completed in {conversion_time:.2f}s",
                        'migration_metadata': {
                            'conversion_time': conversion_time,
                            'ai_used': conversion_result.get('ai_conversion_used', False),
                            'converted_file_path': converted_file_path,
                            'conversion_metadata': conversion_result.get('conversion_metadata', {}),
                            'validation_results': validation_results
                        }
                    })

                    # Log: Conversion successful
                    add_migration_log(
                        migration_id=migration_id,
                        level='INFO',
                        stage='completion',
                        message=f"Migration completed successfully in {conversion_time:.2f}s",
                        details={
                            'conversion_time': conversion_time,
                            'ai_used': conversion_result.get('ai_conversion_used', False),
                            'conversion_method': 'ai_powered' if conversion_result.get('ai_conversion_used') else 'programmatic'
                        }
                    )

                    # Store API Specification in database
                    try:
                        # Get the converted spec from result
                        converted_spec = conversion_result.get('converted_spec') or conversion_result.get('specification')

                        # Get validation results
                        validation = conversion_result.get('validation', {})
                        is_valid = validation.get('valid', True) if isinstance(validation, dict) else True
                        validation_errors = validation.get('errors', []) if isinstance(validation, dict) else []
                        validation_warnings = validation.get('warnings', []) if isinstance(validation, dict) else []

                        spec_data = {
                            'api_id': migration_id,
                            'name': api_info.get('title', 'Unknown API'),
                            'version': api_info.get('version', '1.0.0'),
                            'source_platform': 'file_upload',
                            'original_filename': original_filename,
                            'file_size': file_size,
                            'is_valid': is_valid,
                            'validation_errors': validation_errors if validation_errors else None,
                            'validation_warnings': validation_warnings if validation_warnings else None
                        }

                        api_spec = create_api_specification_safe(spec_data, original_spec, converted_spec)
                        if api_spec:
                            add_migration_log(
                                migration_id=migration_id,
                                level='INFO',
                                stage='storage',
                                message=f"API specification stored in database: {api_spec.name}",
                                details={'api_id': api_spec.api_id, 'format': api_spec.format}
                            )
                    except Exception as spec_error:
                        logger.warning(f"Failed to store API specification: {spec_error}")
                        add_migration_log(
                            migration_id=migration_id,
                            level='WARNING',
                            stage='storage',
                            message=f"Failed to store API specification: {str(spec_error)}"
                        )
                else:
                    update_data.update({
                        'status': 'failed',
                        'end_time': conversion_end_time,
                        'error_message': conversion_result.get('message', 'Conversion failed')
                    })

                    # Log: Conversion failed
                    add_migration_log(
                        migration_id=migration_id,
                        level='ERROR',
                        stage='conversion',
                        message=f"Conversion failed: {conversion_result.get('message', 'Unknown error')}",
                        details={'error': conversion_result.get('message')}
                    )

                if update_migration_record_safe(migration_record, **update_data):
                    logger.info(f"Updated migration record")
            
            if _cache:
                _cache.delete('conversion_preview_cache')
            
            conversion_result['migration_id'] = migration_id
            return jsonify(conversion_result)
            
        except Exception as conversion_error:
            logger.error(f"Conversion failed: {str(conversion_error)}")
            logger.error(traceback.format_exc())

            # Log: Conversion exception
            add_migration_log(
                migration_id=migration_id,
                level='ERROR',
                stage='conversion',
                message=f"Conversion exception: {str(conversion_error)}",
                details={'exception': str(conversion_error), 'traceback': traceback.format_exc()}
            )

            if migration_record:
                update_migration_record_safe(migration_record,
                    status='failed',
                    end_time=datetime.now(),
                    error_message=str(conversion_error)
                )

            return jsonify({
                'status': 'error',
                'message': f'Conversion failed: {str(conversion_error)}',
                'migration_id': migration_id
            }), 500
        
    except Exception as e:
        logger.error(f"Endpoint failed: {e}")
        logger.error(traceback.format_exc())
        
        if migration_record:
            update_migration_record_safe(migration_record, 
                status='failed',
                error_message=str(e)
            )
        
        return jsonify({
            'status': 'error',
            'message': f'Conversion failed: {str(e)}'
        }), 500


@conversion_bp.route('/preview', methods=['POST'])
@login_required
def conversion_preview():
    """Get conversion preview"""
    try:
        data = request.get_json()
        if not data or 'spec_content' not in data:
            return jsonify({'error': 'No specification provided'}), 400
        
        import hashlib
        spec_hash = hashlib.md5(data['spec_content'].encode()).hexdigest()
        cache_key = f'conversion_preview_{spec_hash}'
        
        if _cache:
            cached = _cache.get(cache_key)
            if cached:
                logger.debug(f"Returning cached preview")
                return cached
        
        logger.info("Getting conversion preview")
        preview_result = _get_conversion_service().get_conversion_preview(data['spec_content'])
        
        response = jsonify(preview_result)
        
        if _cache:
            _cache.set(cache_key, response, timeout=120)
        
        return response
        
    except Exception as e:
        logger.error(f"Preview failed: {e}")
        return jsonify({
            'status': 'error',
            'message': f'Preview failed: {str(e)}'
        }), 500