"""
API Diff Blueprint - Multi-Format File Comparison Tool
Compare JSON, YAML, .env, .py, .html files and detect changes
Includes AI-powered analysis with fix suggestions
"""
import json
import yaml
import re
import difflib
import logging
from flask import Blueprint, request, jsonify, render_template
from auth import login_required

logger = logging.getLogger(__name__)

api_diff_bp = Blueprint('api_diff', __name__)

# Supported file types
SUPPORTED_EXTENSIONS = ['.json', '.yaml', '.yml', '.env', '.py', '.html', '.htm', '.css', '.js', '.ts', '.tsx', '.jsx']


@api_diff_bp.route('/')
@login_required
def diff_page():
    """API Diff comparison page"""
    return render_template('api_diff.html')


@api_diff_bp.route('/compare', methods=['POST'])
@login_required
def compare_specs():
    """
    Compare two OpenAPI specifications

    Expects JSON body with:
    - spec1: First specification (object or string)
    - spec2: Second specification (object or string)
    - spec1_name: Optional name for first spec
    - spec2_name: Optional name for second spec
    """
    try:
        from services.api_diff_service import api_diff_service

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        spec1 = data.get('spec1')
        spec2 = data.get('spec2')

        if not spec1 or not spec2:
            return jsonify({
                'success': False,
                'error': 'Both spec1 and spec2 are required'
            }), 400

        # Parse specs if they're strings
        if isinstance(spec1, str):
            spec1 = _parse_spec(spec1)
        if isinstance(spec2, str):
            spec2 = _parse_spec(spec2)

        spec1_name = data.get('spec1_name', 'Original')
        spec2_name = data.get('spec2_name', 'Modified')

        # Perform comparison
        result = api_diff_service.compare_specs(spec1, spec2, spec1_name, spec2_name)

        return jsonify(result)

    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {e}")
        return jsonify({
            'success': False,
            'error': f'Invalid JSON format: {str(e)}'
        }), 400
    except yaml.YAMLError as e:
        logger.error(f"YAML parsing error: {e}")
        return jsonify({
            'success': False,
            'error': f'Invalid YAML format: {str(e)}'
        }), 400
    except Exception as e:
        logger.error(f"Comparison failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@api_diff_bp.route('/compare-files', methods=['POST'])
@login_required
def compare_files():
    """
    Compare two uploaded OpenAPI specification files
    """
    try:
        from services.api_diff_service import api_diff_service

        if 'file1' not in request.files or 'file2' not in request.files:
            return jsonify({
                'success': False,
                'error': 'Both file1 and file2 are required'
            }), 400

        file1 = request.files['file1']
        file2 = request.files['file2']

        # Read and parse files
        content1 = file1.read().decode('utf-8')
        content2 = file2.read().decode('utf-8')

        spec1 = _parse_spec(content1)
        spec2 = _parse_spec(content2)

        spec1_name = file1.filename or 'File 1'
        spec2_name = file2.filename or 'File 2'

        # Perform comparison
        result = api_diff_service.compare_specs(spec1, spec2, spec1_name, spec2_name)

        return jsonify(result)

    except Exception as e:
        logger.error(f"File comparison failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@api_diff_bp.route('/compare-stored', methods=['POST'])
@login_required
def compare_stored_specs():
    """
    Compare two stored API specifications by their IDs
    """
    try:
        from services.api_diff_service import api_diff_service
        from models.database import APISpecification

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        api_id1 = data.get('api_id_1')
        api_id2 = data.get('api_id_2')

        if not api_id1 or not api_id2:
            return jsonify({
                'success': False,
                'error': 'Both api_id_1 and api_id_2 are required'
            }), 400

        # Fetch specifications from database
        spec1_record = APISpecification.get_by_api_id(api_id1)
        spec2_record = APISpecification.get_by_api_id(api_id2)

        if not spec1_record:
            return jsonify({
                'success': False,
                'error': f'Specification not found: {api_id1}'
            }), 404
        if not spec2_record:
            return jsonify({
                'success': False,
                'error': f'Specification not found: {api_id2}'
            }), 404

        spec1 = spec1_record.specification
        spec2 = spec2_record.specification

        # Parse if stored as string
        if isinstance(spec1, str):
            spec1 = json.loads(spec1)
        if isinstance(spec2, str):
            spec2 = json.loads(spec2)

        spec1_name = f"{spec1_record.name} v{spec1_record.version}"
        spec2_name = f"{spec2_record.name} v{spec2_record.version}"

        # Perform comparison
        result = api_diff_service.compare_specs(spec1, spec2, spec1_name, spec2_name)

        return jsonify(result)

    except Exception as e:
        logger.error(f"Stored spec comparison failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@api_diff_bp.route('/compare-environments', methods=['POST'])
@login_required
def compare_environment_deployments():
    """
    Compare API deployments between two environments
    """
    try:
        from services.api_diff_service import api_diff_service
        from models.environment import APIMEnvironment, EnvironmentDeployment

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        api_id = data.get('api_id')
        env1_code = data.get('environment_1')
        env2_code = data.get('environment_2')

        if not all([api_id, env1_code, env2_code]):
            return jsonify({
                'success': False,
                'error': 'api_id, environment_1, and environment_2 are required'
            }), 400

        # Get deployments
        deploy1 = EnvironmentDeployment.get_latest_deployment(api_id, env1_code)
        deploy2 = EnvironmentDeployment.get_latest_deployment(api_id, env2_code)

        if not deploy1:
            return jsonify({
                'success': False,
                'error': f'API {api_id} not found in {env1_code}'
            }), 404
        if not deploy2:
            return jsonify({
                'success': False,
                'error': f'API {api_id} not found in {env2_code}'
            }), 404

        # Check if specs are the same (by hash)
        if deploy1.spec_hash == deploy2.spec_hash:
            return jsonify({
                'success': True,
                'specs_identical': True,
                'message': f'API {api_id} is identical in both environments',
                'deployment_1': deploy1.to_dict(),
                'deployment_2': deploy2.to_dict()
            })

        # TODO: In production, retrieve actual specs from storage or Azure APIM
        # For now, return deployment info with hash comparison
        return jsonify({
            'success': True,
            'specs_identical': False,
            'message': f'API {api_id} differs between environments',
            'deployment_1': deploy1.to_dict(),
            'deployment_2': deploy2.to_dict(),
            'hash_comparison': {
                'env1_hash': deploy1.spec_hash,
                'env2_hash': deploy2.spec_hash
            }
        })

    except Exception as e:
        logger.error(f"Environment comparison failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@api_diff_bp.route('/breaking-changes', methods=['POST'])
@login_required
def get_breaking_changes_only():
    """
    Get only breaking changes between two specs
    """
    try:
        from services.api_diff_service import api_diff_service

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        spec1 = data.get('spec1')
        spec2 = data.get('spec2')

        if not spec1 or not spec2:
            return jsonify({
                'success': False,
                'error': 'Both spec1 and spec2 are required'
            }), 400

        # Parse specs if they're strings
        if isinstance(spec1, str):
            spec1 = _parse_spec(spec1)
        if isinstance(spec2, str):
            spec2 = _parse_spec(spec2)

        # Perform comparison
        result = api_diff_service.compare_specs(spec1, spec2)

        # Return only breaking changes
        return jsonify({
            'success': True,
            'has_breaking_changes': result['statistics']['has_breaking_changes'],
            'breaking_changes_count': result['statistics']['breaking_changes'],
            'breaking_changes': result['breaking_changes_list'],
            'recommendations': result['recommendations'],
            'compatibility': result['summary']['compatibility']
        })

    except Exception as e:
        logger.error(f"Breaking changes check failed: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


def _parse_spec(content: str) -> dict:
    """Parse specification content (JSON or YAML)"""
    content = content.strip()

    # Try JSON first
    if content.startswith('{'):
        return json.loads(content)

    # Try YAML
    return yaml.safe_load(content)


def _parse_env_file(content: str) -> dict:
    """Parse .env file content into dictionary"""
    result = {}
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if '=' in line:
            key, _, value = line.partition('=')
            result[key.strip()] = value.strip()
    return result


def _detect_file_type(filename: str, content: str) -> str:
    """Detect file type from filename or content"""
    filename_lower = filename.lower() if filename else ''

    if filename_lower.endswith('.json'):
        return 'json'
    elif filename_lower.endswith(('.yaml', '.yml')):
        return 'yaml'
    elif filename_lower.endswith('.env') or filename_lower == '.env':
        return 'env'
    elif filename_lower.endswith('.py'):
        return 'python'
    elif filename_lower.endswith(('.html', '.htm')):
        return 'html'
    elif filename_lower.endswith('.css'):
        return 'css'
    elif filename_lower.endswith(('.js', '.jsx')):
        return 'javascript'
    elif filename_lower.endswith(('.ts', '.tsx')):
        return 'typescript'

    # Try to detect from content
    content = content.strip()
    if content.startswith('{') or content.startswith('['):
        return 'json'
    elif content.startswith('<!DOCTYPE') or content.startswith('<html'):
        return 'html'
    elif 'def ' in content or 'import ' in content or 'class ' in content:
        return 'python'

    return 'text'


def _compare_text_files(content1: str, content2: str, file_type: str) -> dict:
    """Compare two text files and return line-by-line diff"""
    lines1 = content1.splitlines(keepends=True)
    lines2 = content2.splitlines(keepends=True)

    differ = difflib.unified_diff(lines1, lines2, lineterm='', fromfile='Original', tofile='Modified')
    diff_lines = list(differ)

    # Count changes
    added = sum(1 for line in diff_lines if line.startswith('+') and not line.startswith('+++'))
    removed = sum(1 for line in diff_lines if line.startswith('-') and not line.startswith('---'))

    changes = []
    line_num = 0
    for line in diff_lines:
        if line.startswith('@@'):
            # Parse line numbers
            match = re.search(r'@@ -(\d+)', line)
            if match:
                line_num = int(match.group(1))
        elif line.startswith('+') and not line.startswith('+++'):
            changes.append({
                'type': 'added',
                'severity': 'non_breaking',
                'category': file_type,
                'path': f'Line {line_num}',
                'description': f'Added: {line[1:].strip()[:80]}...' if len(line) > 80 else f'Added: {line[1:].strip()}'
            })
        elif line.startswith('-') and not line.startswith('---'):
            changes.append({
                'type': 'removed',
                'severity': 'breaking',
                'category': file_type,
                'path': f'Line {line_num}',
                'description': f'Removed: {line[1:].strip()[:80]}...' if len(line) > 80 else f'Removed: {line[1:].strip()}',
                'breaking_reason': 'Content was removed'
            })
            line_num += 1
        else:
            line_num += 1

    return {
        'success': True,
        'file_type': file_type,
        'statistics': {
            'total_changes': added + removed,
            'breaking_changes': removed,
            'non_breaking_changes': added,
            'has_breaking_changes': removed > 0
        },
        'all_changes': changes,
        'diff_text': ''.join(diff_lines),
        'summary': {
            'compatibility': 'INCOMPATIBLE' if removed > 0 else 'COMPATIBLE'
        },
        'recommendations': _generate_file_recommendations(file_type, changes)
    }


def _compare_env_files(content1: str, content2: str) -> dict:
    """Compare two .env files"""
    env1 = _parse_env_file(content1)
    env2 = _parse_env_file(content2)

    changes = []
    all_keys = set(env1.keys()) | set(env2.keys())

    for key in all_keys:
        if key not in env1:
            changes.append({
                'type': 'added',
                'severity': 'non_breaking',
                'category': 'env',
                'path': key,
                'field': key,
                'description': f'New environment variable: {key}',
                'new_value': env2[key][:20] + '...' if len(env2[key]) > 20 else env2[key]
            })
        elif key not in env2:
            changes.append({
                'type': 'removed',
                'severity': 'breaking',
                'category': 'env',
                'path': key,
                'field': key,
                'description': f'Environment variable removed: {key}',
                'breaking_reason': 'Applications depending on this variable will fail'
            })
        elif env1[key] != env2[key]:
            changes.append({
                'type': 'modified',
                'severity': 'non_breaking',
                'category': 'env',
                'path': key,
                'field': key,
                'description': f'Value changed for: {key}',
                'old_value': env1[key][:20] + '...' if len(env1[key]) > 20 else env1[key],
                'new_value': env2[key][:20] + '...' if len(env2[key]) > 20 else env2[key]
            })

    breaking = [c for c in changes if c['severity'] == 'breaking']

    return {
        'success': True,
        'file_type': 'env',
        'statistics': {
            'total_changes': len(changes),
            'breaking_changes': len(breaking),
            'non_breaking_changes': len(changes) - len(breaking),
            'has_breaking_changes': len(breaking) > 0
        },
        'all_changes': changes,
        'summary': {
            'compatibility': 'INCOMPATIBLE' if breaking else 'COMPATIBLE'
        },
        'recommendations': _generate_file_recommendations('env', changes)
    }


def _generate_file_recommendations(file_type: str, changes: list) -> list:
    """Generate recommendations based on file type and changes"""
    recommendations = []
    breaking = [c for c in changes if c.get('severity') == 'breaking']

    if breaking:
        recommendations.append(f"WARNING: {len(breaking)} breaking change(s) detected.")

        if file_type == 'env':
            recommendations.append("Ensure all dependent applications are updated with new environment variables.")
            recommendations.append("Consider using default values in code for removed variables during transition.")
        elif file_type == 'python':
            recommendations.append("Review removed code for dependencies in other modules.")
            recommendations.append("Run tests to ensure no regressions.")
        elif file_type == 'html':
            recommendations.append("Check for broken CSS selectors or JavaScript references.")
            recommendations.append("Test UI in multiple browsers.")
    else:
        recommendations.append("No breaking changes detected.")

    return recommendations


@api_diff_bp.route('/compare-generic', methods=['POST'])
@login_required
def compare_generic_files():
    """
    Compare two generic files (JSON, YAML, .env, .py, .html, etc.)
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        content1 = data.get('content1', '')
        content2 = data.get('content2', '')
        filename1 = data.get('filename1', 'file1.txt')
        filename2 = data.get('filename2', 'file2.txt')

        if not content1 or not content2:
            return jsonify({'success': False, 'error': 'Both content1 and content2 are required'}), 400

        # Detect file type
        file_type = _detect_file_type(filename1, content1)

        # Use appropriate comparison method
        if file_type == 'env':
            result = _compare_env_files(content1, content2)
        elif file_type in ('json', 'yaml'):
            # Use OpenAPI diff service for structured data
            from services.api_diff_service import api_diff_service
            spec1 = _parse_spec(content1) if file_type == 'json' else yaml.safe_load(content1)
            spec2 = _parse_spec(content2) if file_type == 'json' else yaml.safe_load(content2)
            result = api_diff_service.compare_specs(spec1, spec2, filename1, filename2)
            result['file_type'] = file_type
        else:
            # Use text diff for other file types
            result = _compare_text_files(content1, content2, file_type)

        result['spec1_name'] = filename1
        result['spec2_name'] = filename2

        return jsonify(result)

    except Exception as e:
        logger.error(f"Generic file comparison failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@api_diff_bp.route('/analyze-ai', methods=['POST'])
@login_required
def analyze_with_ai():
    """
    Analyze diff results with AI and provide individual file analysis with suggestions
    """
    try:
        from connectors.azure_openai_connector import AzureOpenAIConnector
        openai_connector = AzureOpenAIConnector()

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        content1 = data.get('content1', '')
        content2 = data.get('content2', '')
        filename1 = data.get('filename1', 'Original')
        filename2 = data.get('filename2', 'Modified')
        changes = data.get('changes', [])
        file_type = data.get('file_type', 'text')

        # Build prompt for individual file analysis
        prompt = f"""You are an expert code reviewer. Analyze these two files and compare them.

File Type: {file_type}

=== FILE 1: {filename1} ===
{content1[:3000]}

=== FILE 2: {filename2} ===
{content2[:3000]}

Please provide your analysis in this EXACT JSON format (no markdown, just valid JSON):
{{
    "file1_analysis": {{
        "filename": "{filename1}",
        "summary": "Brief description of this file's purpose and structure",
        "issues": ["List of issues or problems in this file"],
        "suggestions": ["Improvement suggestions for this file"],
        "quality_score": 85
    }},
    "file2_analysis": {{
        "filename": "{filename2}",
        "summary": "Brief description of this file's purpose and structure",
        "issues": ["List of issues or problems in this file"],
        "suggestions": ["Improvement suggestions for this file"],
        "quality_score": 85
    }},
    "comparison": {{
        "key_differences": ["Main differences between the two files"],
        "added_in_file2": ["List of new code/content added in File 2 that is not in File 1"],
        "removed_from_file1": ["List of code/content in File 1 that was removed in File 2"],
        "modified": ["List of things that were changed between the files"]
    }},
    "recommendations": {{
        "immediate_actions": ["Actions to take immediately"],
        "best_practices": ["Best practice recommendations"],
        "code_fixes": ["Specific code fix suggestions"]
    }}
}}

Return ONLY valid JSON, no additional text."""

        # Call Azure OpenAI
        response = openai_connector.generate_completion(
            prompt=prompt,
            max_tokens=3000,
            temperature=0.2
        )

        if response.get('success'):
            analysis_text = response.get('content', '')

            # Try to parse as JSON
            try:
                # Clean up the response - remove markdown code blocks if present
                cleaned = analysis_text.strip()
                if cleaned.startswith('```'):
                    cleaned = cleaned.split('```')[1]
                    if cleaned.startswith('json'):
                        cleaned = cleaned[4:]
                    cleaned = cleaned.strip()

                analysis_data = json.loads(cleaned)
            except json.JSONDecodeError:
                # Fallback: parse as text sections
                analysis_data = _parse_ai_analysis_to_structured(analysis_text, filename1, filename2)

            return jsonify({
                'success': True,
                'analysis': analysis_data,
                'raw_response': analysis_text,
                'model': response.get('model', 'unknown'),
                'tokens_used': response.get('usage', {})
            })
        else:
            return jsonify({
                'success': False,
                'error': response.get('error', 'AI analysis failed')
            }), 500

    except Exception as e:
        logger.error(f"AI analysis failed: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _parse_ai_analysis_to_structured(text: str, filename1: str, filename2: str) -> dict:
    """Parse AI text response into structured format"""
    return {
        "file1_analysis": {
            "filename": filename1,
            "summary": "Analysis extracted from AI response",
            "issues": [],
            "suggestions": [text[:500] if text else "No suggestions available"],
            "quality_score": 75
        },
        "file2_analysis": {
            "filename": filename2,
            "summary": "Analysis extracted from AI response",
            "issues": [],
            "suggestions": [],
            "quality_score": 75
        },
        "comparison": {
            "key_differences": ["See raw analysis for details"],
            "added_in_file2": [],
            "removed_from_file1": [],
            "modified": []
        },
        "recommendations": {
            "immediate_actions": [],
            "best_practices": [],
            "code_fixes": [text] if text else []
        }
    }


def _parse_ai_analysis(text: str) -> dict:
    """Parse AI analysis text into structured sections"""
    sections = {
        'summary': '',
        'risks': [],
        'fixes': [],
        'code_suggestions': []
    }

    current_section = 'summary'
    current_content = []

    for line in text.split('\n'):
        line_lower = line.lower()

        if 'summary' in line_lower and ('**' in line or '#' in line):
            if current_content:
                sections[current_section] = '\n'.join(current_content).strip()
            current_section = 'summary'
            current_content = []
        elif 'risk' in line_lower and ('**' in line or '#' in line):
            if current_content:
                sections[current_section] = '\n'.join(current_content).strip()
            current_section = 'risks'
            current_content = []
        elif ('fix' in line_lower or 'recommend' in line_lower) and ('**' in line or '#' in line):
            if current_content:
                sections[current_section] = '\n'.join(current_content).strip()
            current_section = 'fixes'
            current_content = []
        elif 'code' in line_lower and 'suggestion' in line_lower:
            if current_content:
                sections[current_section] = '\n'.join(current_content).strip()
            current_section = 'code_suggestions'
            current_content = []
        else:
            current_content.append(line)

    # Don't forget the last section
    if current_content:
        sections[current_section] = '\n'.join(current_content).strip()

    # Convert risks and fixes to lists if they're strings
    for key in ['risks', 'fixes', 'code_suggestions']:
        if isinstance(sections[key], str):
            # Split by bullet points or numbered items
            items = re.split(r'\n[-•*]\s*|\n\d+\.\s*', sections[key])
            sections[key] = [item.strip() for item in items if item.strip()]

    return sections
