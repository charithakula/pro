"""
Environments Blueprint - Multi-Environment APIM Support
Manages Dev/Staging/Production environments
"""
import logging
from flask import Blueprint, request, jsonify, render_template
from auth import login_required

logger = logging.getLogger(__name__)

environments_bp = Blueprint('environments', __name__)


def _get_environments_from_config():
    """Get environment configuration from config settings when database is not available"""
    from config import BaseConfig as config

    # Get the currently configured APIM from config
    service_name = getattr(config, 'AZURE_APIM_SERVICE_NAME', None)
    resource_group = getattr(config, 'AZURE_APIM_RESOURCE_GROUP', None)
    subscription_id = getattr(config, 'AZURE_SUBSCRIPTION_ID', None)
    tenant_id = getattr(config, 'AZURE_TENANT_ID', None)
    client_id = getattr(config, 'AZURE_CLIENT_ID', None)

    # Check if APIM is configured
    is_configured = bool(service_name and resource_group and subscription_id)
    has_auth = bool(tenant_id and client_id)

    environments = []

    # If we have a configured APIM, show it as the current environment
    if is_configured:
        environments.append({
            'id': 1,
            'name': f'Current APIM ({service_name})',
            'code': 'current',
            'description': f'Currently configured Azure APIM instance: {service_name}',
            'subscription_id': subscription_id,
            'resource_group': resource_group,
            'service_name': service_name,
            'tenant_id': tenant_id,
            'client_id': client_id,
            'has_client_secret': has_auth,
            'is_active': True,
            'is_default': True,
            'is_production': False,
            'color': '#005841',
            'icon': 'bi-cloud-check',
            'is_configured': True,
            'from_config': True
        })

    # Add placeholder environments for future configuration
    environments.extend([
        {
            'id': 2 if is_configured else 1,
            'name': 'Development',
            'code': 'dev',
            'description': 'Development environment - configure to enable',
            'subscription_id': subscription_id if not is_configured else None,
            'resource_group': resource_group if not is_configured else None,
            'service_name': service_name if not is_configured else None,
            'is_active': True,
            'is_default': not is_configured,
            'is_production': False,
            'color': '#28a745',
            'icon': 'bi-code-square',
            'is_configured': False
        },
        {
            'id': 3 if is_configured else 2,
            'name': 'Staging',
            'code': 'staging',
            'description': 'Staging environment - configure to enable',
            'is_active': True,
            'is_default': False,
            'is_production': False,
            'color': '#ffc107',
            'icon': 'bi-box-seam',
            'is_configured': False
        },
        {
            'id': 4 if is_configured else 3,
            'name': 'Production',
            'code': 'prod',
            'description': 'Production environment - configure to enable',
            'is_active': True,
            'is_default': False,
            'is_production': True,
            'color': '#dc3545',
            'icon': 'bi-globe',
            'is_configured': False
        }
    ])

    return jsonify({
        'success': True,
        'environments': environments,
        'count': len(environments),
        'database_fallback': True,
        'current_apim_configured': is_configured,
        'current_apim': {
            'service_name': service_name,
            'resource_group': resource_group,
            'subscription_id': subscription_id[:8] + '...' if subscription_id else None
        } if is_configured else None
    })


@environments_bp.route('/')
@login_required
def environments_page():
    """Environments management page"""
    return render_template('environments.html')


@environments_bp.route('/api/list', methods=['GET'])
@login_required
def list_environments():
    """Get all environments"""
    try:
        from models.environment import APIMEnvironment

        environments = APIMEnvironment.get_active_environments()
        return jsonify({
            'success': True,
            'environments': [env.to_dict() for env in environments],
            'count': len(environments)
        })
    except Exception as e:
        logger.error(f"Failed to list environments: {e}")
        # Return environments from config if database not ready
        return _get_environments_from_config()


@environments_bp.route('/api/<int:env_id>', methods=['GET'])
@login_required
def get_environment(env_id):
    """Get specific environment details"""
    try:
        from models.environment import APIMEnvironment

        env = APIMEnvironment.query.get(env_id)
        if not env:
            return jsonify({'success': False, 'error': 'Environment not found'}), 404

        return jsonify({
            'success': True,
            'environment': env.to_dict()
        })
    except Exception as e:
        logger.error(f"Failed to get environment: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/create', methods=['POST'])
@login_required
def create_environment():
    """Create new environment"""
    try:
        from models.environment import APIMEnvironment
        from models.database import db

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        required_fields = ['name', 'code', 'subscription_id', 'resource_group', 'service_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'Missing required field: {field}'}), 400

        # Check for duplicate code
        existing = APIMEnvironment.query.filter_by(code=data['code'].lower()).first()
        if existing:
            return jsonify({'success': False, 'error': f'Environment code already exists: {data["code"]}'}), 400

        env = APIMEnvironment(
            name=data['name'],
            code=data['code'].lower(),
            description=data.get('description', ''),
            subscription_id=data['subscription_id'],
            resource_group=data['resource_group'],
            service_name=data['service_name'],
            tenant_id=data.get('tenant_id'),
            client_id=data.get('client_id'),
            client_secret=data.get('client_secret'),
            gateway_url=data.get('gateway_url'),
            management_url=data.get('management_url'),
            developer_portal_url=data.get('developer_portal_url'),
            is_active=data.get('is_active', True),
            is_default=data.get('is_default', False),
            is_production=data.get('is_production', False),
            color=data.get('color', '#6c757d'),
            icon=data.get('icon', 'bi-server'),
            requires_approval=data.get('requires_approval', False),
            display_order=data.get('display_order', 99)
        )

        db.session.add(env)
        db.session.commit()

        logger.info(f"Created environment: {env.name} ({env.code})")
        return jsonify({
            'success': True,
            'environment': env.to_dict(),
            'message': f'Environment "{env.name}" created successfully'
        })
    except Exception as e:
        logger.error(f"Failed to create environment: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/<int:env_id>', methods=['PUT'])
@login_required
def update_environment(env_id):
    """Update environment configuration"""
    try:
        from models.environment import APIMEnvironment
        from models.database import db

        env = APIMEnvironment.query.get(env_id)
        if not env:
            return jsonify({'success': False, 'error': 'Environment not found'}), 404

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        # Update fields
        updatable_fields = [
            'name', 'description', 'subscription_id', 'resource_group', 'service_name',
            'tenant_id', 'client_id', 'client_secret', 'gateway_url', 'management_url',
            'developer_portal_url', 'is_active', 'is_default', 'is_production', 'color',
            'icon', 'requires_approval', 'display_order', 'default_product_id'
        ]

        for field in updatable_fields:
            if field in data:
                setattr(env, field, data[field])

        # If setting as default, unset others
        if data.get('is_default'):
            APIMEnvironment.query.filter(APIMEnvironment.id != env_id).update({'is_default': False})

        db.session.commit()

        logger.info(f"Updated environment: {env.name} ({env.code})")
        return jsonify({
            'success': True,
            'environment': env.to_dict(),
            'message': f'Environment "{env.name}" updated successfully'
        })
    except Exception as e:
        logger.error(f"Failed to update environment: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/<int:env_id>', methods=['DELETE'])
@login_required
def delete_environment(env_id):
    """Delete environment (soft delete - sets inactive)"""
    try:
        from models.environment import APIMEnvironment
        from models.database import db

        env = APIMEnvironment.query.get(env_id)
        if not env:
            return jsonify({'success': False, 'error': 'Environment not found'}), 404

        if env.is_production:
            return jsonify({
                'success': False,
                'error': 'Cannot delete production environment. Deactivate it instead.'
            }), 400

        env.is_active = False
        db.session.commit()

        logger.info(f"Deactivated environment: {env.name} ({env.code})")
        return jsonify({
            'success': True,
            'message': f'Environment "{env.name}" deactivated'
        })
    except Exception as e:
        logger.error(f"Failed to delete environment: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/<int:env_id>/test', methods=['POST'])
@login_required
def test_environment_connection(env_id):
    """Test connection to environment's Azure APIM"""
    try:
        # Check if this is a request to test the current config (env_id=1)
        # This is the config-based environment from _get_environments_from_config()
        if env_id == 1:
            from connectors import AzureAPIMConnector
            from config import BaseConfig as app_config

            service_name = getattr(app_config, 'AZURE_APIM_SERVICE_NAME', None)
            if service_name:
                try:
                    connector = AzureAPIMConnector()
                    test_result = connector.test_connection()

                    # Check for success (connector returns 'status' not 'success')
                    is_success = test_result.get('success') or test_result.get('status') == 'success'

                    if is_success:
                        return jsonify({
                            'success': True,
                            'message': f'Connection to "{service_name}" successful',
                            'environment': 'current',
                            'service_name': test_result.get('service_name', service_name),
                            'apis_found': test_result.get('api_count', 0)
                        })
                    else:
                        error_msg = test_result.get('error') or test_result.get('message', 'Connection test failed')
                        return jsonify({
                            'success': False,
                            'error': error_msg,
                            'message': f'Connection test failed: {error_msg}'
                        }), 500
                except Exception as conn_error:
                    logger.error(f"Config-based connection test failed: {conn_error}")
                    return jsonify({
                        'success': False,
                        'error': str(conn_error),
                        'message': f'Connection test failed: {str(conn_error)}'
                    }), 500
            else:
                return jsonify({
                    'success': False,
                    'error': 'No APIM service configured',
                    'message': 'AZURE_APIM_SERVICE_NAME not set in configuration'
                }), 400

        # For env_id > 1, try database-based environment
        try:
            from models.environment import APIMEnvironment
            from connectors import AzureAPIMConnector

            env = APIMEnvironment.query.get(env_id)
            if not env:
                return jsonify({'success': False, 'error': 'Environment not found'}), 404

            # Test basic connectivity using the default connector
            connector = AzureAPIMConnector()
            test_result = connector.test_connection()

            is_success = test_result.get('success') or test_result.get('status') == 'success'

            if is_success:
                return jsonify({
                    'success': True,
                    'message': f'Connection test for "{env.name}" passed',
                    'environment': env.code,
                    'service_name': env.service_name or test_result.get('service_name'),
                    'apis_found': test_result.get('api_count', 0)
                })
            else:
                return jsonify({
                    'success': False,
                    'error': test_result.get('error', 'Connection failed'),
                    'message': f'Connection test failed'
                }), 500
        except Exception as db_error:
            # Database not available - this is expected if table doesn't exist
            logger.warning(f"Database environment lookup failed: {db_error}")
            return jsonify({
                'success': False,
                'error': 'Environment not found in database',
                'message': 'Database table may not exist. Use the config-based environment.'
            }), 404

    except Exception as e:
        logger.error(f"Failed to test environment connection: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'message': f'Connection test failed: {str(e)}'
        }), 500


@environments_bp.route('/api/<string:env_code>/deploy', methods=['POST'])
@login_required
def deploy_to_environment(env_code):
    """Deploy API to specific environment"""
    try:
        from models.environment import APIMEnvironment, EnvironmentDeployment
        from models.database import db
        import hashlib
        import json

        env = APIMEnvironment.get_by_code(env_code)
        if not env:
            return jsonify({'success': False, 'error': f'Environment not found: {env_code}'}), 404

        if not env.is_active:
            return jsonify({'success': False, 'error': 'Environment is not active'}), 400

        data = request.get_json()
        if not data or 'converted_spec' not in data:
            return jsonify({'success': False, 'error': 'No spec provided'}), 400

        spec = data['converted_spec']
        api_id = data.get('api_id', 'unknown-api')

        # Check if production and requires approval
        if env.is_production and env.requires_approval:
            # In a real implementation, this would create an approval request
            logger.warning(f"Production deployment requires approval: {api_id}")

        # Calculate spec hash
        spec_hash = hashlib.sha256(json.dumps(spec, sort_keys=True).encode()).hexdigest()

        # TODO: Implement actual deployment using environment-specific connector
        # For now, record the deployment intent

        deployment = EnvironmentDeployment(
            environment_id=env.id,
            environment_code=env.code,
            api_id=api_id,
            api_name=spec.get('info', {}).get('title', 'Unknown API'),
            api_version=spec.get('info', {}).get('version', '1.0.0'),
            status='deployed',
            deployment_method='direct',
            spec_hash=spec_hash,
            spec_version=spec.get('info', {}).get('version')
        )

        db.session.add(deployment)
        db.session.commit()

        logger.info(f"Deployed {api_id} to {env.name}")
        return jsonify({
            'success': True,
            'message': f'API deployed to {env.name}',
            'deployment': deployment.to_dict(),
            'environment': env.to_dict()
        })
    except Exception as e:
        logger.error(f"Failed to deploy to environment: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/promote', methods=['POST'])
@login_required
def promote_api():
    """Promote API from one environment to another"""
    try:
        from models.environment import APIMEnvironment, EnvironmentDeployment
        from models.database import db, now_pst

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        source_env_code = data.get('source_environment')
        target_env_code = data.get('target_environment')
        api_id = data.get('api_id')

        if not all([source_env_code, target_env_code, api_id]):
            return jsonify({
                'success': False,
                'error': 'Missing required fields: source_environment, target_environment, api_id'
            }), 400

        # Get environments
        source_env = APIMEnvironment.get_by_code(source_env_code)
        target_env = APIMEnvironment.get_by_code(target_env_code)

        if not source_env:
            return jsonify({'success': False, 'error': f'Source environment not found: {source_env_code}'}), 404
        if not target_env:
            return jsonify({'success': False, 'error': f'Target environment not found: {target_env_code}'}), 404

        # Get latest deployment from source
        source_deployment = EnvironmentDeployment.get_latest_deployment(api_id, source_env_code)
        if not source_deployment:
            return jsonify({
                'success': False,
                'error': f'API {api_id} not found in {source_env.name}'
            }), 404

        # Check target approval requirement
        if target_env.requires_approval and target_env.is_production:
            logger.warning(f"Promotion to {target_env.name} requires approval")
            # In production, create approval workflow

        # Create new deployment record in target environment
        new_deployment = EnvironmentDeployment(
            environment_id=target_env.id,
            environment_code=target_env.code,
            api_id=api_id,
            api_name=source_deployment.api_name,
            api_version=source_deployment.api_version,
            status='deployed',
            deployment_method='promoted',
            promoted_from_environment_id=source_env.id,
            promoted_from_environment_code=source_env.code,
            promotion_timestamp=now_pst(),
            spec_hash=source_deployment.spec_hash,
            spec_version=source_deployment.spec_version,
            deployment_notes=f'Promoted from {source_env.name}'
        )

        db.session.add(new_deployment)
        db.session.commit()

        logger.info(f"Promoted {api_id} from {source_env.name} to {target_env.name}")
        return jsonify({
            'success': True,
            'message': f'API promoted from {source_env.name} to {target_env.name}',
            'deployment': new_deployment.to_dict(),
            'source_environment': source_env.to_dict(),
            'target_environment': target_env.to_dict()
        })
    except Exception as e:
        logger.error(f"Failed to promote API: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@environments_bp.route('/api/deployments/<string:api_id>', methods=['GET'])
@login_required
def get_api_deployments(api_id):
    """Get all deployments for a specific API across environments"""
    try:
        from models.environment import EnvironmentDeployment

        deployments = EnvironmentDeployment.get_api_deployments(api_id)
        return jsonify({
            'success': True,
            'api_id': api_id,
            'deployments': [d.to_dict() for d in deployments],
            'count': len(deployments)
        })
    except Exception as e:
        logger.error(f"Failed to get API deployments: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
