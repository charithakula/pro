"""
Chat Blueprint - All chat-related routes
File: blueprints/chat.py

Routes:
- POST /api/chat/universal - Main chat endpoint (NOT cached, real-time conversation)
- GET/DELETE /api/chat/conversations/<id> - Conversation management (NOT cached, user-specific)
- GET /api/chat/conversations - List conversations - CACHED 30 seconds
- GET /api/chat/assistants - Get available assistants - CACHED 300 seconds
- GET /api/chat/conversations/<id>/suggestions - Get suggestions (NOT cached, dynamic)
"""

from flask import Blueprint, request, jsonify, current_app
from datetime import datetime
from functools import wraps
import logging
from werkzeug.utils import secure_filename

# Import services
from services.chat_service import ChatService
from auth import login_required, admin_required

# Import helpers (will create in next file)
try:
    from utils.chat_helpers import (
        process_chat_file,
        detect_file_purpose,
        format_file_size_local
    )
except ImportError:
    # Fallback if helpers not available
    process_chat_file = None

try:
    from enhanced_prompts import ASSISTANT_TYPES
except ImportError:
    ASSISTANT_TYPES = {
        'code': {'description': 'Code Generation'},
        'code_review': {'description': 'Code Review'},
        'api_design': {'description': 'API Design'},
        'policy': {'description': 'Policy Analysis'},
        'documentation': {'description': 'Documentation'},
        'general': {'description': 'General Assistant'}
    }


logger = logging.getLogger(__name__)

# Create blueprint
chat_bp = Blueprint('chat', __name__, url_prefix='/api/chat')

# Initialize chat service (will be created on first use)
_chat_service = None
_cache = None  # ✅ NEW: Global cache reference


def get_chat_service():
    """Lazy load chat service"""
    global _chat_service
    if _chat_service is None:
        _chat_service = ChatService()
        logger.info("✅ ChatService initialized")
    return _chat_service


def set_chat_cache(cache):
    """Set cache reference for chat routes"""
    global _cache
    _cache = cache
    logger.info("✅ Chat blueprint: cache reference set")


# ==========================================
# MAIN CHAT ROUTE
# ==========================================

@chat_bp.route('/universal', methods=['POST'])
@login_required
def universal_chat():
    """
    Universal chat endpoint
    ❌ NOT CACHED (real-time conversation)
    
    Handles:
    - Text messages
    - File uploads
    - Multiple assistant types
    - Conversation tracking
    
    Request:
    {
        'message': str,
        'conversation_id': str (optional),
        'assistant_type': str (optional),
        'file': FileStorage (optional)
    }
    
    Response:
    {
        'success': bool,
        'response': str,
        'assistant_type': str,
        'confidence': float,
        'conversation_id': str,
        'metadata': dict,
        'suggestions': list
    }
    """
    
    try:
        logger.info("=" * 70)
        logger.info("🤖 UNIVERSAL CHAT REQUEST")
        logger.info("=" * 70)
        
        # Extract request data
        message = request.form.get('message', '').strip()
        conversation_id = request.form.get('conversation_id', f'conv_{datetime.now().timestamp()}')
        assistant_type_override = request.form.get('assistant_type', None)
        file = request.files.get('file') if 'file' in request.files else None
        
        logger.info(f"📝 Message: {message[:100] if message else 'NONE'}...")
        logger.info(f"📎 File: {file.filename if file else 'NONE'}")
        
        # ==========================================
        # PROCESS FILE IF PROVIDED
        # ==========================================
        
        file_info = None
        file_content = None
        
        if file:
            logger.info(f"📁 Processing file: {file.filename}")
            
            if process_chat_file:
                file_info = process_chat_file(file, conversation_id)
                
                if not file_info.get('success'):
                    return jsonify({
                        'success': False,
                        'error': file_info.get('error', 'File processing failed')
                    }), 400
                
                file_content = file_info.get('content')
                logger.info(f"✅ File processed: {len(file_content) if file_content else 0} chars")
            else:
                logger.warning("Chat file helpers not available")
        
        # ==========================================
        # PROCESS MESSAGE WITH CHAT SERVICE
        # ==========================================
        
        chat_service = get_chat_service()
        
        response_result = chat_service.process_message(
            user_message=message,
            file_content=file_content,
            file_info=file_info,
            assistant_type_override=assistant_type_override,
            conversation_id=conversation_id
        )
        
        if not response_result.get('success'):
            logger.error(f"Chat processing failed: {response_result.get('error')}")
            return jsonify({
                'success': False,
                'error': response_result.get('error', 'Chat processing failed')
            }), 500
        
        # ==========================================
        # RETURN VALIDATED RESPONSE
        # ==========================================
        
        response_text = str(response_result.get('response', '')).strip()
        
        if not response_text:
            response_text = "I apologize, but I couldn't generate a response. Please try again."
        
        logger.info("=" * 70)
        
        return jsonify({
            'success': True,
            'response': response_text,
            'conversation_id': conversation_id,
            'assistant_type': response_result.get('assistant_type', 'general'),
            'assistant_name': ASSISTANT_TYPES.get(
                response_result.get('assistant_type', 'general'),
                {}
            ).get('description', 'General Assistant'),
            'confidence': response_result.get('confidence', 0.5),
            'file_info': file_info,
            'metadata': response_result.get('metadata', {}),
            'suggestions': response_result.get('suggestions', []),
            'tokens_used': response_result.get('tokens_used', 0)
        }), 200
    
    except Exception as e:
        logger.error(f"❌ Chat error: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': f'Chat error: {str(e)[:100]}'
        }), 500


# ==========================================
# CONVERSATION MANAGEMENT ROUTES
# ==========================================

@chat_bp.route('/conversations', methods=['GET'])
@login_required
def list_conversations():
    """List all conversations for current user
    ✅ CACHED for 30 seconds
    """
    try:
        # ✅ NEW: Check cache first
        cache_key = 'chat_conversations_list'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug("list_conversations: returning cached result")
                return cached_result
        
        # In-memory storage (can replace with database)
        conversations = get_chat_service().conversation_cache
        
        conv_list = [
            {
                'id': conv_id,
                'message_count': len(conv.get('messages', [])),
                'created_at': conv.get('created_at'),
                'updated_at': conv.get('updated_at'),
                'assistant_types': list(set(conv.get('assistant_types_used', [])))
            }
            for conv_id, conv in conversations.items()
        ]
        
        # Sort by updated_at descending
        conv_list.sort(
            key=lambda x: x['updated_at'],
            reverse=True
        )
        
        response = jsonify({
            'success': True,
            'conversations': conv_list,
            'total': len(conv_list)
        }), 200
        
        # ✅ NEW: Cache successful response for 30 seconds
        if _cache:
            _cache.set(cache_key, response, timeout=30)
            logger.debug("list_conversations: cached for 30 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to list conversations: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@chat_bp.route('/conversations/<conversation_id>', methods=['GET'])
@login_required
def get_conversation(conversation_id):
    """Get specific conversation with full history
    ❌ NOT CACHED (user-specific, dynamic content)
    """
    try:
        conversations = get_chat_service().conversation_cache
        
        if conversation_id not in conversations:
            return jsonify({
                'success': False,
                'error': 'Conversation not found'
            }), 404
        
        conv = conversations[conversation_id]
        
        return jsonify({
            'success': True,
            'conversation': {
                'id': conversation_id,
                'messages': conv.get('messages', []),
                'created_at': conv.get('created_at'),
                'updated_at': conv.get('updated_at'),
                'assistant_types_used': conv.get('assistant_types_used', []),
                'files': conv.get('files', [])
            }
        }), 200
    
    except Exception as e:
        logger.error(f"Failed to get conversation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@chat_bp.route('/conversations/<conversation_id>', methods=['DELETE'])
@admin_required  # ✅ Only admin users can delete conversations
def delete_conversation(conversation_id):
    """Delete a conversation (admin only)
    ❌ NOT CACHED (mutates data, invalidates cache)
    """
    try:
        conversations = get_chat_service().conversation_cache
        
        if conversation_id in conversations:
            del conversations[conversation_id]
            logger.info(f"Deleted conversation: {conversation_id}")
            
            # ✅ NEW: Invalidate conversation list cache
            if _cache:
                _cache.delete('chat_conversations_list')
                logger.debug("delete_conversation: cleared conversations cache")
            
            return jsonify({
                'success': True,
                'message': 'Conversation deleted'
            }), 200
        
        return jsonify({
            'success': False,
            'error': 'Conversation not found'
        }), 404
    
    except Exception as e:
        logger.error(f"Failed to delete conversation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@chat_bp.route('/conversations/<conversation_id>/archive', methods=['POST'])
@login_required
def archive_conversation(conversation_id):
    """Archive a conversation
    ❌ NOT CACHED (mutates data, invalidates cache)
    """
    try:
        conversations = get_chat_service().conversation_cache
        
        if conversation_id not in conversations:
            return jsonify({
                'success': False,
                'error': 'Conversation not found'
            }), 404
        
        conv = conversations[conversation_id]
        conv['archived'] = True
        conv['archived_at'] = datetime.now().isoformat()
        
        logger.info(f"Archived conversation: {conversation_id}")
        
        # ✅ NEW: Invalidate conversation list cache
        if _cache:
            _cache.delete('chat_conversations_list')
            logger.debug("archive_conversation: cleared conversations cache")
        
        return jsonify({
            'success': True,
            'message': 'Conversation archived'
        }), 200
    
    except Exception as e:
        logger.error(f"Failed to archive conversation: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# ASSISTANTS INFO ROUTE
# ==========================================

@chat_bp.route('/assistants', methods=['GET'])
def get_assistants():
    """Get list of available assistants
    ✅ CACHED for 300 seconds (assistants rarely change)
    """
    try:
        # ✅ NEW: Check cache first
        cache_key = 'chat_assistants_list'
        if _cache:
            cached_result = _cache.get(cache_key)
            if cached_result:
                logger.debug("get_assistants: returning cached result")
                return cached_result
        
        assistants = [
            {
                'id': name,
                'name': config.get('description', name),
                'description': config.get('description', ''),
                'temperature': config.get('temperature', 0.7),
                'keywords': config.get('keywords', [])[:5]
            }
            for name, config in ASSISTANT_TYPES.items()
        ]
        
        response = jsonify({
            'success': True,
            'assistants': assistants,
            'total': len(assistants)
        }), 200
        
        # ✅ NEW: Cache successful response for 300 seconds (5 minutes)
        if _cache:
            _cache.set(cache_key, response, timeout=300)
            logger.debug("get_assistants: cached for 300 seconds")
        
        return response
    
    except Exception as e:
        logger.error(f"Failed to get assistants: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# CONVERSATION SUGGESTIONS ROUTE
# ==========================================

@chat_bp.route('/conversations/<conversation_id>/suggestions', methods=['GET'])
@login_required
def get_conversation_suggestions(conversation_id):
    """Get suggested follow-up messages for a conversation
    ❌ NOT CACHED (dynamic, conversation-specific)
    """
    try:
        conversations = get_chat_service().conversation_cache
        
        if conversation_id not in conversations:
            return jsonify({
                'success': False,
                'error': 'Conversation not found'
            }), 404
        
        conv = conversations[conversation_id]
        messages = conv.get('messages', [])
        
        if not messages:
            return jsonify({
                'success': True,
                'suggestions': []
            }), 200
        
        # Get last assistant message
        last_assistant_msg = None
        for msg in reversed(messages):
            if msg.get('sender') == 'assistant':
                last_assistant_msg = msg
                break
        
        if not last_assistant_msg:
            return jsonify({
                'success': True,
                'suggestions': []
            }), 200
        
        suggestions = last_assistant_msg.get('suggestions', [])
        
        return jsonify({
            'success': True,
            'suggestions': suggestions
        }), 200
    
    except Exception as e:
        logger.error(f"Failed to get suggestions: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==========================================
# DEBUG ROUTES
# ==========================================

@chat_bp.route('/debug/last-response', methods=['GET'])
@login_required
def get_last_response_debug():
    """Debug endpoint for last OpenAI response
    ❌ NOT CACHED (debug/diagnostic info)
    """
    try:
        chat_service = get_chat_service()
        connector = chat_service.openai_connector
        debug_info = connector.get_debug_info()
        
        return jsonify({
            'success': True,
            'debug_info': debug_info
        }), 200
    
    except Exception as e:
        logger.error(f"Failed to get debug info: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500