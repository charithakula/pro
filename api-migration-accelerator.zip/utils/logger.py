"""
Logger Configuration for API Migration Tool
Handles UTF-8 encoding for Windows compatibility
"""
import os
import sys
import logging
from typing import Optional
from datetime import datetime


def setup_logger(name: str, log_file: Optional[str] = None, level=logging.INFO):
    """
    Setup logger with proper UTF-8 encoding for Windows compatibility
    
    Args:
        name: Logger name
        log_file: Optional log file path
        level: Logging level (default: INFO)
    
    Returns:
        Logger instance
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Prevent duplicate handlers
    if logger.handlers:
        return logger
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler with UTF-8 encoding
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    
    # Force UTF-8 encoding for Windows compatibility
    if sys.platform == 'win32':
        try:
            # Python 3.7+ has reconfigure method
            if hasattr(sys.stdout, 'reconfigure'):
                sys.stdout.reconfigure(encoding='utf-8')
                sys.stderr.reconfigure(encoding='utf-8')
        except Exception as e:
            # Fallback if reconfigure fails
            logger.warning(f"Could not reconfigure stdout encoding: {e}")
    
    logger.addHandler(console_handler)
    
    # File handler if specified
    if log_file:
        # Create logs directory if it doesn't exist
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        # File handler with UTF-8 encoding
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get an existing logger or create a new one
    
    Args:
        name: Logger name
    
    Returns:
        Logger instance
    """
    logger = logging.getLogger(name)
    
    # If logger has no handlers, set it up
    if not logger.handlers:
        setup_logger(name)
    
    return logger


def setup_application_logging(app_name: str = 'app', log_level=logging.INFO, log_to_file: bool = True):
    """
    Setup application-wide logging configuration
    
    Args:
        app_name: Application name for logger
        log_level: Logging level
        log_to_file: Whether to log to file
    
    Returns:
        Main application logger
    """
    # Create logs directory
    logs_dir = 'logs'
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir, exist_ok=True)
    
    # Generate log file name with timestamp
    if log_to_file:
        timestamp = datetime.now().strftime('%Y%m%d')
        log_file = os.path.join(logs_dir, f'{app_name}_{timestamp}.log')
    else:
        log_file = None
    
    # Setup main logger
    logger = setup_logger(app_name, log_file, log_level)
    
    # Log startup message
    logger.info("=" * 60)
    logger.info(f"Application logging initialized: {app_name}")
    logger.info(f"Log level: {logging.getLevelName(log_level)}")
    if log_file:
        logger.info(f"Log file: {log_file}")
    logger.info("=" * 60)
    
    return logger


def configure_flask_logging(app):
    """
    Configure Flask application logging with UTF-8 support
    
    Args:
        app: Flask application instance
    """
    # Disable Flask's default logger
    app.logger.handlers.clear()
    
    # Get or create app logger
    logger = get_logger('app')
    
    # Set Flask's logger to use our configured logger
    app.logger = logger
    
    # Also configure werkzeug logger
    werkzeug_logger = logging.getLogger('werkzeug')
    werkzeug_logger.setLevel(logging.INFO)
    
    logger.info("[OK] Flask logging configured with UTF-8 support")


# Utility function to test logger
def test_logger():
    """Test logger with various characters"""
    logger = setup_logger('test')
    
    logger.info("Testing ASCII characters: OK")
    logger.info("Testing UTF-8 characters: [OK] [ERROR] [WARNING]")
    logger.info("Testing numbers and symbols: 123 !@#$%^&*()")
    logger.info("Testing paths: C:\\Users\\test\\file.txt")
    
    return logger


if __name__ == '__main__':
    # Test the logger
    test_logger()
    print("\n[OK] Logger test completed successfully!")