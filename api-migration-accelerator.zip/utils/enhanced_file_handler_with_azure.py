"""
Enhanced File Handler with Azure Blob Storage Support - FINAL COMPLETE VERSION
Handles file operations for both uploaded and converted OpenAPI specifications
FEATURES: Separate folders, file validation, cleanup, conversion tracking, Azure Storage
✅ Reads ALL settings from config.py (SSL, Azure creds, container name)
✅ Full detailed logging throughout
✅ Shows every step with emojis
"""
import os
import json
import yaml
import hashlib
import shutil
from typing import Dict, Any, Optional, List
from datetime import datetime
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
import logging
from io import BytesIO

logger = logging.getLogger(__name__)


class AzureStorageAdapter:
    """Adapter for Azure Blob Storage operations - Config Aware"""
    
    def __init__(self, azure_config: Optional[Dict[str, Any]] = None, ssl_config: Optional[Dict[str, Any]] = None):
        """
        Initialize Azure Storage adapter with config from config.py
        
        Args:
            azure_config: Dict with connection_string, account_name, container_name
            ssl_config: Dict with SSL verification settings
        """
        try:
            from azure.storage.blob import BlobServiceClient
            from azure.core.exceptions import AzureError
            
            # ==========================================
            # GET AZURE CONFIG FROM CONFIG.PY
            # ==========================================
            if not azure_config:
                azure_config = self._get_azure_config_from_app()
            
            self.connection_string = azure_config.get('connection_string')
            self.account_name = azure_config.get('account_name')
            self.container_name = azure_config.get('container_name', 'uploads')
            
            logger.info("📋 Azure Configuration loaded from config.py:")
            logger.info(f"   connection_string: {'✅ SET' if self.connection_string else '❌ NOT SET'}")
            logger.info(f"   account_name: {'✅ SET' if self.account_name else '❌ NOT SET'}")
            logger.info(f"   container_name: {self.container_name}")
            
            # ==========================================
            # GET SSL CONFIG FROM CONFIG.PY
            # ==========================================
            self.ssl_config = ssl_config or self._get_ssl_config_from_app()
            
            logger.info(f"🔐 SSL Configuration loaded:")
            logger.info(f"   verify_ssl={self.ssl_config.get('verify', True)}")
            if isinstance(self.ssl_config.get('verify'), str):
                logger.info(f"   ca_bundle_path={self.ssl_config.get('verify')}")
            
            self.client = None

            # Get SSL verification setting for storage
            self.verify_ssl = azure_config.get('verify_ssl', True)
            logger.info(f"🔐 Storage SSL verification: {'ENABLED' if self.verify_ssl else 'DISABLED'}")

            if self.connection_string:
                logger.info("🔍 Attempting to connect to Azure Storage with connection string...")
                try:
                    if self.verify_ssl:
                        # Connect with SSL verification
                        self.client = BlobServiceClient.from_connection_string(
                            self.connection_string
                        )
                        logger.info(f"✅ Azure Storage connected successfully (SSL verify=True)")
                    else:
                        # Connect without SSL verification (for firewall/internal networks)
                        self.client = BlobServiceClient.from_connection_string(
                            self.connection_string,
                            connection_verify=False
                        )
                        logger.warning(f"⚠️  Azure Storage connected (SSL verification DISABLED)")

                except Exception as ssl_error:
                    logger.warning(f"⚠️  Connection failed: {ssl_error}")
                    if self.verify_ssl:
                        logger.info("🔄 Retrying without SSL verification...")
                        try:
                            self.client = BlobServiceClient.from_connection_string(
                                self.connection_string,
                                connection_verify=False
                            )
                            logger.warning(f"⚠️  Azure Storage connected in fallback mode (SSL disabled)")
                        except Exception as fallback_error:
                            logger.error(f"❌ Both connection methods failed: {fallback_error}")
                            self.client = None
                    else:
                        logger.error(f"❌ Connection failed: {ssl_error}")
                        self.client = None

            elif self.account_name:
                logger.info("🔍 Attempting to connect to Azure Storage with account key...")
                try:
                    account_key = os.getenv('API_STORAGE_ACCOUNT_KEY')
                    if not account_key:
                        logger.error("❌ API_STORAGE_ACCOUNT_KEY not set in environment")
                        self.client = None
                    else:
                        self.client = BlobServiceClient(
                            account_url=f"https://{self.account_name}.blob.core.windows.net",
                            credential=account_key
                        )
                        logger.info(f"✅ Azure Storage connected with account key: {self.account_name}")
                except Exception as key_error:
                    logger.error(f"❌ Failed to connect with account key: {key_error}")
                    self.client = None
            else:
                logger.info("ℹ️  Azure Storage not configured - will use local filesystem")
                logger.info("   Missing: API_STORAGE_CONNECTION_STRING or API_STORAGE_ACCOUNT_NAME")
                self.client = None
                return
            
            # Ensure container exists (only if client is available)
            if self.client:
                try:
                    self.container_client = self._get_or_create_container()
                    logger.info(f"✅ Azure Blob Storage ready - Container: {self.container_name}")
                except Exception as container_error:
                    logger.error(f"❌ Failed to get/create container: {container_error}")
                    logger.warning("⚠️  Falling back to local filesystem storage")
                    self.client = None
            
        except ImportError as ie:
            logger.warning(f"⚠️  azure-storage-blob not installed: {ie}")
            logger.warning("   Install with: pip install azure-storage-blob")
            logger.info("   Falling back to local filesystem storage")
            self.client = None
        except Exception as e:
            logger.error(f"❌ Failed to initialize Azure Storage: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            logger.info("   Falling back to local filesystem storage")
            self.client = None
    
    def _get_azure_config_from_app(self) -> Dict[str, Any]:
        """
        Fetch Azure configuration from Flask app's config.py
        This reads all Azure storage settings from environment via config
        """
        try:
            from config import get_config
            config = get_config()

            logger.info("📋 Fetching Azure config from config.py...")
            logger.info(f"   Environment: {config.ENV}")

            # Get verify_ssl setting (default True for safety)
            verify_ssl = getattr(config, 'AZURE_STORAGE_VERIFY_SSL', True)

            azure_config = {
                'connection_string': config.AZURE_STORAGE_CONNECTION_STRING,
                'account_name': config.AZURE_STORAGE_ACCOUNT_NAME,
                'container_name': config.AZURE_STORAGE_CONTAINER_NAME,
                'verify_ssl': verify_ssl
            }

            logger.info(f"   AZURE_STORAGE_CONNECTION_STRING: {'✅ SET' if azure_config['connection_string'] else '❌ NOT SET'}")
            logger.info(f"   AZURE_STORAGE_ACCOUNT_NAME: {'✅ SET' if azure_config['account_name'] else '❌ NOT SET'}")
            logger.info(f"   AZURE_STORAGE_CONTAINER_NAME: {azure_config['container_name']}")
            logger.info(f"   AZURE_STORAGE_VERIFY_SSL: {'✅ ENABLED' if verify_ssl else '⚠️ DISABLED'}")

            return azure_config

        except ImportError as ie:
            logger.warning(f"⚠️  Could not import config.py: {ie}")
            logger.info("   Falling back to environment variables only")
            return {
                'connection_string': os.getenv('API_STORAGE_CONNECTION_STRING'),
                'account_name': os.getenv('API_STORAGE_ACCOUNT_NAME'),
                'container_name': os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads'),
                'verify_ssl': os.getenv('API_STORAGE_VERIFY_SSL', 'True').lower() == 'true'
            }
        except Exception as e:
            logger.warning(f"⚠️  Error fetching Azure config from config.py: {e}")
            logger.info("   Falling back to environment variables only")
            return {
                'connection_string': os.getenv('API_STORAGE_CONNECTION_STRING'),
                'account_name': os.getenv('API_STORAGE_ACCOUNT_NAME'),
                'container_name': os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads'),
                'verify_ssl': os.getenv('API_STORAGE_VERIFY_SSL', 'True').lower() == 'true'
            }

    def _get_ssl_config_from_app(self) -> Dict[str, Any]:
        """Get SSL configuration from Flask app's config.py"""
        try:
            from config import get_config
            config = get_config()
            
            logger.info("📋 Fetching SSL config from config.py...")
            ssl_config = config.get_ssl_config()
            logger.info(f"   SSL config: {ssl_config}")
            
            return ssl_config
            
        except ImportError as ie:
            logger.warning(f"⚠️  Could not import config.py: {ie}")
            logger.info("   Using default SSL configuration (certifi)")
            return self._get_default_ssl_config()
        except Exception as e:
            logger.warning(f"⚠️  Error fetching SSL config from config.py: {e}")
            logger.info("   Using default SSL configuration (certifi)")
            return self._get_default_ssl_config()
    
    def _get_default_ssl_config(self) -> Dict[str, Any]:
        """Get default SSL configuration with certifi"""
        try:
            import certifi
            ca_path = certifi.where()
            logger.info(f"📋 Using certifi CA bundle: {ca_path}")
            return {'verify': ca_path}
        except ImportError:
            logger.warning("⚠️  certifi not installed - using system default")
            return {'verify': True}
    
    def _get_or_create_container(self):
        """Get or create blob container with error handling"""
        try:
            logger.info(f"🔍 Checking container: {self.container_name}")
            container_client = self.client.get_container_client(self.container_name)
            try:
                props = container_client.get_container_properties()
                logger.info(f"✅ Container '{self.container_name}' exists and is accessible")
            except Exception as exists_error:
                logger.info(f"📝 Container '{self.container_name}' does not exist - creating...")
                try:
                    container_client = self.client.create_container(self.container_name)
                    logger.info(f"✅ Container '{self.container_name}' created successfully")
                except Exception as create_error:
                    logger.error(f"❌ Failed to create container: {create_error}")
                    raise
            return container_client
        except Exception as e:
            logger.error(f"❌ Failed to get/create container: {e}")
            raise
    
    @property
    def is_available(self) -> bool:
        """Check if Azure Storage is available and ready"""
        available = self.client is not None and hasattr(self, 'container_client') and self.container_client is not None
        if available:
            logger.debug("✅ Azure Storage is available")
        else:
            logger.debug("❌ Azure Storage is not available")
        return available
    
    def upload_file(self, content: bytes, blob_path: str, metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """Upload file to Azure Blob Storage with detailed logging"""
        try:
            if not self.is_available:
                logger.error(f"❌ Azure Storage not available - cannot upload: {blob_path}")
                return {'success': False, 'error': 'Azure Storage not available'}
            
            logger.info(f"📤 Uploading file to Azure: {blob_path}")
            logger.info(f"   File size: {len(content)} bytes")
            
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.upload_blob(content, overwrite=True)
            
            logger.info(f"✅ File uploaded: {blob_path}")
            
            if metadata:
                logger.info(f"📝 Setting metadata: {list(metadata.keys())}")
                blob_client.set_blob_metadata(metadata)
            
            properties = blob_client.get_blob_properties()
            
            download_url = f"https://{self.account_name}.blob.core.windows.net/{self.container_name}/{blob_path}"
            logger.info(f"🔗 Download URL: {download_url}")
            
            return {
                'success': True,
                'blob_path': blob_path,
                'size': properties.size,
                'download_url': download_url
            }
            
        except Exception as e:
            logger.error(f"❌ Azure upload failed for {blob_path}: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {'success': False, 'error': str(e)}
    
    def download_file(self, blob_path: str) -> Dict[str, Any]:
        """Download file from Azure Blob Storage with detailed logging"""
        try:
            if not self.is_available:
                logger.error(f"❌ Azure Storage not available - cannot download: {blob_path}")
                return {'success': False, 'error': 'Azure Storage not available'}
            
            logger.info(f"📥 Downloading file from Azure: {blob_path}")
            
            blob_client = self.container_client.get_blob_client(blob_path)
            download_stream = blob_client.download_blob()
            content = download_stream.readall()
            
            logger.info(f"✅ File downloaded: {blob_path} ({len(content)} bytes)")
            
            properties = blob_client.get_blob_properties()
            
            return {
                'success': True,
                'blob_path': blob_path,
                'content': content,
                'size': properties.size
            }
            
        except Exception as e:
            logger.error(f"❌ Azure download failed for {blob_path}: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {'success': False, 'error': str(e)}
    
    def delete_file(self, blob_path: str) -> Dict[str, Any]:
        """Delete file from Azure Blob Storage with detailed logging"""
        try:
            if not self.is_available:
                logger.error(f"❌ Azure Storage not available - cannot delete: {blob_path}")
                return {'success': False, 'error': 'Azure Storage not available'}
            
            logger.info(f"🗑️  Deleting file from Azure: {blob_path}")
            
            blob_client = self.container_client.get_blob_client(blob_path)
            blob_client.delete_blob()
            
            logger.info(f"✅ File deleted: {blob_path}")
            
            return {'success': True, 'blob_path': blob_path}
            
        except Exception as e:
            logger.error(f"❌ Azure delete failed for {blob_path}: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {'success': False, 'error': str(e)}
    
    def list_files(self, prefix: str = '') -> Dict[str, Any]:
        """List files in Azure Blob Storage with detailed logging"""
        try:
            if not self.is_available:
                logger.warning(f"⚠️  Azure Storage not available - cannot list files")
                return {'success': False, 'error': 'Azure Storage not available', 'files': []}
            
            logger.info(f"📂 Listing files in Azure with prefix: '{prefix}'")
            
            files = []
            blobs = self.container_client.list_blobs(name_starts_with=prefix)
            
            for blob in blobs:
                files.append({
                    'name': blob.name,
                    'size': blob.size,
                    'modified_time': blob.last_modified.isoformat() if blob.last_modified else None
                })
            
            logger.info(f"✅ Found {len(files)} files with prefix '{prefix}'")
            
            return {'success': True, 'files': files}
            
        except Exception as e:
            logger.error(f"❌ Azure list failed: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {'success': False, 'error': str(e), 'files': []}
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get Azure storage statistics with detailed logging"""
        try:
            if not self.is_available:
                logger.warning("⚠️  Azure Storage not available - returning 0 stats")
                return {'total_size_mb': 0, 'total_files': 0}
            
            logger.info("📊 Calculating Azure storage statistics...")
            
            total_size = 0
            total_files = 0
            
            blobs = self.container_client.list_blobs()
            for blob in blobs:
                total_size += blob.size
                total_files += 1
            
            total_mb = round(total_size / (1024 * 1024), 2)
            
            logger.info(f"✅ Storage stats: {total_files} files, {total_mb} MB total")
            
            return {
                'total_size_mb': total_mb,
                'total_files': total_files
            }
            
        except Exception as e:
            logger.error(f"❌ Azure stats calculation failed: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {'total_size_mb': 0, 'total_files': 0}


class EnhancedFileHandler:
    """Enhanced file handler with local filesystem and Azure Blob Storage support - FINAL VERSION"""
    
    def __init__(self, base_folder: str = 'static/uploads', azure_config: Optional[Dict[str, Any]] = None, ssl_config: Optional[Dict[str, Any]] = None):
        """Initialize file handler with organized folder structure and config-aware SSL + Azure"""
        logger.info("="*70)
        logger.info("🚀 ENHANCED FILE HANDLER INITIALIZATION")
        logger.info("="*70)
        
        self.base_folder = base_folder
        self.upload_folder = os.path.join(base_folder, 'uploaded')
        self.converted_folder = os.path.join(base_folder, 'converted')
        self.temp_folder = os.path.join(base_folder, 'temp')
        
        logger.info(f"📂 Folder structure:")
        logger.info(f"   Base: {base_folder}")
        logger.info(f"   Uploaded: {self.upload_folder}")
        logger.info(f"   Converted: {self.converted_folder}")
        logger.info(f"   Temp: {self.temp_folder}")
        
        # File size limits
        self.max_file_size = 16 * 1024 * 1024  # 16MB
        self.allowed_extensions = {'.json', '.yaml', '.yml', '.txt'}
        
        logger.info(f"📋 File constraints:")
        logger.info(f"   Max size: {self.max_file_size / (1024*1024):.0f} MB")
        logger.info(f"   Allowed types: {', '.join(self.allowed_extensions)}")
        
        # ==========================================
        # AZURE & SSL CONFIGURATION - FROM CONFIG.PY
        # ==========================================
        self.azure_config = azure_config or self._get_azure_config_from_app()
        self.ssl_config = ssl_config or self._get_ssl_config_from_app()
        
        logger.info(f"🔐 SSL Configuration:")
        logger.info(f"   {self.ssl_config}")
        
        # Initialize Azure Storage adapter with configs from config.py
        logger.info("\n🔌 Initializing Azure Storage adapter...")
        self.azure_storage = AzureStorageAdapter(azure_config=self.azure_config, ssl_config=self.ssl_config)
        self.use_azure = self.azure_storage.is_available
        
        # Create local folders (for fallback and metadata)
        self._create_folders()
        
        logger.info("\n" + "="*70)
        storage_type = 'Azure Blob Storage' if self.use_azure else 'Local Filesystem'
        logger.info(f"✅ ENHANCED FILE HANDLER READY - Storage: {storage_type}")
        logger.info("="*70 + "\n")
    
    def _get_azure_config_from_app(self) -> Dict[str, Any]:
        """Fetch Azure configuration from Flask app's config.py"""
        try:
            from config import get_config
            config = get_config()
            
            logger.info("📋 Fetching Azure config from config.py...")
            
            azure_config = {
                'connection_string': config.AZURE_STORAGE_CONNECTION_STRING,
                'account_name': config.AZURE_STORAGE_ACCOUNT_NAME,
                'container_name': config.AZURE_STORAGE_CONTAINER_NAME
            }
            
            return azure_config
            
        except ImportError as ie:
            logger.warning(f"⚠️  Could not import config.py: {ie}")
            logger.info("   Falling back to environment variables only")
            return {
                'connection_string': os.getenv('API_STORAGE_CONNECTION_STRING'),
                'account_name': os.getenv('API_STORAGE_ACCOUNT_NAME'),
                'container_name': os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads')
            }
        except Exception as e:
            logger.warning(f"⚠️  Error fetching Azure config: {e}")
            return {
                'connection_string': os.getenv('API_STORAGE_CONNECTION_STRING'),
                'account_name': os.getenv('API_STORAGE_ACCOUNT_NAME'),
                'container_name': os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads')
            }
    
    def _get_ssl_config_from_app(self) -> Dict[str, Any]:
        """Fetch SSL configuration from Flask app's config.py"""
        try:
            from config import get_config
            config = get_config()
            
            logger.info("📋 Fetching SSL config from config.py...")
            ssl_config = config.get_ssl_config()
            logger.info(f"   SSL config: {ssl_config}")
            
            return ssl_config
            
        except ImportError as ie:
            logger.warning(f"⚠️  Could not import config.py: {ie}")
            logger.info("   Using default SSL configuration (certifi)")
            return self._get_default_ssl_config()
        except Exception as e:
            logger.warning(f"⚠️  Error fetching SSL config: {e}")
            return self._get_default_ssl_config()
    
    def _get_default_ssl_config(self) -> Dict[str, Any]:
        """Get default SSL configuration with certifi"""
        try:
            import certifi
            ca_path = certifi.where()
            logger.info(f"📋 Using certifi CA bundle: {ca_path}")
            return {'verify': ca_path}
        except ImportError:
            logger.warning("⚠️  certifi not installed - using system default")
            return {'verify': True}
    
    def _create_folders(self):
        """Create necessary local folder structure with detailed logging"""
        logger.info("📁 Creating folder structure...")
        folders = [self.base_folder, self.upload_folder, self.converted_folder, self.temp_folder]
        for folder in folders:
            try:
                os.makedirs(folder, exist_ok=True)
                logger.info(f"   ✅ {folder}")
            except Exception as e:
                logger.error(f"   ❌ Failed to create {folder}: {e}")
    
    def save_uploaded_file(self, file: FileStorage, prefix: str = 'upload') -> Dict[str, Any]:
        """Save uploaded file with validation (to Azure or local)"""
        try:
            logger.info(f"📤 Processing file upload: {file.filename}")
            
            # Validate file
            validation_result = self._validate_file(file)
            if not validation_result['valid']:
                logger.error(f"   ❌ Validation failed: {validation_result['error']}")
                return {
                    'success': False,
                    'error': validation_result['error']
                }
            
            logger.info(f"   ✅ File validation passed")
            
            # Generate secure filename
            original_filename = file.filename
            file_extension = os.path.splitext(original_filename)[1].lower()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            secure_base = secure_filename(os.path.splitext(original_filename)[0])
            filename = f"{prefix}_{timestamp}_{secure_base}{file_extension}"
            
            logger.info(f"   📝 Generated filename: {filename}")
            
            # Read file content
            file_content = file.read()
            file_hash = self._calculate_hash(file_content)
            
            logger.info(f"   📊 File size: {len(file_content)} bytes")
            logger.info(f"   🔐 File hash: {file_hash}")
            
            if self.use_azure:
                logger.info(f"   ☁️  Saving to Azure Storage...")
                # Save to Azure Blob Storage
                blob_path = f"uploaded/{filename}"
                
                result = self.azure_storage.upload_file(
                    file_content,
                    blob_path,
                    metadata={
                        'original_filename': original_filename,
                        'upload_time': datetime.now().isoformat(),
                        'file_hash': file_hash
                    }
                )
                
                if not result['success']:
                    logger.error(f"   ❌ Azure upload failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                logger.info(f"✅ File saved to Azure: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,
                    'original_filename': original_filename,
                    'file_size': len(file_content),
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'azure',
                    'download_url': result['download_url']
                }
            
            else:
                logger.info(f"   💾 Saving to local filesystem...")
                # Save to local filesystem
                file_path = os.path.join(self.upload_folder, filename)
                with open(file_path, 'wb') as f:
                    f.write(file_content)
                
                file_stats = os.stat(file_path)
                
                logger.info(f"✅ File saved locally: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'file_path': file_path,
                    'blob_path': None,
                    'original_filename': original_filename,
                    'file_size': file_stats.st_size,
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'local'
                }
            
        except Exception as e:
            logger.error(f"❌ Failed to save uploaded file: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to save file: {str(e)}'
            }
    
    def save_converted_file(self, converted_spec: Dict[str, Any], 
                           original_filename: str, 
                           conversion_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Save converted OpenAPI specification (to Azure or local)"""
        try:
            logger.info(f"💾 Saving converted file from: {original_filename}")
            
            # Generate filename for converted file
            base_name = os.path.splitext(original_filename)[0]
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            converted_filename = f"converted_{timestamp}_{secure_filename(base_name)}.json"
            metadata_filename = f"metadata_{timestamp}_{secure_filename(base_name)}.json"
            
            logger.info(f"   📝 Converted filename: {converted_filename}")
            logger.info(f"   📝 Metadata filename: {metadata_filename}")
            
            # Serialize converted spec
            converted_content = json.dumps(converted_spec, indent=2, ensure_ascii=False).encode('utf-8')
            
            # Prepare metadata
            metadata = {
                'original_filename': original_filename,
                'converted_filename': converted_filename,
                'conversion_timestamp': datetime.now().isoformat(),
                'openapi_version': converted_spec.get('openapi', 'Unknown'),
                'api_title': converted_spec.get('info', {}).get('title', 'Unknown'),
                'api_version': converted_spec.get('info', {}).get('version', 'Unknown'),
                'paths_count': len(converted_spec.get('paths', {})),
                'schemas_count': len(converted_spec.get('components', {}).get('schemas', {})),
                'conversion_metadata': conversion_metadata or {}
            }
            
            logger.info(f"   📊 OpenAPI version: {metadata['openapi_version']}")
            logger.info(f"   📊 API title: {metadata['api_title']}")
            logger.info(f"   📊 Paths: {metadata['paths_count']}, Schemas: {metadata['schemas_count']}")
            
            metadata_content = json.dumps(metadata, indent=2, ensure_ascii=False).encode('utf-8')
            
            if self.use_azure:
                logger.info(f"   ☁️  Saving to Azure Storage...")
                # Save to Azure Blob Storage
                blob_path = f"converted/{converted_filename}"
                metadata_blob_path = f"converted/{metadata_filename}"
                
                # Upload converted spec
                result = self.azure_storage.upload_file(converted_content, blob_path)
                if not result['success']:
                    logger.error(f"   ❌ Azure upload failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                logger.info(f"   ✅ Converted spec uploaded to Azure")
                
                # Upload metadata
                metadata_result = self.azure_storage.upload_file(metadata_content, metadata_blob_path)
                logger.info(f"   ✅ Metadata uploaded to Azure")
                
                logger.info(f"✅ Converted file saved to Azure: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,
                    'metadata_filename': metadata_filename,
                    'metadata_blob_path': metadata_blob_path,
                    'metadata_path': metadata_blob_path,
                    'file_size': len(converted_content),
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'azure',
                    'download_url': result['download_url'],
                    'metadata': metadata
                }
            
            else:
                logger.info(f"   💾 Saving to local filesystem...")
                # Save to local filesystem
                converted_path = os.path.join(self.converted_folder, converted_filename)
                metadata_path = os.path.join(self.converted_folder, metadata_filename)
                
                with open(converted_path, 'wb') as f:
                    f.write(converted_content)
                
                logger.info(f"   ✅ Converted spec saved locally")
                
                with open(metadata_path, 'wb') as f:
                    f.write(metadata_content)
                
                logger.info(f"   ✅ Metadata saved locally")
                
                file_stats = os.stat(converted_path)
                
                logger.info(f"✅ Converted file saved locally: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'file_path': converted_path,
                    'blob_path': None,
                    'metadata_filename': metadata_filename,
                    'metadata_path': metadata_path,
                    'metadata_blob_path': None,
                    'file_size': file_stats.st_size,
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'local',
                    'download_url': f'/api/files/converted/{converted_filename}',
                    'metadata': metadata
                }
            
        except Exception as e:
            logger.error(f"❌ Failed to save converted file: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to save converted file: {str(e)}'
            }
    
    def read_file_content(self, file_path: str, blob_path: Optional[str] = None) -> Dict[str, Any]:
        """Read and parse file content (from Azure or local)"""
        try:
            logger.info(f"📖 Reading file content...")
            
            content = None
            
            if self.use_azure and blob_path:
                logger.info(f"   ☁️  Reading from Azure: {blob_path}")
                # Read from Azure
                result = self.azure_storage.download_file(blob_path)
                if not result['success']:
                    logger.error(f"   ❌ Azure download failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                content = result['content'].decode('utf-8')
                logger.info(f"   ✅ Downloaded from Azure ({len(content)} bytes)")
            
            elif os.path.exists(file_path):
                logger.info(f"   💾 Reading from local: {file_path}")
                # Read from local
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                logger.info(f"   ✅ Read from local ({len(content)} bytes)")
            
            else:
                logger.error(f"   ❌ File not found: {file_path}")
                return {'success': False, 'error': 'File not found'}
            
            # Determine content type and parse
            file_extension = os.path.splitext(file_path)[1].lower() if file_path else '.json'
            content_type = 'json' if file_extension == '.json' else 'yaml'
            
            parsed_content = None
            try:
                if content_type == 'json' or content.strip().startswith('{'):
                    parsed_content = json.loads(content)
                    content_type = 'json'
                    logger.info(f"   ✅ Parsed as JSON")
                else:
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
                    logger.info(f"   ✅ Parsed as YAML")
            except Exception as parse_error:
                logger.warning(f"   ⚠️  Failed to parse content as {content_type}: {parse_error}")
            
            return {
                'success': True,
                'content': content,
                'parsed_content': parsed_content,
                'content_type': content_type,
                'file_size': len(content.encode('utf-8')) if content else 0,
                'encoding': 'utf-8'
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to read file content: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to read file: {str(e)}'
            }
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        try:
            logger.info("📊 Calculating storage statistics...")
            
            if self.use_azure:
                stats = self.azure_storage.get_storage_stats()
                return {
                    'success': True,
                    'folders': {
                        'total': stats
                    },
                    'totals': stats,
                    'storage_type': 'azure'
                }
            
            else:
                stats = {}
                
                for folder_name, folder_path in [
                    ('uploaded', self.upload_folder),
                    ('converted', self.converted_folder),
                    ('temp', self.temp_folder)
                ]:
                    if os.path.exists(folder_path):
                        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
                        total_size = sum(os.path.getsize(os.path.join(folder_path, f)) for f in files)
                        
                        stats[folder_name] = {
                            'file_count': len(files),
                            'total_size_bytes': total_size,
                            'total_size_mb': round(total_size / (1024 * 1024), 2)
                        }
                    else:
                        stats[folder_name] = {
                            'file_count': 0,
                            'total_size_bytes': 0,
                            'total_size_mb': 0
                        }
                
                # Calculate totals
                total_files = sum(s['file_count'] for s in stats.values())
                total_size = sum(s['total_size_bytes'] for s in stats.values())
                
                logger.info(f"   ✅ Total: {total_files} files, {round(total_size / (1024*1024), 2)} MB")
                
                return {
                    'success': True,
                    'folders': stats,
                    'totals': {
                        'total_files': total_files,
                        'total_size_bytes': total_size,
                        'total_size_mb': round(total_size / (1024 * 1024), 2)
                    },
                    'storage_type': 'local'
                }
        
        except Exception as e:
            logger.error(f"❌ Failed to get storage stats: {e}")
            return {
                'success': False,
                'error': f'Failed to get storage stats: {str(e)}'
            }
    
    def _validate_file(self, file: FileStorage) -> Dict[str, Any]:
        """Validate uploaded file"""
        if not file or not file.filename:
            return {'valid': False, 'error': 'No file provided'}
        
        # Check file extension
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in self.allowed_extensions:
            return {
                'valid': False, 
                'error': f'Invalid file type. Allowed: {", ".join(self.allowed_extensions)}'
            }
        
        # Check file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Reset to beginning
        
        if file_size > self.max_file_size:
            return {
                'valid': False,
                'error': f'File too large. Max size: {self.max_file_size // (1024*1024)}MB'
            }
        
        return {'valid': True}
    
    def _calculate_hash(self, content: bytes) -> str:
        """Calculate SHA-256 hash of content"""
        hash_sha256 = hashlib.sha256()
        hash_sha256.update(content)
        return hash_sha256.hexdigest()[:16]
    
    def _list_folder_files(self, folder_path: str, folder_type: str) -> List[Dict[str, Any]]:
        """List files in a specific local folder"""
        files = []
        
        if not os.path.exists(folder_path):
            return files
        
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            
            if os.path.isfile(file_path):
                file_stats = os.stat(file_path)
                
                file_info = {
                    'filename': filename,
                    'folder_type': folder_type,
                    'file_size': file_stats.st_size,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'file_extension': os.path.splitext(filename)[1].lower(),
                    'storage_type': 'local'
                }
                
                files.append(file_info)
        
        return files
    
    def _get_conversion_metadata(self, converted_filename: str, blob_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get conversion metadata for a converted file"""
        try:
            if self.use_azure and blob_path:
                metadata_blob_path = blob_path.replace('converted_', 'metadata_')
                result = self.azure_storage.download_file(metadata_blob_path)

                if result['success']:
                    return json.loads(result['content'].decode('utf-8'))
                return None

            else:
                metadata_filename = converted_filename.replace('converted_', 'metadata_')
                metadata_path = os.path.join(self.converted_folder, metadata_filename)

                if os.path.exists(metadata_path):
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        return json.load(f)

                return None

        except Exception as e:
            logger.warning(f"⚠️  Failed to read metadata: {e}")
            return None

    def get_file_info(self, filename: str, folder_type: str = 'uploaded', blob_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Get information about a specific file (from Azure or local storage)

        Args:
            filename: The name of the file to get info for
            folder_type: Type of folder ('uploaded', 'converted', 'temp')
            blob_path: Optional Azure blob path

        Returns:
            Dict with file information including content, size, etc.
        """
        try:
            logger.info(f"📋 Getting file info: {filename} (folder: {folder_type})")

            if self.use_azure:
                # Construct blob path if not provided
                if not blob_path:
                    blob_path = f"{folder_type}/{filename}"

                logger.info(f"   ☁️  Fetching from Azure: {blob_path}")

                # Download file from Azure
                result = self.azure_storage.download_file(blob_path)

                if not result['success']:
                    logger.error(f"   ❌ File not found in Azure: {blob_path}")
                    return {
                        'success': False,
                        'error': f'File not found: {filename}'
                    }

                content = result['content'].decode('utf-8')

                logger.info(f"   ✅ File retrieved from Azure ({len(content)} bytes)")

                return {
                    'success': True,
                    'filename': filename,
                    'folder_type': folder_type,
                    'content': content,
                    'file_size': result.get('size', len(content)),
                    'blob_path': blob_path,
                    'storage_type': 'azure'
                }

            else:
                # Local filesystem
                folder_map = {
                    'uploaded': self.upload_folder,
                    'converted': self.converted_folder,
                    'temp': self.temp_folder
                }

                folder_path = folder_map.get(folder_type, self.upload_folder)
                file_path = os.path.join(folder_path, filename)

                logger.info(f"   💾 Fetching from local: {file_path}")

                if not os.path.exists(file_path):
                    logger.error(f"   ❌ File not found locally: {file_path}")
                    return {
                        'success': False,
                        'error': f'File not found: {filename}'
                    }

                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                file_stats = os.stat(file_path)

                logger.info(f"   ✅ File retrieved from local ({len(content)} bytes)")

                return {
                    'success': True,
                    'filename': filename,
                    'folder_type': folder_type,
                    'content': content,
                    'file_size': file_stats.st_size,
                    'file_path': file_path,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'storage_type': 'local'
                }

        except Exception as e:
            logger.error(f"❌ Failed to get file info: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to get file info: {str(e)}'
            }

    def list_files(self, folder_type: str = 'all') -> Dict[str, Any]:
        """
        List files in storage (Azure or local)

        Args:
            folder_type: 'uploaded' | 'converted' | 'temp' | 'all'

        Returns:
            Dict with success status and list of files
        """
        try:
            logger.info(f"📂 Listing files: folder_type={folder_type}")

            all_files = []

            if self.use_azure:
                # List from Azure
                if folder_type == 'all':
                    prefixes = ['uploaded/', 'converted/', 'temp/']
                else:
                    prefixes = [f"{folder_type}/"]

                for prefix in prefixes:
                    result = self.azure_storage.list_files(prefix)
                    if result.get('success'):
                        for file_info in result.get('files', []):
                            # Extract filename from blob path
                            blob_name = file_info.get('name', '')
                            filename = blob_name.split('/')[-1] if '/' in blob_name else blob_name
                            folder = blob_name.split('/')[0] if '/' in blob_name else 'unknown'

                            all_files.append({
                                'filename': filename,
                                'folder_type': folder,
                                'file_size': file_info.get('size', 0),
                                'modified_time': file_info.get('modified_time'),
                                'blob_path': blob_name,
                                'storage_type': 'azure'
                            })

                logger.info(f"   ✅ Found {len(all_files)} files in Azure")

            else:
                # List from local filesystem
                if folder_type == 'all':
                    folders = [
                        ('uploaded', self.upload_folder),
                        ('converted', self.converted_folder),
                        ('temp', self.temp_folder)
                    ]
                else:
                    folder_map = {
                        'uploaded': self.upload_folder,
                        'converted': self.converted_folder,
                        'temp': self.temp_folder
                    }
                    folder_path = folder_map.get(folder_type, self.upload_folder)
                    folders = [(folder_type, folder_path)]

                for folder_name, folder_path in folders:
                    files = self._list_folder_files(folder_path, folder_name)
                    all_files.extend(files)

                logger.info(f"   ✅ Found {len(all_files)} files locally")

            # Calculate total size
            total_size = sum(f.get('file_size', 0) for f in all_files)
            total_size_mb = round(total_size / (1024 * 1024), 2)

            return {
                'success': True,
                'files': all_files,
                'folder_type': folder_type,
                'count': len(all_files),
                'total_size_mb': total_size_mb,
                'storage_type': 'azure' if self.use_azure else 'local'
            }

        except Exception as e:
            logger.error(f"❌ Failed to list files: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to list files: {str(e)}',
                'files': [],
                'count': 0
            }