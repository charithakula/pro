"""
Enhanced File Handler with Azure Blob Storage Support - LAZY LOADING VERSION
Handles file operations for both uploaded and converted OpenAPI specifications
FEATURES: Separate folders, file validation, cleanup, conversion tracking, Azure Storage
- Uses lazy-loaded AzureStorageConnector to avoid app startup delays
- Reads settings from config.py (SSL, Azure creds, container name)
- Full detailed logging throughout
"""
import os
import json
import yaml
import hashlib
import shutil
from typing import Dict, Any, Optional, List
from datetime import datetime
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
import logging
from io import BytesIO

logger = logging.getLogger(__name__)


def get_azure_storage():
    """Get lazy-loaded Azure Storage connector"""
    try:
        from connectors.azure_storage_connector import get_storage_connector
        return get_storage_connector()
    except ImportError:
        logger.warning("Azure Storage connector not available")
        return None


class EnhancedFileHandler:
    """
    Enhanced file handler with local filesystem and Azure Blob Storage support.
    Uses LAZY LOADING for Azure Storage to avoid app startup delays.
    """

    def __init__(self, base_folder: str = 'static/uploads'):
        """Initialize file handler with organized folder structure (NO Azure init at startup)"""
        logger.info("Initializing EnhancedFileHandler...")

        self.base_folder = base_folder
        self.upload_folder = os.path.join(base_folder, 'uploaded')
        self.converted_folder = os.path.join(base_folder, 'converted')
        self.temp_folder = os.path.join(base_folder, 'temp')

        # File size limits
        self.max_file_size = 16 * 1024 * 1024  # 16MB
        self.allowed_extensions = {'.json', '.yaml', '.yml', '.txt'}

        # Azure storage will be lazy-loaded on first use
        self._azure_storage = None

        # Create local folders
        self._create_folders()

        logger.info(f"EnhancedFileHandler ready (Azure will be lazy-loaded)")

    @property
    def azure_storage(self):
        """Lazy-load Azure Storage connector on first access"""
        if self._azure_storage is None:
            self._azure_storage = get_azure_storage()
        return self._azure_storage

    @property
    def use_azure(self) -> bool:
        """Check if Azure Storage is available (triggers lazy init)"""
        storage = self.azure_storage
        if storage is None:
            return False
        return storage.is_available
    
    def _create_folders(self):
        """Create necessary local folder structure with detailed logging"""
        logger.info("📁 Creating folder structure...")
        folders = [self.base_folder, self.upload_folder, self.converted_folder, self.temp_folder]
        for folder in folders:
            try:
                os.makedirs(folder, exist_ok=True)
                logger.info(f"   ✅ {folder}")
            except Exception as e:
                logger.error(f"   ❌ Failed to create {folder}: {e}")
    
    def save_uploaded_file(self, file: FileStorage, prefix: str = 'upload') -> Dict[str, Any]:
        """Save uploaded file with validation (to Azure or local)"""
        try:
            logger.info(f"📤 Processing file upload: {file.filename}")
            
            # Validate file
            validation_result = self._validate_file(file)
            if not validation_result['valid']:
                logger.error(f"   ❌ Validation failed: {validation_result['error']}")
                return {
                    'success': False,
                    'error': validation_result['error']
                }
            
            logger.info(f"   ✅ File validation passed")
            
            # Generate secure filename
            original_filename = file.filename
            file_extension = os.path.splitext(original_filename)[1].lower()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            secure_base = secure_filename(os.path.splitext(original_filename)[0])
            filename = f"{prefix}_{timestamp}_{secure_base}{file_extension}"
            
            logger.info(f"   📝 Generated filename: {filename}")
            
            # Read file content
            file_content = file.read()
            file_hash = self._calculate_hash(file_content)
            
            logger.info(f"   📊 File size: {len(file_content)} bytes")
            logger.info(f"   🔐 File hash: {file_hash}")
            
            if self.use_azure:
                logger.info(f"   ☁️  Saving to Azure Storage...")
                # Save to Azure Blob Storage
                blob_path = f"uploaded/{filename}"
                
                result = self.azure_storage.upload_file(
                    file_content,
                    blob_path,
                    metadata={
                        'original_filename': original_filename,
                        'upload_time': datetime.now().isoformat(),
                        'file_hash': file_hash
                    }
                )
                
                if not result['success']:
                    logger.error(f"   ❌ Azure upload failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                logger.info(f"✅ File saved to Azure: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,
                    'original_filename': original_filename,
                    'file_size': len(file_content),
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'azure',
                    'download_url': result['download_url']
                }
            
            else:
                logger.info(f"   💾 Saving to local filesystem...")
                # Save to local filesystem
                file_path = os.path.join(self.upload_folder, filename)
                with open(file_path, 'wb') as f:
                    f.write(file_content)
                
                file_stats = os.stat(file_path)
                
                logger.info(f"✅ File saved locally: {filename}")
                
                return {
                    'success': True,
                    'filename': filename,
                    'file_path': file_path,
                    'blob_path': None,
                    'original_filename': original_filename,
                    'file_size': file_stats.st_size,
                    'file_hash': file_hash,
                    'upload_time': datetime.now().isoformat(),
                    'folder_type': 'uploaded',
                    'storage_type': 'local'
                }
            
        except Exception as e:
            logger.error(f"❌ Failed to save uploaded file: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to save file: {str(e)}'
            }
    
    def save_converted_file(self, converted_spec: Dict[str, Any], 
                           original_filename: str, 
                           conversion_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Save converted OpenAPI specification (to Azure or local)"""
        try:
            logger.info(f"💾 Saving converted file from: {original_filename}")
            
            # Generate filename for converted file
            base_name = os.path.splitext(original_filename)[0]
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            converted_filename = f"converted_{timestamp}_{secure_filename(base_name)}.json"
            metadata_filename = f"metadata_{timestamp}_{secure_filename(base_name)}.json"
            
            logger.info(f"   📝 Converted filename: {converted_filename}")
            logger.info(f"   📝 Metadata filename: {metadata_filename}")
            
            # Serialize converted spec
            converted_content = json.dumps(converted_spec, indent=2, ensure_ascii=False).encode('utf-8')
            
            # Prepare metadata
            metadata = {
                'original_filename': original_filename,
                'converted_filename': converted_filename,
                'conversion_timestamp': datetime.now().isoformat(),
                'openapi_version': converted_spec.get('openapi', 'Unknown'),
                'api_title': converted_spec.get('info', {}).get('title', 'Unknown'),
                'api_version': converted_spec.get('info', {}).get('version', 'Unknown'),
                'paths_count': len(converted_spec.get('paths', {})),
                'schemas_count': len(converted_spec.get('components', {}).get('schemas', {})),
                'conversion_metadata': conversion_metadata or {}
            }
            
            logger.info(f"   📊 OpenAPI version: {metadata['openapi_version']}")
            logger.info(f"   📊 API title: {metadata['api_title']}")
            logger.info(f"   📊 Paths: {metadata['paths_count']}, Schemas: {metadata['schemas_count']}")
            
            metadata_content = json.dumps(metadata, indent=2, ensure_ascii=False).encode('utf-8')
            
            if self.use_azure:
                logger.info(f"   ☁️  Saving to Azure Storage...")
                # Save to Azure Blob Storage
                blob_path = f"converted/{converted_filename}"
                metadata_blob_path = f"converted/{metadata_filename}"
                
                # Upload converted spec
                result = self.azure_storage.upload_file(converted_content, blob_path)
                if not result['success']:
                    logger.error(f"   ❌ Azure upload failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                logger.info(f"   ✅ Converted spec uploaded to Azure")
                
                # Upload metadata
                metadata_result = self.azure_storage.upload_file(metadata_content, metadata_blob_path)
                logger.info(f"   ✅ Metadata uploaded to Azure")
                
                logger.info(f"✅ Converted file saved to Azure: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'blob_path': blob_path,
                    'file_path': blob_path,
                    'metadata_filename': metadata_filename,
                    'metadata_blob_path': metadata_blob_path,
                    'metadata_path': metadata_blob_path,
                    'file_size': len(converted_content),
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'azure',
                    'download_url': result['download_url'],
                    'metadata': metadata
                }
            
            else:
                logger.info(f"   💾 Saving to local filesystem...")
                # Save to local filesystem
                converted_path = os.path.join(self.converted_folder, converted_filename)
                metadata_path = os.path.join(self.converted_folder, metadata_filename)
                
                with open(converted_path, 'wb') as f:
                    f.write(converted_content)
                
                logger.info(f"   ✅ Converted spec saved locally")
                
                with open(metadata_path, 'wb') as f:
                    f.write(metadata_content)
                
                logger.info(f"   ✅ Metadata saved locally")
                
                file_stats = os.stat(converted_path)
                
                logger.info(f"✅ Converted file saved locally: {converted_filename}")
                
                return {
                    'success': True,
                    'filename': converted_filename,
                    'file_path': converted_path,
                    'blob_path': None,
                    'metadata_filename': metadata_filename,
                    'metadata_path': metadata_path,
                    'metadata_blob_path': None,
                    'file_size': file_stats.st_size,
                    'conversion_time': datetime.now().isoformat(),
                    'folder_type': 'converted',
                    'storage_type': 'local',
                    'download_url': f'/api/files/converted/{converted_filename}',
                    'metadata': metadata
                }
            
        except Exception as e:
            logger.error(f"❌ Failed to save converted file: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to save converted file: {str(e)}'
            }
    
    def read_file_content(self, file_path: str, blob_path: Optional[str] = None) -> Dict[str, Any]:
        """Read and parse file content (from Azure or local)"""
        try:
            logger.info(f"📖 Reading file content...")
            
            content = None
            
            if self.use_azure and blob_path:
                logger.info(f"   ☁️  Reading from Azure: {blob_path}")
                # Read from Azure
                result = self.azure_storage.download_file(blob_path)
                if not result['success']:
                    logger.error(f"   ❌ Azure download failed: {result['error']}")
                    return {'success': False, 'error': result['error']}
                
                content = result['content'].decode('utf-8')
                logger.info(f"   ✅ Downloaded from Azure ({len(content)} bytes)")
            
            elif os.path.exists(file_path):
                logger.info(f"   💾 Reading from local: {file_path}")
                # Read from local
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                logger.info(f"   ✅ Read from local ({len(content)} bytes)")
            
            else:
                logger.error(f"   ❌ File not found: {file_path}")
                return {'success': False, 'error': 'File not found'}
            
            # Determine content type and parse
            file_extension = os.path.splitext(file_path)[1].lower() if file_path else '.json'
            content_type = 'json' if file_extension == '.json' else 'yaml'
            
            parsed_content = None
            try:
                if content_type == 'json' or content.strip().startswith('{'):
                    parsed_content = json.loads(content)
                    content_type = 'json'
                    logger.info(f"   ✅ Parsed as JSON")
                else:
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
                    logger.info(f"   ✅ Parsed as YAML")
            except Exception as parse_error:
                logger.warning(f"   ⚠️  Failed to parse content as {content_type}: {parse_error}")
            
            return {
                'success': True,
                'content': content,
                'parsed_content': parsed_content,
                'content_type': content_type,
                'file_size': len(content.encode('utf-8')) if content else 0,
                'encoding': 'utf-8'
            }
            
        except Exception as e:
            logger.error(f"❌ Failed to read file content: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to read file: {str(e)}'
            }
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        try:
            logger.info("📊 Calculating storage statistics...")
            
            if self.use_azure:
                stats = self.azure_storage.get_storage_stats()
                return {
                    'success': True,
                    'folders': {
                        'total': stats
                    },
                    'totals': stats,
                    'storage_type': 'azure'
                }
            
            else:
                stats = {}
                
                for folder_name, folder_path in [
                    ('uploaded', self.upload_folder),
                    ('converted', self.converted_folder),
                    ('temp', self.temp_folder)
                ]:
                    if os.path.exists(folder_path):
                        files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
                        total_size = sum(os.path.getsize(os.path.join(folder_path, f)) for f in files)
                        
                        stats[folder_name] = {
                            'file_count': len(files),
                            'total_size_bytes': total_size,
                            'total_size_mb': round(total_size / (1024 * 1024), 2)
                        }
                    else:
                        stats[folder_name] = {
                            'file_count': 0,
                            'total_size_bytes': 0,
                            'total_size_mb': 0
                        }
                
                # Calculate totals
                total_files = sum(s['file_count'] for s in stats.values())
                total_size = sum(s['total_size_bytes'] for s in stats.values())
                
                logger.info(f"   ✅ Total: {total_files} files, {round(total_size / (1024*1024), 2)} MB")
                
                return {
                    'success': True,
                    'folders': stats,
                    'totals': {
                        'total_files': total_files,
                        'total_size_bytes': total_size,
                        'total_size_mb': round(total_size / (1024 * 1024), 2)
                    },
                    'storage_type': 'local'
                }
        
        except Exception as e:
            logger.error(f"❌ Failed to get storage stats: {e}")
            return {
                'success': False,
                'error': f'Failed to get storage stats: {str(e)}'
            }
    
    def _validate_file(self, file: FileStorage) -> Dict[str, Any]:
        """Validate uploaded file"""
        if not file or not file.filename:
            return {'valid': False, 'error': 'No file provided'}
        
        # Check file extension
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in self.allowed_extensions:
            return {
                'valid': False, 
                'error': f'Invalid file type. Allowed: {", ".join(self.allowed_extensions)}'
            }
        
        # Check file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Reset to beginning
        
        if file_size > self.max_file_size:
            return {
                'valid': False,
                'error': f'File too large. Max size: {self.max_file_size // (1024*1024)}MB'
            }
        
        return {'valid': True}
    
    def _calculate_hash(self, content: bytes) -> str:
        """Calculate SHA-256 hash of content"""
        hash_sha256 = hashlib.sha256()
        hash_sha256.update(content)
        return hash_sha256.hexdigest()[:16]

    def _parse_content(self, content: str, filename: str) -> tuple:
        """
        Parse file content as JSON or YAML and determine content type.

        Args:
            content: Raw file content string
            filename: Filename (used for extension hint)

        Returns:
            Tuple of (parsed_content, content_type)
            - parsed_content: dict if parseable, None otherwise
            - content_type: 'json' or 'yaml'
        """
        parsed_content = None
        file_extension = os.path.splitext(filename)[1].lower() if filename else ''

        # Determine initial content type from extension
        if file_extension in ['.json']:
            content_type = 'json'
        elif file_extension in ['.yaml', '.yml']:
            content_type = 'yaml'
        else:
            # Guess from content
            content_type = 'json' if content.strip().startswith('{') else 'yaml'

        try:
            # Try JSON first if content looks like JSON
            if content_type == 'json' or content.strip().startswith('{'):
                try:
                    parsed_content = json.loads(content)
                    content_type = 'json'
                    logger.debug(f"   ✅ Parsed as JSON")
                except json.JSONDecodeError:
                    # Fall back to YAML
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
                    logger.debug(f"   ✅ Parsed as YAML (JSON failed)")
            else:
                # Try YAML
                parsed_content = yaml.safe_load(content)
                content_type = 'yaml'
                logger.debug(f"   ✅ Parsed as YAML")
        except Exception as parse_error:
            logger.warning(f"   ⚠️ Failed to parse content: {parse_error}")
            parsed_content = None

        return parsed_content, content_type

    def _list_folder_files(self, folder_path: str, folder_type: str) -> List[Dict[str, Any]]:
        """List files in a specific local folder"""
        files = []
        
        if not os.path.exists(folder_path):
            return files
        
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            
            if os.path.isfile(file_path):
                file_stats = os.stat(file_path)
                
                file_info = {
                    'filename': filename,
                    'folder_type': folder_type,
                    'file_size': file_stats.st_size,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'file_extension': os.path.splitext(filename)[1].lower(),
                    'storage_type': 'local'
                }
                
                files.append(file_info)
        
        return files
    
    def _get_conversion_metadata(self, converted_filename: str, blob_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """Get conversion metadata for a converted file"""
        try:
            if self.use_azure and blob_path:
                metadata_blob_path = blob_path.replace('converted_', 'metadata_')
                result = self.azure_storage.download_file(metadata_blob_path)

                if result['success']:
                    return json.loads(result['content'].decode('utf-8'))
                return None

            else:
                metadata_filename = converted_filename.replace('converted_', 'metadata_')
                metadata_path = os.path.join(self.converted_folder, metadata_filename)

                if os.path.exists(metadata_path):
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        return json.load(f)

                return None

        except Exception as e:
            logger.warning(f"⚠️  Failed to read metadata: {e}")
            return None

    def get_file_info(self, filename: str, folder_type: str = 'uploaded', blob_path: Optional[str] = None) -> Dict[str, Any]:
        """
        Get information about a specific file (from Azure or local storage)

        Args:
            filename: The name of the file to get info for
            folder_type: Type of folder ('uploaded', 'converted', 'temp')
            blob_path: Optional Azure blob path

        Returns:
            Dict with file information including content, size, etc.
        """
        try:
            logger.info(f"📋 Getting file info: {filename} (folder: {folder_type})")

            if self.use_azure:
                # Construct blob path if not provided
                if not blob_path:
                    blob_path = f"{folder_type}/{filename}"

                logger.info(f"   ☁️  Fetching from Azure: {blob_path}")

                # Download file from Azure
                result = self.azure_storage.download_file(blob_path)

                if not result['success']:
                    logger.error(f"   ❌ File not found in Azure: {blob_path}")
                    return {
                        'success': False,
                        'error': f'File not found: {filename}'
                    }

                content = result['content'].decode('utf-8')

                logger.info(f"   ✅ File retrieved from Azure ({len(content)} bytes)")

                # Parse content to get parsed_content and content_type
                parsed_content, content_type = self._parse_content(content, filename)

                return {
                    'success': True,
                    'filename': filename,
                    'folder_type': folder_type,
                    'content': content,
                    'content_type': content_type,
                    'parsed_content': parsed_content,
                    'file_size': result.get('size', len(content)),
                    'blob_path': blob_path,
                    'storage_type': 'azure'
                }

            else:
                # Local filesystem
                folder_map = {
                    'uploaded': self.upload_folder,
                    'converted': self.converted_folder,
                    'temp': self.temp_folder
                }

                folder_path = folder_map.get(folder_type, self.upload_folder)
                file_path = os.path.join(folder_path, filename)

                logger.info(f"   💾 Fetching from local: {file_path}")

                if not os.path.exists(file_path):
                    logger.error(f"   ❌ File not found locally: {file_path}")
                    return {
                        'success': False,
                        'error': f'File not found: {filename}'
                    }

                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()

                file_stats = os.stat(file_path)

                logger.info(f"   ✅ File retrieved from local ({len(content)} bytes)")

                # Parse content to get parsed_content and content_type
                parsed_content, content_type = self._parse_content(content, filename)

                return {
                    'success': True,
                    'filename': filename,
                    'folder_type': folder_type,
                    'content': content,
                    'content_type': content_type,
                    'parsed_content': parsed_content,
                    'file_size': file_stats.st_size,
                    'file_path': file_path,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'storage_type': 'local'
                }

        except Exception as e:
            logger.error(f"❌ Failed to get file info: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to get file info: {str(e)}'
            }

    def list_files(self, folder_type: str = 'all') -> Dict[str, Any]:
        """
        List files in storage (Azure or local)

        Args:
            folder_type: 'uploaded' | 'converted' | 'temp' | 'all'

        Returns:
            Dict with success status and list of files
        """
        try:
            logger.info(f"📂 Listing files: folder_type={folder_type}")

            all_files = []

            if self.use_azure:
                # List from Azure
                if folder_type == 'all':
                    prefixes = ['uploaded/', 'converted/', 'temp/']
                else:
                    prefixes = [f"{folder_type}/"]

                for prefix in prefixes:
                    result = self.azure_storage.list_files(prefix)
                    if result.get('success'):
                        for file_info in result.get('files', []):
                            # Extract filename from blob path
                            blob_name = file_info.get('name', '')
                            filename = blob_name.split('/')[-1] if '/' in blob_name else blob_name
                            folder = blob_name.split('/')[0] if '/' in blob_name else 'unknown'

                            all_files.append({
                                'filename': filename,
                                'folder_type': folder,
                                'file_size': file_info.get('size', 0),
                                'modified_time': file_info.get('modified_time'),
                                'blob_path': blob_name,
                                'storage_type': 'azure'
                            })

                logger.info(f"   ✅ Found {len(all_files)} files in Azure")

            else:
                # List from local filesystem
                if folder_type == 'all':
                    folders = [
                        ('uploaded', self.upload_folder),
                        ('converted', self.converted_folder),
                        ('temp', self.temp_folder)
                    ]
                else:
                    folder_map = {
                        'uploaded': self.upload_folder,
                        'converted': self.converted_folder,
                        'temp': self.temp_folder
                    }
                    folder_path = folder_map.get(folder_type, self.upload_folder)
                    folders = [(folder_type, folder_path)]

                for folder_name, folder_path in folders:
                    files = self._list_folder_files(folder_path, folder_name)
                    all_files.extend(files)

                logger.info(f"   ✅ Found {len(all_files)} files locally")

            # Calculate total size
            total_size = sum(f.get('file_size', 0) for f in all_files)
            total_size_mb = round(total_size / (1024 * 1024), 2)

            return {
                'success': True,
                'files': all_files,
                'folder_type': folder_type,
                'count': len(all_files),
                'total_size_mb': total_size_mb,
                'storage_type': 'azure' if self.use_azure else 'local'
            }

        except Exception as e:
            logger.error(f"❌ Failed to list files: {e}")
            logger.error(f"   Error type: {type(e).__name__}")
            return {
                'success': False,
                'error': f'Failed to list files: {str(e)}',
                'files': [],
                'count': 0
            }