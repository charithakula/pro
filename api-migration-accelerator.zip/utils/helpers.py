"""
General helper functions and utilities
Contains commonly used utility functions across the application
"""
import json
import yaml
import hashlib
import re
import uuid
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Union, List, Tuple
import logging

logger = logging.getLogger(__name__)

def generate_id(prefix: str = "", length: int = 8) -> str:
    """
    Generate unique identifier
    
    Args:
        prefix: Optional prefix for the ID
        length: Length of the random part
        
    Returns:
        Generated unique ID
    """
    if length <= 0:
        random_part = str(uuid.uuid4()).replace('-', '')
    else:
        random_part = str(uuid.uuid4()).replace('-', '')[:length]
    
    if prefix:
        return f"{prefix}_{random_part}"
    return random_part

def get_current_timestamp() -> str:
    """Get current timestamp in ISO format"""
    return datetime.now(timezone.utc).isoformat()

def format_datetime(dt: datetime, format_string: str = "%Y-%m-%d %H:%M:%S") -> str:
    """
    Format datetime object to string
    
    Args:
        dt: Datetime object
        format_string: Format string
        
    Returns:
        Formatted datetime string
    """
    if not dt:
        return ""
    
    try:
        return dt.strftime(format_string)
    except Exception as e:
        logger.warning(f"Failed to format datetime {dt}: {e}")
        return str(dt)

def calculate_file_hash(content: Union[str, bytes], algorithm: str = 'sha256') -> str:
    """
    Calculate hash of content
    
    Args:
        content: Content to hash
        algorithm: Hash algorithm (md5, sha1, sha256)
        
    Returns:
        Hash string
    """
    try:
        hash_obj = hashlib.new(algorithm)
        
        if isinstance(content, str):
            content = content.encode('utf-8')
        
        hash_obj.update(content)
        return hash_obj.hexdigest()
        
    except Exception as e:
        logger.error(f"Failed to calculate hash: {e}")
        return ""

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe storage
    
    Args:
        filename: Original filename
        
    Returns:
        Sanitized filename
    """
    # Remove or replace unsafe characters
    filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove leading/trailing whitespace and dots
    filename = filename.strip(' .')
    
    # Limit filename length
    if len(filename) > 255:
        name, ext = os.path.splitext(filename)
        max_name_length = 255 - len(ext)
        filename = name[:max_name_length] + ext
    
    # Ensure filename is not empty
    if not filename:
        filename = f"unnamed_file_{generate_id(length=6)}"
    
    return filename

def validate_json(content: str) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
    """
    Validate JSON content
    
    Args:
        content: JSON content as string
        
    Returns:
        Tuple of (is_valid, parsed_data, error_message)
    """
    try:
        parsed_data = json.loads(content)
        return True, parsed_data, None
    except json.JSONDecodeError as e:
        return False, None, f"Invalid JSON: {str(e)}"
    except Exception as e:
        return False, None, f"JSON parsing error: {str(e)}"

def validate_yaml(content: str) -> Tuple[bool, Optional[Dict[str, Any]], Optional[str]]:
    """
    Validate YAML content
    
    Args:
        content: YAML content as string
        
    Returns:
        Tuple of (is_valid, parsed_data, error_message)
    """
    try:
        parsed_data = yaml.safe_load(content)
        return True, parsed_data, None
    except yaml.YAMLError as e:
        return False, None, f"Invalid YAML: {str(e)}"
    except Exception as e:
        return False, None, f"YAML parsing error: {str(e)}"

def parse_api_spec(content: str) -> Tuple[Optional[Dict[str, Any]], str, Optional[str]]:
    """
    Parse API specification content (JSON or YAML)
    
    Args:
        content: Specification content
        
    Returns:
        Tuple of (parsed_spec, detected_format, error_message)
    """
    # Try JSON first
    is_valid_json, json_data, json_error = validate_json(content)
    if is_valid_json:
        return json_data, 'json', None
    
    # Try YAML
    is_valid_yaml, yaml_data, yaml_error = validate_yaml(content)
    if is_valid_yaml:
        return yaml_data, 'yaml', None
    
    # Both failed
    error_msg = f"Content is neither valid JSON ({json_error}) nor valid YAML ({yaml_error})"
    return None, 'unknown', error_msg

def extract_api_info(spec: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract basic API information from OpenAPI specification
    
    Args:
        spec: Parsed OpenAPI specification
        
    Returns:
        Extracted API information
    """
    info = spec.get('info', {})
    paths = spec.get('paths', {})
    
    # Extract basic info
    api_info = {
        'title': info.get('title', 'Unknown API'),
        'version': info.get('version', 'Unknown'),
        'description': info.get('description', ''),
        'paths_count': len(paths),
        'openapi_version': spec.get('swagger') or spec.get('openapi', 'Unknown'),
        'format': 'openapi_2.0' if 'swagger' in spec else 'openapi_3.0' if 'openapi' in spec else 'unknown'
    }
    
    # Extract contact information
    if 'contact' in info:
        contact = info['contact']
        api_info['contact'] = {
            'name': contact.get('name'),
            'email': contact.get('email'),
            'url': contact.get('url')
        }
    
    # Extract license information
    if 'license' in info:
        license_info = info['license']
        api_info['license'] = {
            'name': license_info.get('name'),
            'url': license_info.get('url')
        }
    
    # Extract server information
    servers = []
    if 'servers' in spec:
        for server in spec['servers']:
            servers.append({
                'url': server.get('url'),
                'description': server.get('description')
            })
    elif 'host' in spec or 'basePath' in spec:
        # OpenAPI 2.0 format
        host = spec.get('host', 'localhost')
        base_path = spec.get('basePath', '')
        schemes = spec.get('schemes', ['http'])
        
        for scheme in schemes:
            servers.append({
                'url': f"{scheme}://{host}{base_path}",
                'description': f"{scheme.upper()} server"
            })
    
    api_info['servers'] = servers
    
    # Count operations
    operations_count = 0
    http_methods = ['get', 'post', 'put', 'delete', 'head', 'options', 'patch', 'trace']
    
    for path_data in paths.values():
        if isinstance(path_data, dict):
            for method in path_data.keys():
                if method.lower() in http_methods:
                    operations_count += 1
    
    api_info['operations_count'] = operations_count
    
    # Count definitions/schemas
    definitions_count = 0
    if 'definitions' in spec:
        definitions_count = len(spec['definitions'])
    elif 'components' in spec and 'schemas' in spec['components']:
        definitions_count = len(spec['components']['schemas'])
    
    api_info['definitions_count'] = definitions_count
    
    # Check for security
    has_security = bool(
        spec.get('securityDefinitions') or 
        (spec.get('components', {}).get('securitySchemes')) or
        spec.get('security')
    )
    api_info['has_security'] = has_security
    
    return api_info

def format_file_size(size_bytes: int) -> str:
    """
    Format file size in human readable format
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        Formatted size string
    """
    if size_bytes == 0:
        return "0 B"
    
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if abs(size_bytes) < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    
    return f"{size_bytes:.1f} PB"

def validate_url(url: str) -> bool:
    """
    Validate URL format
    
    Args:
        url: URL to validate
        
    Returns:
        True if valid URL
    """
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return url_pattern.match(url) is not None

def validate_email(email: str) -> bool:
    """
    Validate email format
    
    Args:
        email: Email to validate
        
    Returns:
        True if valid email
    """
    email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
    return email_pattern.match(email) is not None

def clean_dict(data: Dict[str, Any], remove_none: bool = True, remove_empty: bool = False) -> Dict[str, Any]:
    """
    Clean dictionary by removing None values and optionally empty values
    
    Args:
        data: Dictionary to clean
        remove_none: Remove None values
        remove_empty: Remove empty strings, lists, dicts
        
    Returns:
        Cleaned dictionary
    """
    cleaned = {}
    
    for key, value in data.items():
        # Skip None values if requested
        if remove_none and value is None:
            continue
        
        # Skip empty values if requested
        if remove_empty and not value and value != 0 and value is not False:
            continue
        
        # Recursively clean nested dictionaries
        if isinstance(value, dict):
            nested_cleaned = clean_dict(value, remove_none, remove_empty)
            if nested_cleaned or not remove_empty:
                cleaned[key] = nested_cleaned
        else:
            cleaned[key] = value
    
    return cleaned

def deep_merge_dicts(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deep merge two dictionaries
    
    Args:
        dict1: First dictionary (base)
        dict2: Second dictionary (override)
        
    Returns:
        Merged dictionary
    """
    result = dict1.copy()
    
    for key, value in dict2.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = deep_merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result

def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate string to maximum length with suffix
    
    Args:
        text: Text to truncate
        max_length: Maximum length
        suffix: Suffix to add when truncated
        
    Returns:
        Truncated string
    """
    if not text or len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix

def extract_error_message(exception: Exception, max_length: int = 500) -> str:
    """
    Extract clean error message from exception
    
    Args:
        exception: Exception object
        max_length: Maximum message length
        
    Returns:
        Clean error message
    """
    error_msg = str(exception)
    
    # Clean up common error patterns
    error_msg = re.sub(r'\n+', ' ', error_msg)  # Replace newlines with space
    error_msg = re.sub(r'\s+', ' ', error_msg)  # Normalize whitespace
    error_msg = error_msg.strip()
    
    return truncate_string(error_msg, max_length)

def parse_version_string(version: str) -> Tuple[int, int, int]:
    """
    Parse semantic version string into components
    
    Args:
        version: Version string (e.g., "1.2.3")
        
    Returns:
        Tuple of (major, minor, patch)
    """
    try:
        # Extract numeric parts only
        version_parts = re.findall(r'\d+', version)
        
        major = int(version_parts[0]) if len(version_parts) > 0 else 0
        minor = int(version_parts[1]) if len(version_parts) > 1 else 0
        patch = int(version_parts[2]) if len(version_parts) > 2 else 0
        
        return major, minor, patch
        
    except (ValueError, IndexError) as e:
        logger.warning(f"Failed to parse version string '{version}': {e}")
        return 0, 0, 0

def compare_versions(version1: str, version2: str) -> int:
    """
    Compare two version strings
    
    Args:
        version1: First version
        version2: Second version
        
    Returns:
        -1 if version1 < version2, 0 if equal, 1 if version1 > version2
    """
    v1_parts = parse_version_string(version1)
    v2_parts = parse_version_string(version2)
    
    for v1, v2 in zip(v1_parts, v2_parts):
        if v1 < v2:
            return -1
        elif v1 > v2:
            return 1
    
    return 0

def mask_sensitive_data(data: str, mask_char: str = "*", show_chars: int = 4) -> str:
    """
    Mask sensitive data like API keys or tokens
    
    Args:
        data: Data to mask
        mask_char: Character to use for masking
        show_chars: Number of characters to show at the end
        
    Returns:
        Masked data
    """
    if not data or len(data) <= show_chars:
        return mask_char * 8  # Return fixed length mask for short/empty data
    
    mask_length = len(data) - show_chars
    return mask_char * mask_length + data[-show_chars:]

def retry_with_backoff(func, max_retries: int = 3, base_delay: float = 1.0, max_delay: float = 60.0):
    """
    Retry function with exponential backoff
    
    Args:
        func: Function to retry
        max_retries: Maximum number of retries
        base_delay: Base delay in seconds
        max_delay: Maximum delay in seconds
        
    Returns:
        Function result or raises last exception
    """
    import time
    
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return func()
        except Exception as e:
            last_exception = e
            
            if attempt == max_retries:
                break
            
            # Calculate delay with exponential backoff
            delay = min(base_delay * (2 ** attempt), max_delay)
            logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {delay:.1f}s...")
            time.sleep(delay)
    
    raise last_exception

def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """
    Split list into chunks of specified size
    
    Args:
        lst: List to chunk
        chunk_size: Size of each chunk
        
    Returns:
        List of chunks
    """
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def safe_get_nested(data: Dict[str, Any], path: str, default: Any = None) -> Any:
    """
    Safely get nested dictionary value using dot notation
    
    Args:
        data: Dictionary to search
        path: Dot-separated path (e.g., "info.title")
        default: Default value if path not found
        
    Returns:
        Value at path or default
    """
    try:
        keys = path.split('.')
        current = data
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
        
        return current
        
    except Exception:
        return default

def measure_execution_time(func):
    """
    Decorator to measure function execution time
    
    Args:
        func: Function to measure
        
    Returns:
        Decorated function that logs execution time
    """
    def wrapper(*args, **kwargs):
        import time
        start_time = time.time()
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug(f"{func.__name__} executed in {execution_time:.3f}s")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"{func.__name__} failed after {execution_time:.3f}s: {e}")
            raise
    
    return wrapper