"""
Conversion Service - WITH COMPLETE RESPONSE DATA FOR FRONTEND
Includes: converted_file object with storage_type, filename, file_size
"""
import json
import logging
from typing import Dict, Any, Optional, Union
from datetime import datetime

from connectors import AzureOpenAIConnector
from .validation_service import ValidationService

logger = logging.getLogger(__name__)

class ConversionService:
    """Service for handling OpenAPI specification conversions"""
    
    def __init__(self):
        """Initialize conversion service with required connectors"""
        self.openai_connector = AzureOpenAIConnector()
        self.validation_service = ValidationService()
        
        # ✅ Initialize file handler for saving converted files
        try:
            from utils.enhanced_file_handler_with_azure import EnhancedFileHandler
            self.file_handler = EnhancedFileHandler()
            logger.info("✅ ConversionService: file_handler initialized")
        except Exception as e:
            logger.warning(f"ConversionService: file_handler initialization failed: {e}")
            self.file_handler = None
    
    def convert_specification(self, spec_content: str, source_format: str = 'auto', include_debug: bool = False, conversion_type: str = 'swagger2-to-openapi3') -> Dict[str, Any]:
        """
        Convert OpenAPI specification

        Args:
            spec_content: Raw specification content
            source_format: Source format ('auto', 'json', 'yaml')
            include_debug: Include debug information in response
            conversion_type: Conversion type ('swagger2-to-openapi3', 'swagger2-to-swagger2')

        Returns:
            Dictionary with conversion results
        """
        try:
            logger.info(f"=== STARTING CONVERSION (type: {conversion_type}) ===")
            
            # Step 1: Parse and validate input
            parse_result = self._parse_input_specification(spec_content, source_format)
            if parse_result['status'] == 'error':
                logger.error(f"Parse failed: {parse_result.get('message')}")
                return parse_result
            
            original_spec = parse_result['specification']
            detected_format = parse_result['format']
            
            logger.info(f"Parsed specification: {detected_format.upper()} format")
            logger.info(f"API Title: {original_spec.get('info', {}).get('title', 'Unknown')}")
            
            # Step 2: Validate it's OpenAPI 2.0
            logger.info("Validating OpenAPI 2.0 specification...")
            validation_result = self.validation_service.validate_openapi_2(original_spec, strict=False)
            
            logger.info(f"Validation result: {validation_result['summary']}")
            
            if not validation_result['is_valid']:
                critical_errors = self._filter_critical_errors(validation_result['errors'])
                if critical_errors:
                    logger.error(f"Critical validation errors: {critical_errors}")
                    return {
                        'status': 'error',
                        'message': 'Input is not a valid OpenAPI 2.0 specification',
                        'validation_errors': critical_errors,
                        'all_errors': validation_result['errors'],
                        'warnings': validation_result['warnings']
                    }
                else:
                    logger.warning(f"Non-critical issues found, proceeding")
            
            if validation_result['warnings']:
                logger.info(f"Validation warnings: {validation_result['warnings'][:3]}...")
            
            # Step 3: Perform conversion based on conversion_type
            conversion_start = datetime.now()

            if conversion_type == 'swagger2-to-swagger2':
                # Use LLM to clean/normalize OpenAPI 2.0 while keeping it in 2.0 format
                logger.info("Starting OpenAPI 2.0 to 2.0 conversion using LLM")
                conversion_result = self.openai_connector.convert_specification(
                    spec_content,
                    target_format='json',
                    target_version='2.0',
                    include_debug=include_debug
                )

                if conversion_result['status'] != 'success':
                    logger.error(f"Conversion failed: {conversion_result.get('message')}")
                    return conversion_result

                converted_spec = conversion_result['converted_spec']
                # Additional cleanup for Azure APIM compatibility
                converted_spec = self._clean_openapi2_spec(converted_spec)
                conversion_result['converted_spec'] = converted_spec
                conversion_result['conversion_metadata'] = {
                    'conversion_type': 'swagger2-to-swagger2',
                    'ai_conversion_used': True
                }
                target_format = 'openapi_2.0'
            else:
                # Default: Convert OpenAPI 2.0 to 3.0
                logger.info("Starting OpenAPI 2.0 to 3.0 conversion using LLM")
                conversion_result = self.openai_connector.universal_openapi_converter(spec_content, include_debug)

                if conversion_result['status'] != 'success':
                    logger.error(f"Conversion failed: {conversion_result.get('message')}")
                    return conversion_result

                converted_spec = conversion_result['converted_spec']
                target_format = 'openapi_3.0'

            conversion_time = (datetime.now() - conversion_start).total_seconds()
            logger.info(f"Conversion completed in {conversion_time:.2f} seconds")

            # Step 4: Validate converted specification
            if conversion_type == 'swagger2-to-swagger2':
                logger.info("Validating cleaned OpenAPI 2.0 specification...")
                converted_validation = self.validation_service.validate_openapi_2(converted_spec, strict=False)
            else:
                logger.info("Validating converted OpenAPI 3.0 specification...")
                converted_validation = self.validation_service.validate_openapi_3(converted_spec, strict=False)
            
            if not converted_validation['is_valid']:
                logger.warning(f"Converted spec validation issues: {converted_validation['summary']}")
            else:
                logger.info(f"Converted spec validation: {converted_validation['summary']}")
            
            # Step 5: Compare original vs converted
            comparison_result = self._compare_specifications(original_spec, converted_spec)
            logger.info(f"Comparison: {comparison_result.get('summary', 'N/A')}")
            
            # ✅ STEP 6: SAVE CONVERTED FILE
            converted_file_path = None
            storage_type = 'local'
            converted_filename = None
            
            if self.file_handler and converted_spec:
                try:
                    api_title = original_spec.get('info', {}).get('title', 'Unknown API')
                    original_filename = f"{api_title}.json"
                    
                    conversion_metadata = {
                        'source_format': detected_format,
                        'conversion_time_seconds': conversion_time,
                        'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                        'paths_count': len(converted_spec.get('paths', {})),
                        'schemas_count': len(converted_spec.get('components', {}).get('schemas', {}))
                    }
                    
                    logger.info(f"💾 Saving converted file using save_converted_file()")
                    
                    save_result = self.file_handler.save_converted_file(
                        converted_spec=converted_spec,
                        original_filename=original_filename,
                        conversion_metadata=conversion_metadata
                    )
                    
                    if save_result.get('success'):
                        converted_file_path = save_result.get('file_path')
                        storage_type = save_result.get('storage_type', 'local')
                        converted_filename = save_result.get('filename')
                        logger.info(f"✅ Converted file saved: {converted_file_path}")
                        logger.info(f"   Storage: {storage_type}")
                        logger.info(f"   Filename: {converted_filename}")
                    else:
                        logger.warning(f"Failed to save: {save_result.get('error')}")
                
                except Exception as save_error:
                    logger.error(f"Error saving converted file: {save_error}", exc_info=True)
            
            # ✅ STEP 7: BUILD RESPONSE WITH CONVERTED_FILE OBJECT
            converted_json_str = json.dumps(converted_spec, indent=2)
            file_size = len(converted_json_str.encode('utf-8'))
            
            # ✅ Build the converted_file object that frontend expects
            converted_file_obj = {
                'storage_type': storage_type,
                'filename': converted_filename or 'converted_spec.json',
                'file_size': file_size,
                'download_url': f'/api/files/{converted_filename}' if converted_filename else None
            }
            
            result = {
                'status': 'success',
                'message': 'Conversion completed successfully',
                'converted_spec': converted_spec,
                'converted_file': converted_file_obj,  # ✅ ADDED FOR FRONTEND
                'converted_file_path': converted_file_path,
                'source_format': detected_format,
                'target_format': target_format,
                'conversion_type': conversion_type,
                'conversion_time_seconds': conversion_time,
                'ai_conversion_used': conversion_result.get('ai_conversion_used', False),
                'conversion_metadata': conversion_result.get('conversion_metadata', {})
            }
            
            # Always include validation results (needed for migration records)
            result['validation'] = {
                'valid': converted_validation.get('valid', True),
                'errors': converted_validation.get('errors', []),
                'warnings': converted_validation.get('warnings', []),
                'original_validation': validation_result,
                'converted_validation': converted_validation,
                'comparison': comparison_result
            }

            # Add debug info if requested
            if include_debug:
                debug_info = {}
                if 'raw_openai_response' in conversion_result:
                    debug_info['raw_openai_response'] = conversion_result['raw_openai_response']
                if 'cleaned_json' in conversion_result:
                    debug_info['cleaned_json'] = conversion_result['cleaned_json']
                if 'cleaning_issues' in conversion_result:
                    debug_info['cleaning_issues'] = conversion_result['cleaning_issues']

                if debug_info:
                    result.update(debug_info)
            
            logger.info(f"✅ Conversion completed successfully in {conversion_time:.2f}s")
            return result
            
        except Exception as e:
            logger.error(f"Conversion failed: {e}", exc_info=True)
            return {
                'status': 'error',
                'message': f'Conversion failed: {str(e)}',
                'conversion_time_seconds': 0
            }
    
    # [All other methods remain the same as conversion_service_FINAL.py]
    # ... (copy all remaining methods from FINAL version)
    
    def _filter_critical_errors(self, errors: list) -> list:
        """Filter out non-critical errors"""
        critical_errors = []
        non_critical_patterns = [
            'not defined in', '$ref', 'might be invalid',
            'does not follow semantic versioning', 'missing description'
        ]
        
        for error in errors:
            error_lower = error.lower()
            is_critical = True
            
            for pattern in non_critical_patterns:
                if pattern.lower() in error_lower:
                    is_critical = False
                    break
            
            critical_keywords = [
                'missing required field', 'must be an object',
                'must be an array', 'invalid swagger version', 'invalid openapi version'
            ]
            
            for keyword in critical_keywords:
                if keyword.lower() in error_lower:
                    is_critical = True
                    break
            
            if is_critical and 'not defined in' not in error_lower:
                critical_errors.append(error)
        
        return critical_errors
    
    def _parse_input_specification(self, spec_content: str, source_format: str) -> Dict[str, Any]:
        """Parse input specification"""
        try:
            if source_format == 'auto':
                spec, detected_format = self.openai_connector.parse_api_spec(spec_content)
            else:
                if source_format == 'json':
                    spec = json.loads(spec_content)
                    detected_format = 'json'
                elif source_format in ['yaml', 'yml']:
                    import yaml
                    spec = yaml.safe_load(spec_content)
                    detected_format = 'yaml'
                else:
                    raise ValueError(f"Unsupported format: {source_format}")
            
            return {
                'status': 'success',
                'specification': spec,
                'format': detected_format
            }
            
        except Exception as e:
            logger.error(f"Failed to parse specification: {e}")
            return {
                'status': 'error',
                'message': f'Failed to parse specification: {str(e)}'
            }
    
    def _compare_specifications(self, original: Dict[str, Any], converted: Dict[str, Any]) -> Dict[str, Any]:
        """Compare original and converted specifications"""
        # Handle both OpenAPI 2.0 to 3.0 and 2.0 to 2.0 comparisons
        if 'swagger' in converted:
            # OpenAPI 2.0 to 2.0 comparison
            comparison = {
                'paths_preserved': len(original.get('paths', {})) == len(converted.get('paths', {})),
                'definitions_preserved': len(original.get('definitions', {})) == len(converted.get('definitions', {})),
                'security_preserved': len(original.get('securityDefinitions', {})) == len(converted.get('securityDefinitions', {})),
                'info_preserved': original.get('info', {}).get('title') == converted.get('info', {}).get('title'),
                'version_preserved': original.get('info', {}).get('version') == converted.get('info', {}).get('version')
            }
        else:
            # OpenAPI 2.0 to 3.0 comparison
            comparison = {
                'paths_preserved': len(original.get('paths', {})) == len(converted.get('paths', {})),
                'definitions_preserved': len(original.get('definitions', {})) == len(converted.get('components', {}).get('schemas', {})),
                'security_preserved': 'securityDefinitions' in original and 'components' in converted and 'securitySchemes' in converted['components'],
                'info_preserved': original.get('info', {}).get('title') == converted.get('info', {}).get('title'),
                'version_preserved': original.get('info', {}).get('version') == converted.get('info', {}).get('version')
            }

        preserved_count = sum(1 for v in comparison.values() if v)
        total_checks = len(comparison)
        preservation_score = (preserved_count / total_checks) * 100

        comparison['preservation_score'] = preservation_score
        comparison['summary'] = f"{preserved_count}/{total_checks} checks passed ({preservation_score:.1f}%)"

        return comparison

    def _clean_openapi2_spec(self, spec: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean and format OpenAPI 2.0 specification without converting to 3.0.
        This method normalizes and cleans up the spec while keeping it in Swagger 2.0 format.

        Args:
            spec: Original OpenAPI 2.0 specification

        Returns:
            Cleaned OpenAPI 2.0 specification
        """
        import copy
        cleaned = copy.deepcopy(spec)

        # Ensure swagger version is set
        if 'swagger' not in cleaned:
            cleaned['swagger'] = '2.0'

        # Clean up info section
        if 'info' in cleaned:
            info = cleaned['info']
            # Ensure required fields
            if 'title' not in info:
                info['title'] = 'API'
            if 'version' not in info:
                info['version'] = '1.0.0'
            # Clean description
            if 'description' in info and info['description']:
                info['description'] = info['description'].strip()

        # Normalize paths
        if 'paths' in cleaned:
            for path, path_item in cleaned['paths'].items():
                if isinstance(path_item, dict):
                    for method, operation in path_item.items():
                        if isinstance(operation, dict) and method.lower() in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options']:
                            # Ensure operationId exists
                            if 'operationId' not in operation:
                                safe_path = path.replace('/', '_').replace('{', '').replace('}', '').strip('_')
                                operation['operationId'] = f"{method}_{safe_path}"

                            # Clean up responses
                            if 'responses' in operation:
                                for status_code, response in operation['responses'].items():
                                    if isinstance(response, dict):
                                        # Ensure description exists
                                        if 'description' not in response:
                                            response['description'] = f"Response for status {status_code}"

        # Clean up definitions
        if 'definitions' in cleaned:
            for def_name, definition in cleaned['definitions'].items():
                if isinstance(definition, dict):
                    # Ensure type is set for objects
                    if 'properties' in definition and 'type' not in definition:
                        definition['type'] = 'object'

        # Clean up security definitions
        if 'securityDefinitions' in cleaned:
            for sec_name, sec_def in cleaned['securityDefinitions'].items():
                if isinstance(sec_def, dict):
                    # Ensure type is valid
                    if 'type' not in sec_def:
                        sec_def['type'] = 'apiKey'

        # Remove duplicate security entries (global level)
        if 'security' in cleaned and isinstance(cleaned['security'], list):
            cleaned['security'] = self._deduplicate_security_array(cleaned['security'])

        # Remove duplicate security entries (operation level)
        if 'paths' in cleaned:
            for path, path_item in cleaned['paths'].items():
                if isinstance(path_item, dict):
                    for method, operation in path_item.items():
                        if isinstance(operation, dict) and method.lower() in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options']:
                            if 'security' in operation and isinstance(operation['security'], list):
                                operation['security'] = self._deduplicate_security_array(operation['security'])

        # Remove empty or null values
        cleaned = self._remove_empty_values(cleaned)

        logger.info(f"Cleaned OpenAPI 2.0 spec: {len(cleaned.get('paths', {}))} paths, {len(cleaned.get('definitions', {}))} definitions")
        return cleaned

    def _deduplicate_security_array(self, security_array: list) -> list:
        """
        Remove duplicate security requirement objects from an array.
        Security requirements are objects like [{"apiKey": []}, {"oauth2": ["read"]}]
        """
        import json
        seen = set()
        unique = []
        for item in security_array:
            # Convert to JSON string for comparison (handles nested structures)
            item_str = json.dumps(item, sort_keys=True)
            if item_str not in seen:
                seen.add(item_str)
                unique.append(item)
        if len(unique) < len(security_array):
            logger.info(f"Removed {len(security_array) - len(unique)} duplicate security entries")
        return unique

    def _remove_empty_values(self, obj: Any) -> Any:
        """Recursively remove empty or null values from a dictionary"""
        if isinstance(obj, dict):
            return {
                k: self._remove_empty_values(v)
                for k, v in obj.items()
                if v is not None and v != '' and v != [] and v != {}
            }
        elif isinstance(obj, list):
            return [self._remove_empty_values(item) for item in obj if item is not None]
        return obj
    
    def batch_convert_specifications(self, specifications: list) -> Dict[str, Any]:
        """Convert multiple specifications in batch"""
        results = []
        successful_conversions = 0
        failed_conversions = 0
        batch_start = datetime.now()
        
        for i, spec_data in enumerate(specifications):
            spec_content = spec_data.get('content', '')
            spec_name = spec_data.get('name', f'specification_{i+1}')
            
            logger.info(f"Converting {i+1}/{len(specifications)}: {spec_name}")
            
            conversion_result = self.convert_specification(spec_content)
            conversion_result['name'] = spec_name
            conversion_result['index'] = i + 1
            
            results.append(conversion_result)
            
            if conversion_result['status'] == 'success':
                successful_conversions += 1
            else:
                failed_conversions += 1
        
        batch_time = (datetime.now() - batch_start).total_seconds()
        
        return {
            'status': 'completed',
            'total_specifications': len(specifications),
            'successful_conversions': successful_conversions,
            'failed_conversions': failed_conversions,
            'batch_time_seconds': batch_time,
            'average_time_per_conversion': batch_time / len(specifications) if specifications else 0,
            'results': results,
            'summary': f"Converted {successful_conversions}/{len(specifications)} successfully"
        }
    
    def get_conversion_preview(self, spec_content: str) -> Dict[str, Any]:
        """Get preview of what will be converted"""
        try:
            original_spec, format_type = self.openai_connector.parse_api_spec(spec_content)
            validation_result = self.validation_service.validate_openapi_2(original_spec, strict=False)
            
            info = original_spec.get('info', {})
            paths = original_spec.get('paths', {})
            definitions = original_spec.get('definitions', {})
            security_defs = original_spec.get('securityDefinitions', {})
            
            complexity_score = self._calculate_conversion_complexity(original_spec)
            
            return {
                'status': 'success',
                'api_info': {
                    'title': info.get('title', 'Unknown API'),
                    'version': info.get('version', 'Unknown'),
                    'description': info.get('description', '')
                },
                'current_format': format_type,
                'openapi_version': original_spec.get('swagger', 'Unknown'),
                'is_valid_openapi_2': validation_result['is_valid'],
                'validation_errors': validation_result['errors'] if not validation_result['is_valid'] else [],
                'validation_warnings': validation_result['warnings'],
                'conversion_preview': {
                    'paths_count': len(paths),
                    'definitions_count': len(definitions),
                    'security_schemes_count': len(security_defs),
                    'estimated_complexity': complexity_score,
                    'estimated_conversion_time': self._estimate_conversion_time(complexity_score),
                    'will_create_servers': bool(original_spec.get('host') or original_spec.get('basePath')),
                    'ai_conversion_available': self.openai_connector.is_available
                }
            }
            
        except Exception as e:
            logger.error(f"Preview failed: {e}")
            return {
                'status': 'error',
                'message': f'Preview failed: {str(e)}'
            }
    
    def _calculate_conversion_complexity(self, spec: Dict[str, Any]) -> str:
        """Calculate conversion complexity"""
        score = 0
        paths_count = len(spec.get('paths', {}))
        definitions_count = len(spec.get('definitions', {}))
        security_count = len(spec.get('securityDefinitions', {}))
        
        score += min(paths_count * 2, 20)
        score += min(definitions_count * 3, 30)
        score += min(security_count * 5, 25)
        
        if spec.get('produces') or spec.get('consumes'):
            score += 10
        
        if any('$ref' in str(path_data) for path_data in spec.get('paths', {}).values()):
            score += 15
        
        if score <= 20:
            return 'low'
        elif score <= 50:
            return 'medium'
        else:
            return 'high'
    
    def _estimate_conversion_time(self, complexity: str) -> str:
        """Estimate conversion time"""
        estimates = {
            'low': '< 5 seconds',
            'medium': '5-15 seconds',
            'high': '15-30 seconds'
        }
        return estimates.get(complexity, '< 5 seconds')