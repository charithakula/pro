"""
API Diff/Comparison Service
Compare two OpenAPI specifications and detect changes
Identifies breaking vs non-breaking changes
"""
import json
import hashlib
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from enum import Enum


class ChangeType(str, Enum):
    """Type of change detected"""
    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"
    UNCHANGED = "unchanged"


class ChangeSeverity(str, Enum):
    """Severity of the change"""
    BREAKING = "breaking"          # Will break existing clients
    NON_BREAKING = "non_breaking"  # Safe for existing clients
    INFO = "info"                   # Informational only


class APIDiffService:
    """Service for comparing OpenAPI specifications"""

    # Breaking change patterns
    BREAKING_CHANGES = {
        'path_removed': 'Endpoint removed',
        'method_removed': 'HTTP method removed from endpoint',
        'required_param_added': 'New required parameter added',
        'param_removed': 'Parameter removed',
        'response_removed': 'Response code removed',
        'type_changed': 'Data type changed',
        'required_field_added': 'New required field added in request body',
        'field_removed': 'Field removed from response',
        'security_added': 'New security requirement added',
        'enum_value_removed': 'Enum value removed'
    }

    # Non-breaking change patterns
    NON_BREAKING_CHANGES = {
        'path_added': 'New endpoint added',
        'method_added': 'New HTTP method added to endpoint',
        'optional_param_added': 'New optional parameter added',
        'response_added': 'New response code added',
        'optional_field_added': 'New optional field added',
        'description_changed': 'Description updated',
        'example_changed': 'Example updated',
        'enum_value_added': 'New enum value added',
        'deprecated_added': 'Deprecation warning added'
    }

    def __init__(self):
        self.diff_results = []

    def compare_specs(self, spec1: Dict, spec2: Dict,
                      spec1_name: str = "Original",
                      spec2_name: str = "Modified") -> Dict[str, Any]:
        """
        Compare two OpenAPI specifications

        Args:
            spec1: Original/source specification
            spec2: New/target specification
            spec1_name: Label for first spec
            spec2_name: Label for second spec

        Returns:
            Comprehensive diff report
        """
        self.diff_results = []
        start_time = datetime.now()

        # Basic info comparison
        info_changes = self._compare_info(spec1, spec2)

        # Paths comparison
        path_changes = self._compare_paths(spec1, spec2)

        # Definitions/Schemas comparison
        schema_changes = self._compare_schemas(spec1, spec2)

        # Security comparison
        security_changes = self._compare_security(spec1, spec2)

        # Servers comparison
        server_changes = self._compare_servers(spec1, spec2)

        # Calculate statistics
        all_changes = info_changes + path_changes + schema_changes + security_changes + server_changes

        breaking_count = sum(1 for c in all_changes if c.get('severity') == ChangeSeverity.BREAKING)
        non_breaking_count = sum(1 for c in all_changes if c.get('severity') == ChangeSeverity.NON_BREAKING)
        info_count = sum(1 for c in all_changes if c.get('severity') == ChangeSeverity.INFO)

        # Generate summary
        summary = self._generate_summary(spec1, spec2, all_changes)

        elapsed = (datetime.now() - start_time).total_seconds()

        return {
            'success': True,
            'comparison_time_seconds': elapsed,
            'spec1_name': spec1_name,
            'spec2_name': spec2_name,
            'spec1_hash': self._hash_spec(spec1),
            'spec2_hash': self._hash_spec(spec2),
            'specs_identical': self._hash_spec(spec1) == self._hash_spec(spec2),
            'summary': summary,
            'statistics': {
                'total_changes': len(all_changes),
                'breaking_changes': breaking_count,
                'non_breaking_changes': non_breaking_count,
                'info_changes': info_count,
                'has_breaking_changes': breaking_count > 0
            },
            'changes': {
                'info': info_changes,
                'paths': path_changes,
                'schemas': schema_changes,
                'security': security_changes,
                'servers': server_changes
            },
            'all_changes': all_changes,
            'breaking_changes_list': [c for c in all_changes if c.get('severity') == ChangeSeverity.BREAKING],
            'recommendations': self._generate_recommendations(all_changes)
        }

    def _hash_spec(self, spec: Dict) -> str:
        """Generate SHA256 hash of specification"""
        spec_str = json.dumps(spec, sort_keys=True)
        return hashlib.sha256(spec_str.encode()).hexdigest()

    def _compare_info(self, spec1: Dict, spec2: Dict) -> List[Dict]:
        """Compare API info sections"""
        changes = []
        info1 = spec1.get('info', {})
        info2 = spec2.get('info', {})

        # Compare title
        if info1.get('title') != info2.get('title'):
            changes.append({
                'type': ChangeType.MODIFIED,
                'severity': ChangeSeverity.INFO,
                'category': 'info',
                'field': 'title',
                'path': '/info/title',
                'old_value': info1.get('title'),
                'new_value': info2.get('title'),
                'description': 'API title changed'
            })

        # Compare version
        if info1.get('version') != info2.get('version'):
            changes.append({
                'type': ChangeType.MODIFIED,
                'severity': ChangeSeverity.INFO,
                'category': 'info',
                'field': 'version',
                'path': '/info/version',
                'old_value': info1.get('version'),
                'new_value': info2.get('version'),
                'description': 'API version changed'
            })

        # Compare description
        if info1.get('description') != info2.get('description'):
            changes.append({
                'type': ChangeType.MODIFIED,
                'severity': ChangeSeverity.INFO,
                'category': 'info',
                'field': 'description',
                'path': '/info/description',
                'old_value': info1.get('description', '')[:100] + '...' if len(info1.get('description', '')) > 100 else info1.get('description'),
                'new_value': info2.get('description', '')[:100] + '...' if len(info2.get('description', '')) > 100 else info2.get('description'),
                'description': 'API description changed'
            })

        return changes

    def _compare_paths(self, spec1: Dict, spec2: Dict) -> List[Dict]:
        """Compare API paths/endpoints"""
        changes = []
        paths1 = spec1.get('paths', {})
        paths2 = spec2.get('paths', {})

        all_paths = set(paths1.keys()) | set(paths2.keys())

        for path in all_paths:
            if path not in paths1:
                # New path added
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.NON_BREAKING,
                    'category': 'paths',
                    'field': 'endpoint',
                    'path': path,
                    'new_value': list(paths2[path].keys()) if isinstance(paths2[path], dict) else None,
                    'description': f'New endpoint added: {path}'
                })
            elif path not in paths2:
                # Path removed - BREAKING
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'paths',
                    'field': 'endpoint',
                    'path': path,
                    'old_value': list(paths1[path].keys()) if isinstance(paths1[path], dict) else None,
                    'description': f'Endpoint removed: {path}',
                    'breaking_reason': 'Existing clients using this endpoint will fail'
                })
            else:
                # Path exists in both - compare methods
                method_changes = self._compare_path_methods(path, paths1[path], paths2[path])
                changes.extend(method_changes)

        return changes

    def _compare_path_methods(self, path: str, methods1: Dict, methods2: Dict) -> List[Dict]:
        """Compare HTTP methods for a specific path"""
        changes = []
        http_methods = ['get', 'post', 'put', 'patch', 'delete', 'head', 'options']

        methods1_lower = {k.lower(): v for k, v in methods1.items() if k.lower() in http_methods}
        methods2_lower = {k.lower(): v for k, v in methods2.items() if k.lower() in http_methods}

        all_methods = set(methods1_lower.keys()) | set(methods2_lower.keys())

        for method in all_methods:
            if method not in methods1_lower:
                # New method added
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.NON_BREAKING,
                    'category': 'paths',
                    'field': 'method',
                    'path': f'{path}/{method.upper()}',
                    'description': f'New method added: {method.upper()} {path}'
                })
            elif method not in methods2_lower:
                # Method removed - BREAKING
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'paths',
                    'field': 'method',
                    'path': f'{path}/{method.upper()}',
                    'description': f'Method removed: {method.upper()} {path}',
                    'breaking_reason': 'Existing clients using this method will fail'
                })
            else:
                # Method exists in both - compare details
                operation_changes = self._compare_operation(
                    path, method, methods1_lower[method], methods2_lower[method]
                )
                changes.extend(operation_changes)

        return changes

    def _compare_operation(self, path: str, method: str, op1: Dict, op2: Dict) -> List[Dict]:
        """Compare a specific operation (GET /path, POST /path, etc.)"""
        changes = []
        full_path = f'{path}/{method.upper()}'

        # Compare parameters
        params1 = op1.get('parameters', [])
        params2 = op2.get('parameters', [])
        param_changes = self._compare_parameters(full_path, params1, params2)
        changes.extend(param_changes)

        # Compare responses
        responses1 = op1.get('responses', {})
        responses2 = op2.get('responses', {})
        response_changes = self._compare_responses(full_path, responses1, responses2)
        changes.extend(response_changes)

        # Compare request body (OpenAPI 3.0)
        if 'requestBody' in op1 or 'requestBody' in op2:
            body_changes = self._compare_request_body(full_path, op1.get('requestBody'), op2.get('requestBody'))
            changes.extend(body_changes)

        # Check for deprecation
        if not op1.get('deprecated') and op2.get('deprecated'):
            changes.append({
                'type': ChangeType.MODIFIED,
                'severity': ChangeSeverity.NON_BREAKING,
                'category': 'paths',
                'field': 'deprecated',
                'path': full_path,
                'description': f'Operation marked as deprecated: {method.upper()} {path}'
            })

        return changes

    def _compare_parameters(self, path: str, params1: List, params2: List) -> List[Dict]:
        """Compare operation parameters"""
        changes = []

        # Create param lookup by name and location
        def param_key(p):
            return f"{p.get('name', '')}_{p.get('in', '')}"

        params1_map = {param_key(p): p for p in params1}
        params2_map = {param_key(p): p for p in params2}

        all_params = set(params1_map.keys()) | set(params2_map.keys())

        for key in all_params:
            if key not in params1_map:
                # New parameter
                param = params2_map[key]
                is_required = param.get('required', False)
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.BREAKING if is_required else ChangeSeverity.NON_BREAKING,
                    'category': 'parameters',
                    'field': param.get('name'),
                    'path': f"{path}/parameters/{param.get('name')}",
                    'new_value': {'name': param.get('name'), 'in': param.get('in'), 'required': is_required},
                    'description': f"{'Required' if is_required else 'Optional'} parameter added: {param.get('name')}",
                    'breaking_reason': 'New required parameter will break existing clients' if is_required else None
                })
            elif key not in params2_map:
                # Parameter removed - BREAKING
                param = params1_map[key]
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'parameters',
                    'field': param.get('name'),
                    'path': f"{path}/parameters/{param.get('name')}",
                    'old_value': {'name': param.get('name'), 'in': param.get('in')},
                    'description': f"Parameter removed: {param.get('name')}",
                    'breaking_reason': 'Clients sending this parameter may experience issues'
                })
            else:
                # Parameter exists in both - check for type changes
                p1, p2 = params1_map[key], params2_map[key]
                type1 = p1.get('type') or p1.get('schema', {}).get('type')
                type2 = p2.get('type') or p2.get('schema', {}).get('type')

                if type1 != type2:
                    changes.append({
                        'type': ChangeType.MODIFIED,
                        'severity': ChangeSeverity.BREAKING,
                        'category': 'parameters',
                        'field': p1.get('name'),
                        'path': f"{path}/parameters/{p1.get('name')}/type",
                        'old_value': type1,
                        'new_value': type2,
                        'description': f"Parameter type changed: {p1.get('name')} ({type1} -> {type2})",
                        'breaking_reason': 'Type change may break existing clients'
                    })

                # Check required status change
                if not p1.get('required') and p2.get('required'):
                    changes.append({
                        'type': ChangeType.MODIFIED,
                        'severity': ChangeSeverity.BREAKING,
                        'category': 'parameters',
                        'field': p1.get('name'),
                        'path': f"{path}/parameters/{p1.get('name')}/required",
                        'old_value': False,
                        'new_value': True,
                        'description': f"Parameter now required: {p1.get('name')}",
                        'breaking_reason': 'Clients not sending this parameter will fail'
                    })

        return changes

    def _compare_responses(self, path: str, responses1: Dict, responses2: Dict) -> List[Dict]:
        """Compare operation responses"""
        changes = []

        all_codes = set(str(k) for k in responses1.keys()) | set(str(k) for k in responses2.keys())

        for code in all_codes:
            if code not in [str(k) for k in responses1.keys()]:
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.NON_BREAKING,
                    'category': 'responses',
                    'field': code,
                    'path': f"{path}/responses/{code}",
                    'description': f"New response code added: {code}"
                })
            elif code not in [str(k) for k in responses2.keys()]:
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.NON_BREAKING,  # Response removal is usually not breaking
                    'category': 'responses',
                    'field': code,
                    'path': f"{path}/responses/{code}",
                    'description': f"Response code removed: {code}"
                })

        return changes

    def _compare_request_body(self, path: str, body1: Optional[Dict], body2: Optional[Dict]) -> List[Dict]:
        """Compare request body definitions"""
        changes = []

        if body1 is None and body2 is not None:
            is_required = body2.get('required', False)
            changes.append({
                'type': ChangeType.ADDED,
                'severity': ChangeSeverity.BREAKING if is_required else ChangeSeverity.NON_BREAKING,
                'category': 'requestBody',
                'path': f"{path}/requestBody",
                'description': f"Request body added ({'required' if is_required else 'optional'})",
                'breaking_reason': 'New required request body will break existing clients' if is_required else None
            })
        elif body1 is not None and body2 is None:
            changes.append({
                'type': ChangeType.REMOVED,
                'severity': ChangeSeverity.BREAKING,
                'category': 'requestBody',
                'path': f"{path}/requestBody",
                'description': "Request body removed",
                'breaking_reason': 'Clients sending request body may experience issues'
            })

        return changes

    def _compare_schemas(self, spec1: Dict, spec2: Dict) -> List[Dict]:
        """Compare schema definitions"""
        changes = []

        # Get schemas from both Swagger 2.0 and OpenAPI 3.0 formats
        schemas1 = spec1.get('definitions', {}) or spec1.get('components', {}).get('schemas', {})
        schemas2 = spec2.get('definitions', {}) or spec2.get('components', {}).get('schemas', {})

        all_schemas = set(schemas1.keys()) | set(schemas2.keys())

        for schema_name in all_schemas:
            if schema_name not in schemas1:
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.NON_BREAKING,
                    'category': 'schemas',
                    'field': schema_name,
                    'path': f"/schemas/{schema_name}",
                    'description': f"New schema added: {schema_name}"
                })
            elif schema_name not in schemas2:
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'schemas',
                    'field': schema_name,
                    'path': f"/schemas/{schema_name}",
                    'description': f"Schema removed: {schema_name}",
                    'breaking_reason': 'Schema removal may break clients depending on this definition'
                })
            else:
                # Compare schema properties
                prop_changes = self._compare_schema_properties(
                    schema_name, schemas1[schema_name], schemas2[schema_name]
                )
                changes.extend(prop_changes)

        return changes

    def _compare_schema_properties(self, schema_name: str, schema1: Dict, schema2: Dict) -> List[Dict]:
        """Compare properties within a schema"""
        changes = []

        props1 = schema1.get('properties', {})
        props2 = schema2.get('properties', {})
        required1 = set(schema1.get('required', []))
        required2 = set(schema2.get('required', []))

        all_props = set(props1.keys()) | set(props2.keys())

        for prop_name in all_props:
            if prop_name not in props1:
                # New property
                is_required = prop_name in required2
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.BREAKING if is_required else ChangeSeverity.NON_BREAKING,
                    'category': 'schemas',
                    'field': f"{schema_name}.{prop_name}",
                    'path': f"/schemas/{schema_name}/properties/{prop_name}",
                    'description': f"{'Required' if is_required else 'Optional'} property added to {schema_name}: {prop_name}",
                    'breaking_reason': 'New required property will break existing clients' if is_required else None
                })
            elif prop_name not in props2:
                # Property removed
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'schemas',
                    'field': f"{schema_name}.{prop_name}",
                    'path': f"/schemas/{schema_name}/properties/{prop_name}",
                    'description': f"Property removed from {schema_name}: {prop_name}",
                    'breaking_reason': 'Clients expecting this property may fail'
                })
            else:
                # Check type change
                type1 = props1[prop_name].get('type')
                type2 = props2[prop_name].get('type')
                if type1 != type2:
                    changes.append({
                        'type': ChangeType.MODIFIED,
                        'severity': ChangeSeverity.BREAKING,
                        'category': 'schemas',
                        'field': f"{schema_name}.{prop_name}",
                        'path': f"/schemas/{schema_name}/properties/{prop_name}/type",
                        'old_value': type1,
                        'new_value': type2,
                        'description': f"Property type changed in {schema_name}.{prop_name}: {type1} -> {type2}",
                        'breaking_reason': 'Type change may break existing clients'
                    })

        # Check required changes
        newly_required = required2 - required1
        for prop in newly_required:
            if prop in props1:  # Only if property already existed
                changes.append({
                    'type': ChangeType.MODIFIED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'schemas',
                    'field': f"{schema_name}.{prop}",
                    'path': f"/schemas/{schema_name}/required",
                    'description': f"Property now required in {schema_name}: {prop}",
                    'breaking_reason': 'Clients not providing this property will fail'
                })

        return changes

    def _compare_security(self, spec1: Dict, spec2: Dict) -> List[Dict]:
        """Compare security definitions"""
        changes = []

        # Get security definitions
        sec1 = spec1.get('securityDefinitions', {}) or spec1.get('components', {}).get('securitySchemes', {})
        sec2 = spec2.get('securityDefinitions', {}) or spec2.get('components', {}).get('securitySchemes', {})

        all_schemes = set(sec1.keys()) | set(sec2.keys())

        for scheme in all_schemes:
            if scheme not in sec1:
                changes.append({
                    'type': ChangeType.ADDED,
                    'severity': ChangeSeverity.BREAKING,
                    'category': 'security',
                    'field': scheme,
                    'path': f"/security/{scheme}",
                    'description': f"New security scheme added: {scheme}",
                    'breaking_reason': 'New security requirement may require client updates'
                })
            elif scheme not in sec2:
                changes.append({
                    'type': ChangeType.REMOVED,
                    'severity': ChangeSeverity.NON_BREAKING,
                    'category': 'security',
                    'field': scheme,
                    'path': f"/security/{scheme}",
                    'description': f"Security scheme removed: {scheme}"
                })

        return changes

    def _compare_servers(self, spec1: Dict, spec2: Dict) -> List[Dict]:
        """Compare server definitions (OpenAPI 3.0)"""
        changes = []

        servers1 = spec1.get('servers', [])
        servers2 = spec2.get('servers', [])

        # Also check basePath for Swagger 2.0
        base1 = spec1.get('basePath', '')
        base2 = spec2.get('basePath', '')

        if base1 != base2:
            changes.append({
                'type': ChangeType.MODIFIED,
                'severity': ChangeSeverity.INFO,
                'category': 'servers',
                'field': 'basePath',
                'path': '/basePath',
                'old_value': base1,
                'new_value': base2,
                'description': f"Base path changed: {base1} -> {base2}"
            })

        # Compare server URLs
        urls1 = set(s.get('url', '') for s in servers1)
        urls2 = set(s.get('url', '') for s in servers2)

        for url in urls2 - urls1:
            changes.append({
                'type': ChangeType.ADDED,
                'severity': ChangeSeverity.INFO,
                'category': 'servers',
                'field': 'url',
                'path': '/servers',
                'new_value': url,
                'description': f"Server URL added: {url}"
            })

        for url in urls1 - urls2:
            changes.append({
                'type': ChangeType.REMOVED,
                'severity': ChangeSeverity.INFO,
                'category': 'servers',
                'field': 'url',
                'path': '/servers',
                'old_value': url,
                'description': f"Server URL removed: {url}"
            })

        return changes

    def _generate_summary(self, spec1: Dict, spec2: Dict, changes: List[Dict]) -> Dict:
        """Generate a human-readable summary of the comparison"""
        info1 = spec1.get('info', {})
        info2 = spec2.get('info', {})

        paths1 = len(spec1.get('paths', {}))
        paths2 = len(spec2.get('paths', {}))

        breaking = [c for c in changes if c.get('severity') == ChangeSeverity.BREAKING]

        return {
            'spec1': {
                'title': info1.get('title', 'Unknown'),
                'version': info1.get('version', 'Unknown'),
                'paths_count': paths1
            },
            'spec2': {
                'title': info2.get('title', 'Unknown'),
                'version': info2.get('version', 'Unknown'),
                'paths_count': paths2
            },
            'paths_added': paths2 - paths1 if paths2 > paths1 else 0,
            'paths_removed': paths1 - paths2 if paths1 > paths2 else 0,
            'has_breaking_changes': len(breaking) > 0,
            'breaking_summary': [c.get('description') for c in breaking[:5]],  # Top 5 breaking changes
            'compatibility': 'INCOMPATIBLE' if breaking else 'COMPATIBLE'
        }

    def _generate_recommendations(self, changes: List[Dict]) -> List[str]:
        """Generate recommendations based on detected changes"""
        recommendations = []

        breaking = [c for c in changes if c.get('severity') == ChangeSeverity.BREAKING]

        if breaking:
            recommendations.append(
                f"CRITICAL: {len(breaking)} breaking change(s) detected. "
                "These changes may break existing API clients."
            )
            recommendations.append(
                "Consider incrementing the major version number (e.g., v1 -> v2)."
            )
            recommendations.append(
                "Communicate changes to all API consumers before deployment."
            )

            # Specific recommendations
            removed_endpoints = [c for c in breaking if 'endpoint' in c.get('description', '').lower() and c['type'] == ChangeType.REMOVED]
            if removed_endpoints:
                recommendations.append(
                    f"Consider deprecating {len(removed_endpoints)} endpoint(s) instead of removing them immediately."
                )

            required_params = [c for c in breaking if 'required' in c.get('description', '').lower()]
            if required_params:
                recommendations.append(
                    "New required parameters/fields should have default values if possible."
                )
        else:
            recommendations.append(
                "No breaking changes detected. This update appears backward compatible."
            )
            recommendations.append(
                "Consider incrementing the minor or patch version number."
            )

        return recommendations


# Singleton instance
api_diff_service = APIDiffService()
