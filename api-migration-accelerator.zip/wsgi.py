"""
WSGI Entry Point for Production Deployment

Used by Gunicorn/other WSGI servers (e.g., Azure App Services)
This file should be in the same directory as app.py

Usage:
    gunicorn --workers 4 --bind 0.0.0.0:8000 --timeout 60 wsgi:application
"""

import os
import sys
import logging
from dotenv import load_dotenv

# ============================================================================
# STEP 1: LOAD ENVIRONMENT VARIABLES FIRST (CRITICAL)
# ============================================================================
load_dotenv(override=True)  # Use override=True to ensure .env values take precedence

# ============================================================================
# STEP 2: SETUP LOGGING (for debugging deployment issues)
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

logger.info("=" * 80)
logger.info("WSGI ENTRY POINT - Production Deployment")
logger.info("=" * 80)

# ============================================================================
# STEP 3: VERIFY ENVIRONMENT SETUP
# ============================================================================
flask_env = os.getenv('API_ENV', 'production')
logger.info(f"Flask Environment: {flask_env}")
logger.info(f"Python Version: {sys.version.split()[0]}")
logger.info(f"Working Directory: {os.getcwd()}")

# Verify critical environment variables
required_vars = ['API_DB_HOST', 'API_DB_PORT', 'API_DB_NAME', 'API_DB_USER', 'API_DB_PASSWORD']
missing_vars = [var for var in required_vars if not os.getenv(var)]
if missing_vars:
    logger.warning(f"Missing environment variables: {', '.join(missing_vars)}")
    logger.info("  Add these to Azure App Services -> Configuration -> Application settings")
else:
    logger.info(f"Database environment variables: LOADED")

# ============================================================================
# STEP 4: IMPORT APP FACTORY
# ============================================================================
try:
    from app import create_app
    logger.info("App factory imported successfully")
except ImportError as import_err:
    logger.critical(f"Failed to import app factory: {import_err}")
    sys.exit(1)

# ============================================================================
# STEP 5: CREATE APPLICATION INSTANCE FOR WSGI
# ============================================================================
try:
    logger.info(f"\nCreating Flask application in '{flask_env}' mode...")
    application = create_app()
    logger.info("Flask application created successfully\n")
except Exception as app_err:
    logger.critical(f"Failed to create application: {app_err}")
    import traceback
    logger.critical(traceback.format_exc())
    sys.exit(1)

# ============================================================================
# STEP 6: APPLICATION READY FOR WSGI SERVER
# ============================================================================
logger.info("=" * 80)
logger.info("APPLICATION READY FOR GUNICORN/WSGI SERVER")
logger.info("=" * 80)
logger.info("\nStartup Command for Azure App Services:")
logger.info("   gunicorn --workers 4 --bind 0.0.0.0:8000 --timeout 60 wsgi:application")
logger.info("\nApp Features Enabled:")
logger.info("   - API Migration Accelerator")
logger.info("   - Azure OpenAI Integration")
logger.info("   - Azure APIM Connector")
logger.info("   - Azure Blob Storage (Lazy Loading)")
logger.info("   - PostgreSQL Database")
logger.info("\n" + "=" * 80 + "\n")

# ============================================================================
# DEVELOPMENT ONLY - FOR LOCAL TESTING
# For windows: waitress-serve --port=5000 wsgi:application
# netstat -ano | findstr :5000
# ============================================================================
if __name__ == '__main__':
    try:
        logger.warning("Running in development mode (not recommended for production)")
        logger.info("   For production, use: gunicorn wsgi:application")
        logger.info("   Starting Flask development server on http://0.0.0.0:8000\n")

        # Development server (Flask built-in)
        application.run(
            host='0.0.0.0',
            port=5000,
            debug=False,
            use_reloader=True,
            use_debugger=True
        )
    except Exception as dev_err:
        logger.critical(f"Error running development server: {dev_err}")
        import traceback
        logger.critical(traceback.format_exc())
        sys.exit(1)
