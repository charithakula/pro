# API Migration Tool

A comprehensive tool for migrating APIs from IBM API Connect (OpenAPI 2.0) to Azure API Management (OpenAPI 3.0) using Azure OpenAI for intelligent conversion.

## 🚀 Features

### Core Capabilities
- **Intelligent Conversion**: AI-powered OpenAPI 2.0 to 3.0 conversion using Azure OpenAI
- **Automated Migration**: End-to-end API migration from IBM API Connect to Azure APIM
- **Batch Processing**: Migrate multiple APIs or entire catalogs in one operation
- **Validation & Quality Assurance**: Comprehensive validation of API specifications
- **Web Interface**: User-friendly dashboard for managing migrations
- **Progress Tracking**: Real-time migration status and detailed logging
- **Rollback Support**: Ability to rollback completed migrations

### Platform Integrations
- **IBM API Connect**: Extract APIs from IBM API Connect and Developer Portal
- **Azure API Management**: Deploy converted APIs to Azure APIM
- **Azure OpenAI**: Leverage GPT models for accurate API conversion
- **File Upload**: Support for manual OpenAPI specification uploads

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   IBM API       │    │   Azure OpenAI  │    │   Azure APIM    │
│   Connect       │────▶│   Conversion    │────▶│   Deployment    │
│                 │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│  Extraction     │    │   Validation    │    │   Management    │
│  Service        │    │   Service       │    │   Dashboard     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 ▼
                    ┌─────────────────┐
                    │   Migration     │
                    │   Orchestration │
                    └─────────────────┘
```

### Components
- **Connectors**: Interface with external services (IBM, Azure APIM, Azure OpenAI)
- **Services**: Business logic for conversion, migration, and validation
- **Models**: Data models and database management
- **Utils**: Utility functions and helpers
- **Web Interface**: Flask-based dashboard and API endpoints

## 📋 Prerequisites

### Required Services
- **Azure Subscription** with access to:
  - Azure API Management instance
  - Azure OpenAI service
  - Azure Active Directory (for service principal)
- **IBM API Connect** access with:
  - Valid credentials
  - Organization and catalog permissions

### System Requirements
- Python 3.8+
- 2GB+ RAM
- 1GB+ storage space
- **Database**: SQLite (development) or PostgreSQL (production)

## 🛠️ Installation

### 1. Clone the Repository
```bash
git clone <repository-url>
cd api-migration-tool
```

### 2. Create Virtual Environment
```bash
python -m venv api-migration-env
source api-migration-env/bin/activate  # On Windows: api-migration-env\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Create Environment Configuration
```bash
cp .env.example .env
```

### 5. Configure Environment Variables
Edit `.env` file with your service credentials:

```bash
# Azure Authentication (Service Principal)
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_TENANT_ID=your-tenant-id
AZURE_SUBSCRIPTION_ID=your-subscription-id

# Azure OpenAI
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-openai-api-key
AZURE_OPENAI_DEPLOYMENT=your-deployment-name
AZURE_OPENAI_VERSION=2024-02-15-preview

# Azure API Management
AZURE_APIM_RESOURCE_GROUP=your-resource-group
AZURE_APIM_SERVICE_NAME=your-apim-service-name

# IBM API Connect
IBM_API_CONNECT_URL=https://your-ibm-api-connect-url
IBM_API_CONNECT_USERNAME=your-username
IBM_API_CONNECT_PASSWORD=your-password
IBM_API_CONNECT_ORG=your-organization
IBM_API_CONNECT_CATALOG=your-catalog

# Flask Configuration
FLASK_SECRET_KEY=your-secret-key-change-this-in-production
FLASK_DEBUG=False  # Set to True for development
```

## ⚙️ Setup Guide

### Azure Service Principal Setup

1. **Register Application in Azure AD**
   ```bash
   az ad app create --display-name "API Migration Tool"
   ```

2. **Create Service Principal**
   ```bash
   az ad sp create --id <application-id>
   ```

3. **Generate Client Secret**
   ```bash
   az ad app credential reset --id <application-id>
   ```

4. **Assign Permissions**
   ```bash
   # API Management Contributor
   az role assignment create --assignee <service-principal-id> \
     --role "API Management Service Contributor" \
     --scope /subscriptions/<subscription-id>
   
   # Cognitive Services OpenAI User
   az role assignment create --assignee <service-principal-id> \
     --role "Cognitive Services OpenAI User" \
     --scope /subscriptions/<subscription-id>
   ```

### Database Initialization

#### SQLite (Development)
```bash
# Default - automatically creates migrations.db
python app.py
```

#### PostgreSQL (Production)
```bash
# 1. Install PostgreSQL driver
pip install psycopg2-binary

# 2. Set up PostgreSQL (see docs/postgresql_setup.md)
createdb api_migration_db

# 3. Configure environment
export DATABASE_URL="postgresql://user:password@localhost:5432/api_migration_db"

# 4. Create database schema
python create_database.py
```

See [PostgreSQL Setup Guide](docs/postgresql_setup.md) for detailed instructions.

## 🚀 Usage

### 1. Start the Application
```bash
python app.py
```

The application will be available at `http://localhost:5000`

### 2. Web Interface

#### Dashboard
- View service status and migration statistics
- Quick access to common operations
- Recent migration history

#### Upload & Convert
- Upload OpenAPI 2.0 specifications
- Preview conversion changes
- Convert to OpenAPI 3.0
- Deploy to Azure APIM

#### Migration History
- View all completed migrations
- Download conversion results
- Rollback migrations
- Filter and search history

### 3. API Endpoints

#### Health Check
```bash
GET /api/health
```

#### Upload File
```bash
POST /api/upload
Content-Type: multipart/form-data
```

#### Convert Specification
```bash
POST /api/convert
Content-Type: application/json

{
  "spec_content": "...",
  "source_format": "auto"
}
```

#### Migrate Single API
```bash
POST /api/migrate
Content-Type: application/json

{
  "api_ids": "api-id",
  "org_name": "organization",
  "options": {
    "create_product": true
  }
}
```

#### Batch Migration
```bash
POST /api/migrate/batch
Content-Type: application/json

{
  "migration_type": "apis",
  "api_ids": ["api1", "api2"],
  "org_name": "organization"
}
```

### 4. Command Line Usage

#### Test Connections
```bash
python -c "
from connectors import *
print('IBM:', IBMAPIConnector().test_connection())
print('Azure APIM:', AzureAPIMConnector().test_connection())
print('Azure OpenAI:', AzureOpenAIConnector().test_connection())
"
```

#### Convert Single File
```bash
python -c "
from services import ConversionService
import json

service = ConversionService()
with open('api-spec.json', 'r') as f:
    result = service.convert_specification(f.read())
    
print(json.dumps(result['converted_spec'], indent=2))
"
```

## 📚 API Documentation

### REST API Endpoints

| Endpoint | Method | Description |
|----------|---------|-------------|
| `/api/health` | GET | Service health check |
| `/api/upload` | POST | Upload API specification |
| `/api/convert` | POST | Convert OpenAPI 2.0 to 3.0 |
| `/api/convert/preview` | POST | Preview conversion changes |
| `/api/migrate` | POST | Migrate single API |
| `/api/migrate/batch` | POST | Batch migrate APIs |
| `/api/migrate/prerequisites` | GET | Check migration prerequisites |
| `/api/migrations` | GET | List migrations |
| `/api/migrations/{id}` | GET | Get migration details |
| `/api/migrations/{id}/rollback` | POST | Rollback migration |
| `/api/ibm/apis` | GET | List IBM APIs |
| `/api/azure/apis` | GET | List Azure APIs |
| `/api/statistics` | GET | Application statistics |

### Response Formats

#### Success Response
```json
{
  "status": "success",
  "data": {...},
  "message": "Operation completed successfully"
}
```

#### Error Response
```json
{
  "status": "error",
  "message": "Error description",
  "error_code": "ERROR_CODE"
}
```

## 🧪 Testing

### Run All Tests
```bash
pytest
```

### Run Specific Test Categories
```bash
# Connector tests
pytest tests/test_connectors.py

# Service tests
pytest tests/test_services.py

# Application tests
pytest tests/test_app.py
```

### Run with Coverage
```bash
pytest --cov=. --cov-report=html
```

### Integration Tests
```bash
# Requires real service credentials
pytest tests/ -m integration
```

## 🛡️ Security Considerations

### Credentials Management
- Use environment variables for all secrets
- Never commit credentials to version control
- Rotate secrets regularly
- Use Azure Key Vault in production

### File Upload Security
- File type validation enforced
- Size limits configured (16MB max)
- Content validation before processing
- Temporary file cleanup

### API Security
- Input validation on all endpoints
- Rate limiting recommended for production
- HTTPS enforced in production
- CORS configured appropriately

## 📊 Monitoring & Logging

### Application Logs
Logs are stored in `logs/app.log` with rotation:
```bash
# View recent logs
tail -f logs/app.log

# Search for errors
grep ERROR logs/app.log
```

### Migration Tracking
- All migrations stored in SQLite database
- Detailed logging per migration stage
- Performance metrics collected
- Error tracking and reporting

## 🚢 Production Deployment

### Environment Setup
1. Use production-grade WSGI server:
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:8000 app:app
   ```

2. Configure reverse proxy (nginx):
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://localhost:8000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

3. Use production database (PostgreSQL recommended):
   ```bash
   # PostgreSQL
   DATABASE_URL=postgresql://user:password@localhost:5432/api_migration_db
   
   # Azure Database for PostgreSQL
   DATABASE_URL=postgresql://user@server:password@server.postgres.database.azure.com:5432/dbname?sslmode=require
   
   # AWS RDS
   DATABASE_URL=postgresql://user:password@instance.region.rds.amazonaws.com:5432/dbname
   ```

4. Enable HTTPS with SSL certificates
5. Configure monitoring and alerting
6. Set up automated backups

### Docker Deployment
```dockerfile
FROM python:3.9

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:8000", "app:app"]
```

## 🔧 Troubleshooting

### Common Issues

#### Authentication Errors
```
Error: Azure APIM client not initialized
```
**Solution**: Verify Azure service principal credentials and permissions

#### OpenAI Connection Issues
```
Error: Azure OpenAI connection failed
```
**Solution**: Check endpoint URL, API key, and deployment name

#### IBM API Connect Timeout
```
Error: IBM API Connect session not available
```
**Solution**: Verify IBM credentials and network connectivity

#### File Upload Failures
```
Error: File too large
```
**Solution**: Check file size limit in configuration

### Debug Mode
Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
python app.py
```

### Health Check Endpoints
```bash
# Check service status
curl http://localhost:5000/api/health

# Test specific connector
python -c "from connectors import AzureOpenAIConnector; print(AzureOpenAIConnector().test_connection())"
```

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Install dev dependencies: `pip install -r requirements-dev.txt`
4. Make changes and add tests
5. Run tests: `pytest`
6. Submit pull request

### Code Standards
- Follow PEP 8 style guidelines
- Add docstrings to all functions
- Include unit tests for new features
- Update documentation for API changes

### Project Structure
```
api-migration-tool/
├── app.py                  # Main application
├── config.py              # Configuration
├── requirements.txt       # Dependencies
├── connectors/            # External service connectors
├── services/              # Business logic
├── models/                # Data models
├── utils/                 # Utilities
├── templates/             # HTML templates
├── static/                # Static assets
└── tests/                 # Test suite
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

### Documentation
- API documentation: `/docs` endpoint (when running)
- Configuration examples: `.env.example`
- Test examples: `tests/` directory

### Community
- GitHub Issues: Report bugs and request features
- Discussions: Ask questions and share tips

### Commercial Support
For enterprise support and custom implementations, please contact the development team.

## 📈 Roadmap

### Planned Features
- [ ] Support for additional API formats (AsyncAPI, GraphQL)
- [ ] Advanced transformation rules engine
- [ ] Multi-tenant support
- [ ] Kubernetes deployment charts
- [ ] API lifecycle management integration
- [ ] Advanced analytics and reporting
- [ ] Plugin system for custom connectors

### Current Version: 1.0.0
- ✅ OpenAPI 2.0 to 3.0 conversion
- ✅ IBM API Connect integration
- ✅ Azure APIM deployment
- ✅ Web dashboard
- ✅ Batch migration support
- ✅ Migration history tracking

---

## Quick Start Checklist

- [ ] Python 3.8+ installed
- [ ] Virtual environment created
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] Environment variables configured (`.env` file)
- [ ] Azure service principal created and configured
- [ ] IBM API Connect credentials obtained
- [ ] Application started (`python app.py`)
- [ ] Health check passed (`curl http://localhost:5000/api/health`)
- [ ] First migration test completed

**Happy migrating! 🚀**