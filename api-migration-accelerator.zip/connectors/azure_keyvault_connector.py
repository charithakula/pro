"""
Azure Key Vault Connector
Fetches secrets from Azure Key Vault with fallback to environment variables.

Usage:
    from connectors.azure_keyvault_connector import KeyVaultConfig

    config = KeyVaultConfig()
    db_password = config.get_secret('API-DB-PASSWORD')

Environment Variables Required:
    API_KEYVAULT_URL - Key Vault URL (e.g., https://mykeyvault.vault.azure.net/)

    Authentication (one of):
    - API_KEYVAULT_CLIENT_ID, API_KEYVAULT_CLIENT_SECRET, API_KEYVAULT_TENANT_ID
    - Or use Managed Identity (no credentials needed in Azure)
"""

import os
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)


class KeyVaultConnector:
    """
    Azure Key Vault connector with environment variable fallback.

    Naming Convention:
    - Environment variables: API_DB_PASSWORD (underscores)
    - Key Vault secrets: API-DB-PASSWORD (hyphens, as required by Key Vault)
    """

    def __init__(self):
        """Initialize Key Vault connection"""
        self.client = None
        self.vault_url = os.getenv('API_KEYVAULT_URL')
        self.is_available = False
        self._cache: Dict[str, str] = {}

        if not self.vault_url:
            logger.info("ℹ️  Key Vault not configured (API_KEYVAULT_URL not set)")
            logger.info("   Using environment variables for configuration")
            return

        try:
            from azure.identity import DefaultAzureCredential, ClientSecretCredential
            from azure.keyvault.secrets import SecretClient

            # Try client credentials first (for local development)
            client_id = os.getenv('API_KEYVAULT_CLIENT_ID')
            client_secret = os.getenv('API_KEYVAULT_CLIENT_SECRET')
            tenant_id = os.getenv('API_KEYVAULT_TENANT_ID')

            if client_id and client_secret and tenant_id:
                logger.info("🔐 Connecting to Key Vault with client credentials...")
                credential = ClientSecretCredential(
                    tenant_id=tenant_id,
                    client_id=client_id,
                    client_secret=client_secret
                )
            else:
                # Use DefaultAzureCredential (Managed Identity in Azure, CLI locally)
                logger.info("🔐 Connecting to Key Vault with DefaultAzureCredential...")
                credential = DefaultAzureCredential()

            self.client = SecretClient(vault_url=self.vault_url, credential=credential)

            # Test connection
            try:
                # Try to list secrets (limited to 1) to verify connection
                list(self.client.list_properties_of_secrets(max_page_size=1))
                self.is_available = True
                logger.info(f"✅ Key Vault connected: {self.vault_url}")
            except Exception as test_error:
                logger.warning(f"⚠️  Key Vault connection test failed: {test_error}")
                self.is_available = False

        except ImportError:
            logger.warning("⚠️  Azure Key Vault SDK not installed")
            logger.info("   Install with: pip install azure-keyvault-secrets azure-identity")
        except Exception as e:
            logger.error(f"❌ Key Vault initialization failed: {e}")
            self.is_available = False

    def get_secret(self, name: str, default: Optional[str] = None) -> Optional[str]:
        """
        Get a secret from Key Vault with environment variable fallback.

        Args:
            name: Secret name (use underscores, will be converted to hyphens for Key Vault)
            default: Default value if not found

        Returns:
            Secret value or default

        Example:
            # Will check Key Vault for 'API-DB-PASSWORD', then env var 'API_DB_PASSWORD'
            password = config.get_secret('API_DB_PASSWORD', 'default_pass')
        """
        # Check cache first
        if name in self._cache:
            return self._cache[name]

        # Convert underscores to hyphens for Key Vault (Key Vault doesn't allow underscores)
        kv_name = name.replace('_', '-')

        # Try Key Vault first
        if self.is_available and self.client:
            try:
                secret = self.client.get_secret(kv_name)
                value = secret.value
                self._cache[name] = value
                logger.debug(f"🔐 Secret '{kv_name}' retrieved from Key Vault")
                return value
            except Exception as e:
                logger.debug(f"Secret '{kv_name}' not in Key Vault: {e}")

        # Fall back to environment variable
        env_value = os.getenv(name)
        if env_value is not None:
            self._cache[name] = env_value
            logger.debug(f"📋 Config '{name}' retrieved from environment")
            return env_value

        # Return default
        return default

    def get_secret_bool(self, name: str, default: bool = False) -> bool:
        """Get a secret as boolean"""
        value = self.get_secret(name)
        if value is None:
            return default
        return value.lower() in ('true', '1', 'yes', 'on')

    def get_secret_int(self, name: str, default: int = 0) -> int:
        """Get a secret as integer"""
        value = self.get_secret(name)
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            return default

    def clear_cache(self):
        """Clear the secret cache"""
        self._cache.clear()
        logger.info("🗑️  Secret cache cleared")

    def test_connection(self) -> Dict[str, Any]:
        """Test Key Vault connection"""
        if not self.vault_url:
            return {
                'success': False,
                'message': 'Key Vault not configured',
                'using': 'environment_variables'
            }

        if not self.is_available:
            return {
                'success': False,
                'message': 'Key Vault connection failed',
                'vault_url': self.vault_url
            }

        return {
            'success': True,
            'message': 'Key Vault connected',
            'vault_url': self.vault_url
        }


# Global instance
_keyvault_instance: Optional[KeyVaultConnector] = None


def get_keyvault() -> KeyVaultConnector:
    """Get or create Key Vault connector instance"""
    global _keyvault_instance
    if _keyvault_instance is None:
        _keyvault_instance = KeyVaultConnector()
    return _keyvault_instance


def get_config(name: str, default: Optional[str] = None) -> Optional[str]:
    """
    Convenience function to get config value from Key Vault or environment.

    Usage:
        from connectors.azure_keyvault_connector import get_config
        db_host = get_config('API_DB_HOST', 'localhost')
    """
    return get_keyvault().get_secret(name, default)


def get_config_bool(name: str, default: bool = False) -> bool:
    """Get config as boolean"""
    return get_keyvault().get_secret_bool(name, default)


def get_config_int(name: str, default: int = 0) -> int:
    """Get config as integer"""
    return get_keyvault().get_secret_int(name, default)
