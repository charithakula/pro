"""
Azure Storage Connector - Lazy Loading Version
Handles Azure Blob Storage operations with lazy initialization to avoid app startup delays.

Usage:
    from connectors.azure_storage_connector import AzureStorageConnector

    # Get singleton instance (lazy loaded)
    storage = AzureStorageConnector.get_instance()

    # Check if available before using
    if storage.is_available:
        result = storage.upload_file(content, 'path/to/file.json')
"""
import os
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
import threading

logger = logging.getLogger(__name__)


class AzureStorageConnector:
    """
    Azure Blob Storage connector with lazy initialization.

    Features:
    - Lazy loading: Only connects when first used
    - Singleton pattern: Single instance across app
    - Thread-safe initialization
    - Automatic fallback to local storage
    - SSL configuration support
    """

    _instance = None
    _lock = threading.Lock()
    _initialized = False

    def __init__(self):
        """Initialize connector (but don't connect yet)"""
        self._client = None
        self._container_client = None
        self._connection_string = None
        self._account_name = None
        self._container_name = None
        self._use_azure = False
        self._init_error = None
        self._verify_ssl = True

    @classmethod
    def get_instance(cls) -> 'AzureStorageConnector':
        """Get singleton instance (thread-safe)"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        """Reset singleton instance (for testing)"""
        with cls._lock:
            cls._instance = None
            cls._initialized = False

    def _lazy_init(self) -> bool:
        """
        Lazy initialization - only called when storage is first accessed.
        This prevents app startup delays.
        """
        if self._initialized:
            return self._use_azure

        with self._lock:
            if self._initialized:
                return self._use_azure

            logger.info("=" * 60)
            logger.info("AZURE STORAGE CONNECTOR - LAZY INITIALIZATION")
            logger.info("=" * 60)

            try:
                # Get configuration from environment
                self._connection_string = os.getenv('API_STORAGE_CONNECTION_STRING')
                self._account_name = os.getenv('API_STORAGE_ACCOUNT_NAME')
                self._container_name = os.getenv('API_STORAGE_CONTAINER_NAME', 'uploads')
                self._verify_ssl = os.getenv('API_STORAGE_VERIFY_SSL', 'True').lower() == 'true'

                logger.info(f"Configuration:")
                logger.info(f"  Connection String: {'SET' if self._connection_string else 'NOT SET'}")
                logger.info(f"  Account Name: {self._account_name or 'NOT SET'}")
                logger.info(f"  Container: {self._container_name}")
                logger.info(f"  SSL Verify: {self._verify_ssl}")

                # Check if Azure is configured
                if not self._connection_string and not self._account_name:
                    logger.info("Azure Storage not configured - will use local storage")
                    self._use_azure = False
                    self._initialized = True
                    return False

                # Import Azure SDK (only when needed)
                from azure.storage.blob import BlobServiceClient

                # Connect to Azure
                if self._connection_string:
                    logger.info("Connecting with connection string...")
                    try:
                        if self._verify_ssl:
                            self._client = BlobServiceClient.from_connection_string(
                                self._connection_string
                            )
                        else:
                            self._client = BlobServiceClient.from_connection_string(
                                self._connection_string,
                                connection_verify=False
                            )
                            logger.warning("SSL verification DISABLED")
                    except Exception as ssl_error:
                        if self._verify_ssl:
                            logger.warning(f"SSL connection failed, retrying without SSL: {ssl_error}")
                            self._client = BlobServiceClient.from_connection_string(
                                self._connection_string,
                                connection_verify=False
                            )
                        else:
                            raise

                elif self._account_name:
                    logger.info("Connecting with account key...")
                    account_key = os.getenv('API_STORAGE_ACCOUNT_KEY')
                    if not account_key:
                        raise ValueError("API_STORAGE_ACCOUNT_KEY not set")

                    self._client = BlobServiceClient(
                        account_url=f"https://{self._account_name}.blob.core.windows.net",
                        credential=account_key
                    )

                # Get or create container
                self._container_client = self._get_or_create_container()

                self._use_azure = True
                self._initialized = True

                logger.info(f"Azure Storage connected successfully")
                logger.info(f"  Container: {self._container_name}")
                logger.info("=" * 60)

                return True

            except ImportError as ie:
                logger.warning(f"azure-storage-blob not installed: {ie}")
                logger.warning("Install with: pip install azure-storage-blob")
                self._init_error = str(ie)
                self._use_azure = False
                self._initialized = True
                return False

            except Exception as e:
                logger.error(f"Azure Storage initialization failed: {e}")
                self._init_error = str(e)
                self._use_azure = False
                self._initialized = True
                return False

    def _get_or_create_container(self):
        """Get or create blob container"""
        try:
            container_client = self._client.get_container_client(self._container_name)
            try:
                container_client.get_container_properties()
                logger.info(f"Container '{self._container_name}' exists")
            except Exception:
                logger.info(f"Creating container '{self._container_name}'...")
                container_client = self._client.create_container(self._container_name)
                logger.info(f"Container created")
            return container_client
        except Exception as e:
            logger.error(f"Failed to get/create container: {e}")
            raise

    @property
    def is_available(self) -> bool:
        """Check if Azure Storage is available (triggers lazy init)"""
        self._lazy_init()
        return self._use_azure and self._container_client is not None

    @property
    def is_initialized(self) -> bool:
        """Check if connector has been initialized"""
        return self._initialized

    @property
    def storage_type(self) -> str:
        """Get storage type ('azure' or 'local')"""
        if not self._initialized:
            return 'unknown'
        return 'azure' if self._use_azure else 'local'

    @property
    def init_error(self) -> Optional[str]:
        """Get initialization error if any"""
        return self._init_error

    @property
    def account_name(self) -> Optional[str]:
        """Get account name"""
        self._lazy_init()
        return self._account_name

    @property
    def container_name(self) -> str:
        """Get container name"""
        self._lazy_init()
        return self._container_name or 'uploads'

    # ==========================================
    # FILE OPERATIONS
    # ==========================================

    def upload_file(self, content: bytes, blob_path: str,
                    metadata: Optional[Dict] = None) -> Dict[str, Any]:
        """
        Upload file to Azure Blob Storage.

        Args:
            content: File content as bytes
            blob_path: Path in blob storage (e.g., 'uploaded/file.json')
            metadata: Optional metadata dict

        Returns:
            Dict with success status, blob_path, size, download_url
        """
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}

            logger.info(f"Uploading to Azure: {blob_path} ({len(content)} bytes)")

            blob_client = self._container_client.get_blob_client(blob_path)
            blob_client.upload_blob(content, overwrite=True)

            if metadata:
                blob_client.set_blob_metadata(metadata)

            properties = blob_client.get_blob_properties()
            download_url = f"https://{self._account_name}.blob.core.windows.net/{self._container_name}/{blob_path}"

            logger.info(f"Upload successful: {blob_path}")

            return {
                'success': True,
                'blob_path': blob_path,
                'size': properties.size,
                'download_url': download_url
            }

        except Exception as e:
            logger.error(f"Upload failed for {blob_path}: {e}")
            return {'success': False, 'error': str(e)}

    def download_file(self, blob_path: str) -> Dict[str, Any]:
        """
        Download file from Azure Blob Storage.

        Args:
            blob_path: Path in blob storage

        Returns:
            Dict with success status, content, size
        """
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}

            logger.info(f"Downloading from Azure: {blob_path}")

            blob_client = self._container_client.get_blob_client(blob_path)
            download_stream = blob_client.download_blob()
            content = download_stream.readall()

            properties = blob_client.get_blob_properties()

            logger.info(f"Download successful: {blob_path} ({len(content)} bytes)")

            return {
                'success': True,
                'blob_path': blob_path,
                'content': content,
                'size': properties.size
            }

        except Exception as e:
            logger.error(f"Download failed for {blob_path}: {e}")
            return {'success': False, 'error': str(e)}

    def delete_file(self, blob_path: str) -> Dict[str, Any]:
        """
        Delete file from Azure Blob Storage.

        Args:
            blob_path: Path in blob storage

        Returns:
            Dict with success status
        """
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available'}

            logger.info(f"Deleting from Azure: {blob_path}")

            blob_client = self._container_client.get_blob_client(blob_path)
            blob_client.delete_blob()

            logger.info(f"Delete successful: {blob_path}")

            return {'success': True, 'blob_path': blob_path}

        except Exception as e:
            logger.error(f"Delete failed for {blob_path}: {e}")
            return {'success': False, 'error': str(e)}

    def list_files(self, prefix: str = '') -> Dict[str, Any]:
        """
        List files in Azure Blob Storage.

        Args:
            prefix: Optional prefix to filter files

        Returns:
            Dict with success status and list of files
        """
        try:
            if not self.is_available:
                return {'success': False, 'error': 'Azure Storage not available', 'files': []}

            logger.info(f"Listing files with prefix: '{prefix}'")

            files = []
            blobs = self._container_client.list_blobs(name_starts_with=prefix)

            for blob in blobs:
                files.append({
                    'name': blob.name,
                    'size': blob.size,
                    'modified_time': blob.last_modified.isoformat() if blob.last_modified else None
                })

            logger.info(f"Found {len(files)} files")

            return {'success': True, 'files': files}

        except Exception as e:
            logger.error(f"List files failed: {e}")
            return {'success': False, 'error': str(e), 'files': []}

    def file_exists(self, blob_path: str) -> bool:
        """Check if file exists in Azure Blob Storage"""
        try:
            if not self.is_available:
                return False

            blob_client = self._container_client.get_blob_client(blob_path)
            return blob_client.exists()

        except Exception:
            return False

    # ==========================================
    # STATISTICS
    # ==========================================

    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        try:
            if not self.is_available:
                return {
                    'success': False,
                    'total_size_mb': 0,
                    'total_files': 0,
                    'error': 'Azure Storage not available'
                }

            logger.info("Calculating storage statistics...")

            total_size = 0
            total_files = 0

            blobs = self._container_client.list_blobs()
            for blob in blobs:
                total_size += blob.size
                total_files += 1

            total_mb = round(total_size / (1024 * 1024), 2)

            logger.info(f"Stats: {total_files} files, {total_mb} MB")

            return {
                'success': True,
                'total_size_mb': total_mb,
                'total_files': total_files,
                'storage_type': 'azure'
            }

        except Exception as e:
            logger.error(f"Stats calculation failed: {e}")
            return {
                'success': False,
                'total_size_mb': 0,
                'total_files': 0,
                'error': str(e)
            }

    # ==========================================
    # CONNECTION TESTING
    # ==========================================

    def test_connection(self) -> Dict[str, Any]:
        """Test Azure Storage connection"""
        try:
            if not self.is_available:
                return {
                    'success': False,
                    'status': 'unavailable',
                    'message': self._init_error or 'Azure Storage not configured',
                    'storage_type': 'local'
                }

            # Try to list blobs (lightweight test)
            test_prefix = '__connection_test__'
            self._container_client.list_blobs(name_starts_with=test_prefix)

            return {
                'success': True,
                'status': 'connected',
                'message': 'Azure Storage connection successful',
                'storage_type': 'azure',
                'account_name': self._account_name,
                'container_name': self._container_name
            }

        except Exception as e:
            logger.error(f"Connection test failed: {e}")
            return {
                'success': False,
                'status': 'error',
                'message': str(e),
                'storage_type': 'unknown'
            }

    # ==========================================
    # STATUS INFO
    # ==========================================

    def get_status(self) -> Dict[str, Any]:
        """Get connector status without triggering initialization"""
        if not self._initialized:
            return {
                'initialized': False,
                'storage_type': 'pending',
                'message': 'Not yet initialized (lazy loading)'
            }

        return {
            'initialized': True,
            'storage_type': self.storage_type,
            'is_available': self._use_azure,
            'account_name': self._account_name,
            'container_name': self._container_name,
            'init_error': self._init_error
        }


# Convenience function to get connector instance
def get_storage_connector() -> AzureStorageConnector:
    """Get the Azure Storage connector singleton instance"""
    return AzureStorageConnector.get_instance()
