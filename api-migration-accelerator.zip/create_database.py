#!/usr/bin/env python3
"""
Database Creation Script
Creates the database (SQLite or PostgreSQL) with all required tables
Supports both development (SQLite) and production (PostgreSQL) databases
"""

import os
import sys
from datetime import datetime
import subprocess

# Add the current directory to Python path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask
from models.database import db, MigrationRecord, APISpecification, MigrationLog
from config import get_config

def check_postgresql_connection(database_url):
    """Check if PostgreSQL server is accessible"""
    try:
        import psycopg2
        from urllib.parse import urlparse
        
        parsed = urlparse(database_url)
        
        # Test connection
        conn = psycopg2.connect(
            host=parsed.hostname,
            port=parsed.port or 5432,
            user=parsed.username,
            password=parsed.password,
            database='postgres'  # Connect to default database first
        )
        conn.close()
        return True
    except ImportError:
        print("❌ psycopg2 not installed. Run: pip install psycopg2-binary")
        return False
    except Exception as e:
        print(f"❌ PostgreSQL connection failed: {e}")
        return False

def create_postgresql_database(database_url):
    """Create PostgreSQL database if it doesn't exist"""
    try:
        import psycopg2
        from urllib.parse import urlparse
        
        parsed = urlparse(database_url)
        db_name = parsed.path[1:]  # Remove leading slash
        
        # Connect to PostgreSQL server
        conn = psycopg2.connect(
            host=parsed.hostname,
            port=parsed.port or 5432,
            user=parsed.username,
            password=parsed.password,
            database='postgres'
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
        exists = cursor.fetchone()
        
        if not exists:
            print(f"📄 Creating PostgreSQL database: {db_name}")
            cursor.execute(f'CREATE DATABASE "{db_name}"')
            print(f"✅ Database {db_name} created successfully")
        else:
            print(f"ℹ️  Database {db_name} already exists")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Failed to create PostgreSQL database: {e}")
        return False

def create_database():
    """Create the database with all tables"""
    
    print("🗄️  Creating migrations database...")
    
    # Create Flask app for database context
    app = Flask(__name__)
    config = get_config()
    app.config.from_object(config)
    
    database_url = config.DATABASE_URL
    db_type = config.get_database_type()
    
    print(f"🔧 Database type: {db_type}")
    print(f"📡 Database URL: {database_url.replace(database_url.split('@')[0].split('://')[1], '***:***') if '@' in database_url else database_url}")
    
    # PostgreSQL-specific setup
    if db_type == 'postgresql':
        print("🐘 Setting up PostgreSQL database...")
        
        if not check_postgresql_connection(database_url):
            print("💡 Ensure PostgreSQL is running and credentials are correct")
            return False
        
        if not create_postgresql_database(database_url):
            return False
    
    # Initialize database
    db.init_app(app)
    
    with app.app_context():
        try:
            # Create all tables
            print("📋 Creating database tables...")
            db.create_all()
            
            # Verify tables were created
            if db_type == 'postgresql':
                # For PostgreSQL, query information_schema
                result = db.engine.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")
                tables = [row[0] for row in result]
            else:
                # For SQLite
                tables = db.engine.table_names()
            
            print(f"✅ Database created successfully!")
            print(f"📋 Tables created: {', '.join(tables)}")
            
            # Add some sample data (optional)
            add_sample_data = input("\n❓ Add sample migration records? (y/n): ").lower().strip() == 'y'
            
            if add_sample_data:
                create_sample_data()
                print("✅ Sample data added!")
            
            # Show database info
            show_database_info(config)
            
            return True
            
        except Exception as e:
            print(f"❌ Error creating database: {e}")
            return False

def create_sample_data():
    """Create sample migration records for testing"""
    
    # Sample migration records
    sample_migrations = [
        {
            'migration_id': 'migration_sample_001',
            'original_api_id': 'petstore-api',
            'azure_api_id': 'petstore-api-v3',
            'api_name': 'Petstore API',
            'api_version': '1.0.0',
            'status': 'completed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'completion_time': 8.5,
            'conversion_method': 'ai',
            'ai_conversion_used': True,
            'conversion_notes': 'Successfully converted using Azure OpenAI'
        },
        {
            'migration_id': 'migration_sample_002',
            'original_api_id': 'user-management-api',
            'azure_api_id': 'user-mgmt-api',
            'api_name': 'User Management API',
            'api_version': '2.1.0',
            'status': 'completed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'completion_time': 12.3,
            'conversion_method': 'fallback',
            'ai_conversion_used': False,
            'conversion_notes': 'Converted using fallback method due to AI service unavailability'
        },
        {
            'migration_id': 'migration_sample_003',
            'original_api_id': 'payment-api',
            'api_name': 'Payment Processing API',
            'api_version': '1.5.0',
            'status': 'failed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'error_message': 'Invalid API specification format'
        }
    ]
    
    # Sample API specifications
    sample_openapi_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": "Sample API",
            "version": "1.0.0",
            "description": "A sample API specification"
        },
        "servers": [
            {"url": "https://api.example.com/v1"}
        ],
        "paths": {
            "/users": {
                "get": {
                    "summary": "List users",
                    "responses": {
                        "200": {
                            "description": "Success"
                        }
                    }
                }
            }
        }
    }
    
    sample_api_specs = [
        {
            'api_id': 'sample-api-001',
            'name': 'Sample API',
            'version': '1.0.0',
            'description': 'A sample API for testing',
            'format': 'openapi_3.0',
            'specification': sample_openapi_spec,
            'source_platform': 'manual_upload',
            'is_valid': True,
            'paths_count': 1,
            'operations_count': 1
        }
    ]
    
    try:
        # Add migration records
        for migration_data in sample_migrations:
            migration = MigrationRecord(**migration_data)
            db.session.add(migration)
        
        # Add API specifications
        for spec_data in sample_api_specs:
            api_spec = APISpecification(**spec_data)
            db.session.add(api_spec)
        
        # Add sample logs
        log_entries = [
            MigrationLog('migration_sample_001', 'INFO', 'extraction', 'Starting API extraction from IBM API Connect'),
            MigrationLog('migration_sample_001', 'INFO', 'conversion', 'Converting OpenAPI 2.0 to 3.0 using Azure OpenAI'),
            MigrationLog('migration_sample_001', 'INFO', 'deployment', 'Deploying API to Azure APIM'),
            MigrationLog('migration_sample_001', 'INFO', 'completion', 'Migration completed successfully')
        ]
        
        for log_entry in log_entries:
            db.session.add(log_entry)
        
        # Commit all changes
        db.session.commit()
        
        print(f"📝 Added {len(sample_migrations)} migration records")
        print(f"📄 Added {len(sample_api_specs)} API specifications")
        print(f"📋 Added {len(log_entries)} log entries")
        
    except Exception as e:
        print(f"❌ Error adding sample data: {e}")
        db.session.rollback()

def show_database_info(config):
    """Show information about the created database"""
    
    db_type = config.get_database_type()
    
    print(f"\n📊 Database Information:")
    print(f"   Type: {db_type}")
    print(f"   URL: {config.DATABASE_URL.replace(config.DATABASE_URL.split('@')[0].split('://')[1], '***:***') if '@' in config.DATABASE_URL else config.DATABASE_URL}")
    
    if db_type == 'sqlite':
        db_path = config.DATABASE_URL.replace('sqlite:///', '')
        if os.path.exists(db_path):
            db_size = os.path.getsize(db_path)
            print(f"   File: {db_path}")
            print(f"   Size: {db_size} bytes")
    
    print(f"   Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def show_existing_database_stats():
    """Show statistics about existing database"""
    
    app = Flask(__name__)
    config = get_config()
    app.config.from_object(config)
    db.init_app(app)
    
    with app.app_context():
        try:
            # Count records in each table
            migration_count = MigrationRecord.query.count()
            api_spec_count = APISpecification.query.count()
            log_count = MigrationLog.query.count()
            
            print(f"\n📊 Database Statistics:")
            print(f"   Migrations: {migration_count}")
            print(f"   API Specs: {api_spec_count}")
            print(f"   Log Entries: {log_count}")
            
            # Show recent migrations
            if migration_count > 0:
                print(f"\n📋 Recent Migrations:")
                recent = MigrationRecord.query.order_by(MigrationRecord.created_at.desc()).limit(3).all()
                for migration in recent:
                    status_emoji = "✅" if migration.status == "completed" else "❌" if migration.status == "failed" else "⏳"
                    print(f"   {status_emoji} {migration.api_name} ({migration.status})")
            
        except Exception as e:
            print(f"❌ Error querying database: {e}")

def install_postgresql_requirements():
    """Install PostgreSQL requirements"""
    print("📦 Installing PostgreSQL requirements...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "psycopg2-binary"])
        print("✅ PostgreSQL driver installed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install PostgreSQL driver: {e}")
        return False

if __name__ == "__main__":
    print("🚀 API Migration Tool - Database Setup")
    print("=" * 50)
    
    config = get_config()
    db_type = config.get_database_type()
    
    # Check PostgreSQL requirements
    if db_type == 'postgresql':
        try:
            import psycopg2
        except ImportError:
            print("❌ PostgreSQL driver not found")
            install_driver = input("Install psycopg2-binary? (y/n): ").lower().strip() == 'y'
            if install_driver:
                if not install_postgresql_requirements():
                    sys.exit(1)
            else:
                print("💡 Install with: pip install psycopg2-binary")
                sys.exit(1)
    
    # Check if database already exists
    if db_type == 'sqlite':
        db_path = config.DATABASE_URL.replace('sqlite:///', '')
        database_exists = os.path.exists(db_path)
    else:
        # For PostgreSQL, we'll let the creation process handle existing databases
        database_exists = False
    
    if database_exists:
        print(f"⚠️  Database already exists")
        recreate = input("Recreate database? This will delete existing data (y/n): ").lower().strip() == 'y'
        
        if recreate:
            if db_type == 'sqlite':
                os.remove(db_path)
                print("🗑️  Existing database deleted")
        else:
            print("ℹ️  Showing existing database info...")
            show_existing_database_stats()
            sys.exit(0)
    
    # Create new database
    success = create_database()
    
    if success:
        print(f"\n🎉 Database setup complete!")
        print(f"💡 You can now run the application with: python app.py")
        
        if db_type == 'postgresql':
            print(f"🐘 PostgreSQL database is ready for production use")
        else:
            print(f"🔧 SQLite database is ready for development")
    else:
        print(f"\n❌ Database setup failed")
        sys.exit(1)

def create_sample_data():
    """Create sample migration records for testing"""
    
    # Sample migration records
    sample_migrations = [
        {
            'migration_id': 'migration_sample_001',
            'original_api_id': 'petstore-api',
            'azure_api_id': 'petstore-api-v3',
            'api_name': 'Petstore API',
            'api_version': '1.0.0',
            'status': 'completed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'completion_time': 8.5,
            'conversion_method': 'ai',
            'ai_conversion_used': True,
            'conversion_notes': 'Successfully converted using Azure OpenAI'
        },
        {
            'migration_id': 'migration_sample_002',
            'original_api_id': 'user-management-api',
            'azure_api_id': 'user-mgmt-api',
            'api_name': 'User Management API',
            'api_version': '2.1.0',
            'status': 'completed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'completion_time': 12.3,
            'conversion_method': 'fallback',
            'ai_conversion_used': False,
            'conversion_notes': 'Converted using fallback method due to AI service unavailability'
        },
        {
            'migration_id': 'migration_sample_003',
            'original_api_id': 'payment-api',
            'api_name': 'Payment Processing API',
            'api_version': '1.5.0',
            'status': 'failed',
            'source_platform': 'ibm_api_connect',
            'target_platform': 'azure_apim',
            'error_message': 'Invalid API specification format'
        }
    ]
    
    # Sample API specifications
    sample_openapi_spec = {
        "openapi": "3.0.0",
        "info": {
            "title": "Sample API",
            "version": "1.0.0",
            "description": "A sample API specification"
        },
        "servers": [
            {"url": "https://api.example.com/v1"}
        ],
        "paths": {
            "/users": {
                "get": {
                    "summary": "List users",
                    "responses": {
                        "200": {
                            "description": "Success"
                        }
                    }
                }
            }
        }
    }
    
    sample_api_specs = [
        {
            'api_id': 'sample-api-001',
            'name': 'Sample API',
            'version': '1.0.0',
            'description': 'A sample API for testing',
            'format': 'openapi_3.0',
            'specification': sample_openapi_spec,
            'source_platform': 'manual_upload',
            'is_valid': True,
            'paths_count': 1,
            'operations_count': 1
        }
    ]
    
    try:
        # Add migration records
        for migration_data in sample_migrations:
            migration = MigrationRecord(**migration_data)
            db.session.add(migration)
        
        # Add API specifications
        for spec_data in sample_api_specs:
            api_spec = APISpecification(**spec_data)
            db.session.add(api_spec)
        
        # Add sample logs
        log_entries = [
            MigrationLog('migration_sample_001', 'INFO', 'extraction', 'Starting API extraction from IBM API Connect'),
            MigrationLog('migration_sample_001', 'INFO', 'conversion', 'Converting OpenAPI 2.0 to 3.0 using Azure OpenAI'),
            MigrationLog('migration_sample_001', 'INFO', 'deployment', 'Deploying API to Azure APIM'),
            MigrationLog('migration_sample_001', 'INFO', 'completion', 'Migration completed successfully')
        ]
        
        for log_entry in log_entries:
            db.session.add(log_entry)
        
        # Commit all changes
        db.session.commit()
        
        print(f"📝 Added {len(sample_migrations)} migration records")
        print(f"📄 Added {len(sample_api_specs)} API specifications")
        print(f"📋 Added {len(log_entries)} log entries")
        
    except Exception as e:
        print(f"❌ Error adding sample data: {e}")
        db.session.rollback()

def show_database_info():
    """Show information about the created database"""
    
    app = Flask(__name__)
    config = get_config()
    app.config.from_object(config)
    db.init_app(app)
    
    with app.app_context():
        try:
            # Count records in each table
            migration_count = MigrationRecord.query.count()
            api_spec_count = APISpecification.query.count()
            log_count = MigrationLog.query.count()
            
            print(f"\n📊 Database Statistics:")
            print(f"   Migrations: {migration_count}")
            print(f"   API Specs: {api_spec_count}")
            print(f"   Log Entries: {log_count}")
            
            # Show recent migrations
            if migration_count > 0:
                print(f"\n📋 Recent Migrations:")
                recent = MigrationRecord.query.order_by(MigrationRecord.created_at.desc()).limit(3).all()
                for migration in recent:
                    status_emoji = "✅" if migration.status == "completed" else "❌" if migration.status == "failed" else "⏳"
                    print(f"   {status_emoji} {migration.api_name} ({migration.status})")
            
        except Exception as e:
            print(f"❌ Error querying database: {e}")

if __name__ == "__main__":
    print("🚀 API Migration Tool - Database Setup")
    print("=" * 50)
    
    # Check if database already exists
    config = get_config()
    db_path = config.DATABASE_URL.replace('sqlite:///', '')
    
    if os.path.exists(db_path):
        print(f"⚠️  Database already exists: {db_path}")
        recreate = input("Recreate database? This will delete existing data (y/n): ").lower().strip() == 'y'
        
        if recreate:
            os.remove(db_path)
            print("🗑️  Existing database deleted")
        else:
            print("ℹ️  Showing existing database info...")
            show_database_info()
            sys.exit(0)
    
    # Create new database
    create_database()
    
    print(f"\n🎉 Database setup complete!")
    print(f"💡 You can now run the application with: python app.py")