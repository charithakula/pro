#!/usr/bin/env python3

"""
Azure Environment Variables & Secrets Migration Script (Python Version)

Purpose: Migrate environment variables from .env file to Azure Web App
         and sensitive secrets to Azure Key Vault

Usage: python migrate_to_azure.py --env-file .env --app-name myapp --resource-group myrg --key-vault mykv
"""

import os
import sys
import json
import argparse
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple
from datetime import datetime

# ============================================================================
# COLOR CODES & FORMATTING
# ============================================================================

class Colors:
    """ANSI color codes for terminal output"""
    BLUE = '\033[0;34m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    RED = '\033[0;31m'
    CYAN = '\033[0;36m'
    NC = '\033[0m'  # No Color

class Logger:
    """Custom logger with color support"""
    
    def __init__(self, verbose=False):
        self.verbose = verbose
    
    def header(self, message):
        """Print section header"""
        print(f"\n{Colors.BLUE}╔════════════════════════════════════════════════════════╗{Colors.NC}")
        print(f"{Colors.BLUE}║  {message}{Colors.NC}")
        print(f"{Colors.BLUE}╚════════════════════════════════════════════════════════╝{Colors.NC}\n")
    
    def section(self, message):
        """Print subsection header"""
        print(f"\n{Colors.CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.NC}")
        print(f"{Colors.CYAN}  {message}{Colors.NC}")
        print(f"{Colors.CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{Colors.NC}")
    
    def info(self, message):
        """Print info message"""
        print(f"{Colors.BLUE}ℹ {Colors.NC}{message}")
    
    def success(self, message):
        """Print success message"""
        print(f"{Colors.GREEN}✓ {Colors.NC}{message}")
    
    def warning(self, message):
        """Print warning message"""
        print(f"{Colors.YELLOW}⚠ {Colors.NC}{message}")
    
    def error(self, message):
        """Print error message"""
        print(f"{Colors.RED}✗ {Colors.NC}{message}")
    
    def debug(self, message):
        """Print debug message (only if verbose)"""
        if self.verbose:
            print(f"{Colors.BLUE}→ {Colors.NC}{message}")

# ============================================================================
# AZURE MIGRATION CLASS
# ============================================================================

class AzureMigration:
    """Handle migration of environment variables to Azure"""
    
    # Secrets that must go to Key Vault
    SECRETS = [
        "AZURE_CLIENT_SECRET",
        "AZURE_OPENAI_API_KEY",
        "DB_PASSWORD",
        "FLASK_SECRET_KEY",
        "SECRET_KEY",
        "MAIL_PASSWORD",
    ]
    
    def __init__(self, env_file: str, app_name: str, resource_group: str, 
                 key_vault: str, dry_run: bool = False, verbose: bool = False):
        """Initialize Azure migration"""
        self.env_file = env_file
        self.app_name = app_name
        self.resource_group = resource_group
        self.key_vault = key_vault
        self.dry_run = dry_run
        self.logger = Logger(verbose)
        
        self.variables: Dict[str, str] = {}
        self.secrets: Dict[str, str] = {}
        self.failed_items: List[Tuple[str, str]] = []
    
    def _run_command(self, command: List[str]) -> Tuple[bool, str]:
        """Run Azure CLI command"""
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                check=False
            )
            return result.returncode == 0, result.stdout or result.stderr
        except Exception as e:
            return False, str(e)
    
    def _validate_requirements(self):
        """Validate all requirements are met"""
        self.logger.section("Validating Requirements")
        
        # Check .env file exists
        if not Path(self.env_file).exists():
            self.logger.error(f".env file not found: {self.env_file}")
            sys.exit(1)
        self.logger.success(f".env file found: {self.env_file}")
        
        # Check Azure CLI installed
        success, _ = self._run_command(["az", "--version"])
        if not success:
            self.logger.error("Azure CLI is not installed")
            sys.exit(1)
        self.logger.success("Azure CLI is installed")
        
        # Check Azure login
        success, _ = self._run_command(["az", "account", "show"])
        if not success:
            self.logger.error("Not logged in to Azure (run: az login)")
            sys.exit(1)
        self.logger.success("Logged in to Azure")
        
        # Verify Web App exists
        success, _ = self._run_command([
            "az", "webapp", "show",
            "--name", self.app_name,
            "--resource-group", self.resource_group
        ])
        if not success:
            self.logger.error(f"Web App not found: {self.app_name}")
            sys.exit(1)
        self.logger.success(f"Web App found: {self.app_name}")
        
        # Verify Key Vault exists
        success, _ = self._run_command([
            "az", "keyvault", "show",
            "--name", self.key_vault,
            "--resource-group", self.resource_group
        ])
        if not success:
            self.logger.error(f"Key Vault not found: {self.key_vault}")
            sys.exit(1)
        self.logger.success(f"Key Vault found: {self.key_vault}")
    
    def _is_secret(self, key: str) -> bool:
        """Check if key is a secret"""
        return key in self.SECRETS
    
    def _read_env_file(self):
        """Read and parse .env file"""
        self.logger.section("Reading Environment Variables")
        
        with open(self.env_file, 'r') as f:
            for line in f:
                # Skip comments and empty lines
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                
                # Parse key=value
                if '=' not in line:
                    continue
                
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip().strip('"\'')
                
                # Skip empty values
                if not value:
                    self.logger.debug(f"Skipping empty variable: {key}")
                    continue
                
                # Classify as secret or variable
                if self._is_secret(key):
                    self.secrets[key] = value
                    self.logger.debug(f"Secret: {key}")
                else:
                    self.variables[key] = value
                    self.logger.debug(f"Variable: {key}")
        
        self.logger.success(f"Read {len(self.variables)} variables and {len(self.secrets)} secrets")
    
    def _show_summary(self):
        """Show migration summary"""
        self.logger.section("Migration Summary")
        
        print(f"{Colors.CYAN}Variables to migrate to Web App: {len(self.variables)}{Colors.NC}")
        print(f"{Colors.CYAN}Secrets to migrate to Key Vault: {len(self.secrets)}{Colors.NC}")
        print(f"{Colors.CYAN}Azure Resources:{Colors.NC}")
        print(f"  • Web App: {self.app_name}")
        print(f"  • Resource Group: {self.resource_group}")
        print(f"  • Key Vault: {self.key_vault}")
        
        if self.dry_run:
            print(f"\n{Colors.YELLOW}DRY RUN MODE - No changes will be made{Colors.NC}")
    
    def _confirm_migration(self):
        """Confirm before migration"""
        if self.dry_run:
            print()
            response = input(f"{Colors.YELLOW}Continue with dry run? (yes/no): {Colors.NC}")
        else:
            print()
            response = input(f"{Colors.YELLOW}Ready to migrate? (yes/no): {Colors.NC}")
        
        if response.lower() != "yes":
            self.logger.warning("Migration cancelled")
            sys.exit(0)
    
    def _migrate_secrets(self):
        """Migrate secrets to Key Vault"""
        self.logger.section("Migrating Secrets to Key Vault")
        
        count = 0
        failed = 0
        
        for key, value in self.secrets.items():
            # Convert key to Key Vault format
            kv_key = key.lower().replace('_', '-')
            
            self.logger.info(f"Migrating secret: {key} → {kv_key}")
            
            if self.dry_run:
                self.logger.debug(f"Would set secret: {kv_key}")
            else:
                success, output = self._run_command([
                    "az", "keyvault", "secret", "set",
                    "--vault-name", self.key_vault,
                    "--name", kv_key,
                    "--value", value
                ])
                
                if success:
                    self.logger.success(f"Secret migrated: {kv_key}")
                    count += 1
                else:
                    self.logger.error(f"Failed to migrate secret: {key}")
                    self.failed_items.append((key, output))
                    failed += 1
        
        if not self.dry_run:
            print(f"\n{Colors.CYAN}Summary: {count} secrets migrated, {failed} failed{Colors.NC}")
            return failed == 0
        return True
    
    def _migrate_variables(self):
        """Migrate variables to Web App"""
        self.logger.section("Migrating Variables to Web App")
        
        settings = [f"{k}={v}" for k, v in self.variables.items()]
        count = len(settings)
        failed = 0
        
        self.logger.info(f"Setting {count} variables on Web App: {self.app_name}")
        
        if self.dry_run:
            for setting in settings[:5]:  # Show first 5
                key = setting.split('=')[0]
                self.logger.debug(f"Would set: {key}")
            if len(settings) > 5:
                self.logger.debug(f"... and {len(settings) - 5} more")
        else:
            success, output = self._run_command([
                "az", "webapp", "config", "appsettings", "set",
                "--name", self.app_name,
                "--resource-group", self.resource_group,
                "--settings", *settings
            ])
            
            if success:
                self.logger.success(f"All {count} variables migrated to Web App")
            else:
                self.logger.error(f"Failed to set variables on Web App")
                self.failed_items.append(("webapp_settings", output))
                failed = count
        
        if not self.dry_run:
            print(f"\n{Colors.CYAN}Summary: {count - failed} variables set, {failed} failed{Colors.NC}")
            return failed == 0
        return True
    
    def _verify_migration(self):
        """Verify migration success"""
        if self.dry_run:
            self.logger.info("Dry run mode - verification skipped")
            return
        
        self.logger.section("Verifying Migration")
        
        # Verify Web App settings
        success, output = self._run_command([
            "az", "webapp", "config", "appsettings", "list",
            "--name", self.app_name,
            "--resource-group", self.resource_group
        ])
        
        if success:
            settings = json.loads(output)
            self.logger.success(f"Web App has {len(settings)} application settings")
        else:
            self.logger.error("Failed to verify Web App settings")
        
        # Verify Key Vault secrets
        success, output = self._run_command([
            "az", "keyvault", "secret", "list",
            "--vault-name", self.key_vault
        ])
        
        if success:
            secrets = json.loads(output)
            self.logger.success(f"Key Vault has {len(secrets)} secrets")
        else:
            self.logger.error("Failed to verify Key Vault secrets")
    
    def _generate_report(self):
        """Generate migration report"""
        self.logger.section("Migration Report")
        
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report_file = f"migration_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        with open(report_file, 'w') as f:
            f.write("========================================\n")
            f.write("AZURE MIGRATION REPORT\n")
            f.write("========================================\n\n")
            f.write(f"Timestamp: {timestamp}\n")
            f.write(f"Environment File: {self.env_file}\n")
            f.write(f"Web App: {self.app_name}\n")
            f.write(f"Resource Group: {self.resource_group}\n")
            f.write(f"Key Vault: {self.key_vault}\n")
            f.write(f"Dry Run: {self.dry_run}\n\n")
            
            f.write("------------ VARIABLES MIGRATED -----------\n")
            f.write(f"Total Variables: {len(self.variables)}\n\n")
            for key in sorted(self.variables.keys()):
                f.write(f"  {key}\n")
            
            f.write("\n------------ SECRETS MIGRATED -----------\n")
            f.write(f"Total Secrets: {len(self.secrets)}\n\n")
            for key in sorted(self.secrets.keys()):
                kv_key = key.lower().replace('_', '-')
                f.write(f"  {key} → {kv_key}\n")
            
            f.write("\n------------ CONFIGURATION CHECKLIST -----------\n")
            f.write("[ ] Verify all variables in Web App Application Settings\n")
            f.write("[ ] Verify all secrets in Key Vault\n")
            f.write("[ ] Test application with new configuration\n")
            f.write("[ ] Update application to reference Key Vault secrets (optional)\n")
            f.write("[ ] Backup original .env file\n")
            f.write("[ ] Remove .env file from production (after verification)\n")
            f.write("[ ] Rotate credentials periodically\n")
        
        self.logger.success(f"Migration report saved: {report_file}")
    
    def _show_next_steps(self):
        """Show next steps"""
        self.logger.section("Next Steps")
        
        print(f"{Colors.CYAN}1. Verify Configuration:{Colors.NC}")
        print(f"   az webapp config appsettings list --name {self.app_name} --resource-group {self.resource_group}")
        print(f"   az keyvault secret list --vault-name {self.key_vault}")
        
        print(f"\n{Colors.CYAN}2. Test Application:{Colors.NC}")
        print(f"   • Restart Web App to load new settings")
        print(f"   • Test application functionality")
        print(f"   • Monitor application logs")
        
        print(f"\n{Colors.CYAN}3. Cleanup:{Colors.NC}")
        print(f"   • Backup and remove .env file from production")
        print(f"   • Remove .env from version control")
        print(f"   • Update documentation")
    
    def run(self):
        """Execute migration"""
        self.logger.header("Azure Environment Variables Migration")
        
        # Validate
        self._validate_requirements()
        
        # Read
        self._read_env_file()
        
        # Show summary
        self._show_summary()
        
        # Confirm
        self._confirm_migration()
        
        # Migrate
        if not self._migrate_secrets():
            self.logger.error("Secret migration failed")
            return False
        
        if not self._migrate_variables():
            self.logger.error("Variable migration failed")
            return False
        
        # Verify
        self._verify_migration()
        
        # Report
        self._generate_report()
        
        # Next steps
        self._show_next_steps()
        
        if self.dry_run:
            self.logger.warning("DRY RUN COMPLETE - No changes were made")
        else:
            self.logger.success("Migration completed successfully!")
        
        return True

# ============================================================================
# COMMAND LINE INTERFACE
# ============================================================================

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Migrate environment variables to Azure",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python migrate_to_azure.py --app-name myapp --resource-group myrg --key-vault mykv
  python migrate_to_azure.py --env-file .env.prod --app-name myapp --resource-group myrg --key-vault mykv --dry-run
        """
    )
    
    parser.add_argument("-e", "--env-file", default=".env",
                        help="Path to .env file (default: .env)")
    parser.add_argument("-a", "--app-name", required=True,
                        help="Azure Web App name")
    parser.add_argument("-r", "--resource-group", required=True,
                        help="Azure Resource Group name")
    parser.add_argument("-k", "--key-vault", required=True,
                        help="Azure Key Vault name")
    parser.add_argument("-d", "--dry-run", action="store_true",
                        help="Preview without making changes")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Verbose output")
    
    args = parser.parse_args()
    
    # Run migration
    migration = AzureMigration(
        env_file=args.env_file,
        app_name=args.app_name,
        resource_group=args.resource_group,
        key_vault=args.key_vault,
        dry_run=args.dry_run,
        verbose=args.verbose
    )
    
    try:
        success = migration.run()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Migration cancelled by user{Colors.NC}")
        sys.exit(1)
    except Exception as e:
        print(f"{Colors.RED}Error: {str(e)}{Colors.NC}")
        sys.exit(1)

if __name__ == "__main__":
    main()
