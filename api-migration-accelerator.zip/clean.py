import os
import shutil

# Folders to delete
DELETE_FOLDERS = ['__pycache__', 'venv', '.venv', '.vscode']

# File types to delete
DELETE_EXTENSIONS = ('.log', '.pyc', '.db')

def clean_project(folder_path):
    for root, dirs, files in os.walk(folder_path, topdown=True):

        # Delete folders
        for d in dirs:
            if d in DELETE_FOLDERS:
                folder_to_delete = os.path.join(root, d)
                print(f"Deleting folder: {folder_to_delete}")
                shutil.rmtree(folder_to_delete, ignore_errors=True)

        # Delete files
        for f in files:
            if f.lower().endswith(DELETE_EXTENSIONS):
                file_to_delete = os.path.join(root, f)
                print(f"Deleting file: {file_to_delete}")
                os.remove(file_to_delete)

# 👉 Clean the current project directory
project_folder = os.getcwd()
clean_project(project_folder)

print("✅ Cleanup completed successfully!")
