"""
Models package for database models and data structures
Contains SQLAlchemy models and Pydantic schemas
"""

from .database import db, MigrationRecord, APISpecification, MigrationLog
from .schemas import (
    MigrationRecordSchema,
    APISpecificationSchema,
    ConversionRequestSchema,
    ConversionResponseSchema,
    MigrationRequestSchema,
    MigrationResponseSchema,
    ValidationResultSchema
)

# Database utility functions
def init_database(app):
    """Initialize database with Flask app"""
    with app.app_context():
        db.create_all()
        print("Database initialized successfully")

def get_database_statistics():
    """Get overall database statistics"""
    try:
        migration_stats = MigrationRecord.get_statistics()
        
        total_specs = APISpecification.query.count()
        valid_specs = APISpecification.query.filter_by(is_valid=True).count()
        
        return {
            'migrations': migration_stats,
            'api_specifications': {
                'total_specifications': total_specs,
                'valid_specifications': valid_specs,
                'invalid_specifications': total_specs - valid_specs
            }
        }
    except Exception as e:
        return {
            'migrations': {
                'total_migrations': 0,
                'successful_migrations': 0,
                'failed_migrations': 0,
                'in_progress_migrations': 0,
                'success_rate': 0,
                'average_completion_time': 0
            },
            'api_specifications': {
                'total_specifications': 0,
                'valid_specifications': 0,
                'invalid_specifications': 0
            }
        }

__all__ = [
    # Database models
    'db',
    'MigrationRecord',
    'APISpecification', 
    'MigrationLog',
    
    # Database utilities
    'init_database',
    'get_database_statistics',
    
    # Pydantic schemas
    'MigrationRecordSchema',
    'APISpecificationSchema',
    'ConversionRequestSchema',
    'ConversionResponseSchema',
    'MigrationRequestSchema',
    'MigrationResponseSchema',
    'ValidationResultSchema'
]