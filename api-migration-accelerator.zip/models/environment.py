"""
Environment Configuration Model for Multi-Environment APIM Support
Supports Dev/Staging/Production environments with separate configurations
"""
import json
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON
from models.database import db, now_pst, format_pst_display


class APIMEnvironment(db.Model):
    """Model for Azure APIM Environment configurations

    Supports multiple APIM instances (Dev, Staging, Production)
    Each environment has its own connection settings
    """

    __tablename__ = 'apim_environments'
    # Note: Removed schema='api' for SQLite compatibility

    id = Column(Integer, primary_key=True)
    name = Column(String(100), unique=True, nullable=False, index=True)  # e.g., "Development", "Staging", "Production"
    code = Column(String(20), unique=True, nullable=False, index=True)   # e.g., "dev", "staging", "prod"
    description = Column(Text, nullable=True)

    # Azure APIM Connection Settings
    subscription_id = Column(String(100), nullable=False)
    resource_group = Column(String(100), nullable=False)
    service_name = Column(String(100), nullable=False)

    # Azure Authentication (Service Principal)
    tenant_id = Column(String(100), nullable=True)
    client_id = Column(String(100), nullable=True)
    client_secret = Column(Text, nullable=True)  # Encrypted in production

    # Environment URLs
    gateway_url = Column(String(500), nullable=True)
    management_url = Column(String(500), nullable=True)
    developer_portal_url = Column(String(500), nullable=True)

    # Environment Settings
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)
    is_production = Column(Boolean, default=False)  # Extra confirmation for prod deployments
    color = Column(String(20), default='#6c757d')  # UI color coding
    icon = Column(String(50), default='bi-server')

    # Deployment Settings
    requires_approval = Column(Boolean, default=False)
    auto_subscribe_products = Column(Boolean, default=True)
    default_product_id = Column(String(100), nullable=True)

    # Order for display
    display_order = Column(Integer, default=0)

    # Timestamps
    created_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, index=True)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, onupdate=now_pst)
    created_by = Column(String(100), nullable=True)
    updated_by = Column(String(100), nullable=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.created_at is None:
            self.created_at = now_pst()
        if self.updated_at is None:
            self.updated_at = now_pst()

    def to_dict(self, include_secrets=False):
        """Convert model to dictionary

        Args:
            include_secrets: If True, includes client_secret (use carefully!)
        """
        result = {
            'id': self.id,
            'name': self.name,
            'code': self.code,
            'description': self.description,
            'subscription_id': self.subscription_id,
            'resource_group': self.resource_group,
            'service_name': self.service_name,
            'tenant_id': self.tenant_id,
            'client_id': self.client_id,
            'gateway_url': self.gateway_url,
            'management_url': self.management_url,
            'developer_portal_url': self.developer_portal_url,
            'is_active': self.is_active,
            'is_default': self.is_default,
            'is_production': self.is_production,
            'color': self.color,
            'icon': self.icon,
            'requires_approval': self.requires_approval,
            'auto_subscribe_products': self.auto_subscribe_products,
            'default_product_id': self.default_product_id,
            'display_order': self.display_order,
            'created_at': format_pst_display(self.created_at, '%Y-%m-%d %H:%M:%S %Z'),
            'updated_at': format_pst_display(self.updated_at, '%Y-%m-%d %H:%M:%S %Z'),
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

        if include_secrets:
            result['client_secret'] = self.client_secret
        else:
            result['has_client_secret'] = bool(self.client_secret)

        return result

    def get_connection_config(self):
        """Get connection configuration for Azure APIM connector"""
        return {
            'subscription_id': self.subscription_id,
            'resource_group': self.resource_group,
            'service_name': self.service_name,
            'tenant_id': self.tenant_id,
            'client_id': self.client_id,
            'client_secret': self.client_secret
        }

    @classmethod
    def get_active_environments(cls):
        """Get all active environments ordered by display_order"""
        return cls.query.filter_by(is_active=True).order_by(cls.display_order).all()

    @classmethod
    def get_default_environment(cls):
        """Get the default environment"""
        return cls.query.filter_by(is_default=True, is_active=True).first()

    @classmethod
    def get_by_code(cls, code: str):
        """Get environment by code (dev, staging, prod)"""
        return cls.query.filter_by(code=code.lower(), is_active=True).first()

    @classmethod
    def set_default(cls, environment_id: int):
        """Set an environment as default (unsets others)"""
        # Unset all defaults
        cls.query.update({cls.is_default: False})

        # Set new default
        env = cls.query.get(environment_id)
        if env:
            env.is_default = True
            db.session.commit()
            return True
        return False


class EnvironmentDeployment(db.Model):
    """Track API deployments across environments

    Records which APIs are deployed to which environments
    Enables promotion tracking between environments
    """

    __tablename__ = 'environment_deployments'
    # Note: Removed schema='api' for SQLite compatibility

    id = Column(Integer, primary_key=True)
    environment_id = Column(Integer, nullable=False, index=True)
    environment_code = Column(String(20), nullable=False, index=True)

    # API Information
    api_id = Column(String(100), nullable=False, index=True)
    api_name = Column(String(200), nullable=True)
    api_version = Column(String(50), nullable=True)
    azure_api_id = Column(String(100), nullable=True)  # ID in Azure APIM

    # Deployment Status
    status = Column(String(20), default='deployed')  # deployed, pending, failed, removed
    deployment_method = Column(String(50), default='direct')  # direct, promoted

    # Promotion tracking
    promoted_from_environment_id = Column(Integer, nullable=True)
    promoted_from_environment_code = Column(String(20), nullable=True)
    promotion_timestamp = Column(DateTime(timezone=True), nullable=True)

    # Spec version tracking
    spec_hash = Column(String(64), nullable=True)  # SHA256 of the deployed spec
    spec_version = Column(String(50), nullable=True)

    # Timestamps
    deployed_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, index=True)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, onupdate=now_pst)
    deployed_by = Column(String(100), nullable=True)

    # Metadata
    deployment_notes = Column(Text, nullable=True)
    deployment_metadata = Column(JSON, nullable=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.deployed_at is None:
            self.deployed_at = now_pst()
        if self.updated_at is None:
            self.updated_at = now_pst()

    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'environment_id': self.environment_id,
            'environment_code': self.environment_code,
            'api_id': self.api_id,
            'api_name': self.api_name,
            'api_version': self.api_version,
            'azure_api_id': self.azure_api_id,
            'status': self.status,
            'deployment_method': self.deployment_method,
            'promoted_from_environment_id': self.promoted_from_environment_id,
            'promoted_from_environment_code': self.promoted_from_environment_code,
            'promotion_timestamp': format_pst_display(self.promotion_timestamp) if self.promotion_timestamp else None,
            'spec_hash': self.spec_hash,
            'spec_version': self.spec_version,
            'deployed_at': format_pst_display(self.deployed_at, '%Y-%m-%d %H:%M:%S %Z'),
            'updated_at': format_pst_display(self.updated_at, '%Y-%m-%d %H:%M:%S %Z'),
            'deployed_by': self.deployed_by,
            'deployment_notes': self.deployment_notes,
            'deployment_metadata': self.deployment_metadata
        }

    @classmethod
    def get_api_deployments(cls, api_id: str):
        """Get all deployments for an API across environments"""
        return cls.query.filter_by(api_id=api_id).order_by(cls.deployed_at.desc()).all()

    @classmethod
    def get_environment_apis(cls, environment_code: str):
        """Get all APIs deployed to an environment"""
        return cls.query.filter_by(
            environment_code=environment_code.lower(),
            status='deployed'
        ).order_by(cls.api_name).all()

    @classmethod
    def get_latest_deployment(cls, api_id: str, environment_code: str):
        """Get the latest deployment of an API to a specific environment"""
        return cls.query.filter_by(
            api_id=api_id,
            environment_code=environment_code.lower()
        ).order_by(cls.deployed_at.desc()).first()


def create_default_environments():
    """Create default environment configurations if none exist"""
    if APIMEnvironment.query.count() == 0:
        default_envs = [
            {
                'name': 'Development',
                'code': 'dev',
                'description': 'Development environment for testing and experimentation',
                'subscription_id': '',
                'resource_group': '',
                'service_name': '',
                'is_active': True,
                'is_default': True,
                'is_production': False,
                'color': '#28a745',
                'icon': 'bi-code-square',
                'requires_approval': False,
                'display_order': 1
            },
            {
                'name': 'Staging',
                'code': 'staging',
                'description': 'Staging environment for pre-production testing',
                'subscription_id': '',
                'resource_group': '',
                'service_name': '',
                'is_active': True,
                'is_default': False,
                'is_production': False,
                'color': '#ffc107',
                'icon': 'bi-box-seam',
                'requires_approval': True,
                'display_order': 2
            },
            {
                'name': 'Production',
                'code': 'prod',
                'description': 'Production environment - requires approval for deployments',
                'subscription_id': '',
                'resource_group': '',
                'service_name': '',
                'is_active': True,
                'is_default': False,
                'is_production': True,
                'color': '#dc3545',
                'icon': 'bi-globe',
                'requires_approval': True,
                'display_order': 3
            }
        ]

        for env_data in default_envs:
            env = APIMEnvironment(**env_data)
            db.session.add(env)

        db.session.commit()
        return True
    return False
