"""
Database models for API migration tool - STORE PST DIRECTLY
All timestamps stored as PST in the database
No UTC conversion - straightforward PST timestamps
"""
import json
import pytz
from datetime import datetime, timedelta
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, Text, DateTime, Float, Boolean, JSON, func

# Initialize SQLAlchemy
db = SQLAlchemy()

# ==========================================
# TIMEZONE SETUP - PST ONLY
# ==========================================

PST = pytz.timezone('America/Los_Angeles')

def now_pst():
    """Get current datetime in PST - Store directly in database"""
    return datetime.now(PST)

def format_pst_display(dt, format_str='%Y-%m-%d %I:%M %p PST'):
    """Format datetime as readable PST string"""
    if dt is None:
        return 'N/A'

    # If it's naive (no timezone), assume it's already PST
    if dt.tzinfo is None:
        return dt.strftime(format_str)

    # If it has timezone, convert to PST if needed
    if dt.tzinfo != PST:
        dt = dt.astimezone(PST)

    return dt.strftime(format_str)


def check_database_schema():
    """
    Check if the 'api' schema exists in the database.
    Returns dict with status and details.
    """
    try:
        from sqlalchemy import text

        # Check if we're using PostgreSQL
        db_url = str(db.engine.url)
        if 'postgresql' not in db_url.lower():
            return {
                'status': 'ok',
                'message': 'SQLite database - no schema required',
                'database_type': 'sqlite',
                'schema_exists': True
            }

        # Check if 'api' schema exists in PostgreSQL
        result = db.session.execute(text("""
            SELECT schema_name
            FROM information_schema.schemata
            WHERE schema_name = 'api'
        """)).fetchone()

        if result:
            return {
                'status': 'ok',
                'message': 'Schema "api" exists',
                'database_type': 'postgresql',
                'schema_exists': True
            }
        else:
            return {
                'status': 'error',
                'message': 'Schema "api" does not exist. Please ask your database administrator to create it.',
                'database_type': 'postgresql',
                'schema_exists': False,
                'sql_to_run': 'CREATE SCHEMA IF NOT EXISTS api;',
                'alert_type': 'schema_missing'
            }

    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to check schema: {str(e)}',
            'database_type': 'unknown',
            'schema_exists': False,
            'error': str(e)
        }


def check_database_tables():
    """
    Check if required tables exist in the database.
    Returns dict with status and details.
    """
    try:
        from sqlalchemy import text, inspect

        required_tables = ['migration_records', 'api_specifications', 'migration_logs']
        missing_tables = []
        existing_tables = []

        db_url = str(db.engine.url)

        if 'postgresql' in db_url.lower():
            # PostgreSQL - check in 'api' schema
            for table in required_tables:
                result = db.session.execute(text(f"""
                    SELECT table_name
                    FROM information_schema.tables
                    WHERE table_schema = 'api' AND table_name = '{table}'
                """)).fetchone()

                if result:
                    existing_tables.append(table)
                else:
                    missing_tables.append(table)
        else:
            # SQLite - check tables directly
            inspector = inspect(db.engine)
            existing = inspector.get_table_names()
            for table in required_tables:
                if table in existing:
                    existing_tables.append(table)
                else:
                    missing_tables.append(table)

        if missing_tables:
            return {
                'status': 'warning',
                'message': f'Missing tables: {", ".join(missing_tables)}',
                'missing_tables': missing_tables,
                'existing_tables': existing_tables,
                'alert_type': 'tables_missing',
                'action': 'Run init.sql to create the required tables'
            }
        else:
            return {
                'status': 'ok',
                'message': 'All required tables exist',
                'existing_tables': existing_tables,
                'missing_tables': []
            }

    except Exception as e:
        return {
            'status': 'error',
            'message': f'Failed to check tables: {str(e)}',
            'error': str(e)
        }


def get_database_status():
    """
    Get comprehensive database status including schema and tables.
    Used for dashboard alerts.
    """
    schema_check = check_database_schema()
    tables_check = check_database_tables()

    alerts = []

    # Add schema alert if missing
    if not schema_check.get('schema_exists', True):
        alerts.append({
            'type': 'error',
            'title': 'Database Schema Missing',
            'message': 'The "api" schema does not exist in PostgreSQL.',
            'action': 'Please ask your database administrator to run: CREATE SCHEMA IF NOT EXISTS api;',
            'sql': 'CREATE SCHEMA IF NOT EXISTS api;'
        })

    # Add tables alert if missing
    if tables_check.get('missing_tables'):
        alerts.append({
            'type': 'warning',
            'title': 'Database Tables Missing',
            'message': f'Missing tables: {", ".join(tables_check["missing_tables"])}',
            'action': 'Please ask your database administrator to run the init.sql script.',
            'missing': tables_check['missing_tables']
        })

    return {
        'schema': schema_check,
        'tables': tables_check,
        'alerts': alerts,
        'has_alerts': len(alerts) > 0,
        'is_ready': schema_check.get('schema_exists', False) and len(tables_check.get('missing_tables', [])) == 0
    }


class MigrationRecord(db.Model):
    """Model for tracking API migration records - PST STORAGE

    All timestamps are stored directly as PST in the database.
    No UTC conversion - what you see is what you get!
    """

    __tablename__ = 'migration_records'
    __table_args__ = {'schema': 'api'}
    
    id = Column(Integer, primary_key=True)
    migration_id = Column(String(100), unique=True, nullable=False, index=True)
    original_api_id = Column(String(100), nullable=False, index=True)
    azure_api_id = Column(String(100), nullable=True)
    api_name = Column(String(200), nullable=True, index=True)
    api_version = Column(String(50), nullable=True)
    
    # Migration details
    status = Column(String(20), nullable=False, default='pending', index=True)
    source_platform = Column(String(50), nullable=False, default='ibm_api_connect')
    target_platform = Column(String(50), nullable=False, default='azure_apim')
    
    # Timestamps - Stored as PST (timezone-aware)
    start_time = Column(DateTime(timezone=True), nullable=False, default=now_pst)
    end_time = Column(DateTime(timezone=True), nullable=True)
    completion_time = Column(Float, nullable=True)  # Time in seconds
    
    # File information
    original_filename = Column(String(255), nullable=True)
    converted_filename = Column(String(255), nullable=True)
    file_size = Column(Integer, nullable=True)
    
    # Conversion details
    conversion_method = Column(String(50), nullable=True)
    conversion_time = Column(Float, nullable=True)
    ai_conversion_used = Column(Boolean, default=False)
    
    # Results and metadata
    conversion_notes = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)
    validation_results = Column(JSON, nullable=True)
    migration_metadata = Column(JSON, nullable=True)
    
    # Tracking - Stored as PST
    created_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, index=True)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, onupdate=now_pst)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Ensure timestamps are created with PST timezone
        if self.created_at is None:
            self.created_at = now_pst()
        if self.start_time is None:
            self.start_time = now_pst()
        if self.updated_at is None:
            self.updated_at = now_pst()
    
    def to_dict(self):
        """Convert model to dictionary with PST times"""
        return {
            'id': self.id,
            'migration_id': self.migration_id,
            'original_api_id': self.original_api_id,
            'azure_api_id': self.azure_api_id,
            'api_name': self.api_name,
            'api_version': self.api_version,
            'status': self.status,
            'source_platform': self.source_platform,
            'target_platform': self.target_platform,
            # PST timestamps
            'start_time': format_pst_display(self.start_time, '%Y-%m-%d %H:%M:%S %Z'),
            'end_time': format_pst_display(self.end_time, '%Y-%m-%d %H:%M:%S %Z'),
            'start_time_display': format_pst_display(self.start_time),
            'end_time_display': format_pst_display(self.end_time),
            'completion_time': self.completion_time,
            'created_at': format_pst_display(self.created_at, '%Y-%m-%d %H:%M:%S %Z'),
            'updated_at': format_pst_display(self.updated_at, '%Y-%m-%d %H:%M:%S %Z'),
            'created_at_display': format_pst_display(self.created_at),
            'updated_at_display': format_pst_display(self.updated_at),
            # Additional data
            'original_filename': self.original_filename,
            'converted_filename': self.converted_filename,
            'file_size': self.file_size,
            'conversion_method': self.conversion_method,
            'conversion_time': self.conversion_time,
            'ai_conversion_used': self.ai_conversion_used,
            'conversion_notes': self.conversion_notes,
            'error_message': self.error_message,
            'validation_results': self._deserialize_json(self.validation_results),
            'migration_metadata': self._deserialize_json(self.migration_metadata)
        }
    
    @staticmethod
    def _deserialize_json(value):
        """Helper method to deserialize JSON fields"""
        if value is None:
            return None
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return value
    
    @staticmethod
    def _serialize_json(value):
        """Helper method to serialize JSON fields"""
        if value is None:
            return None
        if isinstance(value, str):
            return value
        return json.dumps(value) if value else None
    
    def update_status(self, status: str, error_message: str = None):
        """Update migration status with PST timestamp"""
        self.status = status
        self.updated_at = now_pst()  # ✅ PST timestamp
        if error_message:
            self.error_message = error_message
        if status == 'completed':
            self.end_time = now_pst()  # ✅ PST timestamp
            if self.start_time and self.end_time:
                # Calculate duration
                self.completion_time = (self.end_time - self.start_time).total_seconds()
    
    def add_conversion_metadata(self, conversion_result: dict):
        """Add conversion metadata from conversion result"""
        if conversion_result:
            self.conversion_time = conversion_result.get('conversion_time_seconds')
            self.ai_conversion_used = conversion_result.get('ai_conversion_used', False)
            self.conversion_method = 'ai' if self.ai_conversion_used else 'fallback'
            
            # Handle validation results - JSON serialization
            validation = conversion_result.get('validation', {})
            self.validation_results = self._serialize_json(validation)
            
            # Handle conversion metadata - JSON serialization
            conversion_metadata = conversion_result.get('conversion_metadata', {})
            self.migration_metadata = self._serialize_json(conversion_metadata)
    
    @classmethod
    def get_by_migration_id(cls, migration_id: str):
        """Get migration record by migration ID"""
        return cls.query.filter_by(migration_id=migration_id).first()
    
    @classmethod
    def get_recent_migrations(cls, limit: int = 50, offset: int = 0):
        """Get recent migrations ordered by creation date (newest first)"""
        return cls.query.order_by(cls.created_at.desc()).offset(offset).limit(limit).all()
    
    @classmethod
    def get_statistics(cls):
        """Get migration statistics"""
        total = cls.query.count()
        completed = cls.query.filter_by(status='completed').count()
        failed = cls.query.filter_by(status='failed').count()
        pending = cls.query.filter(cls.status.in_(['pending', 'in_progress'])).count()
        
        # Calculate average completion time
        completed_migrations = cls.query.filter(
            cls.status == 'completed',
            cls.completion_time.isnot(None)
        ).all()
        
        avg_time = 0
        if completed_migrations:
            total_time = sum(m.completion_time for m in completed_migrations if m.completion_time)
            avg_time = total_time / len(completed_migrations) if completed_migrations else 0
        
        return {
            'total_migrations': total,
            'successful_migrations': completed,
            'failed_migrations': failed,
            'in_progress_migrations': pending,
            'success_rate': round((completed / total * 100), 2) if total > 0 else 0,
            'average_completion_time': round(avg_time, 2)
        }
    
    @classmethod
    def get_migrations_by_date_range(cls, start_date=None, end_date=None):
        """Get migrations within a date range (PST dates)"""
        query = cls.query
        
        if start_date:
            if start_date.tzinfo is None:
                start_date = start_date.replace(tzinfo=PST)
            query = query.filter(cls.created_at >= start_date)
        
        if end_date:
            if end_date.tzinfo is None:
                end_date = end_date.replace(tzinfo=PST)
            query = query.filter(cls.created_at <= end_date)
        
        return query.order_by(cls.created_at.desc()).all()


class APISpecification(db.Model):
    """Model for storing API specifications"""

    __tablename__ = 'api_specifications'
    __table_args__ = {'schema': 'api'}
    
    id = Column(Integer, primary_key=True)
    api_id = Column(String(100), nullable=False, index=True)
    name = Column(String(200), nullable=False, index=True)
    version = Column(String(50), nullable=False)
    description = Column(Text, nullable=True)
    
    # Specification details
    format = Column(String(20), nullable=False, index=True)
    specification = Column(JSON, nullable=False)
    
    # Source information
    source_platform = Column(String(50), nullable=True)
    original_filename = Column(String(255), nullable=True)
    file_size = Column(Integer, nullable=True)
    
    # Validation status
    is_valid = Column(Boolean, default=True)
    validation_errors = Column(JSON, nullable=True)
    validation_warnings = Column(JSON, nullable=True)
    
    # Metadata
    paths_count = Column(Integer, default=0)
    operations_count = Column(Integer, default=0)
    definitions_count = Column(Integer, default=0)
    security_schemes_count = Column(Integer, default=0)
    
    # Timestamps - Stored as PST
    created_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, index=True)
    updated_at = Column(DateTime(timezone=True), nullable=False, default=now_pst, onupdate=now_pst)
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.created_at is None:
            self.created_at = now_pst()
        if self.updated_at is None:
            self.updated_at = now_pst()
        if self.specification:
            self._extract_metadata()
    
    def _extract_metadata(self):
        """Extract metadata from specification"""
        try:
            if isinstance(self.specification, str):
                spec = json.loads(self.specification)
            else:
                spec = self.specification
            
            # Count paths and operations
            paths = spec.get('paths', {})
            self.paths_count = len(paths) if isinstance(paths, dict) else 0
            
            operations = 0
            for path_data in paths.values():
                if isinstance(path_data, dict):
                    operations += sum(1 for key in path_data.keys() 
                                    if key.lower() in ['get', 'post', 'put', 'delete', 'head', 'options', 'patch'])
            self.operations_count = operations
            
            # Count definitions/schemas
            if 'definitions' in spec:
                definitions = spec['definitions']
                self.definitions_count = len(definitions) if isinstance(definitions, dict) else 0
            elif 'components' in spec and 'schemas' in spec['components']:
                schemas = spec['components']['schemas']
                self.definitions_count = len(schemas) if isinstance(schemas, dict) else 0
            
            # Count security schemes
            if 'securityDefinitions' in spec:
                sec_defs = spec['securityDefinitions']
                self.security_schemes_count = len(sec_defs) if isinstance(sec_defs, dict) else 0
            elif 'components' in spec and 'securitySchemes' in spec['components']:
                sec_schemes = spec['components']['securitySchemes']
                self.security_schemes_count = len(sec_schemes) if isinstance(sec_schemes, dict) else 0
                
        except Exception as e:
            print(f"Error extracting metadata: {e}")
    
    def to_dict(self):
        """Convert model to dictionary with PST times"""
        return {
            'id': self.id,
            'api_id': self.api_id,
            'name': self.name,
            'version': self.version,
            'description': self.description,
            'format': self.format,
            'specification': self._deserialize_json(self.specification),
            'source_platform': self.source_platform,
            'original_filename': self.original_filename,
            'file_size': self.file_size,
            'is_valid': self.is_valid,
            'validation_errors': self._deserialize_json(self.validation_errors),
            'validation_warnings': self._deserialize_json(self.validation_warnings),
            'paths_count': self.paths_count,
            'operations_count': self.operations_count,
            'definitions_count': self.definitions_count,
            'security_schemes_count': self.security_schemes_count,
            'created_at': format_pst_display(self.created_at, '%Y-%m-%d %H:%M:%S %Z'),
            'updated_at': format_pst_display(self.updated_at, '%Y-%m-%d %H:%M:%S %Z'),
            'created_at_display': format_pst_display(self.created_at),
            'updated_at_display': format_pst_display(self.updated_at)
        }
    
    @staticmethod
    def _deserialize_json(value):
        """Helper method to deserialize JSON fields"""
        if value is None:
            return None
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return value
    
    @classmethod
    def get_by_api_id(cls, api_id: str):
        """Get API specification by API ID"""
        return cls.query.filter_by(api_id=api_id).first()


class MigrationLog(db.Model):
    """Model for detailed migration logs - PST"""

    __tablename__ = 'migration_logs'
    __table_args__ = {'schema': 'api'}
    
    id = Column(Integer, primary_key=True)
    migration_id = Column(String(100), nullable=False, index=True)
    timestamp = Column(DateTime(timezone=True), nullable=False, default=now_pst, index=True)
    level = Column(String(10), nullable=False, index=True)
    stage = Column(String(50), nullable=False)
    message = Column(Text, nullable=False)
    details = Column(JSON, nullable=True)
    
    def __init__(self, migration_id: str, level: str, stage: str, message: str, details: dict = None):
        self.migration_id = migration_id
        self.level = level
        self.stage = stage
        self.message = message
        self.details = details
        self.timestamp = now_pst()  # ✅ PST timestamp
    
    def to_dict(self):
        """Convert model to dictionary with PST time"""
        return {
            'id': self.id,
            'migration_id': self.migration_id,
            'timestamp': format_pst_display(self.timestamp, '%Y-%m-%d %H:%M:%S %Z'),
            'timestamp_display': format_pst_display(self.timestamp),
            'level': self.level,
            'stage': self.stage,
            'message': self.message,
            'details': self._deserialize_json(self.details)
        }
    
    @staticmethod
    def _deserialize_json(value):
        """Helper method to deserialize JSON fields"""
        if value is None:
            return None
        if isinstance(value, str):
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return value
    
    @classmethod
    def get_logs_for_migration(cls, migration_id: str):
        """Get all logs for a specific migration"""
        return cls.query.filter_by(migration_id=migration_id).order_by(cls.timestamp.asc()).all()


def init_database(app):
    """Initialize database with Flask app"""
    with app.app_context():
        db.create_all()
        print("✅ Database initialized successfully")
        print("📊 Tables created: migration_records, api_specifications, migration_logs")
        print("🌍 Timezone: PST (Pacific Standard Time)")
        print("💾 Storage: All timestamps stored as PST (what you see is what you get!)")


def get_database_statistics():
    """Get overall database statistics"""
    migration_stats = MigrationRecord.get_statistics()
    
    total_specs = APISpecification.query.count()
    valid_specs = APISpecification.query.filter_by(is_valid=True).count()
    
    return {
        'migrations': migration_stats,
        'api_specifications': {
            'total_specifications': total_specs,
            'valid_specifications': valid_specs,
            'invalid_specifications': total_specs - valid_specs
        },
        'timestamp': format_pst_display(now_pst()),
        'timezone': 'PST (Pacific Standard Time)'
    }


def cleanup_old_logs(days_to_keep: int = 30) -> int:
    """Clean up old log entries"""
    cutoff_date = now_pst() - timedelta(days=days_to_keep)
    
    deleted_count = MigrationLog.query.filter(
        MigrationLog.timestamp < cutoff_date,
        MigrationLog.level == 'INFO'
    ).delete()
    
    db.session.commit()
    return deleted_count