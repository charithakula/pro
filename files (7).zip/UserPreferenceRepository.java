package com.enterprise.preferences.repository;

import com.enterprise.preferences.entity.UserPreference;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserPreferenceRepository extends JpaRepository<UserPreference, Long> {

    // ==========================================
    // Query Methods
    // ==========================================
    
    List<UserPreference> findByUserIdAndIsActiveTrue(String userId);

    Optional<UserPreference> findByUserIdAndPreferenceKey(String userId, String preferenceKey);

    List<UserPreference> findByUserIdAndCategory(String userId, String category);

    @Query("SELECT DISTINCT p.category FROM UserPreference p WHERE p.userId = :userId AND p.category IS NOT NULL")
    List<String> findDistinctCategoriesByUserId(@Param("userId") String userId);

    @Query("SELECT p FROM UserPreference p WHERE p.userId = :userId AND LOWER(p.preferenceKey) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    List<UserPreference> searchByKey(@Param("userId") String userId, @Param("searchTerm") String searchTerm);

    // ==========================================
    // Native MERGE for Single-Call Upsert (Oracle)
    // ==========================================
    
    @Modifying
    @Query(value = """
        MERGE INTO user_preferences target
        USING (SELECT :userId AS user_id, :prefKey AS preference_key FROM dual) source
        ON (target.user_id = source.user_id AND target.preference_key = source.preference_key)
        WHEN MATCHED THEN
            UPDATE SET
                preference_value = :prefValue,
                preference_type = COALESCE(:prefType, target.preference_type),
                category = COALESCE(:category, target.category),
                description = COALESCE(:description, target.description),
                is_active = COALESCE(:isActive, target.is_active),
                updated_at = CURRENT_TIMESTAMP
        WHEN NOT MATCHED THEN
            INSERT (user_id, preference_key, preference_value, preference_type, category, description, is_active)
            VALUES (:userId, :prefKey, :prefValue, COALESCE(:prefType, 'STRING'), :category, :description, COALESCE(:isActive, 1))
        """, nativeQuery = true)
    void mergePreference(
        @Param("userId") String userId,
        @Param("prefKey") String prefKey,
        @Param("prefValue") String prefValue,
        @Param("prefType") String prefType,
        @Param("category") String category,
        @Param("description") String description,
        @Param("isActive") Integer isActive
    );
}
