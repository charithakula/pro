-- ==========================================
-- User Preferences Table Schema for Oracle
-- ==========================================

CREATE TABLE user_preferences (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id VARCHAR2(100) NOT NULL,
    preference_key VARCHAR2(100) NOT NULL,
    preference_value CLOB,
    preference_type VARCHAR2(50) DEFAULT 'STRING',
    category VARCHAR2(100),
    description VARCHAR2(500),
    is_active NUMBER(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_user_pref_key UNIQUE (user_id, preference_key)
);

-- Indexes for faster lookups
CREATE INDEX idx_user_pref_user_id ON user_preferences(user_id);
CREATE INDEX idx_user_pref_category ON user_preferences(category);
CREATE INDEX idx_user_pref_key ON user_preferences(preference_key);

-- Trigger to auto-update updated_at timestamp
CREATE OR REPLACE TRIGGER trg_user_pref_updated
    BEFORE UPDATE ON user_preferences
    FOR EACH ROW
BEGIN
    :NEW.updated_at := CURRENT_TIMESTAMP;
END;
/

-- ==========================================
-- Sample Data
-- ==========================================
INSERT INTO user_preferences (user_id, preference_key, preference_value, preference_type, category, description) 
VALUES ('user001', 'theme', 'dark', 'STRING', 'appearance', 'UI Theme preference');

INSERT INTO user_preferences (user_id, preference_key, preference_value, preference_type, category, description) 
VALUES ('user001', 'language', 'en', 'STRING', 'localization', 'Preferred language');

INSERT INTO user_preferences (user_id, preference_key, preference_value, preference_type, category, description) 
VALUES ('user001', 'notifications_enabled', 'true', 'BOOLEAN', 'notifications', 'Enable notifications');

INSERT INTO user_preferences (user_id, preference_key, preference_value, preference_type, category, description) 
VALUES ('user001', 'items_per_page', '25', 'NUMBER', 'display', 'Items per page in tables');

INSERT INTO user_preferences (user_id, preference_key, preference_value, preference_type, category, description) 
VALUES ('user001', 'dashboard_config', '{"widgets":["chart","table","stats"],"layout":"grid"}', 'JSON', 'display', 'Dashboard configuration');

COMMIT;

-- ==========================================
-- Verify
-- ==========================================
SELECT id, user_id, preference_key, preference_value, preference_type, category 
FROM user_preferences
WHERE user_id = 'user001';
