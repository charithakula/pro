import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { MaterialReactTable, useMaterialReactTable } from 'material-react-table';
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  FormControlLabel,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Switch,
  TextField,
  Tooltip,
  Typography,
  Chip,
  Alert,
  Snackbar,
  Paper,
  Divider,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Edit as EditIcon,
  Refresh as RefreshIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  Settings as SettingsIcon,
} from '@mui/icons-material';
import { preferencesApi } from '../services/preferencesApi';

// Constants
const PREFERENCE_TYPES = ['STRING', 'NUMBER', 'BOOLEAN', 'JSON'];
const DEFAULT_USER_ID = 'user001';

const UserPreferencesTable = () => {
  // State
  const [preferences, setPreferences] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRow, setEditingRow] = useState(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [userId] = useState(DEFAULT_USER_ID);

  // Form state
  const [formData, setFormData] = useState({
    preferenceKey: '',
    preferenceValue: '',
    preferenceType: 'STRING',
    category: '',
    description: '',
    isActive: true,
  });

  const [formErrors, setFormErrors] = useState({});

  // Fetch preferences
  const fetchPreferences = useCallback(async () => {
    setLoading(true);
    try {
      const [prefsData, catsData] = await Promise.all([
        preferencesApi.getPreferencesByUser(userId),
        preferencesApi.getCategories(userId),
      ]);
      setPreferences(prefsData || []);
      setCategories(catsData || []);
    } catch (error) {
      showSnackbar(`Error fetching preferences: ${error.message}`, 'error');
    } finally {
      setLoading(false);
    }
  }, [userId]);

  useEffect(() => {
    fetchPreferences();
  }, [fetchPreferences]);

  // Snackbar helper
  const showSnackbar = (message, severity = 'success') => {
    setSnackbar({ open: true, message, severity });
  };

  // Form validation
  const validateForm = () => {
    const errors = {};
    if (!formData.preferenceKey.trim()) {
      errors.preferenceKey = 'Key is required';
    }
    if (!formData.preferenceValue.trim()) {
      errors.preferenceValue = 'Value is required';
    }
    if (formData.preferenceType === 'JSON') {
      try {
        JSON.parse(formData.preferenceValue);
      } catch (e) {
        errors.preferenceValue = 'Invalid JSON format';
      }
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Open modal for create/edit
  const openModal = (row = null) => {
    if (row) {
      // Edit mode
      setEditingRow(row);
      setFormData({
        preferenceKey: row.preferenceKey,
        preferenceValue: row.preferenceValue || '',
        preferenceType: row.preferenceType || 'STRING',
        category: row.category || '',
        description: row.description || '',
        isActive: row.isActive ?? true,
      });
    } else {
      // Create mode
      setEditingRow(null);
      setFormData({
        preferenceKey: '',
        preferenceValue: '',
        preferenceType: 'STRING',
        category: '',
        description: '',
        isActive: true,
      });
    }
    setFormErrors({});
    setIsModalOpen(true);
  };

  // Close modal
  const closeModal = () => {
    setIsModalOpen(false);
    setEditingRow(null);
    setFormErrors({});
  };

  // Save preference (Upsert)
  const handleSave = async () => {
    if (!validateForm()) return;

    try {
      const result = await preferencesApi.upsertPreference(
        userId,
        formData.preferenceKey,
        formData.preferenceValue,
        formData.preferenceType,
        formData.category || null,
        formData.description || null,
        formData.isActive
      );

      // Update local state
      setPreferences((prev) => {
        const existingIndex = prev.findIndex((p) => p.id === result.id);
        if (existingIndex >= 0) {
          const updated = [...prev];
          updated[existingIndex] = result;
          return updated;
        }
        return [...prev, result];
      });

      // Refresh categories if new category added
      if (formData.category && !categories.includes(formData.category)) {
        setCategories((prev) => [...prev, formData.category]);
      }

      showSnackbar(editingRow ? 'Preference updated successfully' : 'Preference created successfully');
      closeModal();
    } catch (error) {
      showSnackbar(`Error saving preference: ${error.message}`, 'error');
    }
  };

  // Delete preference
  const handleDelete = async (row) => {
    if (!window.confirm(`Delete preference "${row.preferenceKey}"?`)) return;

    try {
      await preferencesApi.deletePreference(row.id);
      setPreferences((prev) => prev.filter((p) => p.id !== row.id));
      showSnackbar('Preference deleted successfully');
    } catch (error) {
      showSnackbar(`Error deleting preference: ${error.message}`, 'error');
    }
  };

  // Table columns
  const columns = useMemo(
    () => [
      {
        accessorKey: 'id',
        header: 'ID',
        size: 70,
        enableEditing: false,
      },
      {
        accessorKey: 'preferenceKey',
        header: 'Key',
        size: 150,
        Cell: ({ cell }) => (
          <Typography fontWeight="bold" color="primary">
            {cell.getValue()}
          </Typography>
        ),
      },
      {
        accessorKey: 'preferenceValue',
        header: 'Value',
        size: 200,
        Cell: ({ cell, row }) => {
          const value = cell.getValue();
          const type = row.original.preferenceType;
          return (
            <Tooltip title={value || ''} placement="top">
              <Typography
                sx={{
                  maxWidth: 180,
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  whiteSpace: 'nowrap',
                  fontFamily: type === 'JSON' ? 'monospace' : 'inherit',
                  fontSize: type === 'JSON' ? '0.85rem' : 'inherit',
                }}
              >
                {value || '-'}
              </Typography>
            </Tooltip>
          );
        },
      },
      {
        accessorKey: 'preferenceType',
        header: 'Type',
        size: 110,
        filterVariant: 'select',
        filterSelectOptions: PREFERENCE_TYPES,
        Cell: ({ cell }) => {
          const type = cell.getValue();
          const colorMap = {
            STRING: 'primary',
            NUMBER: 'secondary',
            BOOLEAN: 'success',
            JSON: 'warning',
          };
          return <Chip label={type} size="small" color={colorMap[type] || 'default'} variant="outlined" />;
        },
      },
      {
        accessorKey: 'category',
        header: 'Category',
        size: 130,
        filterVariant: 'select',
        filterSelectOptions: categories,
        Cell: ({ cell }) =>
          cell.getValue() ? (
            <Chip label={cell.getValue()} size="small" color="info" />
          ) : (
            <Typography variant="body2" color="text.secondary">
              -
            </Typography>
          ),
      },
      {
        accessorKey: 'description',
        header: 'Description',
        size: 200,
        Cell: ({ cell }) => (
          <Tooltip title={cell.getValue() || ''} placement="top">
            <Typography
              variant="body2"
              sx={{
                maxWidth: 180,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}
            >
              {cell.getValue() || '-'}
            </Typography>
          </Tooltip>
        ),
      },
      {
        accessorKey: 'isActive',
        header: 'Status',
        size: 100,
        filterVariant: 'checkbox',
        Cell: ({ cell }) => (
          <Chip
            label={cell.getValue() ? 'Active' : 'Inactive'}
            size="small"
            color={cell.getValue() ? 'success' : 'default'}
          />
        ),
      },
      {
        accessorKey: 'updatedAt',
        header: 'Updated',
        size: 150,
        Cell: ({ cell }) => (cell.getValue() ? new Date(cell.getValue()).toLocaleString() : '-'),
      },
    ],
    [categories]
  );

  // Table instance
  const table = useMaterialReactTable({
    columns,
    data: preferences,
    enableEditing: true,
    editDisplayMode: 'modal',
    positionActionsColumn: 'last',
    enableColumnFilters: true,
    enableGlobalFilter: true,
    enablePagination: true,
    enableSorting: true,
    enableColumnResizing: true,
    enableDensityToggle: true,
    initialState: {
      density: 'comfortable',
      showColumnFilters: false,
      sorting: [{ id: 'category', desc: false }],
      pagination: { pageSize: 10 },
    },
    state: {
      isLoading: loading,
    },
    muiTableContainerProps: {
      sx: { maxHeight: '600px' },
    },
    renderRowActions: ({ row }) => (
      <Box sx={{ display: 'flex', gap: '0.5rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => openModal(row.original)} color="primary" size="small">
            <EditIcon />
          </IconButton>
        </Tooltip>
        <Tooltip title="Delete">
          <IconButton onClick={() => handleDelete(row.original)} color="error" size="small">
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbarCustomActions: () => (
      <Stack direction="row" spacing={1}>
        <Button variant="contained" startIcon={<AddIcon />} onClick={() => openModal()}>
          Add Preference
        </Button>
        <Button variant="outlined" startIcon={<RefreshIcon />} onClick={fetchPreferences}>
          Refresh
        </Button>
      </Stack>
    ),
  });

  return (
    <Paper elevation={3} sx={{ p: 3, m: 2 }}>
      {/* Header */}
      <Box sx={{ mb: 3 }}>
        <Stack direction="row" alignItems="center" spacing={2}>
          <SettingsIcon color="primary" sx={{ fontSize: 32 }} />
          <Box>
            <Typography variant="h5" fontWeight="bold">
              User Preferences
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Manage your application preferences and settings
            </Typography>
          </Box>
        </Stack>
      </Box>

      <Divider sx={{ mb: 3 }} />

      {/* Table */}
      <MaterialReactTable table={table} />

      {/* Create/Edit Modal */}
      <Dialog open={isModalOpen} onClose={closeModal} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Stack direction="row" alignItems="center" spacing={1}>
            {editingRow ? <EditIcon color="primary" /> : <AddIcon color="primary" />}
            <Typography variant="h6">{editingRow ? 'Edit Preference' : 'Add New Preference'}</Typography>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <Stack spacing={2.5} sx={{ mt: 1 }}>
            <TextField
              label="Preference Key"
              required
              fullWidth
              value={formData.preferenceKey}
              onChange={(e) => setFormData((prev) => ({ ...prev, preferenceKey: e.target.value }))}
              error={!!formErrors.preferenceKey}
              helperText={formErrors.preferenceKey}
              disabled={!!editingRow}
              placeholder="e.g., theme, language, dashboard_config"
            />
            <TextField
              label="Value"
              required
              fullWidth
              multiline={formData.preferenceType === 'JSON'}
              rows={formData.preferenceType === 'JSON' ? 4 : 1}
              value={formData.preferenceValue}
              onChange={(e) => setFormData((prev) => ({ ...prev, preferenceValue: e.target.value }))}
              error={!!formErrors.preferenceValue}
              helperText={formErrors.preferenceValue || (formData.preferenceType === 'JSON' ? 'Enter valid JSON' : '')}
              placeholder={
                formData.preferenceType === 'JSON'
                  ? '{"key": "value"}'
                  : formData.preferenceType === 'BOOLEAN'
                  ? 'true or false'
                  : 'Enter value'
              }
            />
            <FormControl fullWidth>
              <InputLabel>Type</InputLabel>
              <Select
                value={formData.preferenceType}
                label="Type"
                onChange={(e) => setFormData((prev) => ({ ...prev, preferenceType: e.target.value }))}
              >
                {PREFERENCE_TYPES.map((type) => (
                  <MenuItem key={type} value={type}>
                    {type}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <TextField
              label="Category"
              fullWidth
              value={formData.category}
              onChange={(e) => setFormData((prev) => ({ ...prev, category: e.target.value }))}
              placeholder="e.g., appearance, notifications, display"
            />
            <TextField
              label="Description"
              fullWidth
              multiline
              rows={2}
              value={formData.description}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              placeholder="Brief description of this preference"
            />
            <FormControlLabel
              control={
                <Switch
                  checked={formData.isActive}
                  onChange={(e) => setFormData((prev) => ({ ...prev, isActive: e.target.checked }))}
                />
              }
              label="Active"
            />
          </Stack>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 0 }}>
          <Button onClick={closeModal} startIcon={<CancelIcon />}>
            Cancel
          </Button>
          <Button variant="contained" onClick={handleSave} startIcon={<SaveIcon />}>
            {editingRow ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>

      {/* Snackbar */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity} variant="filled">
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Paper>
  );
};

export default UserPreferencesTable;
