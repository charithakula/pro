// ==========================================
// GraphQL API Service for User Preferences
// ==========================================

const GRAPHQL_ENDPOINT = import.meta.env.VITE_GRAPHQL_ENDPOINT || 'http://localhost:8080/graphql';

// ==========================================
// GraphQL Queries
// ==========================================

const QUERIES = {
  GET_PREFERENCES_BY_USER: `
    query GetPreferencesByUser($userId: String!) {
      preferencesByUserId(userId: $userId) {
        id
        userId
        preferenceKey
        preferenceValue
        preferenceType
        category
        description
        isActive
        createdAt
        updatedAt
      }
    }
  `,

  GET_PREFERENCE_BY_KEY: `
    query GetPreferenceByKey($userId: String!, $key: String!) {
      preferenceByKey(userId: $userId, key: $key) {
        id
        userId
        preferenceKey
        preferenceValue
        preferenceType
        category
        description
        isActive
        createdAt
        updatedAt
      }
    }
  `,

  GET_CATEGORIES: `
    query GetCategories($userId: String!) {
      categories(userId: $userId)
    }
  `,

  SEARCH_PREFERENCES: `
    query SearchPreferences($userId: String!, $searchTerm: String!) {
      searchPreferences(userId: $userId, searchTerm: $searchTerm) {
        id
        userId
        preferenceKey
        preferenceValue
        preferenceType
        category
        description
        isActive
        createdAt
        updatedAt
      }
    }
  `,
};

// ==========================================
// GraphQL Mutations
// ==========================================

const MUTATIONS = {
  UPSERT_PREFERENCE: `
    mutation UpsertPreference(
      $userId: String!
      $key: String!
      $value: String!
      $type: PreferenceType
      $category: String
      $description: String
      $isActive: Boolean
    ) {
      upsertPreference(
        userId: $userId
        key: $key
        value: $value
        type: $type
        category: $category
        description: $description
        isActive: $isActive
      ) {
        id
        userId
        preferenceKey
        preferenceValue
        preferenceType
        category
        description
        isActive
        createdAt
        updatedAt
      }
    }
  `,

  DELETE_PREFERENCE: `
    mutation DeletePreference($id: ID!) {
      deletePreference(id: $id)
    }
  `,

  DELETE_PREFERENCE_BY_KEY: `
    mutation DeletePreferenceByKey($userId: String!, $key: String!) {
      deletePreferenceByKey(userId: $userId, key: $key)
    }
  `,
};

// ==========================================
// GraphQL Request Helper
// ==========================================

async function graphqlRequest(query, variables = {}) {
  try {
    const response = await fetch(GRAPHQL_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query, variables }),
    });

    const result = await response.json();

    if (result.errors) {
      throw new Error(result.errors.map((e) => e.message).join(', '));
    }

    return result.data;
  } catch (error) {
    console.error('GraphQL Request Error:', error);
    throw error;
  }
}

// ==========================================
// API Functions
// ==========================================

export const preferencesApi = {
  // Get all preferences for a user
  getPreferencesByUser: async (userId) => {
    const data = await graphqlRequest(QUERIES.GET_PREFERENCES_BY_USER, { userId });
    return data.preferencesByUserId;
  },

  // Get a single preference by key
  getPreferenceByKey: async (userId, key) => {
    const data = await graphqlRequest(QUERIES.GET_PREFERENCE_BY_KEY, { userId, key });
    return data.preferenceByKey;
  },

  // Get all categories
  getCategories: async (userId) => {
    const data = await graphqlRequest(QUERIES.GET_CATEGORIES, { userId });
    return data.categories;
  },

  // Search preferences
  searchPreferences: async (userId, searchTerm) => {
    const data = await graphqlRequest(QUERIES.SEARCH_PREFERENCES, { userId, searchTerm });
    return data.searchPreferences;
  },

  // Upsert (create or update) a preference
  upsertPreference: async (userId, key, value, type = 'STRING', category = null, description = null, isActive = true) => {
    const data = await graphqlRequest(MUTATIONS.UPSERT_PREFERENCE, {
      userId,
      key,
      value,
      type,
      category,
      description,
      isActive,
    });
    return data.upsertPreference;
  },

  // Delete a preference by ID
  deletePreference: async (id) => {
    const data = await graphqlRequest(MUTATIONS.DELETE_PREFERENCE, { id });
    return data.deletePreference;
  },

  // Delete a preference by key
  deletePreferenceByKey: async (userId, key) => {
    const data = await graphqlRequest(MUTATIONS.DELETE_PREFERENCE_BY_KEY, { userId, key });
    return data.deletePreferenceByKey;
  },
};

// ==========================================
// Helper Functions for JSON Preferences
// ==========================================

export const preferenceHelpers = {
  // Save a JSON preference
  saveJsonPreference: async (userId, key, jsonObject, category = null, description = null) => {
    const jsonString = JSON.stringify(jsonObject);
    return await preferencesApi.upsertPreference(userId, key, jsonString, 'JSON', category, description);
  },

  // Get and parse a JSON preference
  getJsonPreference: async (userId, key, defaultValue = null) => {
    try {
      const pref = await preferencesApi.getPreferenceByKey(userId, key);
      if (pref && pref.preferenceValue) {
        return JSON.parse(pref.preferenceValue);
      }
      return defaultValue;
    } catch (error) {
      console.error('Error getting JSON preference:', error);
      return defaultValue;
    }
  },

  // Get all preferences as a key-value object with auto-parsing
  getPreferencesAsObject: async (userId) => {
    const prefs = await preferencesApi.getPreferencesByUser(userId);
    const result = {};

    for (const pref of prefs) {
      let value = pref.preferenceValue;

      switch (pref.preferenceType) {
        case 'JSON':
          try {
            value = JSON.parse(value);
          } catch (e) {
            /* keep as string */
          }
          break;
        case 'NUMBER':
          value = Number(value);
          break;
        case 'BOOLEAN':
          value = value === 'true' || value === '1';
          break;
        default:
        // Keep as string
      }

      result[pref.preferenceKey] = value;
    }

    return result;
  },
};

export default preferencesApi;
