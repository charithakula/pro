package com.enterprise.preferences.controller;

import com.enterprise.preferences.entity.UserPreference;
import com.enterprise.preferences.service.UserPreferenceService;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class UserPreferenceController {

    private final UserPreferenceService service;

    public UserPreferenceController(UserPreferenceService service) {
        this.service = service;
    }

    // ==========================================
    // QUERIES
    // ==========================================

    @QueryMapping
    public List<UserPreference> preferencesByUserId(@Argument String userId) {
        return service.getPreferencesByUserId(userId);
    }

    @QueryMapping
    public UserPreference preferenceByKey(@Argument String userId, @Argument String key) {
        return service.getPreferenceByKey(userId, key).orElse(null);
    }

    @QueryMapping
    public List<UserPreference> preferencesByCategory(@Argument String userId, @Argument String category) {
        return service.getPreferencesByCategory(userId, category);
    }

    @QueryMapping
    public List<String> categories(@Argument String userId) {
        return service.getCategories(userId);
    }

    @QueryMapping
    public List<UserPreference> searchPreferences(@Argument String userId, @Argument String searchTerm) {
        return service.searchPreferences(userId, searchTerm);
    }

    // ==========================================
    // MUTATIONS
    // ==========================================

    @MutationMapping
    public UserPreference upsertPreference(
            @Argument String userId,
            @Argument String key,
            @Argument String value,
            @Argument String type,
            @Argument String category,
            @Argument String description,
            @Argument Boolean isActive) {
        return service.upsertPreference(userId, key, value, type, category, description, isActive);
    }

    @MutationMapping
    public Boolean deletePreference(@Argument Long id) {
        return service.deletePreference(id);
    }

    @MutationMapping
    public Boolean deletePreferenceByKey(@Argument String userId, @Argument String key) {
        return service.deletePreferenceByKey(userId, key);
    }
}
