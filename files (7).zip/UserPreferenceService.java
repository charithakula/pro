package com.enterprise.preferences.service;

import com.enterprise.preferences.entity.UserPreference;
import com.enterprise.preferences.repository.UserPreferenceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserPreferenceService {

    private final UserPreferenceRepository repository;

    public UserPreferenceService(UserPreferenceRepository repository) {
        this.repository = repository;
    }

    // ==========================================
    // Query Operations
    // ==========================================

    public List<UserPreference> getPreferencesByUserId(String userId) {
        return repository.findByUserIdAndIsActiveTrue(userId);
    }

    public Optional<UserPreference> getPreferenceByKey(String userId, String key) {
        return repository.findByUserIdAndPreferenceKey(userId, key);
    }

    public List<UserPreference> getPreferencesByCategory(String userId, String category) {
        return repository.findByUserIdAndCategory(userId, category);
    }

    public List<String> getCategories(String userId) {
        return repository.findDistinctCategoriesByUserId(userId);
    }

    public List<UserPreference> searchPreferences(String userId, String searchTerm) {
        return repository.searchByKey(userId, searchTerm);
    }

    // ==========================================
    // Upsert Operation (MERGE - Single DB Call)
    // ==========================================

    /**
     * Upsert using Oracle MERGE - atomic insert/update in single DB call
     * Then fetches the result to return the entity
     */
    public UserPreference upsertPreference(String userId, String key, String value, 
                                           String type, String category, String description,
                                           Boolean isActive) {
        // Convert Boolean to Integer for Oracle NUMBER(1)
        Integer activeFlag = (isActive != null) ? (isActive ? 1 : 0) : null;
        
        // Single MERGE call - handles both INSERT and UPDATE atomically
        repository.mergePreference(userId, key, value, type, category, description, activeFlag);
        
        // Fetch and return the upserted record
        return repository.findByUserIdAndPreferenceKey(userId, key)
            .orElseThrow(() -> new IllegalStateException("Upsert failed for key: " + key));
    }

    // Simplified version with defaults
    public UserPreference upsertPreference(String userId, String key, String value, 
                                           String type, String category, String description) {
        return upsertPreference(userId, key, value, type, category, description, true);
    }

    // ==========================================
    // Delete Operation
    // ==========================================

    public boolean deletePreference(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

    public boolean deletePreferenceByKey(String userId, String key) {
        Optional<UserPreference> pref = repository.findByUserIdAndPreferenceKey(userId, key);
        if (pref.isPresent()) {
            repository.deleteById(pref.get().getId());
            return true;
        }
        return false;
    }
}
