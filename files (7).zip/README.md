# User Preferences System

A simplified user preferences management system with **Spring GraphQL** backend and **React** frontend using **Material React Table** and **MUI**.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     React Frontend                               │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Material React Table + MUI                               │  │
│  │  - View, Create, Edit, Delete preferences                 │  │
│  │  - Filtering, Sorting, Pagination                         │  │
│  │  - JSON support for complex configs                       │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ GraphQL (upsertPreference mutation)
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                  Spring Boot Backend                             │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Spring GraphQL                                           │  │
│  │  - Queries: preferencesByUserId, preferenceByKey          │  │
│  │  - Mutation: upsertPreference (MERGE), delete             │  │
│  └───────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Spring Data JPA + Native MERGE Query                     │  │
│  │  - Single DB call for insert/update                       │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │ Oracle MERGE (atomic)
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                       Oracle Database                            │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  user_preferences table                                   │  │
│  │  - CLOB for preference_value (supports JSON)              │  │
│  │  - Unique constraint on (user_id, preference_key)         │  │
│  └───────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Key Design Decisions

### 1. Single Mutation (Upsert) ✅
Instead of separate `createPreference` and `updatePreference`, we use one `upsertPreference`:
- Simpler API
- No duplicate key errors
- Atomic operation

### 2. Oracle MERGE (Single DB Call) ✅
```sql
MERGE INTO user_preferences target
USING (...) source
ON (target.user_id = source.user_id AND target.preference_key = source.preference_key)
WHEN MATCHED THEN UPDATE ...
WHEN NOT MATCHED THEN INSERT ...
```

### 3. CLOB for Values ✅
Supports large JSON configurations stored as text.

## Quick Start

### 1. Setup Oracle Database

Run the schema script:
```sql
@schema-oracle.sql
```

### 2. Configure Backend

Edit `application.properties`:
```properties
spring.datasource.url=jdbc:oracle:thin:@//localhost:1521/ORCL
spring.datasource.username=your_username
spring.datasource.password=your_password
```

### 3. Run Backend
```bash
cd backend
mvn spring-boot:run
```
- GraphQL: http://localhost:8080/graphql
- GraphiQL: http://localhost:8080/graphiql

### 4. Run Frontend
```bash
cd frontend
npm install
npm run dev
```
- App: http://localhost:3000

## GraphQL API

### Query: Get Preferences
```graphql
query {
  preferencesByUserId(userId: "user001") {
    id
    preferenceKey
    preferenceValue
    preferenceType
    category
  }
}
```

### Mutation: Upsert (Create or Update)
```graphql
mutation {
  upsertPreference(
    userId: "user001"
    key: "theme"
    value: "dark"
    type: STRING
    category: "appearance"
    description: "UI theme"
  ) {
    id
    preferenceKey
    preferenceValue
    updatedAt
  }
}
```

### Mutation: Upsert JSON
```graphql
mutation {
  upsertPreference(
    userId: "user001"
    key: "dashboard_config"
    value: "{\"widgets\":[\"chart\",\"table\"],\"layout\":\"grid\"}"
    type: JSON
    category: "display"
  ) {
    id
    preferenceValue
  }
}
```

### Mutation: Delete
```graphql
mutation {
  deletePreference(id: "1")
}
```

## Project Structure

```
user-preferences/
├── backend/
│   ├── src/main/java/com/enterprise/preferences/
│   │   ├── UserPreferencesApplication.java
│   │   ├── controller/
│   │   │   └── UserPreferenceController.java
│   │   ├── entity/
│   │   │   └── UserPreference.java
│   │   ├── repository/
│   │   │   └── UserPreferenceRepository.java   # Has native MERGE
│   │   └── service/
│   │       └── UserPreferenceService.java
│   ├── src/main/resources/
│   │   ├── application.properties
│   │   ├── schema-oracle.sql
│   │   └── graphql/
│   │       └── schema.graphqls
│   └── pom.xml
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   └── UserPreferencesTable.jsx
    │   ├── services/
    │   │   └── preferencesApi.js
    │   ├── App.jsx
    │   └── main.jsx
    ├── index.html
    ├── package.json
    └── vite.config.js
```

## Preference Types

| Type | Example Value | Use Case |
|------|---------------|----------|
| STRING | `"dark"` | Simple text values |
| NUMBER | `"25"` | Numeric values |
| BOOLEAN | `"true"` | True/false flags |
| JSON | `'{"key":"value"}'` | Complex configurations |

## React Usage Examples

```javascript
import { preferencesApi, preferenceHelpers } from './services/preferencesApi';

// Save a simple preference
await preferencesApi.upsertPreference('user001', 'theme', 'dark', 'STRING', 'appearance');

// Save a JSON preference
await preferenceHelpers.saveJsonPreference('user001', 'dashboard_config', {
  widgets: ['chart', 'table'],
  layout: 'grid'
}, 'display');

// Get and parse a JSON preference
const config = await preferenceHelpers.getJsonPreference('user001', 'dashboard_config');
console.log(config.widgets); // ['chart', 'table']

// Get all preferences as object
const prefs = await preferenceHelpers.getPreferencesAsObject('user001');
console.log(prefs.theme); // 'dark'
```

## License

MIT
