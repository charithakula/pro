"""
WSGI Entry Point for Production Deployment

Used by Gunicorn/other WSGI servers (e.g., Azure App Services)
This file should be in the same directory as app.py

Usage:
    gunicorn --workers 4 --bind 0.0.0.0:8000 --timeout 60 wsgi:application
"""

import os
import sys
import logging
from dotenv import load_dotenv

# ============================================================================
# STEP 1: LOAD ENVIRONMENT VARIABLES FIRST (CRITICAL)
# ============================================================================
load_dotenv()

# ============================================================================
# STEP 2: SETUP LOGGING (for debugging deployment issues)
# ============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

logger.info("=" * 80)
logger.info("WSGI ENTRY POINT - Production Deployment")
logger.info("=" * 80)

# ============================================================================
# STEP 3: VERIFY ENVIRONMENT SETUP
# ============================================================================
flask_env = os.getenv('FLASK_ENV', 'production')
logger.info(f"✓ Flask Environment: {flask_env}")
logger.info(f"✓ Python Version: {sys.version.split()[0]}")
logger.info(f"✓ Working Directory: {os.getcwd()}")

# Verify critical environment variables
required_vars = ['DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD']
missing_vars = [var for var in required_vars if not os.getenv(var)]
if missing_vars:
    logger.warning(f"⚠ Missing environment variables: {', '.join(missing_vars)}")
    logger.info("  Add these to Azure App Services → Configuration → Application settings")
else:
    logger.info(f"✓ Database environment variables: LOADED")

# ============================================================================
# STEP 4: IMPORT APP FACTORY
# ============================================================================
try:
    from app import create_app
    logger.info("✓ App factory imported successfully")
except ImportError as import_err:
    logger.critical(f"❌ Failed to import app factory: {import_err}")
    sys.exit(1)

# ============================================================================
# STEP 5: CREATE APPLICATION INSTANCE FOR WSGI
# ============================================================================
try:
    logger.info(f"\n🚀 Creating Flask application in '{flask_env}' mode...")
    application = create_app(flask_env)
    logger.info("✅ Flask application created successfully\n")
except Exception as app_err:
    logger.critical(f"❌ Failed to create application: {app_err}")
    import traceback
    logger.critical(traceback.format_exc())
    sys.exit(1)

# ============================================================================
# STEP 6: APPLICATION READY FOR WSGI SERVER
# ============================================================================
logger.info("=" * 80)
logger.info("✅ APPLICATION READY FOR GUNICORN/WSGI SERVER")
logger.info("=" * 80)
logger.info("\n📝 Startup Command for Azure App Services:")
logger.info("   gunicorn --workers 4 --bind 0.0.0.0:8000 --timeout 60 wsgi:application")
logger.info("\n🌐 App Features Enabled:")
logger.info("   ✓ 360° Enterprise Dashboard v4.5.0")
logger.info("   ✓ Hybrid RAG System with pgvector")
logger.info("   ✓ Professional JWT Authentication")
logger.info("   ✓ Azure OpenAI Integration")
logger.info("   ✓ PostgreSQL with pgvector")
logger.info("   ✓ 35+ Routes + Chat API")
logger.info("\n" + "=" * 80 + "\n")

# ============================================================================
# DEVELOPMENT ONLY - FOR LOCAL TESTING
# For windows  waitress-serve --port=5000 wsgi:application
# ============================================================================
if __name__ == '__main__':
    try:
        logger.warning("⚠️  Running in development mode (not recommended for production)")
        logger.info("   For production, use: gunicorn wsgi:application")
        logger.info("   Starting Flask development server on http://0.0.0.0:5000\n")
        
        # Development server (Flask built-in)
        application.run(
            host='0.0.0.0',
            port=5000,
            debug=False,  # Keep debug=False even in development for consistency
            use_reloader=True,
            use_debugger=True
        )
    except Exception as dev_err:
        logger.critical(f"❌ Error running development server: {dev_err}")
        import traceback
        logger.critical(traceback.format_exc())
        sys.exit(1)