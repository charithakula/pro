#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Wrapper to run the Flask app with proper UTF-8 encoding
"""
import os
import sys
import io

# Set UTF-8 encoding for stdout/stderr
if sys.version_info[0] >= 3:
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

# Now import and run the app
from app import create_app

if __name__ == '__main__':
    app = create_app()
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=False,
        use_reloader=False
    )
