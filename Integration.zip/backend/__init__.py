"""
Backend Package - 360° Enterprise Dashboard v4.5.0

This file marks the 'backend' directory as a Python package.
All initialization is handled by app.py
"""

__version__ = '4.5.0'
__author__ = 'Enterprise Dashboard Team'
__description__ = 'Backend services for Enterprise Dashboard'

# This file tells Python that 'backend' is a package
# Submodules (auth, routes, connectors, services) are imported in app.py