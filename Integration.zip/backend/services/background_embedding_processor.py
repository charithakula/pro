"""
Background Embedding Processor Service
=======================================
✅ Processes embeddings in background thread (no HTTP timeout)
✅ Handles 4000-5000+ records efficiently
✅ Chunked processing for memory efficiency
✅ Progress tracking with status endpoint
✅ Thread-safe with proper locking

Usage:
    from backend.services.background_embedding_processor import EmbeddingProcessor

    # Start background processing
    job_id = EmbeddingProcessor.start_embedding_job(data_rows, rag_service)

    # Check status
    status = EmbeddingProcessor.get_job_status(job_id)
    # Returns: {"status": "processing", "progress": 2500, "total": 5000, ...}
"""

import logging
import threading
import uuid
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


# ============================================================================
# JOB STATUS ENUM
# ============================================================================

class JobStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


# ============================================================================
# JOB DATA CLASS
# ============================================================================

@dataclass
class EmbeddingJob:
    """Represents a background embedding job"""
    job_id: str
    status: JobStatus = JobStatus.PENDING
    total_records: int = 0
    processed_records: int = 0
    embeddings_created: int = 0
    embeddings_failed: int = 0
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    error_message: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API response"""
        return {
            'job_id': self.job_id,
            'status': self.status.value,
            'total_records': self.total_records,
            'processed_records': self.processed_records,
            'embeddings_created': self.embeddings_created,
            'embeddings_failed': self.embeddings_failed,
            'progress_percent': round((self.processed_records / self.total_records * 100), 1) if self.total_records > 0 else 0,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_seconds': (self.completed_at - self.started_at).total_seconds() if self.completed_at and self.started_at else None,
            'error_message': self.error_message
        }


# ============================================================================
# BACKGROUND EMBEDDING PROCESSOR
# ============================================================================

class EmbeddingProcessor:
    """
    Background Embedding Processor

    Handles large dataset embedding creation without HTTP timeout:
    - Processes in background thread
    - Chunks data for memory efficiency
    - Tracks progress for status API
    - Thread-safe job management
    """

    # Class-level job storage (thread-safe)
    _jobs: Dict[str, EmbeddingJob] = {}
    _lock = threading.Lock()

    # Processing configuration
    CHUNK_SIZE = 500  # Process 500 records at a time for memory efficiency

    @classmethod
    def start_embedding_job(
        cls,
        data_rows: List[Dict[str, Any]],
        rag_service: Any,
        app_context: Any = None
    ) -> str:
        """
        Start a background embedding job

        Args:
            data_rows: List of data dictionaries with interface_id, interface_name, etc.
            rag_service: HybridRAGService instance with create_embeddings_for_uploaded_data method
            app_context: Flask app context (optional, for database access)

        Returns:
            job_id: Unique identifier to track the job
        """
        job_id = str(uuid.uuid4())[:8]  # Short UUID for easier tracking

        # Create job entry
        job = EmbeddingJob(
            job_id=job_id,
            status=JobStatus.PENDING,
            total_records=len(data_rows)
        )

        with cls._lock:
            cls._jobs[job_id] = job

        logger.info(f"📋 Created embedding job {job_id} for {len(data_rows)} records")

        # Start background thread
        thread = threading.Thread(
            target=cls._process_embeddings,
            args=(job_id, data_rows, rag_service, app_context),
            daemon=True  # Thread will stop when main app stops
        )
        thread.start()

        logger.info(f"🚀 Started background thread for job {job_id}")

        return job_id

    @classmethod
    def _process_embeddings(
        cls,
        job_id: str,
        data_rows: List[Dict[str, Any]],
        rag_service: Any,
        app_context: Any
    ):
        """
        Background worker that processes embeddings

        This runs in a separate thread to avoid HTTP timeout
        """
        job = cls._jobs.get(job_id)
        if not job:
            logger.error(f"❌ Job {job_id} not found")
            return

        try:
            # Update job status
            with cls._lock:
                job.status = JobStatus.PROCESSING
                job.started_at = datetime.utcnow()

            logger.info(f"🔄 Processing job {job_id}: {len(data_rows)} records")

            # Push app context if provided (needed for database access)
            if app_context:
                app_context.push()

            total_embeddings = 0
            total_failed = 0

            # Process in chunks for memory efficiency
            for i in range(0, len(data_rows), cls.CHUNK_SIZE):
                chunk = data_rows[i:i + cls.CHUNK_SIZE]
                chunk_num = (i // cls.CHUNK_SIZE) + 1
                total_chunks = (len(data_rows) + cls.CHUNK_SIZE - 1) // cls.CHUNK_SIZE

                logger.info(f"   📦 Processing chunk {chunk_num}/{total_chunks} ({len(chunk)} records)")

                try:
                    # Call the RAG service to create embeddings for this chunk
                    if rag_service and hasattr(rag_service, 'create_embeddings_for_uploaded_data'):
                        result = rag_service.create_embeddings_for_uploaded_data(chunk)

                        if result.get('success'):
                            chunk_embeddings = result.get('total_embeddings', 0)
                            chunk_failed = result.get('failed', 0)
                            total_embeddings += chunk_embeddings
                            total_failed += chunk_failed
                            logger.info(f"   ✅ Chunk {chunk_num}: {chunk_embeddings} embeddings created")
                        else:
                            logger.warning(f"   ⚠️ Chunk {chunk_num} failed: {result.get('error')}")
                            total_failed += len(chunk) * 2  # Assume 2 embeddings per record (name + description)
                    else:
                        logger.warning(f"   ⚠️ RAG service not available for chunk {chunk_num}")
                        total_failed += len(chunk) * 2

                except Exception as chunk_err:
                    logger.error(f"   ❌ Chunk {chunk_num} error: {chunk_err}")
                    total_failed += len(chunk) * 2

                # Update progress
                with cls._lock:
                    job.processed_records = min(i + len(chunk), len(data_rows))
                    job.embeddings_created = total_embeddings
                    job.embeddings_failed = total_failed

                logger.info(f"   📊 Progress: {job.processed_records}/{job.total_records} records")

            # Mark job as completed
            with cls._lock:
                job.status = JobStatus.COMPLETED
                job.completed_at = datetime.utcnow()
                job.embeddings_created = total_embeddings
                job.embeddings_failed = total_failed

            duration = (job.completed_at - job.started_at).total_seconds()
            logger.info(f"✅ Job {job_id} completed: {total_embeddings} embeddings in {duration:.1f}s")

        except Exception as e:
            logger.error(f"❌ Job {job_id} failed: {e}")
            import traceback
            logger.error(traceback.format_exc())

            with cls._lock:
                job.status = JobStatus.FAILED
                job.completed_at = datetime.utcnow()
                job.error_message = str(e)

        finally:
            # Pop app context if we pushed it
            if app_context:
                try:
                    app_context.pop()
                except:
                    pass

    @classmethod
    def get_job_status(cls, job_id: str) -> Optional[Dict[str, Any]]:
        """
        Get status of an embedding job

        Args:
            job_id: Job identifier from start_embedding_job

        Returns:
            Dictionary with job status, or None if job not found
        """
        with cls._lock:
            job = cls._jobs.get(job_id)
            if job:
                return job.to_dict()
        return None

    @classmethod
    def get_all_jobs(cls) -> List[Dict[str, Any]]:
        """Get status of all jobs"""
        with cls._lock:
            return [job.to_dict() for job in cls._jobs.values()]

    @classmethod
    def get_latest_job(cls) -> Optional[Dict[str, Any]]:
        """Get the most recent job"""
        with cls._lock:
            if not cls._jobs:
                return None

            # Get job with latest started_at
            latest = max(
                cls._jobs.values(),
                key=lambda j: j.started_at or datetime.min
            )
            return latest.to_dict()

    @classmethod
    def cleanup_old_jobs(cls, max_age_hours: int = 24):
        """Remove jobs older than max_age_hours"""
        cutoff = datetime.utcnow()

        with cls._lock:
            old_jobs = [
                job_id for job_id, job in cls._jobs.items()
                if job.completed_at and (cutoff - job.completed_at).total_seconds() > max_age_hours * 3600
            ]

            for job_id in old_jobs:
                del cls._jobs[job_id]

            if old_jobs:
                logger.info(f"🧹 Cleaned up {len(old_jobs)} old embedding jobs")


# ============================================================================
# HELPER FUNCTION FOR EASY IMPORT
# ============================================================================

def start_background_embedding(
    data_rows: List[Dict[str, Any]],
    rag_service: Any,
    app_context: Any = None
) -> str:
    """
    Convenience function to start background embedding

    Usage:
        from backend.services.background_embedding_processor import start_background_embedding

        job_id = start_background_embedding(data_rows, rag_service, current_app.app_context())
    """
    return EmbeddingProcessor.start_embedding_job(data_rows, rag_service, app_context)


def get_embedding_status(job_id: str = None) -> Optional[Dict[str, Any]]:
    """
    Get embedding job status

    Usage:
        from backend.services.background_embedding_processor import get_embedding_status

        status = get_embedding_status(job_id)  # Specific job
        status = get_embedding_status()  # Latest job
    """
    if job_id:
        return EmbeddingProcessor.get_job_status(job_id)
    return EmbeddingProcessor.get_latest_job()


__all__ = [
    'EmbeddingProcessor',
    'EmbeddingJob',
    'JobStatus',
    'start_background_embedding',
    'get_embedding_status'
]
