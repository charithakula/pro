"""
✅ PRODUCTION-READY Hybrid RAG Service - COMPLETE FINAL VERSION WITH ALL FEATURES
==================================================================================

KEY IMPROVEMENTS:
✅ RETURNS ALL 44 COLUMNS in every response
✅ ORGANIZED DISPLAY with 7 categories
✅ SEQUENTIAL NUMBERING (1., 2., 3., ...) in ALL functions
✅ InterfaceDetailsFormatter class for complete formatting
✅ DB_SCHEMA (igpt) support on all queries
✅ Safe config access with .get() (no AttributeError)
✅ Intelligent greeting detection
✅ Smart query routing (ID Lookup → Vector → SQL → LLM)
✅ GPT-5-MINI token limit fixes
✅ Vector search with embeddings
✅ LLM formatting with complex error handling
✅ Aggregation & statistics
✅ Multiple fallback chains
✅ Comprehensive error handling
✅ Enhanced logging
✅ DYNAMIC SQL SEARCH - NO HARDCODING (NEW)

CRITICAL FIXES:
✅ SELECT * instead of hardcoded 6 columns
✅ InterfaceDetailsFormatter handles all 44 columns
✅ Sequential numbering in ALL functions with enumerate()
✅ Smart field selection (shows only populated)
✅ LLM complexity preserved and enhanced
✅ All helper methods included
✅ Complete aggregation stats
✅ Full error handling with retries
✅ DynamicSearchHelper for auto-discovering columns and values

OUTPUT FORMAT - NOW WITH ALL 44 COLUMNS:

1. **INT-1001** - API Product 1
   Status: Retired | Platform: HR
   Description: Integration for HR data synchronization...
   
   **Pattern & Type:**
     • Pattern: REST to REST
     • Mode: Real-time
     • Build Type: Custom
   
   **Operations & Communication:**
     • Operation: SyncHR
     • Mode: Asynchronous
     • Frequency: Daily
     • Priority: High
     • QoS: 99.9%
   
   **Source System:**
     • Type: SAP ERP
     • System: SAP ERP
     • Protocol: HTTP
     • Format: JSON
     • URL: https://sap.company.com
   
   **Target System:**
     • Type: Azure
     • System: Azure Cloud
     • Protocol: REST
     • Format: JSON
     • URL: https://api.azure.com
   
   **Dependencies:**
     • Dependency: INT-1000
     • Resolver: IT Operations
   
   **Metadata:**
     • Reuse: Reusable
     • Project: HR Modernization
     • OU: OU-IT
     • Go-Live: 2025-01-15
     • Work Order: WO-12345
"""

import os
import logging
import re
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from flask import current_app
from sqlalchemy import text
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# ============================================================================
# DYNAMIC SEARCH HELPER - NO HARDCODING
# ============================================================================

class DynamicSearchHelper:
    """
    Dynamic search helper - discovers data structure automatically
    
    ✅ How it works:
    1. Auto-detects all columns in the database
    2. Auto-discovers unique values in searchable columns
    3. Matches keywords to actual data dynamically
    4. Works with ANY database schema/data structure
    5. No hardcoded column names or values
    6. Self-learning and adaptive
    """
    
    def __init__(self, db_connection, db_schema: str = 'igpt'):
        self.db = db_connection
        self.db_schema = db_schema
        self.table_name = 'integration_interfaces'
        self._column_cache = None
        self._unique_values_cache = {}
        self._last_cache_update = None
    
    
    def get_all_columns(self) -> List[str]:
        """Get all column names from the table - dynamically"""
        if self._column_cache and self._is_cache_valid():
            return self._column_cache
        
        try:
            if hasattr(self.db, 'execute'):
                query = f"""
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = '{self.db_schema}'
                    AND table_name = '{self.table_name}'
                    ORDER BY ordinal_position
                """
                result = self.db.execute(text(query))
                columns = [row[0] for row in result.fetchall()]
            else:
                cursor = self.db.cursor()
                query = f"""
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = '{self.db_schema}'
                    AND table_name = '{self.table_name}'
                    ORDER BY ordinal_position
                """
                cursor.execute(query)
                columns = [row[0] for row in cursor.fetchall()]
                cursor.close()
            
            self._column_cache = columns
            self._last_cache_update = datetime.utcnow()
            logger.info(f"✅ Discovered {len(columns)} columns")
            return columns
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to get columns: {e}")
            return []
    
    
    def get_unique_values(self, column_name: str, limit: int = 100) -> List[str]:
        """Get unique values from a column - dynamically"""
        cache_key = f"{column_name}_{limit}"
        
        if cache_key in self._unique_values_cache and self._is_cache_valid():
            return self._unique_values_cache[cache_key]
        
        try:
            if hasattr(self.db, 'execute'):
                query = f"""
                    SELECT DISTINCT {column_name}
                    FROM {self.db_schema}.{self.table_name}
                    WHERE {column_name} IS NOT NULL
                    ORDER BY {column_name}
                    LIMIT {limit}
                """
                result = self.db.execute(text(query))
                values = [str(row[0]).strip() for row in result.fetchall() if row[0]]
            else:
                cursor = self.db.cursor()
                query = f"""
                    SELECT DISTINCT {column_name}
                    FROM {self.db_schema}.{self.table_name}
                    WHERE {column_name} IS NOT NULL
                    ORDER BY {column_name}
                    LIMIT {limit}
                """
                cursor.execute(query)
                values = [str(row[0]).strip() for row in cursor.fetchall() if row[0]]
                cursor.close()
            
            self._unique_values_cache[cache_key] = values
            return values
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to get values for {column_name}: {e}")
            return []
    
    
    def find_columns_containing_keyword(self, keyword: str, exclude_cols: List[str] = None) -> List[Tuple[str, List[str]]]:
        """
        Find which columns contain the keyword value
        
        Returns: List of (column_name, matching_values) tuples
        """
        if not keyword or not keyword.strip():
            return []
        
        if exclude_cols is None:
            exclude_cols = ['id', 'created_at', 'updated_at']
        
        keyword_lower = keyword.lower().strip()
        results = []
        all_columns = self.get_all_columns()
        
        # Searchable columns (skip ID, timestamps, system columns)
        searchable_columns = [
            col for col in all_columns 
            if col not in exclude_cols 
            and not col.startswith('_')
        ]
        
        logger.info(f"🔍 Searching {len(searchable_columns)} columns for '{keyword}'...")
        
        for column in searchable_columns:
            try:
                unique_values = self.get_unique_values(column)
                
                # Find matching values
                matching_values = [
                    val for val in unique_values
                    if keyword_lower in val.lower()
                ]
                
                if matching_values:
                    results.append((column, matching_values))
                    logger.info(f"   ✅ {column}: {len(matching_values)} matches → {matching_values[:3]}")
            
            except Exception as e:
                logger.warning(f"   ⚠️ Error checking {column}: {e}")
        
        return results
    
    
    def _is_cache_valid(self) -> bool:
        """Check if cache is still valid (1 hour TTL)"""
        if not self._last_cache_update:
            return False
        
        age_seconds = (datetime.utcnow() - self._last_cache_update).total_seconds()
        return age_seconds < 3600  # 1 hour cache
    
    
    def clear_cache(self):
        """Clear the cache"""
        self._column_cache = None
        self._unique_values_cache = {}
        self._last_cache_update = None
        logger.info("🧹 Cache cleared")


# ============================================================================
# INTERFACE DETAILS FORMATTER - FOR ALL 44 COLUMNS
# ============================================================================

class InterfaceDetailsFormatter:
    """✅ Format interface details with ALL 44 columns organized by category"""
    
    @staticmethod
    def format_interface(row_dict: Dict[str, Any]) -> str:
        """Format complete interface with all 44 columns"""
        lines = []
        
        # HEADER: ID and Name
        interface_id = row_dict.get('interface_id', 'Unknown')
        interface_name = row_dict.get('interface_name', 'Unknown')
        lines.append(f"**{interface_id}** - {interface_name}")
        
        # QUICK SUMMARY
        status = row_dict.get('status', 'Unknown')
        platform = row_dict.get('interface_platform', 'Unknown')
        lines.append(f"Status: {status} | Platform: {platform}")
        
        # CORE DESCRIPTION
        if row_dict.get('interface_description'):
            desc = row_dict['interface_description']
            lines.append(f"Description: {desc[:200]}{'...' if len(desc) > 200 else ''}")
        
        # PATTERN & TYPE (4 columns)
        pattern_items = []
        if row_dict.get('interface_pattern'):
            pattern_items.append(f"Pattern: {row_dict['interface_pattern']}")
        if row_dict.get('interface_mode'):
            pattern_items.append(f"Mode: {row_dict['interface_mode']}")
        if row_dict.get('interface_build_type'):
            pattern_items.append(f"Build: {row_dict['interface_build_type']}")
        if row_dict.get('sub_interface'):
            pattern_items.append(f"Sub: {row_dict['sub_interface']}")
        
        if pattern_items:
            lines.append("")
            lines.append("**Pattern & Type:**")
            for item in pattern_items:
                lines.append(f"  • {item}")
        
        # OPERATIONS & COMMUNICATION (8 columns)
        ops_items = []
        if row_dict.get('operation_name'):
            ops_items.append(f"Operation: {row_dict['operation_name']}")
        if row_dict.get('communication_mode'):
            ops_items.append(f"Mode: {row_dict['communication_mode']}")
        if row_dict.get('frequency'):
            ops_items.append(f"Frequency: {row_dict['frequency']}")
        if row_dict.get('volume'):
            ops_items.append(f"Volume: {row_dict['volume']}")
        if row_dict.get('schedule'):
            ops_items.append(f"Schedule: {row_dict['schedule']}")
        if row_dict.get('priority'):
            ops_items.append(f"Priority: {row_dict['priority']}")
        if row_dict.get('qos'):
            ops_items.append(f"QoS: {row_dict['qos']}")
        if row_dict.get('retention_period'):
            ops_items.append(f"Retention: {row_dict['retention_period']}")
        
        if ops_items:
            lines.append("")
            lines.append("**Operations & Communication:**")
            for item in ops_items:
                lines.append(f"  • {item}")
        
        # SOURCE SYSTEM (8 columns)
        source_items = []
        if row_dict.get('source_ci_type'):
            source_items.append(f"Type: {row_dict['source_ci_type']}")
        if row_dict.get('source_name'):
            source_items.append(f"System: {row_dict['source_name']}")
        if row_dict.get('source_protocol'):
            source_items.append(f"Protocol: {row_dict['source_protocol']}")
        if row_dict.get('source_data_format'):
            source_items.append(f"Format: {row_dict['source_data_format']}")
        if row_dict.get('source_service_url'):
            source_items.append(f"URL: {row_dict['source_service_url']}")
        if row_dict.get('source_trust_level'):
            source_items.append(f"Trust: {row_dict['source_trust_level']}")
        if row_dict.get('source_resolver_contact'):
            source_items.append(f"Contact: {row_dict['source_resolver_contact']}")
        if row_dict.get('source_intermediary'):
            source_items.append(f"Intermediary: {row_dict['source_intermediary']}")
        
        if source_items:
            lines.append("")
            lines.append("**Source System:**")
            for item in source_items:
                lines.append(f"  • {item}")
        
        # TARGET SYSTEM (8 columns)
        target_items = []
        if row_dict.get('target_ci_type'):
            target_items.append(f"Type: {row_dict['target_ci_type']}")
        if row_dict.get('target_name'):
            target_items.append(f"System: {row_dict['target_name']}")
        if row_dict.get('target_protocol'):
            target_items.append(f"Protocol: {row_dict['target_protocol']}")
        if row_dict.get('target_data_format'):
            target_items.append(f"Format: {row_dict['target_data_format']}")
        if row_dict.get('target_service_url'):
            target_items.append(f"URL: {row_dict['target_service_url']}")
        if row_dict.get('target_trust_level'):
            target_items.append(f"Trust: {row_dict['target_trust_level']}")
        if row_dict.get('target_resolver_contact'):
            target_items.append(f"Contact: {row_dict['target_resolver_contact']}")
        if row_dict.get('target_intermediary'):
            target_items.append(f"Intermediary: {row_dict['target_intermediary']}")
        
        if target_items:
            lines.append("")
            lines.append("**Target System:**")
            for item in target_items:
                lines.append(f"  • {item}")
        
        # DEPENDENCIES (2 columns)
        deps_items = []
        if row_dict.get('dependency_id'):
            deps_items.append(f"Dependency: {row_dict['dependency_id']}")
        if row_dict.get('interface_resolver_group'):
            deps_items.append(f"Resolver: {row_dict['interface_resolver_group']}")
        
        if deps_items:
            lines.append("")
            lines.append("**Dependencies:**")
            for item in deps_items:
                lines.append(f"  • {item}")
        
        # METADATA (8 columns)
        meta_items = []
        if row_dict.get('reuse_status'):
            meta_items.append(f"Reuse: {row_dict['reuse_status']}")
        if row_dict.get('integration_pattern'):
            meta_items.append(f"Pattern: {row_dict['integration_pattern']}")
        if row_dict.get('project_name'):
            meta_items.append(f"Project: {row_dict['project_name']}")
        if row_dict.get('ou'):
            meta_items.append(f"OU: {row_dict['ou']}")
        if row_dict.get('production_migration_date'):
            meta_items.append(f"Go-Live: {row_dict['production_migration_date']}")
        if row_dict.get('pid_wo'):
            meta_items.append(f"Work Order: {row_dict['pid_wo']}")
        if row_dict.get('api_product_name'):
            meta_items.append(f"API Product: {row_dict['api_product_name']}")
        if row_dict.get('process_area'):
            meta_items.append(f"Process Area: {row_dict['process_area']}")
        if row_dict.get('comments'):
            comments = row_dict['comments']
            meta_items.append(f"Notes: {comments[:100]}{'...' if len(comments) > 100 else ''}")
        
        if meta_items:
            lines.append("")
            lines.append("**Metadata:**")
            for item in meta_items:
                lines.append(f"  • {item}")
        
        return "\n".join(lines)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    ✅ Get schema from Flask config (config.py)
    
    Returns:
        Schema name (e.g., 'igpt')
    """
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        # Outside application context, default to 'igpt'
        return 'igpt'


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class RAGConfig:
    """Configuration for RAG Service"""
    vector_enabled: bool = True
    vector_search_limit: int = 10
    similarity_threshold: float = 0.7
    
    llm_enabled: bool = True
    llm_max_retries: int = 2
    llm_timeout_seconds: int = 30
    llm_temperature: float = 0.7
    
    # Model-specific token limits (FIX FOR GPT-5-MINI)
    llm_max_tokens_mini: int = 2000  # For mini models
    llm_max_tokens_standard: int = 4000  # For standard models
    
    @classmethod
    def from_flask_config(cls, flask_config) -> 'RAGConfig':
        """Load from Flask config object - SAFELY"""
        return cls(
            vector_enabled=flask_config.get('FEATURE_AI_SERVICES', True),
            llm_enabled=flask_config.get('FEATURE_AI_SERVICES', True),
            llm_temperature=flask_config.get('AZURE_OPENAI_TEMPERATURE', 0.7),
            similarity_threshold=0.5
        )


@dataclass
class RAGMetrics:
    """Metrics for RAG operations"""
    total_queries: int = 0
    id_lookups: int = 0
    vector_searches: int = 0
    sql_fallbacks: int = 0
    llm_formats: int = 0
    errors: int = 0
    total_processing_time_ms: float = 0
    
    def average_processing_time_ms(self) -> float:
        if self.total_queries == 0:
            return 0
        return self.total_processing_time_ms / self.total_queries
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'total_queries': self.total_queries,
            'breakdown': {
                'id_lookups': self.id_lookups,
                'vector_searches': self.vector_searches,
                'sql_fallbacks': self.sql_fallbacks,
                'llm_formats': self.llm_formats,
                'errors': self.errors
            },
            'performance': {
                'average_processing_time_ms': round(self.average_processing_time_ms(), 2)
            }
        }


# ============================================================================
# MAIN SERVICE
# ============================================================================

class HybridRAGService:
    """
    Production-Ready Smart Hybrid RAG System WITH ALL FEATURES
    
    Features:
    - ✅ Safe config access with .get() (no AttributeError)
    - ✅ DB_SCHEMA (igpt) support on all queries
    - ✅ FIXED: Sequential numbering in all results (1., 2., 3., ...)
    - ✅ Intelligent greeting detection
    - ✅ Smart response routing
    - ✅ Fixes gpt-5-mini token limit issues
    - ✅ Vector search with embeddings
    - ✅ LLM formatting with complex error handling
    - ✅ Aggregation & statistics
    - ✅ Multiple fallback chains
    - ✅ Connection pooling
    - ✅ Comprehensive metrics
    - ✅ Enhanced logging
    - ✅ DYNAMIC SQL SEARCH - NO HARDCODING (NEW)
    """
    
    def __init__(self, db_connection=None, openai_client=None, config: Optional[Dict[str, Any]] = None):
        """Initialize RAG Service using Flask config - FULLY SAFE"""
        self.db = db_connection
        self.openai_client = openai_client
        self.config = config or {}
        self.vector_search = None
        self.llm_enabled = False
        self.dynamic_search_helper = None  # NEW: Dynamic search helper
        
        # ✅ Get schema from config
        self.db_schema = get_db_schema()
        
        # Get Flask config object (safely)
        flask_config = self.config.get('flask_config', {})
        
        logger.info("=" * 80)
        logger.info("🤖 Initializing Production Hybrid RAG Service...")
        logger.info("=" * 80)
        
        # Load configuration from Flask config - USE .get() FOR SAFETY
        if flask_config:
            logger.info("\n📋 Loading Flask Configuration...")
            
            try:
                self.rag_config = RAGConfig.from_flask_config(flask_config)
                logger.info("   ✓ RAGConfig loaded from Flask config")
            except Exception as e:
                logger.warning(f"   ⚠️ RAGConfig error: {e}, using defaults")
                self.rag_config = RAGConfig()
            
            # ✅ USE .get() FOR ALL CONFIG ACCESS - This prevents AttributeError
            self.deployment = flask_config.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
            self.azure_endpoint = flask_config.get('AZURE_OPENAI_ENDPOINT', '')
            self.azure_api_key = flask_config.get('AZURE_OPENAI_API_KEY', '')
            self.azure_api_version = flask_config.get('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
            
            logger.info(f"   ✓ AZURE_OPENAI_DEPLOYMENT: {self.deployment}")
            logger.info(f"   ✓ AZURE_OPENAI_API_VERSION: {self.azure_api_version}")
            logger.info(f"   ✓ DB_SCHEMA: {self.db_schema}")
            
        else:
            logger.warning("\n⚠️  Flask config not provided, using environment variables")
            
            # Fallback to environment variables
            self.rag_config = RAGConfig()
            self.deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
            self.azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT', '')
            self.azure_api_key = os.getenv('AZURE_OPENAI_API_KEY', '')
            self.azure_api_version = os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
            
            logger.info(f"   ✓ From env: AZURE_OPENAI_DEPLOYMENT={self.deployment}")
            logger.info(f"   ✓ DB_SCHEMA: {self.db_schema}")
        
        self.metrics = RAGMetrics()
        
        # Validate database
        logger.info("\n📋 Validating Components...")
        if db_connection:
            try:
                if hasattr(db_connection, 'execute'):
                    db_connection.execute(text("SELECT 1"))
                    logger.info("   ✅ Database connection OK")
                else:
                    cursor = db_connection.cursor()
                    cursor.execute("SELECT 1")
                    cursor.close()
                    logger.info("   ✅ Database connection OK")
            except Exception as e:
                logger.warning(f"   ⚠️ Database check failed: {e}")
        else:
            logger.warning("   ⚠️ Database connection not provided")
        
        # Check LLM availability
        if openai_client and self.rag_config.llm_enabled:
            logger.info("   ✅ Azure OpenAI client provided and enabled")
            logger.info(f"   📝 Deployment: {self.deployment}")
            
            # Detect mini model and warn
            if 'mini' in self.deployment.lower():
                logger.warning(f"   ⚠️ Mini model detected: {self.deployment}")
                logger.warning(f"   ⚠️ Output limited to {self.rag_config.llm_max_tokens_mini} tokens")
                logger.warning(f"   ⚠️ Temperature parameter disabled for mini models")
                logger.warning(f"   💡 Consider switching to gpt-35-turbo for better results")
            
            self.llm_enabled = True
        else:
            if not openai_client:
                logger.info("   ⚠️ No Azure OpenAI client provided")
            if not self.rag_config.llm_enabled:
                logger.info("   ⚠️ LLM disabled by config")
            self.llm_enabled = False
        
        # Initialize Vector Search
        self._initialize_vector_search()
        
        # Initialize Dynamic Search Helper (NEW)
        self._initialize_dynamic_search()
        
        logger.info("\n✅ Configuration validation complete")
        
        # Print routing info
        if self.llm_enabled:
            logger.info("\n📍 Query Routing Path:")
            logger.info("   1. Greeting Detection")
            logger.info("   2. ID Lookup → Vector Search → Dynamic SQL → LLM")
        else:
            logger.info("\n📍 Query Routing Path:")
            logger.info("   1. Greeting Detection")
            logger.info("   2. ID Lookup → Vector Search → Dynamic SQL")
        
        logger.info(f"\n⚙️  Service Settings:")
        logger.info(f"   - Similarity Threshold: {self.rag_config.similarity_threshold:.0%}")
        logger.info(f"   - Vector Search Limit: {self.rag_config.vector_search_limit}")
        logger.info(f"   - LLM Max Tokens: {self.rag_config.llm_max_tokens_standard}")
        logger.info(f"   - LLM Temperature: {self.rag_config.llm_temperature}")
        logger.info(f"   - LLM Max Retries: {self.rag_config.llm_max_retries}")
        logger.info(f"   - DB Schema: {self.db_schema}")
        logger.info(f"   - ✅ SEQUENTIAL NUMBERING ENABLED (1., 2., 3., ...)")
        logger.info(f"   - ✅ ALL 44 COLUMNS INCLUDED")
        logger.info(f"   - ✅ LLM FORMATTING ENABLED")
        logger.info(f"   - ✅ AGGREGATION STATS ENABLED")
        logger.info(f"   - ✅ DYNAMIC SQL SEARCH ENABLED (NO HARDCODING)")
        logger.info(f"   - ✅ FULL ERROR HANDLING")
        
        logger.info("\n✅ Production RAG Service initialized successfully")
        logger.info("=" * 80 + "\n")
    
    
    def _initialize_vector_search(self):
        """Initialize vector search service"""
        try:
            logger.info("\n🔌 Initializing Vector Search...")

            try:
                from backend.services.vector_search import VectorSearch
                self.vector_search = VectorSearch(config=self.config)
                logger.info("   ✅ Vector Search initialized with connection pooling")
            
            except ImportError as import_err:
                logger.warning(f"   ⚠️ Vector Search import failed: {import_err}")
                self.vector_search = None
            
            except Exception as init_err:
                logger.warning(f"   ⚠️ Vector Search init failed: {init_err}")
                self.vector_search = None
        
        except Exception as e:
            logger.warning(f"   ⚠️ Vector Search error: {e}")
            self.vector_search = None
    
    
    def _initialize_dynamic_search(self):
        """Initialize dynamic search helper - NEW"""
        try:
            if self.db:
                self.dynamic_search_helper = DynamicSearchHelper(self.db, self.db_schema)
                logger.info("   ✅ Dynamic search helper initialized")
            else:
                logger.warning("   ⚠️ Dynamic search helper not initialized (no DB)")
                self.dynamic_search_helper = None
        except Exception as e:
            logger.warning(f"   ⚠️ Dynamic search helper init failed: {e}")
            self.dynamic_search_helper = None
    
    
    def _is_greeting(self, question: str) -> bool:
        """Detect if question is just a greeting"""
        greetings = [
            'hi', 'hello', 'hey', 'greetings', 'how are you',
            'what\'s up', 'howdy', 'sup', 'hiya', 'hallo',
            'good morning', 'good afternoon', 'good evening',
            'welcome', 'starting fresh'
        ]
        
        q_lower = question.lower().strip()
        
        # Check if it's just a greeting (less than 5 chars or exact match)
        if len(q_lower) < 5:
            for greeting in greetings:
                if greeting in q_lower or q_lower in greeting:
                    return True
        
        return False
    
    
    def _get_greeting_response(self) -> str:
        """Get a smart greeting response"""
        try:
            if not self.db:
                return "Hello! I'm your AI Assistant. How can I help you with your integrations?"
            
            # Get some stats to personalize greeting
            try:
                schema = self.db_schema
                
                if hasattr(self.db, 'execute'):
                    total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                    total = total_result.scalar() or 0
                    
                    status_result = self.db.execute(text(f"""
                        SELECT status, COUNT(*) as count 
                        FROM {schema}.integration_interfaces 
                        GROUP BY status
                        ORDER BY count DESC
                        LIMIT 1
                    """))
                    status_row = status_result.fetchone()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                    total = cursor.fetchone()[0]
                    
                    cursor.execute(f"""
                        SELECT status, COUNT(*) as count 
                        FROM {schema}.integration_interfaces 
                        GROUP BY status
                        ORDER BY count DESC
                        LIMIT 1
                    """)
                    status_row = cursor.fetchone()
                    cursor.close()
                
                # Personalized greeting with insights
                if total > 0:
                    top_status = status_row[0] if status_row else "Active"
                    greeting = f"👋 Hello! I'm your AI Assistant powered by Hybrid RAG. "
                    greeting += f"I can help you find information about your {total} integration interfaces with complete details (all 44 columns). "
                    greeting += f"Most of them are {top_status}. "
                    greeting += f"\n\nTry asking me:\n"
                    greeting += f"• 'Show me SAP CPI interfaces'\n"
                    greeting += f"• 'How many are in Testing?'\n"
                    greeting += f"• 'What's INT-1010?'\n"
                    greeting += f"• 'Find Azure APIM interfaces'"
                    return greeting
                else:
                    return "👋 Hello! I'm your AI Assistant. No integration data loaded yet. Please upload an Excel file with your integration interfaces to get started!"
            
            except Exception as e:
                logger.warning(f"⚠️ Greeting personalization failed: {e}")
                return "👋 Hello! I'm your AI Assistant powered by Hybrid RAG. Ask about your integration interfaces!"
        
        except Exception as e:
            logger.error(f"❌ Greeting failed: {e}")
            return "Hello! How can I help?"
    
    
    def create_embeddings_for_uploaded_data(self, data_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create embeddings for uploaded data"""
        if not self.vector_search:
            return {'success': False, 'total_embeddings': 0, 'error': 'Vector search unavailable'}
        
        if not self.vector_search.use_local_embeddings:
            return {'success': False, 'total_embeddings': 0, 'error': 'Embeddings disabled'}
        
        if not data_rows:
            return {'success': False, 'total_embeddings': 0, 'error': 'No data provided'}
        
        try:
            logger.info(f"🔄 Creating embeddings for {len(data_rows)} items...")
            start_time = datetime.utcnow()
            
            batch_data = []
            
            for row in data_rows:
                interface_id = None
                for col in ['interface_id', 'Interface ID', 'id', 'ID']:
                    if col in row and row[col]:
                        interface_id = str(row[col]).strip()
                        break
                
                if not interface_id:
                    continue
                
                interface_name = None
                for col in ['interface_name', 'Interface Name', 'name', 'Name', 'Title']:
                    if col in row and row[col]:
                        interface_name = str(row[col]).strip()
                        break
                
                interface_description = None
                for col in ['interface_description', 'Interface Description', 'description', 'Description']:
                    if col in row and row[col]:
                        interface_description = str(row[col]).strip()
                        break
                
                if interface_name:
                    batch_data.append({
                        'interface_id': interface_id,
                        'content_type': 'name',
                        'content': interface_name
                    })
                
                if interface_description:
                    batch_data.append({
                        'interface_id': interface_id,
                        'content_type': 'description',
                        'content': interface_description
                    })
            
            logger.info(f"   ✅ Prepared {len(batch_data)} embedding items")
            
            if not batch_data:
                return {'success': False, 'total_embeddings': 0, 'error': 'No valid data'}
            
            texts_to_embed = [item['content'] for item in batch_data]
            embeddings = self.vector_search.generate_embeddings(texts_to_embed)
            
            if not embeddings:
                return {'success': False, 'total_embeddings': 0, 'error': 'Generation failed'}
            
            embeddings_to_store = []
            for item, embedding in zip(batch_data, embeddings):
                embeddings_to_store.append({
                    'interface_id': item['interface_id'],
                    'content_type': item['content_type'],
                    'content': item['content'],
                    'embedding': embedding
                })
            
            succeeded, failed = self.vector_search.store_embeddings(embeddings_to_store)
            elapsed = (datetime.utcnow() - start_time).total_seconds()
            
            logger.info(f"✅ Complete: {succeeded} embeddings in {elapsed:.1f}s")
            
            return {
                'success': True,
                'total_embeddings': succeeded,
                'total_rows': len(data_rows),
                'failed': failed,
                'processing_time_seconds': elapsed
            }
        
        except Exception as e:
            logger.error(f"❌ Embedding creation failed: {e}")
            return {'success': False, 'total_embeddings': 0, 'error': str(e)}
    
    
    def _detect_query_intent(self, question: str) -> Dict[str, Any]:
        """Detect query intent"""
        if not question or not question.strip():
            return {'type': 'error', 'description': 'Empty query'}
        
        q_lower = question.lower().strip()
        
        # 1. Exact ID lookup
        id_match = re.findall(r'INT-\d+', question, re.IGNORECASE)
        if id_match:
            return {
                'type': 'id_lookup',
                'ids': id_match,
                'description': 'Specific interface ID lookup'
            }
        
        # 2. Aggregation queries
        if any(word in q_lower for word in ['how many', 'count', 'total', 'number', 'all interfaces', 'statistics']):
            return {
                'type': 'aggregation',
                'description': 'Count/statistics query'
            }
        
        # 3. Semantic search
        if any(word in q_lower for word in ['for', 'synchronization', 'integration', 'data', 'system', 'what', 'find', 'similar', 'show']):
            return {
                'type': 'semantic_search',
                'description': 'Semantic search'
            }
        
        return {
            'type': 'semantic_search',
            'description': 'General query'
        }
    
    
    def process_question(self, question: str) -> Dict[str, Any]:
        """Process user question with intelligent routing"""
        self.metrics.total_queries += 1
        start_time = datetime.utcnow()
        
        try:
            if not question or not question.strip():
                return self._error_response("Empty question", start_time)
            
            logger.info(f"\n🔍 Processing: {question[:100]}...")
            
            # ✨ Check for greeting first
            if self._is_greeting(question):
                logger.info("   → Greeting detected")
                greeting_response = self._get_greeting_response()
                
                elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                self.metrics.total_processing_time_ms += elapsed_ms
                
                logger.info(f"   ✅ Greeting response ({elapsed_ms:.0f}ms)\n")
                
                return {
                    'answer': greeting_response,
                    'method': 'greeting',
                    'routing': {
                        'query_type': 'greeting',
                        'path': 'greeting',
                    },
                    'performance': {
                        'processing_time_ms': round(elapsed_ms, 2),
                        'processing_time_seconds': round(elapsed_ms / 1000, 2)
                    },
                    'cost': {
                        'optimization': 'no_computation',
                        'estimated_usd': 0
                    }
                }
            
            # Continue with normal processing
            intent = self._detect_query_intent(question)
            
            if intent['type'] == 'error':
                return self._error_response(intent['description'], start_time)
            
            logger.info(f"   → Type: {intent['type']}")
            
            final_answer = None
            routing_method = None
            
            # ROUTE 1: ID LOOKUP
            if intent['type'] == 'id_lookup':
                self.metrics.id_lookups += 1
                logger.info(f"   → Looking up: {intent['ids']}")
                final_answer = self._lookup_interfaces_by_id(intent['ids'])
                routing_method = 'exact_id_lookup'
            
            # ROUTE 2: AGGREGATION
            elif intent['type'] == 'aggregation':
                logger.info("   → Aggregation")
                final_answer = self._get_aggregation_stats()
                routing_method = 'sql_aggregation'
            
            # ROUTE 3: SEMANTIC SEARCH
            elif intent['type'] == 'semantic_search':
                self.metrics.vector_searches += 1
                logger.info("   → Vector search")
                
                if self.vector_search and self.vector_search.use_local_embeddings:
                    search_result = self.vector_search.search_similar(
                        question,
                        limit=self.rag_config.vector_search_limit,
                        similarity_threshold=self.rag_config.similarity_threshold
                    )
                    vector_results = search_result.data if search_result.status.value == 'success' else []
                else:
                    vector_results = []
                
                logger.info(f"   📊 Results: {len(vector_results)}")
                
                if vector_results:
                    if self.llm_enabled and self.openai_client:
                        logger.info("   → LLM formatting")
                        
                        llm_answer = self._format_with_llm(question, vector_results)
                        
                        if llm_answer and llm_answer.strip():
                            final_answer = llm_answer
                            routing_method = 'vector_with_llm'
                            self.metrics.llm_formats += 1
                        else:
                            logger.warning("   ⚠️ LLM failed, vector format")
                            final_answer = self._format_vector_results(vector_results)
                            routing_method = 'vector_search'
                    else:
                        final_answer = self._format_vector_results(vector_results)
                        routing_method = 'vector_search'
                else:
                    self.metrics.sql_fallbacks += 1
                    logger.info("   → Dynamic SQL fallback")
                    final_answer = self._get_sql_results_with_data(question)
                    routing_method = 'dynamic_sql_fallback'
            
            if not final_answer:
                final_answer = "No results found. Try asking about specific interfaces (e.g., 'Show me SAP CPI interfaces') or use interface IDs (e.g., 'INT-1010')."
                routing_method = 'no_results'
            
            elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            self.metrics.total_processing_time_ms += elapsed_ms
            
            logger.info(f"   ✅ Ready: {routing_method} ({elapsed_ms:.0f}ms)\n")
            
            return {
                'answer': final_answer,
                'method': routing_method,
                'routing': {
                    'query_type': intent['type'],
                    'path': routing_method,
                },
                'performance': {
                    'processing_time_ms': round(elapsed_ms, 2),
                    'processing_time_seconds': round(elapsed_ms / 1000, 2)
                },
                'cost': {
                    'optimization': 'smart_routing',
                    'estimated_usd': 0.001 if 'llm' in routing_method else 0
                }
            }
        
        except Exception as e:
            self.metrics.errors += 1
            logger.error(f"❌ Processing failed: {e}")
            return self._error_response(str(e), start_time)
    
    
    def _error_response(self, error_msg: str, start_time: datetime) -> Dict[str, Any]:
        """Generate error response"""
        elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
        return {
            'answer': f'Error: {error_msg}',
            'method': 'error',
            'routing': {'query_type': 'error', 'path': 'error'},
            'performance': {
                'processing_time_ms': round(elapsed_ms, 2),
                'processing_time_seconds': round(elapsed_ms / 1000, 2)
            },
            'cost': {'optimization': 'none', 'estimated_usd': 0}
        }
    
    
    # ========================================================================
    # ✅ FUNCTION 1: _lookup_interfaces_by_id() - WITH ALL 44 COLUMNS
    # ========================================================================
    def _lookup_interfaces_by_id(self, interface_ids: List[str]) -> str:
        """
        Look up interfaces by exact ID - WITH SEQUENTIAL NUMBERING & ALL 44 COLUMNS
        """
        if not self.db:
            return "Database not available"
        
        try:
            results = []
            schema = self.db_schema
            
            for interface_id in interface_ids:
                try:
                    if hasattr(self.db, 'execute'):
                        # ✅ SELECT * for ALL 44 columns
                        result = self.db.execute(text(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = :id
                            LIMIT 1
                        """), {'id': interface_id})
                        row = result.fetchone()
                        if row:
                            keys = result.keys()
                            results.append(dict(zip(keys, row)))
                    else:
                        cursor = self.db.cursor()
                        cursor.execute(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = %s
                            LIMIT 1
                        """, (interface_id,))
                        col_names = [desc[0] for desc in cursor.description]
                        row = cursor.fetchone()
                        cursor.close()
                        if row:
                            results.append(dict(zip(col_names, row)))
                
                except Exception as e:
                    logger.warning(f"⚠️ Error: {e}")
            
            if not results:
                return f"No interfaces found: {', '.join(interface_ids)}"
            
            # ✅ FIXED: WITH ENUMERATE FOR SEQUENTIAL NUMBERING & ALL COLUMNS
            formatted = f"Found {len(results)} interface(s):\n\n"
            
            for idx, row_dict in enumerate(results, 1):
                formatted += f"{idx}. "
                formatted += InterfaceDetailsFormatter.format_interface(row_dict)
                formatted += "\n\n"
            
            logger.info(f"✅ Returning {len(results)} interfaces with sequential numbering and all 44 columns")
            return formatted
        
        except Exception as e:
            logger.error(f"❌ Lookup failed: {e}")
            return f"Error: {str(e)}"
    
    
    # ========================================================================
    # ✅ FUNCTION 2: _get_aggregation_stats() - COMPLETE STATS
    # ========================================================================
    def _get_aggregation_stats(self) -> str:
        """Get aggregation statistics with detailed breakdown"""
        if not self.db:
            return "Database not available"
        
        try:
            schema = self.db_schema
            
            if hasattr(self.db, 'execute'):
                # Total
                total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                total = total_result.scalar()
                
                # By Status
                status_result = self.db.execute(text(f"""
                    SELECT status, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY status
                    ORDER BY count DESC
                """))
                statuses = status_result.fetchall()
                
                # By Platform
                platform_result = self.db.execute(text(f"""
                    SELECT interface_platform, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """))
                platforms = platform_result.fetchall()
                
                # By Pattern
                pattern_result = self.db.execute(text(f"""
                    SELECT interface_pattern, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    WHERE interface_pattern IS NOT NULL
                    GROUP BY interface_pattern
                    ORDER BY count DESC
                """))
                patterns = pattern_result.fetchall()
            else:
                cursor = self.db.cursor()
                
                cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                total = cursor.fetchone()[0]
                
                cursor.execute(f"""
                    SELECT status, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY status
                    ORDER BY count DESC
                """)
                statuses = cursor.fetchall()
                
                cursor.execute(f"""
                    SELECT interface_platform, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """)
                platforms = cursor.fetchall()
                
                cursor.execute(f"""
                    SELECT interface_pattern, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    WHERE interface_pattern IS NOT NULL
                    GROUP BY interface_pattern
                    ORDER BY count DESC
                """)
                patterns = cursor.fetchall()
                
                cursor.close()
            
            formatted = f"**Interface Statistics**\n\n"
            formatted += f"**Total:** {total:,}\n\n"
            
            formatted += "**By Status:**\n"
            for status, count in statuses:
                percentage = (count / total * 100) if total > 0 else 0
                formatted += f"  - {status}: {count:,} ({percentage:.1f}%)\n"
            
            formatted += "\n**By Platform:**\n"
            for platform, count in platforms:
                percentage = (count / total * 100) if total > 0 else 0
                formatted += f"  - {platform}: {count:,} ({percentage:.1f}%)\n"
            
            if patterns:
                formatted += "\n**By Pattern:**\n"
                for pattern, count in patterns:
                    percentage = (count / total * 100) if total > 0 else 0
                    formatted += f"  - {pattern}: {count:,} ({percentage:.1f}%)\n"
            
            return formatted
        
        except Exception as e:
            logger.error(f"❌ Aggregation failed: {e}")
            return f"Error: {str(e)}"
    
    
    # ========================================================================
    # ✅ FUNCTION 3: _format_vector_results() - WITH SEQUENTIAL NUMBERING
    # ========================================================================
    def _format_vector_results(self, results: List[Dict[str, Any]]) -> str:
        """Format vector search results - WITH SEQUENTIAL NUMBERING"""
        if not results:
            return "No similar results found."
        
        formatted = "**Similar interfaces found:**\n\n"
        
        for idx, result in enumerate(results, 1):
            formatted += f"{idx}. **{result.get('interface_id', 'Unknown')}**\n"
            formatted += f"   Type: {result.get('content_type', 'N/A')}\n"
            formatted += f"   Content: {result.get('content', 'N/A')[:150]}\n"
            formatted += f"   Match: {result.get('similarity', 0):.1%}\n\n"
        
        return formatted
    
    
    # ========================================================================
    # ✅ FUNCTION 4: _get_sql_results_with_data() - DYNAMIC SQL (NO HARDCODING)
    # ========================================================================
    def _get_sql_results_with_data(self, question: str) -> Optional[str]:
        """
        Dynamic SQL search - NO hardcoded columns or values
        
        ✅ How it works:
        1. Takes user question (e.g., "Show SAP interfaces")
        2. Extracts keywords (e.g., "SAP")
        3. Searches ALL columns for values containing keyword
        4. Finds which columns match (e.g., interface_platform has "SAP CPI")
        5. Builds dynamic WHERE clause
        6. Executes query
        7. Returns results with ALL columns
        
        ✅ Advantages:
        - Works with ANY database structure
        - No hardcoded column names
        - No hardcoded values
        - Self-adapts to data
        - Future-proof
        """
        try:
            if not self.db:
                return None
            
            logger.info("📋 Dynamic Smart SQL Search (NO HARDCODING)...")
            schema = self.db_schema
            
            if not question or not question.strip():
                return None
            
            # Initialize dynamic search helper if not already done
            if not self.dynamic_search_helper:
                self.dynamic_search_helper = DynamicSearchHelper(self.db, schema)
            
            q_lower = question.lower().strip()
            
            # ============================================================
            # STRATEGY 1: Exact ID Lookup (INT-XXXX)
            # ============================================================
            id_matches = re.findall(r'INT-\d+', question, re.IGNORECASE)
            if id_matches:
                logger.info(f"   → ID Lookup: {id_matches}")
                ids_clause = " OR ".join([f"interface_id = '{iid}'" for iid in id_matches])
                sql_query = f"""
                    SELECT * FROM {schema}.integration_interfaces
                    WHERE {ids_clause}
                    LIMIT 10
                """
                search_type = f"Exact ID Match: {', '.join(id_matches)}"
                search_icon = "🔍"
            
            # ============================================================
            # STRATEGY 2: Dynamic Keyword Search
            # ============================================================
            else:
                # Extract potential keywords (words >= 3 chars, not common words)
                # ✅ FIX: Changed from > 3 to >= 3 to capture keywords like "SAP", "HR", "API"
                common_words = {'show', 'list', 'find', 'where', 'what', 'which', 'give', 'please', 'interfaces', 'systems', 'me', 'for', 'the', 'and', 'or', 'is', 'are', 'all', 'get', 'can', 'you', 'how', 'any'}
                words = [
                    w for w in q_lower.split() 
                    if len(w) >= 3 and w not in common_words and not w.endswith('?')
                ]
                
                if not words:
                    # Fallback: return all
                    sql_query = f"""
                        SELECT * FROM {schema}.integration_interfaces
                        ORDER BY interface_id
                        LIMIT 10
                    """
                    search_type = "All Interfaces"
                    search_icon = "📊"
                
                else:
                    logger.info(f"   → Keywords found: {words}")
                    
                    # Search for columns containing these keywords
                    all_matches = []
                    for keyword in words:
                        column_matches = self.dynamic_search_helper.find_columns_containing_keyword(keyword)
                        all_matches.extend(column_matches)
                    
                    if all_matches:
                        # Build WHERE clause from discovered columns
                        where_conditions = []
                        found_columns_set = set()
                        
                        for column, values in all_matches:
                            found_columns_set.add(column)
                            # Match any of the discovered values
                            value_conditions = " OR ".join([
                                f"{column} ILIKE '%{val}%'"
                                for val in values[:5]  # Limit to 5 values per column
                            ])
                            where_conditions.append(f"({value_conditions})")
                        
                        where_clause = " OR ".join(where_conditions)
                        sql_query = f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE {where_clause}
                            ORDER BY interface_id
                            LIMIT 10
                        """
                        
                        # Create descriptive search type
                        cols_str = ", ".join(sorted(found_columns_set))
                        search_type = f"Search in: {cols_str}"
                        search_icon = "🔎"
                        
                        logger.info(f"   → Found in columns: {cols_str}")
                    
                    else:
                        # No matches found, return all
                        logger.info("   → No specific matches, returning all interfaces")
                        sql_query = f"""
                            SELECT * FROM {schema}.integration_interfaces
                            ORDER BY interface_id
                            LIMIT 10
                        """
                        search_type = "All Interfaces (no keyword matches)"
                        search_icon = "📊"
            
            # ============================================================
            # EXECUTE QUERY
            # ============================================================
            logger.info(f"   → Search type: {search_type}")
            
            try:
                if hasattr(self.db, 'execute'):
                    result = self.db.execute(text(sql_query))
                    rows = result.fetchall()
                    keys = result.keys()
                    results = [dict(zip(keys, row)) for row in rows]
                else:
                    cursor = self.db.cursor()
                    cursor.execute(sql_query)
                    col_names = [desc[0] for desc in cursor.description]
                    rows = cursor.fetchall()
                    cursor.close()
                    results = [dict(zip(col_names, row)) for row in rows]
                
                if not rows:
                    logger.info(f"⚠️ No results found for: {search_type}")
                    return f"No results found for: {search_type}"
                
                # ============================================================
                # FORMAT RESULTS WITH ALL 44 COLUMNS
                # ============================================================
                formatted = f"{search_icon} **Found {len(results)} Results** ({search_type}):\n\n"
                
                for idx, row_dict in enumerate(results, 1):
                    formatted += f"{idx}. "
                    formatted += InterfaceDetailsFormatter.format_interface(row_dict)
                    formatted += "\n\n"
                
                logger.info(f"✅ Returned {len(results)} interfaces with all columns")
                return formatted
            
            except Exception as query_err:
                logger.warning(f"⚠️ Query failed: {query_err}")
                logger.warning(f"   Query: {sql_query}")
                return None
        
        except Exception as e:
            logger.warning(f"⚠️ Dynamic search failed: {e}")
            return None
    
    
    # ========================================================================
    # ✅ FUNCTION 5: _format_with_llm() - COMPLETE LLM WITH ALL ERROR HANDLING
    # ========================================================================
    def _format_with_llm(self, question: str, vector_results: List[Dict[str, Any]]) -> Optional[str]:
        """
        Format with Azure OpenAI - FIXED FOR GPT-5-MINI
        ✅ Auto-detects mini models and adjusts parameters
        ✅ Removes temperature parameter for mini models
        ✅ Handles token limits gracefully
        ✅ Complex retry logic with detailed error handling
        """
        if not self.openai_client:
            logger.warning("⚠️ No OpenAI client available")
            return None
        
        max_retries = self.rag_config.llm_max_retries
        
        for attempt in range(max_retries):
            try:
                # Detect model type
                model_lower = self.deployment.lower()
                is_mini_model = 'mini' in model_lower
                
                # Set token limit based on model
                if is_mini_model:
                    max_tokens = self.rag_config.llm_max_tokens_mini
                    logger.info(f"   🔍 Mini model detected: {self.deployment}")
                    logger.info(f"   📝 Max tokens: {max_tokens}")
                else:
                    max_tokens = self.rag_config.llm_max_tokens_standard
                
                # Build context - shorter for mini models
                context_lines = []
                max_results = 3 if is_mini_model else 5
                max_content_len = 100 if is_mini_model else 200
                
                for result in vector_results[:max_results]:
                    interface_id = result.get('interface_id', 'Unknown')
                    content = result.get('content', 'N/A')[:max_content_len]
                    similarity = result.get('similarity', 0)
                    
                    context_lines.append(f"• {interface_id}: {content} [{similarity:.0%}]")
                
                context = "\n".join(context_lines)
                
                # Create prompt - ultra-short for mini models
                if is_mini_model:
                    prompt = f"Question: {question}\n\nData: {context}\n\nBrief answer (1-2 sentences):"
                else:
                    prompt = f"""Summarize interfaces matching "{question}":

{context}

Provide 2-3 sentences highlighting top matches."""
                
                logger.info(f"   🧠 Attempt {attempt + 1}/{max_retries}")
                
                # Build request parameters
                request_params = {
                    "model": self.deployment,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Summarize search results briefly."
                        },
                        {"role": "user", "content": prompt}
                    ],
                    "max_completion_tokens": max_tokens
                }
                
                # ✅ CRITICAL FIX: Only add temperature if NOT mini model
                if not is_mini_model:
                    request_params["temperature"] = self.rag_config.llm_temperature
                    logger.info(f"   🌡️ Temperature: {self.rag_config.llm_temperature}")
                else:
                    logger.info("   🌡️ Temperature: disabled (mini model)")
                
                # Make request
                logger.info(f"   📤 Sending to {self.deployment}...")
                response = self.openai_client.chat.completions.create(**request_params)
                
                if not response or not response.choices:
                    logger.warning(f"   ⚠️ Empty response (attempt {attempt + 1})")
                    continue
                
                # Extract message
                message = response.choices[0].message
                llm_answer = message.content if hasattr(message, 'content') else str(message)
                
                # Check for truncation
                finish_reason = response.choices[0].finish_reason
                if finish_reason == 'length':
                    logger.warning(f"   ⚠️ Response truncated (finish_reason=length)")
                    if is_mini_model and llm_answer:
                        logger.info("   ✓ Using truncated response (mini model accepts this)")
                        return llm_answer.strip()
                
                # Validate response
                if not llm_answer or not llm_answer.strip():
                    logger.warning(f"   ⚠️ Empty content")
                    continue
                
                if len(llm_answer.strip()) < 20:
                    logger.warning(f"   ⚠️ Response too short ({len(llm_answer)} chars)")
                    continue
                
                # Check for decline phrases
                decline_phrases = ['cannot', 'unable', 'no information']
                if any(phrase in llm_answer.lower() for phrase in decline_phrases):
                    logger.warning(f"   ⚠️ LLM declined to answer")
                    continue
                
                logger.info(f"   ✅ Valid response: {len(llm_answer)} chars")
                return llm_answer.strip()
            
            except Exception as e:
                error_str = str(e).lower()
                
                # Check for token limit errors
                if 'max_tokens' in error_str or 'model output limit' in error_str or 'maximum context length' in error_str:
                    logger.error(f"   ❌ Token limit error: {e}")
                    logger.error(f"   💡 Model {self.deployment} exceeded token limits")
                    logger.error(f"   💡 Solution 1: Switch to gpt-35-turbo in .env:")
                    logger.error(f"       AZURE_OPENAI_DEPLOYMENT=gpt-35-turbo")
                    logger.error(f"   💡 Solution 2: Check your Azure deployment can handle requests")
                    
                    # Try with even fewer tokens for mini models
                    if is_mini_model and attempt == 0:
                        logger.info("   🔄 Retry with 50 tokens...")
                        self.rag_config.llm_max_tokens_mini = 50
                        continue
                    
                    return None
                
                # Check for authentication errors
                if 'authentication' in error_str or 'unauthorized' in error_str or 'api key' in error_str:
                    logger.error(f"   ❌ Authentication error: {e}")
                    logger.error(f"   💡 Check your .env has valid Azure credentials:")
                    logger.error(f"       AZURE_OPENAI_API_KEY=your-key")
                    logger.error(f"       AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
                    return None
                
                # Other errors
                logger.warning(f"   ⚠️ Error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    logger.info("   🔄 Retrying...")
                    continue
        
        logger.warning("   ❌ All LLM attempts failed - will use vector search results only")
        return None
    
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics"""
        return self.metrics.to_dict()
    
    
    def get_service_stats(self) -> Dict[str, Any]:
        """Get service statistics"""
        try:
            if not self.db:
                return {'error': 'Database not available'}
            
            schema = self.db_schema
            
            stats = {
                'timestamp': datetime.utcnow().isoformat(),
                'vector_search_enabled': self.vector_search is not None and self.vector_search.use_local_embeddings,
                'llm_enabled': self.llm_enabled,
                'llm_deployment': self.deployment,
                'embeddings_model': 'all-MiniLM-L6-v2' if self.vector_search else None,
                'similarity_threshold': self.rag_config.similarity_threshold,
                'db_schema': schema,
                'sequential_numbering': True,
                'all_44_columns': True,
                'dynamic_sql_search': True,  # NEW
                'metrics': self.get_metrics()
            }
            
            try:
                if hasattr(self.db, 'execute'):
                    interfaces_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                    stats['total_interfaces'] = interfaces_result.scalar() or 0
                    
                    embeddings_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.interface_embeddings"))
                    stats['total_embeddings'] = embeddings_result.scalar() or 0
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                    stats['total_interfaces'] = cursor.fetchone()[0]
                    cursor.execute(f"SELECT COUNT(*) FROM {schema}.interface_embeddings")
                    stats['total_embeddings'] = cursor.fetchone()[0]
                    cursor.close()
            except Exception as e:
                logger.warning(f"⚠️ Stats error: {e}")
                stats['total_interfaces'] = 0
                stats['total_embeddings'] = 0
            
            if self.vector_search:
                try:
                    stats['cache_stats'] = self.vector_search.get_cache_stats()
                except:
                    pass
            
            return stats
        
        except Exception as e:
            logger.error(f"❌ Failed to get stats: {e}")
            return {'error': str(e)}
    
    
    def health_check(self) -> Dict[str, Any]:
        """Health status"""
        health = {
            'status': 'healthy',
            'vector_search': 'disabled',
            'database': 'unavailable',
            'llm': 'disabled',
            'llm_deployment': self.deployment,
            'smart_routing': 'enabled',
            'sequential_numbering': 'enabled',
            'all_44_columns': 'enabled',
            'dynamic_sql_search': 'enabled',  # NEW
            'db_schema': self.db_schema,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if self.vector_search:
            vs_health = self.vector_search.health_check()
            health['vector_search'] = vs_health.get('status', 'unknown')
        
        if self.db:
            try:
                schema = self.db_schema
                if hasattr(self.db, 'execute'):
                    self.db.execute(text("SELECT 1"))
                else:
                    cursor = self.db.cursor()
                    cursor.execute("SELECT 1")
                    cursor.close()
                health['database'] = 'healthy'
            except:
                health['database'] = 'unhealthy'
                health['status'] = 'degraded'
        
        health['llm'] = 'healthy' if self.llm_enabled else 'disabled'
        
        if health['database'] == 'unhealthy':
            health['status'] = 'unhealthy'
        elif health['vector_search'] == 'degraded':
            health['status'] = 'degraded'
        
        return health


__all__ = ['HybridRAGService', 'InterfaceDetailsFormatter', 'DynamicSearchHelper', 'RAGConfig', 'RAGMetrics']