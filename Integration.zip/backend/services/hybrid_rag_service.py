"""
✅ PRODUCTION-READY Hybrid RAG Service - COMPLETE FINAL VERSION WITH ALL FEATURES
==================================================================================

KEY IMPROVEMENTS:
✅ RETURNS ALL 44 COLUMNS in every response
✅ ORGANIZED DISPLAY with 7 categories
✅ SEQUENTIAL NUMBERING (1., 2., 3., ...) in ALL functions
✅ InterfaceDetailsFormatter class for complete formatting
✅ DB_SCHEMA (igpt) support on all queries
✅ Safe config access with .get() (no AttributeError)
✅ Intelligent greeting detection
✅ Smart query routing (ID Lookup → Vector → SQL → LLM)
✅ GPT-5-MINI token limit fixes
✅ Vector search with embeddings
✅ LLM formatting with complex error handling
✅ Aggregation & statistics
✅ Multiple fallback chains
✅ Comprehensive error handling
✅ Enhanced logging
✅ DYNAMIC SQL SEARCH - NO HARDCODING (NEW)

CRITICAL FIXES:
✅ SELECT * instead of hardcoded 6 columns
✅ InterfaceDetailsFormatter handles all 44 columns
✅ Sequential numbering in ALL functions with enumerate()
✅ Smart field selection (shows only populated)
✅ LLM complexity preserved and enhanced
✅ All helper methods included
✅ Complete aggregation stats
✅ Full error handling with retries
✅ DynamicSearchHelper for auto-discovering columns and values

OUTPUT FORMAT - NOW WITH ALL 44 COLUMNS:

1. **INT-1001** - API Product 1
   Status: Retired | Platform: HR
   Description: Integration for HR data synchronization...
   
   **Pattern & Type:**
     • Pattern: REST to REST
     • Mode: Real-time
     • Build Type: Custom
   
   **Operations & Communication:**
     • Operation: SyncHR
     • Mode: Asynchronous
     • Frequency: Daily
     • Priority: High
     • QoS: 99.9%
   
   **Source System:**
     • Type: SAP ERP
     • System: SAP ERP
     • Protocol: HTTP
     • Format: JSON
     • URL: https://sap.company.com
   
   **Target System:**
     • Type: Azure
     • System: Azure Cloud
     • Protocol: REST
     • Format: JSON
     • URL: https://api.azure.com
   
   **Dependencies:**
     • Dependency: INT-1000
     • Resolver: IT Operations
   
   **Metadata:**
     • Reuse: Reusable
     • Project: HR Modernization
     • OU: OU-IT
     • Go-Live: 2025-01-15
     • Work Order: WO-12345
"""

import os
import logging
import re
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from flask import current_app
from sqlalchemy import text
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# ============================================================================
# DYNAMIC SEARCH HELPER - NO HARDCODING
# ============================================================================

class DynamicSearchHelper:
    """
    Dynamic search helper - discovers data structure automatically
    
    ✅ How it works:
    1. Auto-detects all columns in the database
    2. Auto-discovers unique values in searchable columns
    3. Matches keywords to actual data dynamically
    4. Works with ANY database schema/data structure
    5. No hardcoded column names or values
    6. Self-learning and adaptive
    """
    
    def __init__(self, db_connection, db_schema: str = 'igpt'):
        self.db = db_connection
        self.db_schema = db_schema
        self.table_name = 'integration_interfaces'
        self._column_cache = None
        self._unique_values_cache = {}
        self._last_cache_update = None
    
    
    def get_all_columns(self) -> List[str]:
        """Get all column names from the table - dynamically"""
        if self._column_cache and self._is_cache_valid():
            return self._column_cache
        
        try:
            if hasattr(self.db, 'execute'):
                query = f"""
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = '{self.db_schema}'
                    AND table_name = '{self.table_name}'
                    ORDER BY ordinal_position
                """
                result = self.db.execute(text(query))
                columns = [row[0] for row in result.fetchall()]
            else:
                cursor = self.db.cursor()
                query = f"""
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = '{self.db_schema}'
                    AND table_name = '{self.table_name}'
                    ORDER BY ordinal_position
                """
                cursor.execute(query)
                columns = [row[0] for row in cursor.fetchall()]
                cursor.close()
            
            self._column_cache = columns
            self._last_cache_update = datetime.utcnow()
            logger.info(f"✅ Discovered {len(columns)} columns")
            return columns
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to get columns: {e}")
            return []
    
    
    def get_unique_values(self, column_name: str, limit: int = 100) -> List[str]:
        """Get unique values from a column - dynamically"""
        cache_key = f"{column_name}_{limit}"
        
        if cache_key in self._unique_values_cache and self._is_cache_valid():
            return self._unique_values_cache[cache_key]
        
        try:
            if hasattr(self.db, 'execute'):
                query = f"""
                    SELECT DISTINCT {column_name}
                    FROM {self.db_schema}.{self.table_name}
                    WHERE {column_name} IS NOT NULL
                    ORDER BY {column_name}
                    LIMIT {limit}
                """
                result = self.db.execute(text(query))
                values = [str(row[0]).strip() for row in result.fetchall() if row[0]]
            else:
                cursor = self.db.cursor()
                query = f"""
                    SELECT DISTINCT {column_name}
                    FROM {self.db_schema}.{self.table_name}
                    WHERE {column_name} IS NOT NULL
                    ORDER BY {column_name}
                    LIMIT {limit}
                """
                cursor.execute(query)
                values = [str(row[0]).strip() for row in cursor.fetchall() if row[0]]
                cursor.close()
            
            self._unique_values_cache[cache_key] = values
            return values
        
        except Exception as e:
            logger.warning(f"⚠️ Failed to get values for {column_name}: {e}")
            return []
    
    
    def find_columns_containing_keyword(self, keyword: str, exclude_cols: List[str] = None) -> List[Tuple[str, List[str]]]:
        """
        Find which columns contain the keyword value
        
        Returns: List of (column_name, matching_values) tuples
        """
        if not keyword or not keyword.strip():
            return []
        
        if exclude_cols is None:
            exclude_cols = ['id', 'created_at', 'updated_at']
        
        keyword_lower = keyword.lower().strip()
        results = []
        all_columns = self.get_all_columns()
        
        # Searchable columns (skip ID, timestamps, system columns)
        searchable_columns = [
            col for col in all_columns 
            if col not in exclude_cols 
            and not col.startswith('_')
        ]
        
        logger.info(f"🔍 Searching {len(searchable_columns)} columns for '{keyword}'...")
        
        for column in searchable_columns:
            try:
                unique_values = self.get_unique_values(column)
                
                # Find matching values
                matching_values = [
                    val for val in unique_values
                    if keyword_lower in val.lower()
                ]
                
                if matching_values:
                    results.append((column, matching_values))
                    logger.info(f"   ✅ {column}: {len(matching_values)} matches → {matching_values[:3]}")
            
            except Exception as e:
                logger.warning(f"   ⚠️ Error checking {column}: {e}")
        
        return results
    
    
    def _is_cache_valid(self) -> bool:
        """Check if cache is still valid (1 hour TTL)"""
        if not self._last_cache_update:
            return False
        
        age_seconds = (datetime.utcnow() - self._last_cache_update).total_seconds()
        return age_seconds < 3600  # 1 hour cache
    
    
    def clear_cache(self):
        """Clear the cache"""
        self._column_cache = None
        self._unique_values_cache = {}
        self._last_cache_update = None
        logger.info("🧹 Cache cleared")


# ============================================================================
# INTERFACE DETAILS FORMATTER - FOR ALL 44 COLUMNS
# ============================================================================

class InterfaceDetailsFormatter:
    """✅ Format interface details with ALL 44 columns organized by category"""
    
    @staticmethod
    def format_interface(row_dict: Dict[str, Any]) -> str:
        """Format complete interface with all 44 columns"""
        lines = []
        
        # HEADER: ID and Name
        interface_id = row_dict.get('interface_id', 'Unknown')
        interface_name = row_dict.get('interface_name', 'Unknown')
        lines.append(f"**{interface_id}** - {interface_name}")
        
        # QUICK SUMMARY
        status = row_dict.get('status', 'Unknown')
        platform = row_dict.get('interface_platform', 'Unknown')
        lines.append(f"Status: {status} | Platform: {platform}")
        
        # CORE DESCRIPTION
        if row_dict.get('interface_description'):
            desc = row_dict['interface_description']
            lines.append(f"Description: {desc[:200]}{'...' if len(desc) > 200 else ''}")
        
        # PATTERN & TYPE (4 columns)
        pattern_items = []
        if row_dict.get('interface_pattern'):
            pattern_items.append(f"Pattern: {row_dict['interface_pattern']}")
        if row_dict.get('interface_mode'):
            pattern_items.append(f"Mode: {row_dict['interface_mode']}")
        if row_dict.get('interface_build_type'):
            pattern_items.append(f"Build: {row_dict['interface_build_type']}")
        if row_dict.get('sub_interface'):
            pattern_items.append(f"Sub: {row_dict['sub_interface']}")
        
        if pattern_items:
            lines.append("")
            lines.append("**Pattern & Type:**")
            for item in pattern_items:
                lines.append(f"  • {item}")
        
        # OPERATIONS & COMMUNICATION (8 columns)
        ops_items = []
        if row_dict.get('operation_name'):
            ops_items.append(f"Operation: {row_dict['operation_name']}")
        if row_dict.get('communication_mode'):
            ops_items.append(f"Mode: {row_dict['communication_mode']}")
        if row_dict.get('frequency'):
            ops_items.append(f"Frequency: {row_dict['frequency']}")
        if row_dict.get('volume'):
            ops_items.append(f"Volume: {row_dict['volume']}")
        if row_dict.get('schedule'):
            ops_items.append(f"Schedule: {row_dict['schedule']}")
        if row_dict.get('priority'):
            ops_items.append(f"Priority: {row_dict['priority']}")
        if row_dict.get('qos'):
            ops_items.append(f"QoS: {row_dict['qos']}")
        if row_dict.get('retention_period'):
            ops_items.append(f"Retention: {row_dict['retention_period']}")
        
        if ops_items:
            lines.append("")
            lines.append("**Operations & Communication:**")
            for item in ops_items:
                lines.append(f"  • {item}")
        
        # SOURCE SYSTEM (8 columns)
        source_items = []
        if row_dict.get('source_ci_type'):
            source_items.append(f"Type: {row_dict['source_ci_type']}")
        if row_dict.get('source_name'):
            source_items.append(f"System: {row_dict['source_name']}")
        if row_dict.get('source_protocol'):
            source_items.append(f"Protocol: {row_dict['source_protocol']}")
        if row_dict.get('source_data_format'):
            source_items.append(f"Format: {row_dict['source_data_format']}")
        if row_dict.get('source_service_url'):
            source_items.append(f"URL: {row_dict['source_service_url']}")
        if row_dict.get('source_trust_level'):
            source_items.append(f"Trust: {row_dict['source_trust_level']}")
        if row_dict.get('source_resolver_contact'):
            source_items.append(f"Contact: {row_dict['source_resolver_contact']}")
        if row_dict.get('source_intermediary'):
            source_items.append(f"Intermediary: {row_dict['source_intermediary']}")
        
        if source_items:
            lines.append("")
            lines.append("**Source System:**")
            for item in source_items:
                lines.append(f"  • {item}")
        
        # TARGET SYSTEM (8 columns)
        target_items = []
        if row_dict.get('target_ci_type'):
            target_items.append(f"Type: {row_dict['target_ci_type']}")
        if row_dict.get('target_name'):
            target_items.append(f"System: {row_dict['target_name']}")
        if row_dict.get('target_protocol'):
            target_items.append(f"Protocol: {row_dict['target_protocol']}")
        if row_dict.get('target_data_format'):
            target_items.append(f"Format: {row_dict['target_data_format']}")
        if row_dict.get('target_service_url'):
            target_items.append(f"URL: {row_dict['target_service_url']}")
        if row_dict.get('target_trust_level'):
            target_items.append(f"Trust: {row_dict['target_trust_level']}")
        if row_dict.get('target_resolver_contact'):
            target_items.append(f"Contact: {row_dict['target_resolver_contact']}")
        if row_dict.get('target_intermediary'):
            target_items.append(f"Intermediary: {row_dict['target_intermediary']}")
        
        if target_items:
            lines.append("")
            lines.append("**Target System:**")
            for item in target_items:
                lines.append(f"  • {item}")
        
        # DEPENDENCIES (2 columns)
        deps_items = []
        if row_dict.get('dependency_id'):
            deps_items.append(f"Dependency: {row_dict['dependency_id']}")
        if row_dict.get('interface_resolver_group'):
            deps_items.append(f"Resolver: {row_dict['interface_resolver_group']}")
        
        if deps_items:
            lines.append("")
            lines.append("**Dependencies:**")
            for item in deps_items:
                lines.append(f"  • {item}")
        
        # METADATA (8 columns)
        meta_items = []
        if row_dict.get('reuse_status'):
            meta_items.append(f"Reuse: {row_dict['reuse_status']}")
        if row_dict.get('integration_pattern'):
            meta_items.append(f"Pattern: {row_dict['integration_pattern']}")
        if row_dict.get('project_name'):
            meta_items.append(f"Project: {row_dict['project_name']}")
        if row_dict.get('ou'):
            meta_items.append(f"OU: {row_dict['ou']}")
        if row_dict.get('production_migration_date'):
            meta_items.append(f"Go-Live: {row_dict['production_migration_date']}")
        if row_dict.get('pid_wo'):
            meta_items.append(f"Work Order: {row_dict['pid_wo']}")
        if row_dict.get('api_product_name'):
            meta_items.append(f"API Product: {row_dict['api_product_name']}")
        if row_dict.get('process_area'):
            meta_items.append(f"Process Area: {row_dict['process_area']}")
        if row_dict.get('comments'):
            comments = row_dict['comments']
            meta_items.append(f"Notes: {comments[:100]}{'...' if len(comments) > 100 else ''}")
        
        if meta_items:
            lines.append("")
            lines.append("**Metadata:**")
            for item in meta_items:
                lines.append(f"  • {item}")

        return "\n".join(lines)

    @staticmethod
    def format_brief(row_dict: Dict[str, Any]) -> str:
        """Format a concise summary of the interface (key details only)"""
        lines = []

        # HEADER: ID and Name
        interface_id = row_dict.get('interface_id', 'Unknown')
        interface_name = row_dict.get('interface_name', 'Unknown')
        lines.append(f"**{interface_id}** - {interface_name}")

        # STATUS & PLATFORM
        status = row_dict.get('status', 'Unknown')
        platform = row_dict.get('interface_platform', 'Unknown')
        lines.append(f"**Status:** {status} | **Platform:** {platform}")

        # DESCRIPTION (brief)
        if row_dict.get('interface_description'):
            desc = row_dict['interface_description']
            lines.append(f"**Description:** {desc[:150]}{'...' if len(desc) > 150 else ''}")

        # FLOW: Source → Target
        source = row_dict.get('source_name', 'Unknown')
        target = row_dict.get('target_name', 'Unknown')
        pattern = row_dict.get('interface_pattern', '')
        mode = row_dict.get('interface_mode', '')
        flow_info = f"**Flow:** {source} → {target}"
        if pattern:
            flow_info += f" ({pattern})"
        if mode:
            flow_info += f" [{mode}]"
        lines.append(flow_info)

        # KEY METRICS (one line)
        metrics = []
        if row_dict.get('frequency'):
            metrics.append(f"Freq: {row_dict['frequency']}")
        if row_dict.get('volume'):
            metrics.append(f"Vol: {row_dict['volume']}")
        if row_dict.get('priority'):
            metrics.append(f"Priority: {row_dict['priority']}")
        if metrics:
            lines.append(f"**Metrics:** {' | '.join(metrics)}")

        # PROJECT & OU (one line)
        project = row_dict.get('project_name', '')
        ou = row_dict.get('ou', '')
        if project or ou:
            context = []
            if project:
                context.append(f"Project: {project}")
            if ou:
                context.append(f"OU: {ou}")
            lines.append(f"**Context:** {' | '.join(context)}")

        return "\n".join(lines)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    ✅ Get schema from Flask config (config.py)
    
    Returns:
        Schema name (e.g., 'igpt')
    """
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        # Outside application context, default to 'igpt'
        return 'igpt'


# ============================================================================
# DATA CLASSES
# ============================================================================

@dataclass
class RAGConfig:
    """Configuration for RAG Service"""
    vector_enabled: bool = True
    vector_search_limit: int = 10
    similarity_threshold: float = 0.7
    
    llm_enabled: bool = True
    llm_max_retries: int = 2
    llm_timeout_seconds: int = 30
    llm_temperature: float = 0.7
    
    # Model-specific token limits (FIX FOR GPT-5-MINI)
    llm_max_tokens_mini: int = 2000  # For mini models
    llm_max_tokens_standard: int = 4000  # For standard models
    
    @classmethod
    def from_flask_config(cls, flask_config) -> 'RAGConfig':
        """Load from Flask config object - SAFELY"""
        return cls(
            vector_enabled=flask_config.get('FEATURE_AI_SERVICES', True),
            llm_enabled=flask_config.get('FEATURE_AI_SERVICES', True),
            llm_temperature=flask_config.get('AZURE_OPENAI_TEMPERATURE', 0.7),
            similarity_threshold=0.5
        )


@dataclass
class RAGMetrics:
    """Metrics for RAG operations"""
    total_queries: int = 0
    id_lookups: int = 0
    vector_searches: int = 0
    sql_fallbacks: int = 0
    llm_formats: int = 0
    errors: int = 0
    total_processing_time_ms: float = 0
    
    def average_processing_time_ms(self) -> float:
        if self.total_queries == 0:
            return 0
        return self.total_processing_time_ms / self.total_queries
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'total_queries': self.total_queries,
            'breakdown': {
                'id_lookups': self.id_lookups,
                'vector_searches': self.vector_searches,
                'sql_fallbacks': self.sql_fallbacks,
                'llm_formats': self.llm_formats,
                'errors': self.errors
            },
            'performance': {
                'average_processing_time_ms': round(self.average_processing_time_ms(), 2)
            }
        }


# ============================================================================
# MAIN SERVICE
# ============================================================================

class HybridRAGService:
    """
    Production-Ready Smart Hybrid RAG System WITH ALL FEATURES

    Features:
    - ✅ Safe config access with .get() (no AttributeError)
    - ✅ DB_SCHEMA (igpt) support on all queries
    - ✅ FIXED: Sequential numbering in all results (1., 2., 3., ...)
    - ✅ Intelligent greeting detection
    - ✅ Smart response routing
    - ✅ Fixes gpt-5-mini token limit issues
    - ✅ Vector search with embeddings
    - ✅ LLM formatting with complex error handling
    - ✅ Aggregation & statistics
    - ✅ Multiple fallback chains
    - ✅ Connection pooling
    - ✅ Comprehensive metrics
    - ✅ Enhanced logging
    - ✅ DYNAMIC SQL SEARCH - NO HARDCODING (NEW)
    - ✅ CONTEXT AWARENESS - Remembers last interface (NEW)
    """

    # Class-level context storage (persists across requests)
    _last_interface_id = None
    _last_query_context = None  # Stores {'type': 'patterns', 'column': 'interface_pattern'}
    _last_report_filter = None  # Stores {'platform': 'sap cpi', 'status': 'active'} for follow-up queries

    def __init__(self, db_connection=None, openai_client=None, config: Optional[Dict[str, Any]] = None):
        """Initialize RAG Service using Flask config - FULLY SAFE"""
        self.db = db_connection
        self.openai_client = openai_client
        self.config = config or {}
        self.vector_search = None
        self.llm_enabled = False
        self.dynamic_search_helper = None  # NEW: Dynamic search helper
        
        # ✅ Get schema from config
        self.db_schema = get_db_schema()
        
        # Get Flask config object (safely)
        flask_config = self.config.get('flask_config', {})
        
        logger.info("=" * 80)
        logger.info("🤖 Initializing Production Hybrid RAG Service...")
        logger.info("=" * 80)
        
        # Load configuration from Flask config - USE .get() FOR SAFETY
        if flask_config:
            logger.info("\n📋 Loading Flask Configuration...")
            
            try:
                self.rag_config = RAGConfig.from_flask_config(flask_config)
                logger.info("   ✓ RAGConfig loaded from Flask config")
            except Exception as e:
                logger.warning(f"   ⚠️ RAGConfig error: {e}, using defaults")
                self.rag_config = RAGConfig()
            
            # ✅ USE .get() FOR ALL CONFIG ACCESS - This prevents AttributeError
            self.deployment = flask_config.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
            self.azure_endpoint = flask_config.get('AZURE_OPENAI_ENDPOINT', '')
            self.azure_api_key = flask_config.get('AZURE_OPENAI_API_KEY', '')
            self.azure_api_version = flask_config.get('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
            
            logger.info(f"   ✓ AZURE_OPENAI_DEPLOYMENT: {self.deployment}")
            logger.info(f"   ✓ AZURE_OPENAI_API_VERSION: {self.azure_api_version}")
            logger.info(f"   ✓ DB_SCHEMA: {self.db_schema}")
            
        else:
            logger.warning("\n⚠️  Flask config not provided, using environment variables")
            
            # Fallback to environment variables
            self.rag_config = RAGConfig()
            self.deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
            self.azure_endpoint = os.getenv('AZURE_OPENAI_ENDPOINT', '')
            self.azure_api_key = os.getenv('AZURE_OPENAI_API_KEY', '')
            self.azure_api_version = os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
            
            logger.info(f"   ✓ From env: AZURE_OPENAI_DEPLOYMENT={self.deployment}")
            logger.info(f"   ✓ DB_SCHEMA: {self.db_schema}")
        
        self.metrics = RAGMetrics()
        
        # Validate database
        logger.info("\n📋 Validating Components...")
        if db_connection:
            try:
                if hasattr(db_connection, 'execute'):
                    db_connection.execute(text("SELECT 1"))
                    logger.info("   ✅ Database connection OK")
                else:
                    cursor = db_connection.cursor()
                    cursor.execute("SELECT 1")
                    cursor.close()
                    logger.info("   ✅ Database connection OK")
            except Exception as e:
                logger.warning(f"   ⚠️ Database check failed: {e}")
        else:
            logger.warning("   ⚠️ Database connection not provided")
        
        # Check LLM availability
        if openai_client and self.rag_config.llm_enabled:
            logger.info("   ✅ Azure OpenAI client provided and enabled")
            logger.info(f"   📝 Deployment: {self.deployment}")
            
            # Detect mini model and warn
            if 'mini' in self.deployment.lower():
                logger.warning(f"   ⚠️ Mini model detected: {self.deployment}")
                logger.warning(f"   ⚠️ Output limited to {self.rag_config.llm_max_tokens_mini} tokens")
                logger.warning(f"   ⚠️ Temperature parameter disabled for mini models")
                logger.warning(f"   💡 Consider switching to gpt-35-turbo for better results")
            
            self.llm_enabled = True
        else:
            if not openai_client:
                logger.info("   ⚠️ No Azure OpenAI client provided")
            if not self.rag_config.llm_enabled:
                logger.info("   ⚠️ LLM disabled by config")
            self.llm_enabled = False
        
        # Initialize Vector Search
        self._initialize_vector_search()
        
        # Initialize Dynamic Search Helper (NEW)
        self._initialize_dynamic_search()
        
        logger.info("\n✅ Configuration validation complete")
        
        # Print routing info
        if self.llm_enabled:
            logger.info("\n📍 Query Routing Path:")
            logger.info("   1. Greeting Detection")
            logger.info("   2. ID Lookup → Vector Search → Dynamic SQL → LLM")
        else:
            logger.info("\n📍 Query Routing Path:")
            logger.info("   1. Greeting Detection")
            logger.info("   2. ID Lookup → Vector Search → Dynamic SQL")
        
        logger.info(f"\n⚙️  Service Settings:")
        logger.info(f"   - Similarity Threshold: {self.rag_config.similarity_threshold:.0%}")
        logger.info(f"   - Vector Search Limit: {self.rag_config.vector_search_limit}")
        logger.info(f"   - LLM Max Tokens: {self.rag_config.llm_max_tokens_standard}")
        logger.info(f"   - LLM Temperature: {self.rag_config.llm_temperature}")
        logger.info(f"   - LLM Max Retries: {self.rag_config.llm_max_retries}")
        logger.info(f"   - DB Schema: {self.db_schema}")
        logger.info(f"   - ✅ SEQUENTIAL NUMBERING ENABLED (1., 2., 3., ...)")
        logger.info(f"   - ✅ ALL 44 COLUMNS INCLUDED")
        logger.info(f"   - ✅ LLM FORMATTING ENABLED")
        logger.info(f"   - ✅ AGGREGATION STATS ENABLED")
        logger.info(f"   - ✅ DYNAMIC SQL SEARCH ENABLED (NO HARDCODING)")
        logger.info(f"   - ✅ FULL ERROR HANDLING")
        
        logger.info("\n✅ Production RAG Service initialized successfully")
        logger.info("=" * 80 + "\n")
    
    
    def _initialize_vector_search(self):
        """Initialize vector search service"""
        try:
            logger.info("\n🔌 Initializing Vector Search...")

            try:
                from backend.services.vector_search import VectorSearch
                self.vector_search = VectorSearch(config=self.config)
                logger.info("   ✅ Vector Search initialized with connection pooling")
            
            except ImportError as import_err:
                logger.warning(f"   ⚠️ Vector Search import failed: {import_err}")
                self.vector_search = None
            
            except Exception as init_err:
                logger.warning(f"   ⚠️ Vector Search init failed: {init_err}")
                self.vector_search = None
        
        except Exception as e:
            logger.warning(f"   ⚠️ Vector Search error: {e}")
            self.vector_search = None
    
    
    def _initialize_dynamic_search(self):
        """Initialize dynamic search helper - NEW"""
        try:
            if self.db:
                self.dynamic_search_helper = DynamicSearchHelper(self.db, self.db_schema)
                logger.info("   ✅ Dynamic search helper initialized")
            else:
                logger.warning("   ⚠️ Dynamic search helper not initialized (no DB)")
                self.dynamic_search_helper = None
        except Exception as e:
            logger.warning(f"   ⚠️ Dynamic search helper init failed: {e}")
            self.dynamic_search_helper = None
    
    
    def _is_greeting(self, question: str) -> bool:
        """
        LLM-FIRST classification - Let the LLM decide if this is a general
        conversation or a data query. No hardcoded patterns!

        Returns True for: greetings, general chat, help requests, non-data questions
        Returns False for: queries about interfaces, data lookups, reports, stats
        """
        q_lower = question.lower().strip()

        # Only skip for empty messages
        if len(q_lower) < 2:
            return True

        # ═══════════════════════════════════════════════════════════════════
        # PRIMARY: Use LLM for ALL classification decisions
        # ═══════════════════════════════════════════════════════════════════
        if self.llm_enabled and self.openai_client:
            try:
                classification_prompt = f"""You are a query classifier for an Integration Interfaces database.

Database fields: interface_id, interface_name, platform, status, pattern, frequency, priority, etc.
Valid patterns: Request-Response, Request-Reply, One-Way, Fire and Forget, Batch Processing, Pub-Sub
Valid statuses: Active, Inactive, Testing, In Development, Retired
Valid platforms: SAP CPI, Azure APIM, Dell Boomi, Informatica, Azure Logic Apps

GENERAL = ONLY pure greetings (hi, hello), farewells (bye), thanks, compliments
DATA = ANY question about data, including:
- "What are the patterns?" → DATA
- "Give me all patterns" → DATA
- "List statuses" → DATA
- "Show platforms" → DATA
- "How many active?" → DATA
- "Find SAP interfaces" → DATA
- "INT-1001" → DATA
- "Show report" → DATA
- "What is Request-Response?" → DATA (asking about a pattern)
- "Request-Response: 125 what is this" → DATA (asking about data/pattern)
- "Explain Active status" → DATA (asking about a status)
- "What does Testing mean?" → DATA (asking about a status)
- Any question containing numbers, percentages, or data values → DATA

User: "{question}"

Reply ONLY: GENERAL or DATA"""

                response = self.openai_client.chat.completions.create(
                    model=self.deployment,
                    messages=[{"role": "user", "content": classification_prompt}],
                    max_tokens=10,
                    temperature=0
                )

                classification = response.choices[0].message.content.strip().upper()
                logger.info(f"   🤖 LLM classified '{question[:40]}...' → {classification}")

                if "GENERAL" in classification:
                    return True
                elif "DATA" in classification:
                    return False
                else:
                    logger.warning(f"   ⚠️ Unexpected LLM response: {classification}")

            except Exception as e:
                logger.error(f"   ❌ LLM classification failed: {e}")

        # ═══════════════════════════════════════════════════════════════════
        # FALLBACK: Only used if LLM is unavailable/fails
        # ═══════════════════════════════════════════════════════════════════
        logger.warning("   ⚠️ Using fallback (LLM unavailable)")
        data_keywords = [
            'interface', 'int-', 'api', 'show', 'find', 'list', 'count', 'how many',
            'sap', 'azure', 'boomi', 'informatica', 'report', 'chart', 'graph',
            'pattern', 'patterns', 'status', 'statuses', 'platform', 'platforms',
            'frequency', 'priority', 'active', 'inactive', 'testing', 'retired',
            'what are', 'give me', 'all', 'what is', 'explain', 'describe',
            # Pattern names
            'request-response', 'request-reply', 'one-way', 'fire and forget',
            'batch processing', 'pub-sub', 'publish', 'subscribe',
            # Numbers and percentages indicate data questions
            '%', 'percent'
        ]
        # Also check for numbers in the query (indicates data context)
        has_numbers = any(char.isdigit() for char in q_lower)
        return not (any(kw in q_lower for kw in data_keywords) or has_numbers)
    
    
    def _get_greeting_response(self, user_message: str = "") -> str:
        """
        Use LLM to generate intelligent, contextual response for general queries.
        Provides data context if available.
        """
        try:
            # Get data context for personalization
            total = 0
            top_status = "Active"

            if self.db:
                try:
                    schema = self.db_schema
                    if hasattr(self.db, 'execute'):
                        total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                        total = total_result.scalar() or 0

                        status_result = self.db.execute(text(f"""
                            SELECT status, COUNT(*) as count
                            FROM {schema}.integration_interfaces
                            GROUP BY status ORDER BY count DESC LIMIT 1
                        """))
                        status_row = status_result.fetchone()
                        top_status = status_row[0] if status_row else "Active"
                    else:
                        cursor = self.db.cursor()
                        cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                        total = cursor.fetchone()[0]
                        cursor.close()
                except Exception as e:
                    logger.warning(f"⚠️ Stats fetch failed: {e}")

            # Use LLM for intelligent response
            if self.llm_enabled and self.openai_client:
                try:
                    context = f"""You are an AI Assistant for an Integration Interfaces Dashboard.
You help users find information about {total} integration interfaces across platforms like SAP CPI, Azure APIM, Dell Boomi, and Informatica.

The user said: "{user_message}"

Respond naturally and helpfully. If it's a greeting, greet them back warmly.
If they're asking what you can do, explain your capabilities.
If they're saying thanks or goodbye, respond appropriately.

Keep response concise (2-4 sentences). Mention you can help with:
- Searching interfaces by name, platform, or status
- Getting interface details (e.g., "What's INT-1010?")
- Statistics and reports
- Finding interfaces by pattern or description"""

                    response = self.openai_client.chat.completions.create(
                        model=self.deployment,
                        messages=[{"role": "user", "content": context}],
                        max_tokens=200,
                        temperature=0.7
                    )

                    return response.choices[0].message.content.strip()

                except Exception as e:
                    logger.warning(f"⚠️ LLM greeting failed: {e}, using fallback")

            # Fallback response
            if total > 0:
                return f"👋 Hello! I'm your AI Assistant. I can help you explore {total} integration interfaces (most are {top_status}). Try asking about specific interfaces (e.g., 'What's INT-1010?'), platforms ('Show SAP CPI interfaces'), or get statistics ('How many are Active?')."
            else:
                return "👋 Hello! I'm your AI Assistant. Upload an Excel file with integration data to get started, then ask me anything about your interfaces!"

        except Exception as e:
            logger.error(f"❌ Greeting response failed: {e}")
            return "Hello! I'm your AI Assistant. How can I help you today?"
    
    
    def create_embeddings_for_uploaded_data(self, data_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create embeddings for uploaded data"""
        if not self.vector_search:
            return {'success': False, 'total_embeddings': 0, 'error': 'Vector search unavailable'}
        
        if not self.vector_search.use_local_embeddings:
            return {'success': False, 'total_embeddings': 0, 'error': 'Embeddings disabled'}
        
        if not data_rows:
            return {'success': False, 'total_embeddings': 0, 'error': 'No data provided'}
        
        try:
            logger.info(f"🔄 Creating embeddings for {len(data_rows)} items...")
            start_time = datetime.utcnow()
            
            batch_data = []
            
            for row in data_rows:
                interface_id = None
                for col in ['interface_id', 'Interface ID', 'id', 'ID']:
                    if col in row and row[col]:
                        interface_id = str(row[col]).strip()
                        break
                
                if not interface_id:
                    continue
                
                interface_name = None
                for col in ['interface_name', 'Interface Name', 'name', 'Name', 'Title']:
                    if col in row and row[col]:
                        interface_name = str(row[col]).strip()
                        break
                
                interface_description = None
                for col in ['interface_description', 'Interface Description', 'description', 'Description']:
                    if col in row and row[col]:
                        interface_description = str(row[col]).strip()
                        break
                
                if interface_name:
                    batch_data.append({
                        'interface_id': interface_id,
                        'content_type': 'name',
                        'content': interface_name
                    })
                
                if interface_description:
                    batch_data.append({
                        'interface_id': interface_id,
                        'content_type': 'description',
                        'content': interface_description
                    })
            
            logger.info(f"   ✅ Prepared {len(batch_data)} embedding items")
            
            if not batch_data:
                return {'success': False, 'total_embeddings': 0, 'error': 'No valid data'}
            
            texts_to_embed = [item['content'] for item in batch_data]
            embeddings = self.vector_search.generate_embeddings(texts_to_embed)
            
            if not embeddings:
                return {'success': False, 'total_embeddings': 0, 'error': 'Generation failed'}
            
            embeddings_to_store = []
            for item, embedding in zip(batch_data, embeddings):
                embeddings_to_store.append({
                    'interface_id': item['interface_id'],
                    'content_type': item['content_type'],
                    'content': item['content'],
                    'embedding': embedding
                })
            
            succeeded, failed = self.vector_search.store_embeddings(embeddings_to_store)
            elapsed = (datetime.utcnow() - start_time).total_seconds()
            
            logger.info(f"✅ Complete: {succeeded} embeddings in {elapsed:.1f}s")
            
            return {
                'success': True,
                'total_embeddings': succeeded,
                'total_rows': len(data_rows),
                'failed': failed,
                'processing_time_seconds': elapsed
            }
        
        except Exception as e:
            logger.error(f"❌ Embedding creation failed: {e}")
            return {'success': False, 'total_embeddings': 0, 'error': str(e)}
    
    
    def _detect_query_intent(self, question: str) -> Dict[str, Any]:
        """
        LLM-FIRST Intent Detection - Let the AI decide which tool to use

        Tools available:
        1. ID_LOOKUP - Look up specific interface by ID (INT-XXXX)
        2. REPORT - Generate charts/reports (with optional platform/status filter)
        3. STATISTICS - Get counts, totals, aggregations
        4. SEARCH - Search interfaces by keywords
        5. DISTINCT - List unique values in a column
        """
        if not question or not question.strip():
            return {'type': 'error', 'description': 'Empty query'}

        q_lower = question.lower().strip()

        # ═══════════════════════════════════════════════════════════════════
        # PRIMARY: LLM-BASED TOOL DETECTION
        # Let the AI understand the user's intent and select the right tool
        # ═══════════════════════════════════════════════════════════════════
        if self.llm_enabled and self.openai_client:
            try:
                # Build context about previous query for follow-ups
                context_info = ""
                if HybridRAGService._last_report_filter:
                    ctx = HybridRAGService._last_report_filter
                    context_info = f"\nPrevious report filter: Platform={ctx.get('platform', 'None')}, Status={ctx.get('status', 'None')}"
                if HybridRAGService._last_interface_id:
                    context_info += f"\nLast interface viewed: {HybridRAGService._last_interface_id}"

                tool_detection_prompt = f"""You are an AI assistant for an Integration Interfaces database.
The database has interfaces with: interface_id (INT-XXXX), interface_name, interface_platform (SAP CPI, Azure APIM, Dell Boomi, Informatica, Azure Logic Apps), status (Active, Inactive, Testing, Retired, In Development), interface_pattern, frequency, priority, etc.
{context_info}

User query: "{question}"

Select the BEST tool and extract parameters:

TOOLS:
1. ID_LOOKUP - User wants info about specific interface ID (e.g., "What is INT-1001?", "Show INT-1234")
2. REPORT - User wants charts, graphs, reports, visualizations (e.g., "Show SAP report", "Chart for Active interfaces", "One more SAP report")
3. STATISTICS - User wants counts, totals, numbers (e.g., "How many active?", "Count interfaces")
4. SEARCH - User wants to find interfaces by keyword (e.g., "Find HR interfaces", "Show SAP interfaces")
5. DISTINCT - User wants to list unique values (e.g., "What are the patterns?", "List all statuses")

IMPORTANT: If user says "one more", "again", "same", "another" - check previous context and repeat with same filters.

Reply in this EXACT format (one line):
TOOL|platform_filter|status_filter|interface_id|column

Examples:
- "Show SAP CPI report" → REPORT|sap cpi|||
- "One more SAP report" → REPORT|sap cpi||| (uses previous context)
- "What is INT-1001?" → ID_LOOKUP|||INT-1001|
- "How many active?" → STATISTICS||active||
- "What are the patterns?" → DISTINCT||||interface_pattern
- "Find HR interfaces" → SEARCH||||"""

                response = self.openai_client.chat.completions.create(
                    model=self.deployment,
                    messages=[{"role": "user", "content": tool_detection_prompt}],
                    max_tokens=50,
                    temperature=0
                )

                llm_result = response.choices[0].message.content.strip()
                logger.info(f"   🤖 LLM Tool Detection: {llm_result}")

                # Parse the LLM response
                if '|' in llm_result:
                    parts = llm_result.split('|')
                    tool = parts[0].strip().upper() if len(parts) > 0 else ''
                    platform_filter = parts[1].strip().lower() if len(parts) > 1 and parts[1].strip() else None
                    status_filter = parts[2].strip().lower() if len(parts) > 2 and parts[2].strip() else None
                    interface_id = parts[3].strip().upper() if len(parts) > 3 and parts[3].strip() else None
                    column = parts[4].strip().lower() if len(parts) > 4 and parts[4].strip() else None

                    # Handle each tool type
                    if tool == 'ID_LOOKUP' and interface_id:
                        HybridRAGService._last_interface_id = interface_id
                        return {
                            'type': 'id_lookup',
                            'ids': [interface_id],
                            'description': f'LLM detected: ID lookup for {interface_id}'
                        }

                    elif tool == 'REPORT':
                        # Store context for future follow-ups
                        HybridRAGService._last_report_filter = {
                            'platform': platform_filter,
                            'status': status_filter
                        }
                        return {
                            'type': 'report',
                            'platform_filter': platform_filter,
                            'status_filter': status_filter,
                            'description': f'LLM detected: Report' + (f' for {platform_filter}' if platform_filter else '') + (f' ({status_filter})' if status_filter else '')
                        }

                    elif tool == 'STATISTICS':
                        return {
                            'type': 'aggregation',
                            'status_filter': status_filter,
                            'platform_filter': platform_filter,
                            'description': f'LLM detected: Statistics query'
                        }

                    elif tool == 'DISTINCT' and column:
                        HybridRAGService._last_query_context = {'type': 'distinct_values', 'column': column}
                        return {
                            'type': 'distinct_values',
                            'column': column,
                            'description': f'LLM detected: List distinct {column} values'
                        }

                    elif tool == 'SEARCH':
                        return {
                            'type': 'semantic_search',
                            'description': f'LLM detected: Search query'
                        }

                logger.info(f"   ⚠️ LLM response format unexpected: {llm_result}, falling back to keyword detection")

            except Exception as e:
                logger.warning(f"   ⚠️ LLM tool detection failed: {e}, falling back to keyword detection")

        # ═══════════════════════════════════════════════════════════════════
        # FALLBACK: Keyword-based detection (if LLM unavailable)
        # ═══════════════════════════════════════════════════════════════════
        logger.info("   📋 Using fallback keyword detection")

        # 1. Full details request (details INT-XXXX)
        id_match = re.findall(r'INT-\d+', question, re.IGNORECASE)
        if id_match:
            # Store the last interface ID for context
            HybridRAGService._last_interface_id = id_match[0]
            logger.info(f"   📝 Stored context: {id_match[0]}")

            # Check if user wants full details
            if any(word in q_lower for word in ['details', 'detail', 'full', 'complete', 'all info', 'all columns', 'everything']):
                return {
                    'type': 'id_lookup_full',
                    'ids': id_match,
                    'description': 'Full interface details'
                }
            # Regular brief lookup
            return {
                'type': 'id_lookup',
                'ids': id_match,
                'description': 'Specific interface ID lookup'
            }

        # 2. Context-aware queries (references "this", "it", "that interface", etc.)
        context_phrases = ['this interface', 'this one', 'that interface', 'that one', 'about this', 'about it', 'tell me more', 'more about', 'the interface', 'more details', 'brief about', 'about that']
        if any(phrase in q_lower for phrase in context_phrases):
            if HybridRAGService._last_interface_id:
                logger.info(f"   🔗 Context reference detected, using: {HybridRAGService._last_interface_id}")
                # Check if user wants full details
                if any(word in q_lower for word in ['details', 'detail', 'full', 'complete', 'all info', 'all columns', 'everything', 'more']):
                    return {
                        'type': 'id_lookup_full',
                        'ids': [HybridRAGService._last_interface_id],
                        'description': f'Full details for {HybridRAGService._last_interface_id} (from context)'
                    }
                return {
                    'type': 'id_lookup',
                    'ids': [HybridRAGService._last_interface_id],
                    'description': f'Brief for {HybridRAGService._last_interface_id} (from context)'
                }
            else:
                logger.info("   ⚠️ Context reference but no previous interface")

        # 3. Distinct values queries (what are the patterns, list all statuses, available platforms, etc.)
        distinct_patterns = [
            (r'what\s+(are|is)\s+(the\s+)?(integration\s+)?patterns?', 'interface_pattern'),
            (r'(list|show|available|all)\s+(integration\s+)?patterns?', 'interface_pattern'),
            (r'what\s+(are|is)\s+(the\s+)?statuse?s?', 'status'),
            (r'(list|show|available|all)\s+statuse?s?', 'status'),
            (r'what\s+(are|is)\s+(the\s+)?platforms?', 'interface_platform'),
            (r'(list|show|available|all)\s+platforms?', 'interface_platform'),
            (r'what\s+(are|is)\s+(the\s+)?frequenc(y|ies)', 'frequency'),
            (r'(list|show|available|all)\s+frequenc(y|ies)', 'frequency'),
            (r'what\s+(are|is)\s+(the\s+)?priorit(y|ies)', 'priority'),
            (r'(list|show|available|all)\s+priorit(y|ies)', 'priority'),
            (r'what\s+(are|is)\s+(the\s+)?modes?', 'interface_mode'),
            (r'(list|show|available|all)\s+modes?', 'interface_mode'),
        ]
        for pattern, column in distinct_patterns:
            if re.search(pattern, q_lower):
                # Store context for follow-up queries
                HybridRAGService._last_query_context = {'type': 'distinct_values', 'column': column}
                logger.info(f"   📝 Stored context: distinct_values for {column}")
                return {
                    'type': 'distinct_values',
                    'column': column,
                    'description': f'List distinct {column} values'
                }

        # 4. Context-aware report queries ("report for this data", "chart for this", etc.)
        context_report_phrases = ['this data', 'for this', 'for these', 'this result', 'these results', 'the above', 'above data']
        if any(phrase in q_lower for phrase in context_report_phrases):
            if 'report' in q_lower or 'chart' in q_lower or 'graph' in q_lower or 'visualize' in q_lower:
                if HybridRAGService._last_query_context:
                    ctx = HybridRAGService._last_query_context
                    logger.info(f"   🔗 Context report detected, using previous: {ctx}")
                    # If last query was about patterns, show pattern report
                    if ctx.get('column') == 'interface_pattern':
                        return {'type': 'report', 'report_filter': 'pattern', 'description': 'Pattern report (from context)'}
                    elif ctx.get('column') == 'status':
                        return {'type': 'report', 'report_filter': 'status', 'description': 'Status report (from context)'}
                    elif ctx.get('column') == 'interface_platform':
                        return {'type': 'report', 'report_filter': 'platform', 'description': 'Platform report (from context)'}
                    elif ctx.get('column') == 'frequency':
                        return {'type': 'report', 'report_filter': 'frequency', 'description': 'Frequency report (from context)'}
                    elif ctx.get('column') == 'priority':
                        return {'type': 'report', 'report_filter': 'priority', 'description': 'Priority report (from context)'}
                    else:
                        return {'type': 'report', 'description': 'Report (from context)'}
                else:
                    logger.info("   ⚠️ Context report requested but no previous context")

        # 5. Report/Chart queries - with platform/status filter extraction
        report_keywords = ['report', 'chart', 'graph', 'visualize', 'visualization', 'pie chart', 'bar chart', 'dashboard', 'breakdown', 'distribution']
        if any(word in q_lower for word in report_keywords):
            # Extract platform filter if mentioned
            platform_filter = None
            platforms = ['sap cpi', 'azure apim', 'dell boomi', 'informatica', 'azure logic apps']
            for platform in platforms:
                if platform in q_lower:
                    platform_filter = platform
                    break

            # Extract status filter if mentioned
            status_filter = None
            statuses = ['active', 'inactive', 'testing', 'retired', 'in development']
            for status in statuses:
                if status in q_lower:
                    status_filter = status
                    break

            return {
                'type': 'report',
                'platform_filter': platform_filter,
                'status_filter': status_filter,
                'description': f'Report/chart generation' + (f' for {platform_filter}' if platform_filter else '') + (f' ({status_filter})' if status_filter else '')
            }

        # 5. Aggregation queries
        if any(word in q_lower for word in ['how many', 'count', 'total', 'number', 'all interfaces', 'statistics']):
            return {
                'type': 'aggregation',
                'description': 'Count/statistics query'
            }

        # 6. Explanation queries - asking "what is X" about patterns, statuses, etc.
        explanation_patterns = [
            # Pattern explanations
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+request[- ]?response', 'pattern', 'Request-Response'),
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+request[- ]?reply', 'pattern', 'Request-Reply'),
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+one[- ]?way', 'pattern', 'One-Way'),
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+fire\s+and\s+forget', 'pattern', 'Fire and Forget'),
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+batch\s+processing', 'pattern', 'Batch Processing'),
            (r'(what\s+is|explain|describe|tell\s+me\s+about)\s+pub[- ]?sub', 'pattern', 'Pub-Sub'),
            # Check if query contains pattern name followed by "what is this"
            (r'request[- ]?response.*what\s+(is|does)\s+(this|it|that)', 'pattern', 'Request-Response'),
            (r'request[- ]?reply.*what\s+(is|does)\s+(this|it|that)', 'pattern', 'Request-Reply'),
            (r'one[- ]?way.*what\s+(is|does)\s+(this|it|that)', 'pattern', 'One-Way'),
            (r'fire\s+and\s+forget.*what\s+(is|does)\s+(this|it|that)', 'pattern', 'Fire and Forget'),
            (r'batch\s+processing.*what\s+(is|does)\s+(this|it|that)', 'pattern', 'Batch Processing'),
            # Status explanations
            (r'(what\s+is|explain|describe)\s+(the\s+)?active\s+(status)?', 'status', 'Active'),
            (r'(what\s+is|explain|describe)\s+(the\s+)?inactive\s+(status)?', 'status', 'Inactive'),
            (r'(what\s+is|explain|describe)\s+(the\s+)?testing\s+(status)?', 'status', 'Testing'),
            (r'(what\s+is|explain|describe)\s+(the\s+)?retired\s+(status)?', 'status', 'Retired'),
            (r'(what\s+is|explain|describe)\s+(the\s+)?in\s+development\s+(status)?', 'status', 'In Development'),
        ]
        for pattern, category, value in explanation_patterns:
            if re.search(pattern, q_lower):
                return {
                    'type': 'explanation',
                    'category': category,
                    'value': value,
                    'description': f'Explain {category}: {value}'
                }

        # 7. Semantic search
        if any(word in q_lower for word in ['for', 'synchronization', 'integration', 'data', 'system', 'what', 'find', 'similar', 'show']):
            return {
                'type': 'semantic_search',
                'description': 'Semantic search'
            }

        return {
            'type': 'semantic_search',
            'description': 'General query'
        }
    
    
    def process_question(self, question: str, offset: int = 0, limit: int = 50) -> Dict[str, Any]:
        """Process user question with intelligent routing

        Args:
            question: User's question
            offset: Pagination offset (default 0)
            limit: Results per page (default 50)
        """
        self.metrics.total_queries += 1
        start_time = datetime.utcnow()

        # Store pagination params for use in SQL queries
        self._pagination_offset = offset
        self._pagination_limit = limit
        
        try:
            if not question or not question.strip():
                return self._error_response("Empty question", start_time)
            
            logger.info(f"\n🔍 Processing: {question[:100]}...")
            
            # ✨ Check for general/conversational query first (uses LLM classification)
            if self._is_greeting(question):
                logger.info("   → General/conversational query detected (LLM classified)")
                greeting_response = self._get_greeting_response(question)

                elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
                self.metrics.total_processing_time_ms += elapsed_ms

                logger.info(f"   ✅ LLM response ({elapsed_ms:.0f}ms)\n")

                return {
                    'answer': greeting_response,
                    'method': 'direct_llm',
                    'routing': {
                        'query_type': 'general_conversation',
                        'path': 'llm_response',
                    },
                    'performance': {
                        'processing_time_ms': round(elapsed_ms, 2),
                        'processing_time_seconds': round(elapsed_ms / 1000, 2)
                    },
                    'cost': {
                        'optimization': 'direct_llm',
                        'estimated_usd': 0.001
                    }
                }
            
            # Continue with normal processing
            intent = self._detect_query_intent(question)
            
            if intent['type'] == 'error':
                return self._error_response(intent['description'], start_time)
            
            logger.info(f"   → Type: {intent['type']}")
            
            final_answer = None
            routing_method = None
            
            # ROUTE 1a: ID LOOKUP (BRIEF) - Concise summary
            if intent['type'] == 'id_lookup':
                self.metrics.id_lookups += 1
                logger.info(f"   → Brief lookup: {intent['ids']}")
                final_answer = self._lookup_interfaces_by_id(intent['ids'])
                routing_method = 'exact_id_lookup'

            # ROUTE 1b: ID LOOKUP (FULL) - All 44 columns
            elif intent['type'] == 'id_lookup_full':
                self.metrics.id_lookups += 1
                logger.info(f"   → Full details lookup: {intent['ids']}")
                final_answer = self._lookup_interfaces_by_id_full(intent['ids'])
                routing_method = 'full_id_lookup'

            # ROUTE 2: DISTINCT VALUES (what are the patterns, list statuses, etc.)
            elif intent['type'] == 'distinct_values':
                column = intent.get('column', 'status')
                logger.info(f"   → Distinct values for: {column}")
                final_answer = self._get_distinct_values(column)
                routing_method = 'distinct_values'

            # ROUTE 3: REPORT/CHART
            elif intent['type'] == 'report':
                report_filter = intent.get('report_filter')
                platform_filter = intent.get('platform_filter')
                status_filter = intent.get('status_filter')
                logger.info(f"   → Report/Chart generation (filter: {report_filter}, platform: {platform_filter}, status: {status_filter})")
                final_answer = self._generate_report_data(question, report_filter, platform_filter, status_filter)
                routing_method = 'report_chart'

            # ROUTE 4: AGGREGATION
            elif intent['type'] == 'aggregation':
                logger.info("   → Aggregation")
                raw_answer = self._get_aggregation_stats()

                # Try LLM formatting for aggregation
                if raw_answer and self.llm_enabled and self.openai_client:
                    logger.info("   → LLM formatting aggregation")
                    llm_answer = self._format_data_with_llm(question, raw_answer, 'aggregation')
                    if llm_answer and llm_answer.strip():
                        final_answer = llm_answer
                        routing_method = 'aggregation_with_llm'
                        self.metrics.llm_formats += 1
                    else:
                        final_answer = raw_answer
                        routing_method = 'sql_aggregation'
                else:
                    final_answer = raw_answer
                    routing_method = 'sql_aggregation'

            # ROUTE 5: EXPLANATION (what is Request-Response, etc.)
            elif intent['type'] == 'explanation':
                category = intent.get('category', 'pattern')
                value = intent.get('value', '')
                logger.info(f"   → Explanation for {category}: {value}")
                final_answer = self._generate_explanation(category, value, question)
                routing_method = 'explanation'

            # ROUTE 6: SEMANTIC SEARCH
            elif intent['type'] == 'semantic_search':
                self.metrics.vector_searches += 1
                logger.info("   → Vector search")

                if self.vector_search and self.vector_search.use_local_embeddings:
                    search_result = self.vector_search.search_similar(
                        question,
                        limit=self.rag_config.vector_search_limit,
                        similarity_threshold=self.rag_config.similarity_threshold
                    )
                    vector_results = search_result.data if search_result.status.value == 'success' else []
                else:
                    vector_results = []

                logger.info(f"   📊 Results: {len(vector_results)}")

                if vector_results:
                    if self.llm_enabled and self.openai_client:
                        logger.info("   → LLM formatting")

                        llm_answer = self._format_with_llm(question, vector_results)

                        if llm_answer and llm_answer.strip():
                            final_answer = llm_answer
                            routing_method = 'vector_with_llm'
                            self.metrics.llm_formats += 1
                        else:
                            logger.warning("   ⚠️ LLM failed, vector format")
                            final_answer = self._format_vector_results(vector_results)
                            routing_method = 'vector_search'
                    else:
                        final_answer = self._format_vector_results(vector_results)
                        routing_method = 'vector_search'
                else:
                    self.metrics.sql_fallbacks += 1
                    logger.info("   → Dynamic SQL fallback")
                    raw_answer = self._get_sql_results_with_data(question)

                    # SQL results already come in table format - return directly
                    # Table format is more useful than LLM summary for search results
                    if raw_answer:
                        final_answer = raw_answer
                        routing_method = 'sql_table_results'
                        logger.info("   → Returning SQL table results directly")
                    else:
                        final_answer = None
                        routing_method = 'no_results'
            
            if not final_answer:
                final_answer = "No results found. Try asking about specific interfaces (e.g., 'Show me SAP CPI interfaces') or use interface IDs (e.g., 'INT-1010')."
                routing_method = 'no_results'
            
            elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            self.metrics.total_processing_time_ms += elapsed_ms
            
            logger.info(f"   ✅ Ready: {routing_method} ({elapsed_ms:.0f}ms)\n")
            
            return {
                'answer': final_answer,
                'method': routing_method,
                'routing': {
                    'query_type': intent['type'],
                    'path': routing_method,
                },
                'performance': {
                    'processing_time_ms': round(elapsed_ms, 2),
                    'processing_time_seconds': round(elapsed_ms / 1000, 2)
                },
                'cost': {
                    'optimization': 'smart_routing',
                    'estimated_usd': 0.001 if 'llm' in routing_method else 0
                }
            }
        
        except Exception as e:
            self.metrics.errors += 1
            logger.error(f"❌ Processing failed: {e}")
            return self._error_response(str(e), start_time)
    
    
    def _error_response(self, error_msg: str, start_time: datetime) -> Dict[str, Any]:
        """Generate error response"""
        elapsed_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
        return {
            'answer': f'Error: {error_msg}',
            'method': 'error',
            'routing': {'query_type': 'error', 'path': 'error'},
            'performance': {
                'processing_time_ms': round(elapsed_ms, 2),
                'processing_time_seconds': round(elapsed_ms / 1000, 2)
            },
            'cost': {'optimization': 'none', 'estimated_usd': 0}
        }
    
    
    # ========================================================================
    # ✅ FUNCTION 1: _lookup_interfaces_by_id() - WITH ALL 44 COLUMNS
    # ========================================================================
    def _lookup_interfaces_by_id(self, interface_ids: List[str]) -> str:
        """
        Look up interfaces by exact ID - WITH SEQUENTIAL NUMBERING & ALL 44 COLUMNS
        """
        if not self.db:
            return "Database not available"
        
        try:
            results = []
            schema = self.db_schema
            
            for interface_id in interface_ids:
                try:
                    if hasattr(self.db, 'execute'):
                        # ✅ SELECT * for ALL 44 columns
                        result = self.db.execute(text(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = :id
                            LIMIT 1
                        """), {'id': interface_id})
                        row = result.fetchone()
                        if row:
                            keys = result.keys()
                            results.append(dict(zip(keys, row)))
                    else:
                        cursor = self.db.cursor()
                        cursor.execute(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = %s
                            LIMIT 1
                        """, (interface_id,))
                        col_names = [desc[0] for desc in cursor.description]
                        row = cursor.fetchone()
                        cursor.close()
                        if row:
                            results.append(dict(zip(col_names, row)))
                
                except Exception as e:
                    logger.warning(f"⚠️ Error: {e}")
            
            if not results:
                return f"No interfaces found: {', '.join(interface_ids)}"

            # Format output based on number of results
            if len(results) == 1:
                # Single interface - show brief summary
                row_dict = results[0]
                formatted = InterfaceDetailsFormatter.format_brief(row_dict)
                formatted += "\n\n💡 *Type 'details INT-XXXX' for full information*"
                logger.info(f"✅ Returning 1 interface with brief format")
            else:
                # Multiple interfaces - show brief list
                formatted = f"Found {len(results)} interface(s):\n\n"
                for idx, row_dict in enumerate(results, 1):
                    formatted += f"**{idx}.** "
                    formatted += InterfaceDetailsFormatter.format_brief(row_dict)
                    formatted += "\n\n---\n\n"
                logger.info(f"✅ Returning {len(results)} interfaces with brief format")

            return formatted

        except Exception as e:
            logger.error(f"❌ Lookup failed: {e}")
            return f"Error: {str(e)}"

    def _lookup_interfaces_by_id_full(self, interface_ids: List[str]) -> str:
        """
        Look up interfaces by exact ID - WITH ALL 44 COLUMNS (full details)
        """
        if not self.db:
            return "Database not available"

        try:
            results = []
            schema = self.db_schema

            for interface_id in interface_ids:
                try:
                    if hasattr(self.db, 'execute'):
                        result = self.db.execute(text(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = :id
                            LIMIT 1
                        """), {'id': interface_id})
                        row = result.fetchone()
                        if row:
                            keys = result.keys()
                            results.append(dict(zip(keys, row)))
                    else:
                        cursor = self.db.cursor()
                        cursor.execute(f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE interface_id = %s
                            LIMIT 1
                        """, (interface_id,))
                        col_names = [desc[0] for desc in cursor.description]
                        row = cursor.fetchone()
                        cursor.close()
                        if row:
                            results.append(dict(zip(col_names, row)))

                except Exception as e:
                    logger.warning(f"⚠️ Error: {e}")

            if not results:
                return f"No interfaces found: {', '.join(interface_ids)}"

            # Full format with all 44 columns
            formatted = f"📋 **Full Details** - Found {len(results)} interface(s):\n\n"

            for idx, row_dict in enumerate(results, 1):
                if len(results) > 1:
                    formatted += f"**━━━ Interface {idx} of {len(results)} ━━━**\n\n"
                formatted += InterfaceDetailsFormatter.format_interface(row_dict)
                formatted += "\n\n"

            logger.info(f"✅ Returning {len(results)} interfaces with FULL 44 columns")
            return formatted

        except Exception as e:
            logger.error(f"❌ Full lookup failed: {e}")
            return f"Error: {str(e)}"


    # ========================================================================
    # ✅ FUNCTION 1c: _generate_explanation() - EXPLAIN PATTERNS/STATUSES
    # ========================================================================
    def _generate_explanation(self, category: str, value: str, question: str) -> str:
        """
        Generate explanation for patterns, statuses, or other domain concepts.
        Uses LLM if available, otherwise returns predefined explanations.
        """
        # Predefined explanations for common terms
        pattern_explanations = {
            'Request-Response': """**Request-Response Pattern**

This is a synchronous integration pattern where:
- The **source system** sends a request and **waits** for a response
- The **target system** processes the request and returns a response
- Communication is **blocking** - the caller is blocked until response arrives

**Use Cases:** Real-time data queries, validation checks, immediate confirmations

**Example:** A CRM system queries an ERP for customer credit limit before processing an order.""",

            'Request-Reply': """**Request-Reply Pattern**

Similar to Request-Response but with more flexible timing:
- The source sends a request and may continue processing
- Response comes back through a **separate channel** or callback
- Often uses **correlation IDs** to match responses to requests

**Use Cases:** Order processing, asynchronous validations, batch confirmations""",

            'One-Way': """**One-Way Pattern (Fire-and-Forget)**

An asynchronous pattern where:
- The source system sends a message and **doesn't wait** for a response
- No acknowledgment or confirmation is expected
- Used for **notifications** and **event publishing**

**Use Cases:** Log events, notifications, audit trails, status updates""",

            'Fire and Forget': """**Fire and Forget Pattern**

A simple asynchronous messaging pattern:
- Message is sent **without expecting any response**
- Source system continues immediately after sending
- Reliability depends on the messaging infrastructure

**Use Cases:** Logging, notifications, non-critical updates, event streaming""",

            'Batch Processing': """**Batch Processing Pattern**

A pattern for handling large volumes of data:
- Data is collected and processed in **scheduled batches**
- Typically runs during **off-peak hours**
- Efficient for **bulk data transfers** and ETL operations

**Use Cases:** Nightly data syncs, bulk imports/exports, report generation""",

            'Pub-Sub': """**Publish-Subscribe (Pub-Sub) Pattern**

An event-driven messaging pattern:
- **Publishers** send messages to topics without knowing subscribers
- **Subscribers** receive messages from topics they're interested in
- Enables **loose coupling** between systems

**Use Cases:** Event notifications, real-time updates, microservices communication"""
        }

        status_explanations = {
            'Active': """**Active Status**

Interfaces marked as Active are:
- Currently **in production** and processing live data
- Fully operational and monitored
- Subject to SLAs and support agreements""",

            'Inactive': """**Inactive Status**

Interfaces marked as Inactive are:
- Temporarily **disabled** but not removed
- May be paused for maintenance or business reasons
- Can be reactivated when needed""",

            'Testing': """**Testing Status**

Interfaces in Testing are:
- Under **development or QA validation**
- Not yet approved for production use
- May be running in test/staging environments""",

            'In Development': """**In Development Status**

Interfaces In Development are:
- Currently being **built or configured**
- Not ready for testing yet
- Part of ongoing projects""",

            'Retired': """**Retired Status**

Interfaces marked as Retired are:
- **Permanently decommissioned**
- No longer in use or supported
- Kept for historical/audit purposes"""
        }

        # Get count from database for context
        count = 0
        if self.db:
            try:
                schema = self.db_schema
                if category == 'pattern':
                    result = self.db.execute(text(f"""
                        SELECT COUNT(*) FROM {schema}.integration_interfaces
                        WHERE LOWER(interface_pattern) LIKE :pattern
                    """), {'pattern': f'%{value.lower()}%'})
                else:
                    result = self.db.execute(text(f"""
                        SELECT COUNT(*) FROM {schema}.integration_interfaces
                        WHERE LOWER(status) = :status
                    """), {'status': value.lower()})
                count = result.scalar() or 0
            except Exception as e:
                logger.warning(f"⚠️ Count query failed: {e}")

        # Try LLM first for more contextual explanation
        if self.llm_enabled and self.openai_client:
            try:
                context = f"""You are explaining integration concepts in a dashboard.
The user asked: "{question}"
They want to know about: {category} = "{value}"
Database has {count} interfaces with this {category}.

Provide a clear, concise explanation (3-5 sentences) of what "{value}" means in the context of enterprise integrations.
Include practical use cases. Keep it professional but accessible."""

                response = self.openai_client.chat.completions.create(
                    model=self.deployment,
                    messages=[{"role": "user", "content": context}],
                    max_tokens=300,
                    temperature=0.3
                )

                llm_response = response.choices[0].message.content.strip()
                if llm_response:
                    result = f"**{value}** ({category.title()})\n\n{llm_response}"
                    if count > 0:
                        result += f"\n\n📊 *Your database has **{count}** interfaces with this {category}.*"
                    return result
            except Exception as e:
                logger.warning(f"⚠️ LLM explanation failed: {e}")

        # Fallback to predefined explanations
        if category == 'pattern' and value in pattern_explanations:
            result = pattern_explanations[value]
            if count > 0:
                result += f"\n\n📊 *Your database has **{count}** interfaces using this pattern.*"
            return result
        elif category == 'status' and value in status_explanations:
            result = status_explanations[value]
            if count > 0:
                result += f"\n\n📊 *Your database has **{count}** interfaces with this status.*"
            return result

        # Generic fallback
        return f"**{value}** is a {category} used in integration interfaces. Your database has {count} interfaces with this {category}."


    # ========================================================================
    # ✅ FUNCTION 2: _get_aggregation_stats() - COMPLETE STATS
    # ========================================================================
    def _get_aggregation_stats(self) -> str:
        """Get aggregation statistics with detailed breakdown"""
        if not self.db:
            return "Database not available"
        
        try:
            schema = self.db_schema
            
            if hasattr(self.db, 'execute'):
                # Total
                total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                total = total_result.scalar()
                
                # By Status
                status_result = self.db.execute(text(f"""
                    SELECT status, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY status
                    ORDER BY count DESC
                """))
                statuses = status_result.fetchall()
                
                # By Platform
                platform_result = self.db.execute(text(f"""
                    SELECT interface_platform, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """))
                platforms = platform_result.fetchall()
                
                # By Pattern
                pattern_result = self.db.execute(text(f"""
                    SELECT interface_pattern, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    WHERE interface_pattern IS NOT NULL
                    GROUP BY interface_pattern
                    ORDER BY count DESC
                """))
                patterns = pattern_result.fetchall()
            else:
                cursor = self.db.cursor()
                
                cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                total = cursor.fetchone()[0]
                
                cursor.execute(f"""
                    SELECT status, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY status
                    ORDER BY count DESC
                """)
                statuses = cursor.fetchall()
                
                cursor.execute(f"""
                    SELECT interface_platform, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    GROUP BY interface_platform
                    ORDER BY count DESC
                """)
                platforms = cursor.fetchall()
                
                cursor.execute(f"""
                    SELECT interface_pattern, COUNT(*) as count 
                    FROM {schema}.integration_interfaces 
                    WHERE interface_pattern IS NOT NULL
                    GROUP BY interface_pattern
                    ORDER BY count DESC
                """)
                patterns = cursor.fetchall()
                
                cursor.close()
            
            formatted = f"**Interface Statistics**\n\n"
            formatted += f"**Total:** {total:,}\n\n"
            
            formatted += "**By Status:**\n"
            for status, count in statuses:
                percentage = (count / total * 100) if total > 0 else 0
                formatted += f"  - {status}: {count:,} ({percentage:.1f}%)\n"
            
            formatted += "\n**By Platform:**\n"
            for platform, count in platforms:
                percentage = (count / total * 100) if total > 0 else 0
                formatted += f"  - {platform}: {count:,} ({percentage:.1f}%)\n"
            
            if patterns:
                formatted += "\n**By Pattern:**\n"
                for pattern, count in patterns:
                    percentage = (count / total * 100) if total > 0 else 0
                    formatted += f"  - {pattern}: {count:,} ({percentage:.1f}%)\n"
            
            return formatted

        except Exception as e:
            logger.error(f"❌ Aggregation failed: {e}")
            return f"Error: {str(e)}"


    # ========================================================================
    # ✅ FUNCTION 2a: _get_distinct_values() - LIST UNIQUE VALUES IN A COLUMN
    # ========================================================================
    def _get_distinct_values(self, column: str) -> str:
        """
        Get distinct values for a specific column with counts.
        Used for questions like "what are the patterns", "list all statuses", etc.
        """
        if not self.db:
            return "Database not available"

        try:
            schema = self.db_schema

            # Map friendly names to actual column names
            column_map = {
                'pattern': 'interface_pattern',
                'patterns': 'interface_pattern',
                'interface_pattern': 'interface_pattern',
                'status': 'status',
                'statuses': 'status',
                'platform': 'interface_platform',
                'platforms': 'interface_platform',
                'interface_platform': 'interface_platform',
                'frequency': 'frequency',
                'frequencies': 'frequency',
                'priority': 'priority',
                'priorities': 'priority',
                'mode': 'interface_mode',
                'modes': 'interface_mode',
                'interface_mode': 'interface_mode',
            }

            actual_column = column_map.get(column.lower(), column)

            # Friendly display names
            display_names = {
                'interface_pattern': 'Integration Patterns',
                'status': 'Statuses',
                'interface_platform': 'Platforms',
                'frequency': 'Frequencies',
                'priority': 'Priorities',
                'interface_mode': 'Interface Modes',
            }
            display_name = display_names.get(actual_column, actual_column.replace('_', ' ').title())

            if hasattr(self.db, 'execute'):
                result = self.db.execute(text(f"""
                    SELECT {actual_column}, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE {actual_column} IS NOT NULL AND {actual_column} != ''
                    GROUP BY {actual_column}
                    ORDER BY count DESC
                """))
                rows = result.fetchall()
            else:
                cursor = self.db.cursor()
                cursor.execute(f"""
                    SELECT {actual_column}, COUNT(*) as count
                    FROM {schema}.integration_interfaces
                    WHERE {actual_column} IS NOT NULL AND {actual_column} != ''
                    GROUP BY {actual_column}
                    ORDER BY count DESC
                """)
                rows = cursor.fetchall()
                cursor.close()

            if not rows:
                return f"No {display_name.lower()} found in the database."

            # Calculate total
            total = sum(row[1] for row in rows)

            # Format response
            formatted = f"📋 **Available {display_name}** ({len(rows)} types)\n\n"
            formatted += f"| # | {display_name.rstrip('s')} | Count | % |\n"
            formatted += "|---|---|---|---|\n"

            for idx, (value, count) in enumerate(rows, 1):
                percentage = (count / total * 100) if total > 0 else 0
                formatted += f"| {idx} | {value} | {count:,} | {percentage:.1f}% |\n"

            formatted += f"\n**Total interfaces:** {total:,}"

            logger.info(f"✅ Found {len(rows)} distinct values for {actual_column}")
            return formatted

        except Exception as e:
            logger.error(f"❌ Distinct values query failed: {e}")
            return f"Error getting {column} values: {str(e)}"


    # ========================================================================
    # ✅ FUNCTION 2b: _generate_report_data() - CHART.JS DATA GENERATION
    # ========================================================================
    def _generate_report_data(self, question: str, report_filter: str = None, platform_filter: str = None, status_filter: str = None) -> str:
        """
        Generate report data for Chart.js visualization

        Args:
            question: User's question
            report_filter: Optional filter from context ('pattern', 'status', 'platform', etc.)
            platform_filter: Optional platform filter ('sap cpi', 'azure apim', etc.)
            status_filter: Optional status filter ('active', 'testing', etc.)

        Returns JSON-formatted chart data that frontend can render
        """
        if not self.db:
            return "Database not available"

        try:
            import json
            schema = self.db_schema
            q_lower = question.lower()

            # Build WHERE clause for filters
            where_conditions = []
            if platform_filter:
                # Handle case-insensitive matching
                where_conditions.append(f"LOWER(interface_platform) = '{platform_filter.lower()}'")
                logger.info(f"   → Platform filter: {platform_filter}")
            if status_filter:
                where_conditions.append(f"LOWER(status) = '{status_filter.lower()}'")
                logger.info(f"   → Status filter: {status_filter}")

            base_where = " AND ".join(where_conditions) if where_conditions else "1=1"
            filter_title = ""
            if platform_filter:
                filter_title = f" - {platform_filter.upper()}"
            if status_filter:
                filter_title += f" ({status_filter.title()})"

            # Determine what type of report the user wants
            if report_filter:
                report_type = report_filter
                logger.info(f"   → Using context-based report filter: {report_filter}")
            else:
                report_type = 'overview'
                # If a platform filter is already set (e.g., "Platform Report for SAP CPI"),
                # treat it as an overview report for that platform, not a platform distribution
                if platform_filter:
                    # User wants a filtered report for a specific platform
                    report_type = 'overview'
                    logger.info(f"   → Platform filter set, using overview report type")
                elif 'status' in q_lower:
                    report_type = 'status'
                elif 'platform' in q_lower:
                    report_type = 'platform'
                elif 'pattern' in q_lower:
                    report_type = 'pattern'
                elif 'priority' in q_lower:
                    report_type = 'priority'
                elif 'frequency' in q_lower:
                    report_type = 'frequency'

            logger.info(f"   → Report type: {report_type}, WHERE: {base_where}")

            charts = []

            # ================================================================
            # STATUS DISTRIBUTION CHART (Pie/Doughnut)
            # ================================================================
            if report_type in ['overview', 'status']:
                if hasattr(self.db, 'execute'):
                    status_result = self.db.execute(text(f"""
                        SELECT status, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE status IS NOT NULL AND {base_where}
                        GROUP BY status
                        ORDER BY count DESC
                    """))
                    status_data = status_result.fetchall()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"""
                        SELECT status, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE status IS NOT NULL AND {base_where}
                        GROUP BY status
                        ORDER BY count DESC
                    """)
                    status_data = cursor.fetchall()
                    cursor.close()

                if status_data:
                    logger.info(f"   → Status data: {status_data}")
                    charts.append({
                        'id': 'statusChart',
                        'type': 'doughnut',
                        'title': f'Interface Status Distribution{filter_title}',
                        'labels': [str(row[0]) if row[0] else 'Unknown' for row in status_data],
                        'data': [int(row[1]) for row in status_data],
                        'colors': ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#f97316']
                    })

            # ================================================================
            # PLATFORM DISTRIBUTION CHART (Bar) - Skip if platform is already filtered
            # ================================================================
            if report_type in ['overview', 'platform'] and not platform_filter:
                if hasattr(self.db, 'execute'):
                    platform_result = self.db.execute(text(f"""
                        SELECT interface_platform, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE interface_platform IS NOT NULL AND {base_where}
                        GROUP BY interface_platform
                        ORDER BY count DESC
                        LIMIT 10
                    """))
                    platform_data = platform_result.fetchall()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"""
                        SELECT interface_platform, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE interface_platform IS NOT NULL AND {base_where}
                        GROUP BY interface_platform
                        ORDER BY count DESC
                        LIMIT 10
                    """)
                    platform_data = cursor.fetchall()
                    cursor.close()

                if platform_data:
                    logger.info(f"   → Platform data: {platform_data}")
                    charts.append({
                        'id': 'platformChart',
                        'type': 'bar',
                        'title': f'Interfaces by Platform{filter_title}',
                        'labels': [str(row[0]) if row[0] else 'Unknown' for row in platform_data],
                        'data': [int(row[1]) for row in platform_data],
                        'colors': ['#2d8659']
                    })

            # ================================================================
            # PATTERN DISTRIBUTION CHART (Horizontal Bar)
            # ================================================================
            if report_type in ['overview', 'pattern']:
                if hasattr(self.db, 'execute'):
                    pattern_result = self.db.execute(text(f"""
                        SELECT interface_pattern, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE interface_pattern IS NOT NULL AND {base_where}
                        GROUP BY interface_pattern
                        ORDER BY count DESC
                        LIMIT 8
                    """))
                    pattern_data = pattern_result.fetchall()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"""
                        SELECT interface_pattern, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE interface_pattern IS NOT NULL AND {base_where}
                        GROUP BY interface_pattern
                        ORDER BY count DESC
                        LIMIT 8
                    """)
                    pattern_data = cursor.fetchall()
                    cursor.close()

                if pattern_data:
                    logger.info(f"   → Pattern data: {pattern_data}")
                    charts.append({
                        'id': 'patternChart',
                        'type': 'horizontalBar',
                        'title': f'Integration Patterns{filter_title}',
                        'labels': [str(row[0]) if row[0] else 'Unknown' for row in pattern_data],
                        'data': [int(row[1]) for row in pattern_data],
                        'colors': ['#1a4d2e']
                    })

            # ================================================================
            # PRIORITY DISTRIBUTION CHART (Pie)
            # ================================================================
            if report_type == 'priority':
                if hasattr(self.db, 'execute'):
                    priority_result = self.db.execute(text(f"""
                        SELECT priority, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE priority IS NOT NULL AND {base_where}
                        GROUP BY priority
                        ORDER BY count DESC
                    """))
                    priority_data = priority_result.fetchall()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"""
                        SELECT priority, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE priority IS NOT NULL AND {base_where}
                        GROUP BY priority
                        ORDER BY count DESC
                    """)
                    priority_data = cursor.fetchall()
                    cursor.close()

                if priority_data:
                    logger.info(f"   → Priority data: {priority_data}")
                    charts.append({
                        'id': 'priorityChart',
                        'type': 'pie',
                        'title': f'Priority Distribution{filter_title}',
                        'labels': [str(row[0]) if row[0] else 'Unknown' for row in priority_data],
                        'data': [int(row[1]) for row in priority_data],
                        'colors': ['#ef4444', '#f59e0b', '#10b981', '#6b7280']
                    })

            # ================================================================
            # FREQUENCY DISTRIBUTION CHART
            # ================================================================
            if report_type == 'frequency':
                if hasattr(self.db, 'execute'):
                    freq_result = self.db.execute(text(f"""
                        SELECT frequency, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE frequency IS NOT NULL AND {base_where}
                        GROUP BY frequency
                        ORDER BY count DESC
                    """))
                    freq_data = freq_result.fetchall()
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"""
                        SELECT frequency, COUNT(*) as count
                        FROM {schema}.integration_interfaces
                        WHERE frequency IS NOT NULL AND {base_where}
                        GROUP BY frequency
                        ORDER BY count DESC
                    """)
                    freq_data = freq_result.fetchall()
                    cursor.close()

                if freq_data:
                    logger.info(f"   → Frequency data: {freq_data}")
                    charts.append({
                        'id': 'frequencyChart',
                        'type': 'bar',
                        'title': f'Frequency Distribution{filter_title}',
                        'labels': [str(row[0]) if row[0] else 'Unknown' for row in freq_data],
                        'data': [int(row[1]) for row in freq_data],
                        'colors': ['#8b5cf6']
                    })

            # ================================================================
            # GET TOTAL COUNT (with filter applied)
            # ================================================================
            if hasattr(self.db, 'execute'):
                total_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces WHERE {base_where}"))
                total_count = total_result.scalar() or 0
            else:
                cursor = self.db.cursor()
                cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces WHERE {base_where}")
                total_count = cursor.fetchone()[0] or 0
                cursor.close()

            # ================================================================
            # FORMAT RESPONSE WITH CHART DATA MARKER
            # ================================================================
            if not charts:
                return "No data available for the requested report."

            # Create the chart data JSON block
            chart_json = json.dumps({
                'type': 'chart_report',
                'report_type': report_type,
                'total_interfaces': total_count,
                'charts': charts
            })

            # Return response with special marker for frontend parsing
            filter_info = ""
            if platform_filter:
                filter_info += f" for {platform_filter.upper()}"
            if status_filter:
                filter_info += f" ({status_filter.title()})"

            response = f"📊 **Interface Report{filter_info}** - {report_type.title()} Overview\n\n"
            response += f"**Total Interfaces{filter_info}:** {total_count:,}\n\n"
            response += f"<!--CHART_DATA:{chart_json}:CHART_DATA-->\n\n"

            # Add summary text
            for chart in charts:
                response += f"**{chart['title']}:**\n"
                for label, value in zip(chart['labels'][:5], chart['data'][:5]):
                    percentage = (value / total_count * 100) if total_count > 0 else 0
                    response += f"  • {label}: {value:,} ({percentage:.1f}%)\n"
                if len(chart['labels']) > 5:
                    response += f"  • ... and {len(chart['labels']) - 5} more\n"
                response += "\n"

            logger.info(f"✅ Generated report with {len(charts)} chart(s)")
            return response

        except Exception as e:
            logger.error(f"❌ Report generation failed: {e}")
            return f"Error generating report: {str(e)}"


    # ========================================================================
    # ✅ FUNCTION 3: _format_vector_results() - WITH SEQUENTIAL NUMBERING
    # ========================================================================
    def _format_vector_results(self, results: List[Dict[str, Any]]) -> str:
        """Format vector search results - WITH SEQUENTIAL NUMBERING"""
        if not results:
            return "No similar results found."
        
        formatted = "**Similar interfaces found:**\n\n"
        
        for idx, result in enumerate(results, 1):
            formatted += f"{idx}. **{result.get('interface_id', 'Unknown')}**\n"
            formatted += f"   Type: {result.get('content_type', 'N/A')}\n"
            formatted += f"   Content: {result.get('content', 'N/A')[:150]}\n"
            formatted += f"   Match: {result.get('similarity', 0):.1%}\n\n"
        
        return formatted
    
    
    # ========================================================================
    # ✅ FUNCTION 4: _get_sql_results_with_data() - DYNAMIC SQL (NO HARDCODING)
    # ========================================================================
    def _get_sql_results_with_data(self, question: str) -> Optional[str]:
        """
        Dynamic SQL search - NO hardcoded columns or values
        
        ✅ How it works:
        1. Takes user question (e.g., "Show SAP interfaces")
        2. Extracts keywords (e.g., "SAP")
        3. Searches ALL columns for values containing keyword
        4. Finds which columns match (e.g., interface_platform has "SAP CPI")
        5. Builds dynamic WHERE clause
        6. Executes query
        7. Returns results with ALL columns
        
        ✅ Advantages:
        - Works with ANY database structure
        - No hardcoded column names
        - No hardcoded values
        - Self-adapts to data
        - Future-proof
        """
        try:
            if not self.db:
                return None
            
            logger.info("📋 Dynamic Smart SQL Search (NO HARDCODING)...")
            schema = self.db_schema
            
            if not question or not question.strip():
                return None
            
            # Initialize dynamic search helper if not already done
            if not self.dynamic_search_helper:
                self.dynamic_search_helper = DynamicSearchHelper(self.db, schema)
            
            q_lower = question.lower().strip()

            # Use pagination params if set, otherwise default to 50
            SEARCH_LIMIT = getattr(self, '_pagination_limit', 50)
            SEARCH_OFFSET = getattr(self, '_pagination_offset', 0)

            # Variable to store WHERE clause for count query
            where_clause = None

            # ============================================================
            # STRATEGY 1: Exact ID Lookup (INT-XXXX)
            # ============================================================
            id_matches = re.findall(r'INT-\d+', question, re.IGNORECASE)
            if id_matches:
                logger.info(f"   → ID Lookup: {id_matches}")
                ids_clause = " OR ".join([f"interface_id = '{iid}'" for iid in id_matches])
                where_clause = ids_clause
                sql_query = f"""
                    SELECT * FROM {schema}.integration_interfaces
                    WHERE {ids_clause}
                    ORDER BY interface_id
                    LIMIT {SEARCH_LIMIT} OFFSET {SEARCH_OFFSET}
                """
                search_type = f"Exact ID Match: {', '.join(id_matches)}"
                search_icon = "🔍"

            # ============================================================
            # STRATEGY 2: Dynamic Keyword Search
            # ============================================================
            else:
                # Clean the query - remove quotes and special characters
                clean_query = re.sub(r'["\'\(\)\[\]\{\}]', ' ', q_lower)

                # Extract potential keywords (words >= 3 chars, not common words)
                common_words = {'show', 'list', 'find', 'where', 'what', 'which', 'give', 'please', 'interfaces', 'systems', 'me', 'for', 'the', 'and', 'or', 'is', 'are', 'all', 'get', 'can', 'you', 'how', 'any', 'details', 'more', 'with', 'this', 'that', 'those', 'these'}
                words = [
                    w.strip() for w in clean_query.split()
                    if len(w.strip()) >= 3 and w.strip() not in common_words and not w.endswith('?')
                ]

                if not words:
                    # Fallback: return all
                    where_clause = None
                    sql_query = f"""
                        SELECT * FROM {schema}.integration_interfaces
                        ORDER BY interface_id
                        LIMIT {SEARCH_LIMIT} OFFSET {SEARCH_OFFSET}
                    """
                    search_type = "All Interfaces"
                    search_icon = "📊"

                else:
                    logger.info(f"   → Keywords found: {words}")

                    # Search for columns containing these keywords
                    all_matches = []
                    for keyword in words:
                        column_matches = self.dynamic_search_helper.find_columns_containing_keyword(keyword)
                        all_matches.extend(column_matches)

                    if all_matches:
                        # Build WHERE clause from discovered columns
                        where_conditions = []
                        found_columns_set = set()

                        for column, values in all_matches:
                            found_columns_set.add(column)
                            # Match any of the discovered values
                            value_conditions = " OR ".join([
                                f"{column} ILIKE '%{val}%'"
                                for val in values[:5]  # Limit to 5 values per column
                            ])
                            where_conditions.append(f"({value_conditions})")

                        where_clause = " OR ".join(where_conditions)
                        sql_query = f"""
                            SELECT * FROM {schema}.integration_interfaces
                            WHERE {where_clause}
                            ORDER BY interface_id
                            LIMIT {SEARCH_LIMIT} OFFSET {SEARCH_OFFSET}
                        """

                        # Create descriptive search type
                        cols_str = ", ".join(sorted(found_columns_set))
                        search_type = f"Search in: {cols_str}"
                        search_icon = "🔎"

                        logger.info(f"   → Found in columns: {cols_str}")

                    else:
                        # No matches found, return all
                        logger.info("   → No specific matches, returning all interfaces")
                        where_clause = None
                        sql_query = f"""
                            SELECT * FROM {schema}.integration_interfaces
                            ORDER BY interface_id
                            LIMIT {SEARCH_LIMIT} OFFSET {SEARCH_OFFSET}
                        """
                        search_type = "All Interfaces (no keyword matches)"
                        search_icon = "📊"
            
            # ============================================================
            # EXECUTE QUERY WITH TOTAL COUNT
            # ============================================================
            logger.info(f"   → Search type: {search_type}")

            try:
                # First get total count
                total_count = 0
                if where_clause:
                    count_query = f"SELECT COUNT(*) FROM {schema}.integration_interfaces WHERE {where_clause}"
                else:
                    count_query = f"SELECT COUNT(*) FROM {schema}.integration_interfaces"

                if hasattr(self.db, 'execute'):
                    count_result = self.db.execute(text(count_query))
                    total_count = count_result.scalar() or 0

                    result = self.db.execute(text(sql_query))
                    rows = result.fetchall()
                    keys = result.keys()
                    results = [dict(zip(keys, row)) for row in rows]
                else:
                    cursor = self.db.cursor()
                    cursor.execute(count_query)
                    total_count = cursor.fetchone()[0] or 0

                    cursor.execute(sql_query)
                    col_names = [desc[0] for desc in cursor.description]
                    rows = cursor.fetchall()
                    cursor.close()
                    results = [dict(zip(col_names, row)) for row in rows]

                if not rows:
                    logger.info(f"⚠️ No results found for: {search_type}")
                    return f"No results found for: {search_type}"

                # ============================================================
                # FORMAT RESULTS AS TABLE WITH PAGINATION INFO
                # ============================================================
                showing = len(results)
                start_row = SEARCH_OFFSET + 1
                end_row = SEARCH_OFFSET + showing
                formatted = f"{search_icon} **Showing {showing} of {total_count} interfaces** ({search_type})\n\n"

                # Add table header
                formatted += "| # | Interface ID | Name | Status | Platform | Description |\n"
                formatted += "|---|-------------|------|--------|----------|-------------|\n"

                # Add table rows (row numbers continue from offset)
                for idx, row_dict in enumerate(results, start_row):
                    interface_id = row_dict.get('interface_id', 'N/A')
                    name = row_dict.get('interface_name', 'N/A')[:30]
                    status = row_dict.get('status', 'N/A')
                    platform = row_dict.get('interface_platform', 'N/A')
                    desc = row_dict.get('interface_description', 'N/A')[:40]
                    if len(row_dict.get('interface_description', '')) > 40:
                        desc += '...'

                    formatted += f"| {idx} | {interface_id} | {name} | {status} | {platform} | {desc} |\n"

                # Add pagination note if there are more results
                remaining = total_count - end_row
                if remaining > 0:
                    formatted += f"\n📌 **Note:** Showing {end_row} of {total_count} total matches ({remaining} remaining).\n"

                logger.info(f"✅ Returned rows {start_row}-{end_row} of {total_count} interfaces as table")
                return formatted

            except Exception as query_err:
                logger.warning(f"⚠️ Query failed: {query_err}")
                logger.warning(f"   Query: {sql_query}")
                return None
        
        except Exception as e:
            logger.warning(f"⚠️ Dynamic search failed: {e}")
            return None
    
    
    # ========================================================================
    # ✅ FUNCTION 5: _format_with_llm() - COMPLETE LLM WITH ALL ERROR HANDLING
    # ========================================================================
    def _format_with_llm(self, question: str, vector_results: List[Dict[str, Any]]) -> Optional[str]:
        """
        Format with Azure OpenAI - FIXED FOR GPT-5-MINI
        ✅ Auto-detects mini models and adjusts parameters
        ✅ Removes temperature parameter for mini models
        ✅ Handles token limits gracefully
        ✅ Complex retry logic with detailed error handling
        """
        if not self.openai_client:
            logger.warning("⚠️ No OpenAI client available")
            return None
        
        max_retries = self.rag_config.llm_max_retries
        
        for attempt in range(max_retries):
            try:
                # Detect model type
                model_lower = self.deployment.lower()
                is_mini_model = 'mini' in model_lower
                
                # Set token limit based on model
                if is_mini_model:
                    max_tokens = self.rag_config.llm_max_tokens_mini
                    logger.info(f"   🔍 Mini model detected: {self.deployment}")
                    logger.info(f"   📝 Max tokens: {max_tokens}")
                else:
                    max_tokens = self.rag_config.llm_max_tokens_standard
                
                # Build context - shorter for mini models
                context_lines = []
                max_results = 3 if is_mini_model else 5
                max_content_len = 100 if is_mini_model else 200
                
                for result in vector_results[:max_results]:
                    interface_id = result.get('interface_id', 'Unknown')
                    content = result.get('content', 'N/A')[:max_content_len]
                    similarity = result.get('similarity', 0)
                    
                    context_lines.append(f"• {interface_id}: {content} [{similarity:.0%}]")
                
                context = "\n".join(context_lines)
                
                # Create prompt - always list interface IDs first
                if is_mini_model:
                    prompt = f"""Question: {question}

Data: {context}

List ALL interface IDs first, then brief summary (1-2 sentences).
Format: **Interfaces:** INT-XXXX, INT-XXXX... **Summary:** ..."""
                else:
                    prompt = f"""Question: {question}

{context}

IMPORTANT: First list ALL interface IDs found.
Then provide a brief summary (1-2 sentences).

Format:
**Interfaces Found:** INT-XXXX, INT-XXXX, INT-XXXX, ...
**Summary:** What these interfaces do."""

                logger.info(f"   🧠 Attempt {attempt + 1}/{max_retries}")

                # Build request parameters
                request_params = {
                    "model": self.deployment,
                    "messages": [
                        {
                            "role": "system",
                            "content": "List all interface IDs found, then summarize briefly."
                        },
                        {"role": "user", "content": prompt}
                    ],
                    "max_completion_tokens": max_tokens
                }
                
                # ✅ CRITICAL FIX: Only add temperature if NOT mini model
                if not is_mini_model:
                    request_params["temperature"] = self.rag_config.llm_temperature
                    logger.info(f"   🌡️ Temperature: {self.rag_config.llm_temperature}")
                else:
                    logger.info("   🌡️ Temperature: disabled (mini model)")
                
                # Make request
                logger.info(f"   📤 Sending to {self.deployment}...")
                response = self.openai_client.chat.completions.create(**request_params)
                
                if not response or not response.choices:
                    logger.warning(f"   ⚠️ Empty response (attempt {attempt + 1})")
                    continue
                
                # Extract message
                message = response.choices[0].message
                llm_answer = message.content if hasattr(message, 'content') else str(message)
                
                # Check for truncation
                finish_reason = response.choices[0].finish_reason
                if finish_reason == 'length':
                    logger.warning(f"   ⚠️ Response truncated (finish_reason=length)")
                    if is_mini_model and llm_answer:
                        logger.info("   ✓ Using truncated response (mini model accepts this)")
                        return llm_answer.strip()
                
                # Validate response
                if not llm_answer or not llm_answer.strip():
                    logger.warning(f"   ⚠️ Empty content")
                    continue
                
                if len(llm_answer.strip()) < 20:
                    logger.warning(f"   ⚠️ Response too short ({len(llm_answer)} chars)")
                    continue
                
                # Check for decline phrases
                decline_phrases = ['cannot', 'unable', 'no information']
                if any(phrase in llm_answer.lower() for phrase in decline_phrases):
                    logger.warning(f"   ⚠️ LLM declined to answer")
                    continue
                
                logger.info(f"   ✅ Valid response: {len(llm_answer)} chars")
                return llm_answer.strip()
            
            except Exception as e:
                error_str = str(e).lower()
                
                # Check for token limit errors
                if 'max_tokens' in error_str or 'model output limit' in error_str or 'maximum context length' in error_str:
                    logger.error(f"   ❌ Token limit error: {e}")
                    logger.error(f"   💡 Model {self.deployment} exceeded token limits")
                    logger.error(f"   💡 Solution 1: Switch to gpt-35-turbo in .env:")
                    logger.error(f"       AZURE_OPENAI_DEPLOYMENT=gpt-35-turbo")
                    logger.error(f"   💡 Solution 2: Check your Azure deployment can handle requests")
                    
                    # Try with even fewer tokens for mini models
                    if is_mini_model and attempt == 0:
                        logger.info("   🔄 Retry with 50 tokens...")
                        self.rag_config.llm_max_tokens_mini = 50
                        continue
                    
                    return None
                
                # Check for authentication errors
                if 'authentication' in error_str or 'unauthorized' in error_str or 'api key' in error_str:
                    logger.error(f"   ❌ Authentication error: {e}")
                    logger.error(f"   💡 Check your .env has valid Azure credentials:")
                    logger.error(f"       AZURE_OPENAI_API_KEY=your-key")
                    logger.error(f"       AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
                    return None
                
                # Other errors
                logger.warning(f"   ⚠️ Error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    logger.info("   🔄 Retrying...")
                    continue
        
        logger.warning("   ❌ All LLM attempts failed - will use vector search results only")
        return None


    # ========================================================================
    # ✅ FUNCTION 6: _format_data_with_llm() - LLM FOR ID/SQL/AGGREGATION
    # ========================================================================
    def _format_data_with_llm(self, question: str, raw_data: str, data_type: str = 'general') -> Optional[str]:
        """
        Format any data type with LLM - for ID lookups, SQL results, aggregations

        Args:
            question: User's original question
            raw_data: Raw formatted data from database
            data_type: 'id_lookup', 'sql_search', 'aggregation', or 'general'

        Returns:
            LLM-formatted natural language response or None if failed
        """
        if not self.openai_client:
            logger.warning("⚠️ No OpenAI client available")
            return None

        if not raw_data or len(raw_data.strip()) < 10:
            logger.warning("⚠️ Raw data too short for LLM formatting")
            return None

        max_retries = self.rag_config.llm_max_retries

        for attempt in range(max_retries):
            try:
                # Detect model type
                model_lower = self.deployment.lower()
                is_mini_model = 'mini' in model_lower

                # Set token limit based on model
                if is_mini_model:
                    max_tokens = self.rag_config.llm_max_tokens_mini
                else:
                    max_tokens = self.rag_config.llm_max_tokens_standard

                # Truncate raw data if too long (for mini models)
                max_data_len = 1500 if is_mini_model else 3000
                truncated_data = raw_data[:max_data_len]
                if len(raw_data) > max_data_len:
                    truncated_data += "\n... (truncated)"

                # Build prompt based on data type
                if data_type == 'id_lookup':
                    system_prompt = "You are a helpful assistant explaining integration interface details. Provide a clear, concise summary of the interface data."
                    user_prompt = f"""Question: {question}

Interface Data:
{truncated_data}

Provide a natural language summary of this interface. Include key details like:
- Interface ID and name
- Current status and platform
- What it does (source to target)
- Any important metadata

Keep it concise (3-5 sentences)."""

                elif data_type == 'aggregation':
                    system_prompt = "You are a helpful assistant summarizing statistics. Be concise and highlight key insights."
                    user_prompt = f"""Question: {question}

Statistics:
{truncated_data}

Summarize these statistics in natural language. Highlight key numbers and trends. Keep it brief (2-3 sentences)."""

                elif data_type == 'sql_search':
                    system_prompt = "You are a helpful assistant summarizing search results. Always list ALL interface IDs found."
                    user_prompt = f"""Question: {question}

Search Results:
{truncated_data}

IMPORTANT: First list ALL interface IDs found (e.g., INT-1001, INT-1002, INT-1003...).
Then provide a brief summary of what they do (1-2 sentences).

Format:
**Interfaces Found:** INT-XXXX, INT-XXXX, INT-XXXX, ...
**Summary:** Brief description of what these interfaces do."""

                else:
                    system_prompt = "You are a helpful assistant. Be concise."
                    user_prompt = f"""Question: {question}

Data:
{truncated_data}

Provide a brief, helpful summary (2-3 sentences)."""

                logger.info(f"   🧠 LLM {data_type} formatting (attempt {attempt + 1}/{max_retries})")

                # Build request parameters
                request_params = {
                    "model": self.deployment,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "max_completion_tokens": max_tokens
                }

                # Only add temperature if NOT mini model
                if not is_mini_model:
                    request_params["temperature"] = self.rag_config.llm_temperature

                # Make request
                logger.info(f"   📤 Sending to {self.deployment}...")
                response = self.openai_client.chat.completions.create(**request_params)

                if not response or not response.choices:
                    logger.warning(f"   ⚠️ Empty response (attempt {attempt + 1})")
                    continue

                # Extract message
                message = response.choices[0].message
                llm_answer = message.content if hasattr(message, 'content') else str(message)

                # Validate response
                if not llm_answer or not llm_answer.strip():
                    logger.warning(f"   ⚠️ Empty content")
                    continue

                if len(llm_answer.strip()) < 20:
                    logger.warning(f"   ⚠️ Response too short ({len(llm_answer)} chars)")
                    continue

                logger.info(f"   ✅ LLM {data_type} response: {len(llm_answer)} chars")
                return llm_answer.strip()

            except Exception as e:
                error_str = str(e).lower()

                # Check for token limit errors
                if 'max_tokens' in error_str or 'token' in error_str:
                    logger.warning(f"   ⚠️ Token limit error, retrying with shorter data...")
                    max_data_len = max_data_len // 2
                    continue

                # Other errors
                logger.warning(f"   ⚠️ LLM error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    continue

        logger.warning(f"   ❌ LLM {data_type} formatting failed - using raw data")
        return None


    def get_metrics(self) -> Dict[str, Any]:
        """Get current metrics"""
        return self.metrics.to_dict()
    
    
    def get_service_stats(self) -> Dict[str, Any]:
        """Get service statistics"""
        try:
            if not self.db:
                return {'error': 'Database not available'}
            
            schema = self.db_schema
            
            stats = {
                'timestamp': datetime.utcnow().isoformat(),
                'vector_search_enabled': self.vector_search is not None and self.vector_search.use_local_embeddings,
                'llm_enabled': self.llm_enabled,
                'llm_deployment': self.deployment,
                'embeddings_model': 'all-MiniLM-L6-v2' if self.vector_search else None,
                'similarity_threshold': self.rag_config.similarity_threshold,
                'db_schema': schema,
                'sequential_numbering': True,
                'all_44_columns': True,
                'dynamic_sql_search': True,  # NEW
                'metrics': self.get_metrics()
            }
            
            try:
                if hasattr(self.db, 'execute'):
                    interfaces_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                    stats['total_interfaces'] = interfaces_result.scalar() or 0
                    
                    embeddings_result = self.db.execute(text(f"SELECT COUNT(*) FROM {schema}.interface_embeddings"))
                    stats['total_embeddings'] = embeddings_result.scalar() or 0
                else:
                    cursor = self.db.cursor()
                    cursor.execute(f"SELECT COUNT(*) FROM {schema}.integration_interfaces")
                    stats['total_interfaces'] = cursor.fetchone()[0]
                    cursor.execute(f"SELECT COUNT(*) FROM {schema}.interface_embeddings")
                    stats['total_embeddings'] = cursor.fetchone()[0]
                    cursor.close()
            except Exception as e:
                logger.warning(f"⚠️ Stats error: {e}")
                stats['total_interfaces'] = 0
                stats['total_embeddings'] = 0
            
            if self.vector_search:
                try:
                    stats['cache_stats'] = self.vector_search.get_cache_stats()
                except:
                    pass
            
            return stats
        
        except Exception as e:
            logger.error(f"❌ Failed to get stats: {e}")
            return {'error': str(e)}
    
    
    def health_check(self) -> Dict[str, Any]:
        """Health status"""
        health = {
            'status': 'healthy',
            'vector_search': 'disabled',
            'database': 'unavailable',
            'llm': 'disabled',
            'llm_deployment': self.deployment,
            'smart_routing': 'enabled',
            'sequential_numbering': 'enabled',
            'all_44_columns': 'enabled',
            'dynamic_sql_search': 'enabled',  # NEW
            'db_schema': self.db_schema,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if self.vector_search:
            vs_health = self.vector_search.health_check()
            health['vector_search'] = vs_health.get('status', 'unknown')
        
        if self.db:
            try:
                schema = self.db_schema
                if hasattr(self.db, 'execute'):
                    self.db.execute(text("SELECT 1"))
                else:
                    cursor = self.db.cursor()
                    cursor.execute("SELECT 1")
                    cursor.close()
                health['database'] = 'healthy'
            except:
                health['database'] = 'unhealthy'
                health['status'] = 'degraded'
        
        health['llm'] = 'healthy' if self.llm_enabled else 'disabled'
        
        if health['database'] == 'unhealthy':
            health['status'] = 'unhealthy'
        elif health['vector_search'] == 'degraded':
            health['status'] = 'degraded'
        
        return health


__all__ = ['HybridRAGService', 'InterfaceDetailsFormatter', 'DynamicSearchHelper', 'RAGConfig', 'RAGMetrics']