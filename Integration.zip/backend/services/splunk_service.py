"""
Splunk Services - Business Logic Layer
360° Enterprise Dashboard - Splunk Integration
High-level operations and analytics
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from enum import Enum
from backend.connectors.splunk_connector import get_splunk_connector

logger = logging.getLogger(__name__)


class TimeRange(Enum):
    """Predefined time ranges"""
    LAST_HOUR = "-1h@h"
    LAST_DAY = "-1d@d"
    LAST_7_DAYS = "-7d@d"
    LAST_30_DAYS = "-30d@d"
    LAST_90_DAYS = "-90d@d"
    LAST_YEAR = "-1y@y"
    TODAY = "-1d@d"
    THIS_MONTH = "-1mon@mon"
    CUSTOM = None


class SplunkService:
    """
    High-level Splunk service operations
    Provides business logic for Splunk queries and analytics
    """
    
    def __init__(self, config=None):
        """
        Initialize Splunk service
        
        Args:
            config: Flask configuration object
        """
        self.connector = get_splunk_connector(config)
        self.config = config
    
    
    def is_available(self) -> bool:
        """Check if Splunk is available"""
        if self.connector is None:
            return False
        health = self.connector.health_check()
        return health['status'] == 'healthy'
    
    
    # ========================================================================
    # BASIC SEARCH OPERATIONS
    # ========================================================================
    
    def search(self, query: str, time_range: TimeRange = TimeRange.LAST_7_DAYS,
               timeout: int = None) -> Dict[str, Any]:
        """
        Execute basic search query
        
        Args:
            query: Splunk search query
            time_range: Predefined or custom time range
            timeout: Query timeout in seconds
        
        Returns:
            Dictionary with results
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Splunk is not available',
                'results': []
            }
        
        try:
            earliest = time_range.value if time_range.value else "-30d@d"
            
            logger.info(f"Executing search: {query[:80]}...")
            
            result = self.connector.execute_query(
                query=query,
                earliest_time=earliest,
                latest_time='now',
                timeout=timeout
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Search error: {e}")
            return {
                'success': False,
                'error': str(e),
                'results': []
            }
    
    
    def search_last_hour(self, query: str) -> Dict[str, Any]:
        """Search in last hour"""
        return self.search(query, TimeRange.LAST_HOUR)
    
    
    def search_last_day(self, query: str) -> Dict[str, Any]:
        """Search in last day"""
        return self.search(query, TimeRange.LAST_DAY)
    
    
    def search_last_week(self, query: str) -> Dict[str, Any]:
        """Search in last week"""
        return self.search(query, TimeRange.LAST_7_DAYS)
    
    
    def search_last_month(self, query: str) -> Dict[str, Any]:
        """Search in last month"""
        return self.search(query, TimeRange.LAST_30_DAYS)
    
    
    def search_custom(self, query: str, earliest_time: str,
                     latest_time: str = 'now') -> Dict[str, Any]:
        """
        Search with custom time range
        
        Args:
            query: Splunk search query
            earliest_time: Start time (Splunk format)
            latest_time: End time (Splunk format)
        
        Returns:
            Dictionary with results
        """
        if not self.is_available():
            return {
                'success': False,
                'error': 'Splunk is not available',
                'results': []
            }
        
        try:
            logger.info(f"Custom search: {earliest_time} to {latest_time}")
            
            result = self.connector.execute_query(
                query=query,
                earliest_time=earliest_time,
                latest_time=latest_time
            )
            
            return result
        
        except Exception as e:
            logger.error(f"Custom search error: {e}")
            return {
                'success': False,
                'error': str(e),
                'results': []
            }
    
    
    # ========================================================================
    # STATISTICS & AGGREGATIONS
    # ========================================================================
    
    def get_count(self, index: str = 'main',
                 search_filter: str = None,
                 time_range: TimeRange = TimeRange.LAST_7_DAYS) -> Dict[str, Any]:
        """
        Get event count for an index
        
        Args:
            index: Splunk index name
            search_filter: Additional search filter
            time_range: Time range for search
        
        Returns:
            Dictionary with count
        """
        query = f"search index={index}"
        
        if search_filter:
            query += f" {search_filter}"
        
        query += " | stats count"
        
        result = self.search(query, time_range)
        
        if result['success'] and result['results']:
            count = int(result['results'][0].get('count', 0))
            return {
                'success': True,
                'count': count,
                'index': index,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': False,
            'count': 0,
            'error': result.get('error', 'Failed to get count'),
            'index': index
        }
    
    
    def get_average(self, index: str, field: str,
                   search_filter: str = None,
                   time_range: TimeRange = TimeRange.LAST_7_DAYS) -> Dict[str, Any]:
        """
        Get average value for a field
        
        Args:
            index: Splunk index name
            field: Field to average
            search_filter: Additional search filter
            time_range: Time range for search
        
        Returns:
            Dictionary with average
        """
        query = f"search index={index}"
        
        if search_filter:
            query += f" {search_filter}"
        
        query += f" | stats avg({field})"
        
        result = self.search(query, time_range)
        
        if result['success'] and result['results']:
            avg = float(result['results'][0].get(f'avg({field})', 0))
            return {
                'success': True,
                'field': field,
                'average': avg,
                'index': index,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': False,
            'average': 0,
            'error': result.get('error', 'Failed to get average'),
            'field': field,
            'index': index
        }
    
    
    def get_top_values(self, index: str, field: str, limit: int = 10,
                      search_filter: str = None,
                      time_range: TimeRange = TimeRange.LAST_7_DAYS) -> Dict[str, Any]:
        """
        Get top values for a field
        
        Args:
            index: Splunk index name
            field: Field to get top values from
            limit: Number of top values to return
            search_filter: Additional search filter
            time_range: Time range for search
        
        Returns:
            Dictionary with top values
        """
        limit = min(limit, 100)  # Max 100
        
        query = f"search index={index}"
        
        if search_filter:
            query += f" {search_filter}"
        
        query += f" | top limit={limit} {field}"
        
        result = self.search(query, time_range)
        
        if result['success']:
            return {
                'success': True,
                'field': field,
                'values': result['results'],
                'count': result['count'],
                'index': index,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': False,
            'field': field,
            'values': [],
            'error': result.get('error', 'Failed to get top values'),
            'index': index
        }
    
    
    def group_by(self, index: str, field: str, stats: str = 'count',
                search_filter: str = None,
                time_range: TimeRange = TimeRange.LAST_7_DAYS) -> Dict[str, Any]:
        """
        Group events by field with statistics
        
        Args:
            index: Splunk index name
            field: Field to group by
            stats: Statistic type (count, avg, sum, min, max)
            search_filter: Additional search filter
            time_range: Time range for search
        
        Returns:
            Dictionary with grouped results
        """
        query = f"search index={index}"
        
        if search_filter:
            query += f" {search_filter}"
        
        query += f" | stats {stats} by {field}"
        
        result = self.search(query, time_range)
        
        if result['success']:
            return {
                'success': True,
                'field': field,
                'stat': stats,
                'results': result['results'],
                'count': result['count'],
                'index': index,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': False,
            'field': field,
            'stat': stats,
            'results': [],
            'error': result.get('error', 'Failed to group by'),
            'index': index
        }
    
    
    # ========================================================================
    # TIME-SERIES ANALYTICS
    # ========================================================================
    
    def timechart(self, index: str, field: str, stats: str = 'count',
                 span: str = '1h',
                 search_filter: str = None,
                 time_range: TimeRange = TimeRange.LAST_7_DAYS) -> Dict[str, Any]:
        """
        Create time-series chart data
        
        Args:
            index: Splunk index name
            field: Field to chart
            stats: Statistic type (count, avg, sum, min, max)
            span: Time span (10m, 1h, 1d, etc.)
            search_filter: Additional search filter
            time_range: Time range for search
        
        Returns:
            Dictionary with timechart results
        """
        query = f"search index={index}"
        
        if search_filter:
            query += f" {search_filter}"
        
        query += f" | timechart {stats}({field}) span={span}"
        
        result = self.search(query, time_range)
        
        if result['success']:
            return {
                'success': True,
                'field': field,
                'stat': stats,
                'span': span,
                'results': result['results'],
                'count': result['count'],
                'index': index,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return {
            'success': False,
            'field': field,
            'stat': stats,
            'span': span,
            'results': [],
            'error': result.get('error', 'Failed to create timechart'),
            'index': index
        }
    
    
    # ========================================================================
    # MONITORING & ALERTING
    # ========================================================================
    
    def find_errors(self, index: str = 'main',
                   time_range: TimeRange = TimeRange.LAST_HOUR) -> Dict[str, Any]:
        """
        Find error events
        
        Args:
            index: Splunk index name
            time_range: Time range for search
        
        Returns:
            Dictionary with error events
        """
        search_filter = 'error OR ERROR or fail OR FAIL or exception'
        return self.get_top_values(
            index=index,
            field='error',
            limit=50,
            search_filter=search_filter,
            time_range=time_range
        )
    
    
    def find_exceptions(self, index: str = 'main',
                       time_range: TimeRange = TimeRange.LAST_HOUR) -> Dict[str, Any]:
        """
        Find exception events
        
        Args:
            index: Splunk index name
            time_range: Time range for search
        
        Returns:
            Dictionary with exception events
        """
        search_filter = 'exception OR Exception OR ERROR'
        return self.get_top_values(
            index=index,
            field='_raw',
            limit=50,
            search_filter=search_filter,
            time_range=time_range
        )
    
    
    def check_host_health(self, host: str,
                         time_range: TimeRange = TimeRange.LAST_HOUR) -> Dict[str, Any]:
        """
        Check health of a specific host
        
        Args:
            host: Host name
            time_range: Time range for search
        
        Returns:
            Dictionary with host health metrics
        """
        try:
            # Count events
            count_query = f"search host={host} | stats count"
            count_result = self.search(count_query, time_range)
            
            # Find errors
            errors_query = f"search host={host} (error OR ERROR) | stats count"
            errors_result = self.search(errors_query, time_range)
            
            count = int(count_result['results'][0].get('count', 0)) if count_result['success'] else 0
            errors = int(errors_result['results'][0].get('count', 0)) if errors_result['success'] else 0
            
            # Calculate health score
            health_score = 100 if count == 0 else max(0, 100 - (errors / count * 100))
            
            return {
                'success': True,
                'host': host,
                'total_events': count,
                'error_events': errors,
                'health_score': health_score,
                'status': 'healthy' if health_score > 80 else ('warning' if health_score > 50 else 'critical'),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Host health check error: {e}")
            return {
                'success': False,
                'host': host,
                'error': str(e)
            }
    
    
    # ========================================================================
    # INDEX MANAGEMENT
    # ========================================================================
    
    def get_index_list(self) -> Dict[str, Any]:
        """
        Get list of all indexes
        
        Returns:
            Dictionary with index list
        """
        try:
            query = "search * | stats count by index"
            result = self.search(query, TimeRange.LAST_30_DAYS)
            
            if result['success']:
                return {
                    'success': True,
                    'indexes': result['results'],
                    'count': result['count'],
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            return {
                'success': False,
                'indexes': [],
                'error': result.get('error', 'Failed to get index list')
            }
        
        except Exception as e:
            logger.error(f"Get index list error: {e}")
            return {
                'success': False,
                'indexes': [],
                'error': str(e)
            }
    
    
    def get_index_stats(self, index: str = None) -> Dict[str, Any]:
        """
        Get statistics for indexes
        
        Args:
            index: Optional specific index
        
        Returns:
            Dictionary with index statistics
        """
        try:
            if index:
                query = f"search index={index} | stats count, min(_time), max(_time)"
            else:
                query = "search * | stats count, min(_time), max(_time) by index"
            
            result = self.search(query, TimeRange.LAST_30_DAYS)
            
            if result['success']:
                return {
                    'success': True,
                    'stats': result['results'],
                    'count': result['count'],
                    'index': index,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            return {
                'success': False,
                'stats': [],
                'error': result.get('error', 'Failed to get index stats'),
                'index': index
            }
        
        except Exception as e:
            logger.error(f"Get index stats error: {e}")
            return {
                'success': False,
                'stats': [],
                'error': str(e),
                'index': index
            }
    
    
    # ========================================================================
    # DASHBOARD DATA
    # ========================================================================
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """
        Get comprehensive dashboard data
        
        Returns:
            Dictionary with all dashboard metrics
        """
        try:
            # Get summary metrics
            all_events = self.get_count('*')
            main_events = self.get_count('main')
            recent_errors = self.find_errors()
            index_stats = self.get_index_stats()
            
            return {
                'success': True,
                'total_events': all_events['count'] if all_events['success'] else 0,
                'main_index_events': main_events['count'] if main_events['success'] else 0,
                'recent_errors': recent_errors['count'] if recent_errors['success'] else 0,
                'indexes': len(index_stats['stats']) if index_stats['success'] else 0,
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Get dashboard data error: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    
    # ========================================================================
    # HEALTH & STATUS
    # ========================================================================
    
    def health_check(self) -> Dict[str, Any]:
        """
        Check Splunk service health
        
        Returns:
            Dictionary with health status
        """
        if not self.connector:
            return {
                'status': 'unavailable',
                'message': 'Splunk connector not initialized',
                'timestamp': datetime.utcnow().isoformat()
            }
        
        return self.connector.health_check()
    
    
    def get_service_status(self) -> Dict[str, Any]:
        """
        Get complete service status
        
        Returns:
            Dictionary with service status
        """
        health = self.health_check()
        
        status_info = {
            'health': health,
            'available': health['status'] == 'healthy',
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if self.connector and health['status'] == 'healthy':
            status_info['connector_info'] = self.connector.get_status()
        
        return status_info


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def get_splunk_service(config=None) -> Optional[SplunkService]:
    """
    Get Splunk service instance
    
    Args:
        config: Flask configuration object
    
    Returns:
        SplunkService instance or None
    """
    try:
        return SplunkService(config)
    except Exception as e:
        logger.error(f"Failed to create Splunk service: {e}")
        return None