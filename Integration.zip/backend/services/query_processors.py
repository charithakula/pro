"""
Query Processors - FIXED VERSION
Handles different processing paths: Direct LLM, SQL First, and Hybrid
FIXED: Corrected deployment parameter handling
Updated: November 2025
"""

import logging
import json
import pandas as pd
from typing import Dict, Any, Optional
from datetime import datetime
from openai import AzureOpenAI

logger = logging.getLogger(__name__)


class QueryProcessorError(Exception):
    """Custom exception for query processor errors"""
    pass


class DirectLLMProcessor:
    """
    Process queries by sending data directly to LLM
    Best for: Small datasets, specific lookups, analysis requiring full context
    """
    
    def __init__(self, db_connection, openai_client: AzureOpenAI, 
                 vector_search_service, config=None, deployment=None):
        self.db = db_connection
        self.client = openai_client
        self.vector_search = vector_search_service
        self.config = config
        # ✅ FIXED: Accept deployment parameter
        self.deployment = deployment or (
            config.get('AZURE_OPENAI_DEPLOYMENT') if config else None
        ) or 'gpt-4'
    
    def process(self, user_question: str, routing_decision: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process question using direct LLM approach
        
        Args:
            user_question: User's question
            routing_decision: Routing decision from QueryRouter
            
        Returns:
            Dictionary with answer and metadata
        """
        try:
            logger.info("🔄 Processing with DIRECT_LLM path...")
            
            # Step 1: Vector search for relevant data
            search_results = self.vector_search.search_similar(
                query_text=user_question,
                limit=min(50, routing_decision.get('estimated_rows', 20))
            )
            
            if not search_results:
                return {
                    'answer': "No relevant data found in the database. Please ensure data has been uploaded.",
                    'method': 'direct_llm',
                    'rows_processed': 0,
                    'data_preview': []
                }
            
            # Step 2: Format data for LLM
            data_json = json.dumps(search_results, indent=2, default=str)
            
            # Step 3: Create prompt
            prompt = f"""You are a data analyst assistant. Answer the user's question based on the provided database data.

USER QUESTION: {user_question}

DATABASE DATA (JSON format):
{data_json}

INSTRUCTIONS:
1. Analyze the data thoroughly
2. Provide a clear, accurate answer based on the actual data
3. Include specific values, counts, and examples when relevant
4. Format your response with bullet points for multiple items
5. If the question asks for counts or aggregations, calculate them from the data
6. Be concise but informative

ANSWER:
"""
            
            # Step 4: Get LLM response using correct deployment
            # ✅ FIXED: Use self.deployment instead of config access
            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a helpful data analyst assistant providing clear, accurate answers."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            answer = response.choices[0].message.content
            
            logger.info("✅ Direct LLM processing complete")
            
            return {
                'answer': answer,
                'method': 'direct_llm',
                'rows_processed': len(search_results),
                'data_preview': search_results[:5],
                'reasoning': routing_decision.get('reason'),
                'timestamp': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Direct LLM Processing Error: {e}")
            raise QueryProcessorError(f"Direct LLM processing failed: {str(e)}")


class SQLFirstProcessor:
    """
    Process queries by generating SQL first, then formatting results with LLM
    Best for: Aggregations, large datasets, complex filtering
    """
    
    def __init__(self, db_connection, openai_client: AzureOpenAI, 
                 sql_generator, vector_search_service, config=None, deployment=None):
        self.db = db_connection
        self.client = openai_client
        self.sql_generator = sql_generator
        self.vector_search = vector_search_service
        self.config = config
        # ✅ FIXED: Accept deployment parameter
        self.deployment = deployment or (
            config.get('AZURE_OPENAI_DEPLOYMENT') if config else None
        ) or 'gpt-4'
    
    def process(self, user_question: str, routing_decision: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process question using SQL-first approach
        
        Args:
            user_question: User's question
            routing_decision: Routing decision from QueryRouter
            
        Returns:
            Dictionary with answer and metadata
        """
        try:
            logger.info("🔄 Processing with SQL_FIRST path...")
            
            # Step 1: Get context from vector search
            context_data = self.vector_search.search_similar(
                query_text=user_question,
                limit=5
            )
            
            # Step 2: Generate SQL query
            sql_query = self.sql_generator.generate_sql(user_question, context_data)
            
            logger.info(f"📝 Generated SQL:\n{sql_query}")
            
            # Step 3: Execute SQL query
            try:
                result = self.db.execute(sql_query)
                rows = result.fetchall()
                
                # Convert to list of dicts
                results = [dict(row._mapping) for row in rows]
                
            except Exception as sql_error:
                logger.warning(f"⚠️ SQL execution failed: {sql_error}")
                # Try to fix the query
                logger.info("🔧 Attempting to fix SQL query...")
                sql_query = self.sql_generator.fix_sql_query(sql_query, str(sql_error))
                
                result = self.db.execute(sql_query)
                rows = result.fetchall()
                results = [dict(row._mapping) for row in rows]
            
            if not results:
                return {
                    'answer': "No data found matching your criteria.",
                    'method': 'sql_first',
                    'sql_query': sql_query,
                    'rows_processed': 0,
                    'data_preview': []
                }
            
            # Step 4: Format results with LLM
            results_json = json.dumps(results, indent=2, default=str)
            
            prompt = f"""User Question: {user_question}

SQL Query Executed:
{sql_query}

Query Results (JSON):
{results_json}

Provide a natural language answer that:
1. Directly answers the user's question
2. Highlights key insights from the data
3. Formats numbers with proper separators
4. Uses bullet points for lists
5. Keeps it concise but informative

ANSWER:
"""
            
            # ✅ FIXED: Use self.deployment instead of config access
            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a data analyst assistant formatting query results into clear answers."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=800
            )
            
            answer = response.choices[0].message.content
            
            logger.info("✅ SQL-first processing complete")
            
            return {
                'answer': answer,
                'method': 'sql_first',
                'sql_query': sql_query,
                'rows_processed': len(results),
                'data_preview': results[:10],
                'reasoning': routing_decision.get('reason'),
                'timestamp': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ SQL-First Processing Error: {e}")
            raise QueryProcessorError(f"SQL-first processing failed: {str(e)}")


class HybridProcessor:
    """
    Process queries using hybrid approach: SQL aggregates + data sampling
    Best for: Large dataset analysis, pattern detection, comparisons
    """
    
    def __init__(self, db_connection, openai_client: AzureOpenAI, 
                 sql_generator, vector_search_service, config=None, deployment=None):
        self.db = db_connection
        self.client = openai_client
        self.sql_generator = sql_generator
        self.vector_search = vector_search_service
        self.config = config
        # ✅ FIXED: Accept deployment parameter
        self.deployment = deployment or (
            config.get('AZURE_OPENAI_DEPLOYMENT') if config else None
        ) or 'gpt-4'
    
    def process(self, user_question: str, routing_decision: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process question using hybrid approach
        
        Args:
            user_question: User's question
            routing_decision: Routing decision from QueryRouter
            
        Returns:
            Dictionary with answer and metadata
        """
        try:
            logger.info("🔄 Processing with HYBRID path...")
            
            # Step 1: Get aggregate statistics
            aggregate_query = self.sql_generator.generate_aggregate_query(user_question)
            
            logger.info(f"📊 Aggregate Query:\n{aggregate_query}")
            
            result = self.db.execute(aggregate_query)
            rows = result.fetchall()
            aggregates = [dict(row._mapping) for row in rows]
            
            # Step 2: Get representative sample
            sample_size = routing_decision.get('sample_size', 30)
            
            sample_query = f"""
            SELECT * FROM integration_interfaces
            ORDER BY RANDOM()
            LIMIT {sample_size}
            """
            
            result = self.db.execute(sample_query)
            rows = result.fetchall()
            sample_data = [dict(row._mapping) for row in rows]
            
            # Step 3: Combine for LLM analysis
            aggregates_json = json.dumps(aggregates, indent=2, default=str)
            sample_json = json.dumps(sample_data, indent=2, default=str)
            
            prompt = f"""USER QUESTION: {user_question}

AGGREGATE STATISTICS:
{aggregates_json}

REPRESENTATIVE SAMPLE ({sample_size} random records):
{sample_json}

Based on the aggregates and sample data, provide insights to answer the user's question.

Include:
1. Overall patterns and trends
2. Key statistics and distributions
3. Notable observations
4. Recommendations if applicable

ANSWER:
"""
            
            # ✅ FIXED: Use self.deployment instead of config access
            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a data analyst providing insights from aggregate data and samples."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=1200
            )
            
            answer = response.choices[0].message.content
            
            logger.info("✅ Hybrid processing complete")
            
            return {
                'answer': answer,
                'method': 'hybrid',
                'sql_query': aggregate_query,
                'rows_processed': len(aggregates) + len(sample_data),
                'aggregate_data': aggregates,
                'sample_data': sample_data[:5],
                'reasoning': routing_decision.get('reason'),
                'timestamp': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"❌ Hybrid Processing Error: {e}")
            raise QueryProcessorError(f"Hybrid processing failed: {str(e)}")