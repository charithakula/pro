"""
Database Setup Script
Creates tables for hybrid RAG system with pgvector support (optional)
Run this script once to initialize your database
"""

import logging
from sqlalchemy import create_engine, text, event
from sqlalchemy.pool import NullPool
import os
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_database_url():
    """Build database URL from environment variables"""
    db_user = os.getenv('DB_USER', 'dashboard_user')
    db_password = os.getenv('DB_PASSWORD', 'password')
    db_host = os.getenv('DB_HOST', 'localhost')
    db_port = os.getenv('DB_PORT', '5432')
    db_name = os.getenv('DB_NAME', 'dashboard_360')
    
    return f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"


def setup_database():
    """Setup database with all required tables and extensions"""
    
    try:
        # Connect to database with autocommit to avoid transaction issues
        database_url = get_database_url()
        engine = create_engine(database_url, poolclass=NullPool)
        
        pgvector_available = False
        
        # Check pgvector availability in a separate connection
        logger.info("🔄 Setting up database...")
        logger.info("📦 Checking pgvector extension availability...")
        
        with engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            try:
                conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
                logger.info("✅ pgvector extension enabled")
                pgvector_available = True
            except Exception as e:
                logger.warning(f"⚠️  pgvector extension not available")
                logger.warning("⚠️  Continuing without pgvector. Vector search will not be available.")
                pgvector_available = False
        
        # Start fresh connection for table creation
        with engine.connect() as conn:
            conn = conn.execution_options(isolation_level="AUTOCOMMIT")
            
            # Step 1: Create integration_interfaces table
            logger.info("📋 Creating integration_interfaces table...")
            create_interfaces_table = """
            CREATE TABLE IF NOT EXISTS integration_interfaces (
                id SERIAL PRIMARY KEY,
                interface_platform TEXT,
                interface_id TEXT,
                sub_interface TEXT,
                interface_name TEXT,
                operation_name TEXT,
                api_product_name TEXT,
                interface_description TEXT,
                dependency_id TEXT,
                process_area TEXT,
                interface_pattern TEXT,
                source_ci_type TEXT,
                source_name TEXT,
                target_ci_type TEXT,
                target_name TEXT,
                communication_mode TEXT,
                volume TEXT,
                frequency TEXT,
                schedule TEXT,
                interface_resolver_group TEXT,
                qos TEXT,
                source_service_url TEXT,
                target_service_url TEXT,
                source_protocol TEXT,
                source_data_format TEXT,
                source_trust_level TEXT,
                target_protocol TEXT,
                target_data_format TEXT,
                target_trust_level TEXT,
                retention_period TEXT,
                source_resolver_contact TEXT,
                target_resolver_contact TEXT,
                priority TEXT,
                status TEXT,
                source_intermediary TEXT,
                target_intermediary TEXT,
                project_name TEXT,
                production_migration_date DATE,
                pid_wo TEXT,
                reuse_status TEXT,
                integration_pattern TEXT,
                interface_mode TEXT,
                ou TEXT,
                comments TEXT,
                interface_build_type TEXT,
                created_at TIMESTAMP DEFAULT NOW()
            )
            """
            conn.execute(text(create_interfaces_table))
            logger.info("✅ integration_interfaces table created")
            
            # Step 2: Create indexes for common queries
            logger.info("🔍 Creating indexes...")
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_interface_platform ON integration_interfaces(interface_platform)",
                "CREATE INDEX IF NOT EXISTS idx_process_area ON integration_interfaces(process_area)",
                "CREATE INDEX IF NOT EXISTS idx_status ON integration_interfaces(status)",
                "CREATE INDEX IF NOT EXISTS idx_priority ON integration_interfaces(priority)",
                "CREATE INDEX IF NOT EXISTS idx_interface_id ON integration_interfaces(interface_id)"
            ]
            
            for index_sql in indexes:
                conn.execute(text(index_sql))
            logger.info("✅ Indexes created")
            
            # Step 3: Create interface_embeddings table (with or without vector type)
            logger.info("🧠 Creating interface_embeddings table...")
            if pgvector_available:
                create_embeddings_table = """
                CREATE TABLE IF NOT EXISTS interface_embeddings (
                    id SERIAL PRIMARY KEY,
                    interface_id INTEGER REFERENCES integration_interfaces(id) ON DELETE CASCADE,
                    content_type TEXT,
                    content TEXT,
                    embedding vector(1536),
                    created_at TIMESTAMP DEFAULT NOW()
                )
                """
            else:
                # Fallback: store embeddings as text (JSON array)
                create_embeddings_table = """
                CREATE TABLE IF NOT EXISTS interface_embeddings (
                    id SERIAL PRIMARY KEY,
                    interface_id INTEGER REFERENCES integration_interfaces(id) ON DELETE CASCADE,
                    content_type TEXT,
                    content TEXT,
                    embedding TEXT,
                    created_at TIMESTAMP DEFAULT NOW()
                )
                """
            
            conn.execute(text(create_embeddings_table))
            logger.info("✅ interface_embeddings table created")
            
            # Step 4: Create vector index for similarity search (only if pgvector available)
            if pgvector_available:
                logger.info("🔎 Creating vector index...")
                try:
                    create_vector_index = """
                    CREATE INDEX IF NOT EXISTS idx_embedding_vector 
                    ON interface_embeddings 
                    USING ivfflat (embedding vector_cosine_ops)
                    WITH (lists = 100)
                    """
                    conn.execute(text(create_vector_index))
                    logger.info("✅ Vector index created")
                except Exception as e:
                    logger.warning(f"⚠️  Could not create vector index: {str(e)[:100]}")
            else:
                # Create basic index for embeddings table
                logger.info("🔎 Creating standard index on embeddings...")
                try:
                    conn.execute(text("CREATE INDEX IF NOT EXISTS idx_embedding_interface_id ON interface_embeddings(interface_id)"))
                    logger.info("✅ Standard index created")
                except Exception as e:
                    logger.warning(f"⚠️  Could not create index: {str(e)[:100]}")
            
            logger.info("\n" + "="*60)
            logger.info("🎉 DATABASE SETUP COMPLETE!")
            logger.info("="*60)
            logger.info("\nTables created:")
            logger.info("  1. integration_interfaces (main data table)")
            logger.info("  2. interface_embeddings (embeddings storage)")
            logger.info("\nExtensions enabled:")
            if pgvector_available:
                logger.info("  ✅ pgvector")
            else:
                logger.info("  ⚠️  pgvector (NOT AVAILABLE - using TEXT storage for embeddings)")
            logger.info("\nIndexes created:")
            logger.info("  - Standard B-tree indexes on key columns")
            if pgvector_available:
                logger.info("  - IVFFlat vector index for similarity search")
            else:
                logger.info("  - Standard index on embeddings table")
            logger.info("\nNOTE: Install pgvector for vector similarity search:")
            logger.info("  Windows: Download from https://github.com/pgvector/pgvector/releases")
            logger.info("  Linux: sudo apt-get install postgresql-17-pgvector")
            logger.info("  macOS: brew install pgvector")
            logger.info("="*60 + "\n")
            
    except Exception as e:
        logger.error(f"❌ Database setup failed: {e}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == "__main__":
    setup_database()