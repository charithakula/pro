"""
AI Interaction and Storage Models - 360° Enterprise Dashboard
Handles AI service interactions and file storage tracking
"""

from datetime import datetime
import logging

logger = logging.getLogger(__name__)


def create_ai_interaction_model(db):
    """Factory function to create AIInteraction model"""
    
    class AIInteraction(db.Model):
        """Azure OpenAI interaction logging"""
        __tablename__ = 'ai_interactions'
        
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
        interaction_type = db.Column(db.String(50), nullable=False)
        input_text = db.Column(db.Text, nullable=False)
        output_text = db.Column(db.Text, nullable=True)
        tokens_used = db.Column(db.Integer, default=0)
        status = db.Column(db.String(20), default='success')
        error_message = db.Column(db.Text, nullable=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        
        def to_dict(self):
            """Convert to dictionary"""
            try:
                return {
                    'id': self.id,
                    'interaction_type': self.interaction_type,
                    'input_text': self.input_text[:200],  # Truncate for display
                    'output_text': self.output_text[:200] if self.output_text else None,
                    'tokens_used': self.tokens_used,
                    'status': self.status,
                    'error_message': self.error_message,
                    'created_at': self.created_at.isoformat() if self.created_at else None
                }
            except Exception as e:
                logger.error(f"✗ Error converting AIInteraction to dict: {e}")
                return {}
        
        def __repr__(self):
            return f"<AIInteraction {self.interaction_type}>"
    
    return AIInteraction


def create_storage_file_model(db):
    """Factory function to create StorageFile model"""
    
    class StorageFile(db.Model):
        """Azure Blob Storage file tracking"""
        __tablename__ = 'storage_files'
        
        id = db.Column(db.Integer, primary_key=True)
        user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
        filename = db.Column(db.String(255), nullable=False)
        blob_name = db.Column(db.String(255), nullable=False)
        blob_url = db.Column(db.String(500), nullable=False)
        file_size = db.Column(db.Integer, nullable=False)
        file_type = db.Column(db.String(50), nullable=False)
        status = db.Column(db.String(20), default='uploaded')
        error_message = db.Column(db.Text, nullable=True)
        created_at = db.Column(db.DateTime, default=datetime.utcnow)
        
        def to_dict(self):
            """Convert to dictionary"""
            try:
                return {
                    'id': self.id,
                    'filename': self.filename,
                    'blob_name': self.blob_name,
                    'blob_url': self.blob_url,
                    'file_size': self.file_size,
                    'file_size_mb': round(self.file_size / (1024 * 1024), 2),
                    'file_type': self.file_type,
                    'status': self.status,
                    'error_message': self.error_message,
                    'created_at': self.created_at.isoformat() if self.created_at else None
                }
            except Exception as e:
                logger.error(f"✗ Error converting StorageFile to dict: {e}")
                return {}
        
        def __repr__(self):
            return f"<StorageFile {self.filename}>"
    
    return StorageFile