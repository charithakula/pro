"""
Database Queries Module
Contains all SQL query builders and query definitions
Separates business logic from query construction
"""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class DatabaseQueries:
    """
    Static class containing all database query builders
    Centralized query management for maintainability
    """
    
    # ========================================================================
    # AGGREGATION QUERIES
    # ========================================================================
    
    @staticmethod
    def build_aggregation_query(table: str, group_by_field: str,
                               count_field: str = None,
                               where_clause: str = None,
                               order_by: str = 'count_desc',
                               limit: int = None) -> str:
        """
        Build GROUP BY aggregation query
        
        Args:
            table: Table name
            group_by_field: Field to group by
            count_field: Field to count (optional, defaults to *)
            where_clause: WHERE condition (optional)
            order_by: Sort order ('count_asc', 'count_desc', 'field_asc', 'field_desc')
            limit: Limit results (optional)
        
        Returns:
            SQL query string
        """
        count_expr = f"COUNT({count_field})" if count_field else "COUNT(*)"
        query = f"""
            SELECT 
                {group_by_field},
                {count_expr} as item_count
            FROM {table}
        """
        
        if where_clause:
            query += f" WHERE {where_clause}"
        
        query += f" GROUP BY {group_by_field}"
        
        # Apply ordering
        if order_by == 'count_asc':
            query += " ORDER BY item_count ASC"
        elif order_by == 'count_desc':
            query += " ORDER BY item_count DESC"
        elif order_by == 'field_asc':
            query += f" ORDER BY {group_by_field} ASC"
        elif order_by == 'field_desc':
            query += f" ORDER BY {group_by_field} DESC"
        else:
            query += " ORDER BY item_count DESC"
        
        if limit:
            query += f" LIMIT {limit}"
        
        return query.strip()
    
    
    # ========================================================================
    # STATISTICS QUERIES
    # ========================================================================
    
    @staticmethod
    def build_stats_query(table: str, stat_fields: dict, where_clause: str = None) -> str:
        """
        Build statistics query (avg, sum, count, min, max, distinct, etc.)
        
        Args:
            table: Table name
            stat_fields: Dict of {field_name: stat_type}
                        Examples: {'response_time': 'avg', 'user_id': 'distinct'}
            where_clause: WHERE condition (optional)
        
        Returns:
            SQL query string
        """
        select_parts = []
        for field, stat_type in stat_fields.items():
            if stat_type.lower() == 'distinct':
                select_parts.append(f"COUNT(DISTINCT {field}) as {field}_{stat_type}")
            else:
                select_parts.append(f"{stat_type.upper()}({field}) as {field}_{stat_type}")
        
        query = f"SELECT {', '.join(select_parts)} FROM {table}"
        
        if where_clause:
            query += f" WHERE {where_clause}"
        
        return query.strip()
    
    
    # ========================================================================
    # RECORD QUERIES
    # ========================================================================
    
    @staticmethod
    def build_select_query(table: str, filters: dict = None,
                          order_by: str = None, limit: int = 100,
                          offset: int = 0) -> str:
        """
        Build SELECT query with optional filtering and pagination
        
        Args:
            table: Table name
            filters: Dict of {column: value} for WHERE clause
            order_by: ORDER BY clause
            limit: Max results
            offset: Offset for pagination
        
        Returns:
            SQL query string
        """
        query = f"SELECT * FROM {table}"
        
        if filters:
            where_parts = []
            for key, value in filters.items():
                if isinstance(value, str):
                    # Escape single quotes in strings
                    escaped_value = value.replace("'", "''")
                    where_parts.append(f"{key} = '{escaped_value}'")
                elif value is None:
                    where_parts.append(f"{key} IS NULL")
                else:
                    where_parts.append(f"{key} = {value}")
            
            if where_parts:
                query += " WHERE " + " AND ".join(where_parts)
        
        if order_by:
            query += f" ORDER BY {order_by}"
        
        query += f" LIMIT {limit} OFFSET {offset}"
        
        return query.strip()
    
    
    # ========================================================================
    # SPECIALIZED QUERIES FOR DASHBOARD
    # ========================================================================
    
    @staticmethod
    def integration_patterns() -> str:
        """Get integration patterns with counts"""
        return DatabaseQueries.build_aggregation_query(
            table='integration_interfaces',
            group_by_field='interface_pattern',
            order_by='count_desc'
        )
    
    
    @staticmethod
    def integration_patterns_by_category(category: str = None) -> str:
        """Get integration patterns grouped by category"""
        where_clause = f"interface_category = '{category}'" if category else None
        return DatabaseQueries.build_aggregation_query(
            table='integration_interfaces',
            group_by_field='interface_pattern',
            where_clause=where_clause,
            order_by='count_desc'
        )
    
    
    @staticmethod
    def integration_interfaces_by_type() -> str:
        """Get interfaces grouped by type"""
        return DatabaseQueries.build_aggregation_query(
            table='integration_interfaces',
            group_by_field='interface_type',
            order_by='count_desc'
        )
    
    
    @staticmethod
    def integration_interfaces_by_category() -> str:
        """Get interfaces grouped by category"""
        return DatabaseQueries.build_aggregation_query(
            table='integration_interfaces',
            group_by_field='interface_category',
            order_by='count_desc'
        )
    
    
    @staticmethod
    def api_metrics_stats() -> str:
        """Get API metrics statistics"""
        return DatabaseQueries.build_stats_query(
            table='api_metrics',
            stat_fields={
                'response_time': 'avg',
                'error_rate': 'avg',
                'request_count': 'sum',
                'user_id': 'distinct'
            }
        )
    
    
    @staticmethod
    def ou_distribution() -> str:
        """Get organizational unit distribution"""
        return DatabaseQueries.build_aggregation_query(
            table='organizational_units',
            group_by_field='ou_name',
            order_by='count_desc'
        )
    
    
    # ========================================================================
    # SIMPLE UTILITY QUERIES
    # ========================================================================
    
    @staticmethod
    def health_check() -> str:
        """Simple query to test database connectivity"""
        return "SELECT 1 as health"
    
    
    @staticmethod
    def get_table_count(table: str) -> str:
        """Get count of rows in a table"""
        return f"SELECT COUNT(*) as total FROM {table}"
    
    
    @staticmethod
    def get_columns(table: str) -> str:
        """Get column information for a table (PostgreSQL)"""
        return f"""
            SELECT column_name, data_type, is_nullable
            FROM information_schema.columns
            WHERE table_name = '{table}'
            ORDER BY ordinal_position
        """
    
    
    @staticmethod
    def get_tables() -> str:
        """Get list of all tables (PostgreSQL)"""
        return """
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name
        """
    
    
    # ========================================================================
    # ADVANCED QUERIES
    # ========================================================================
    
    @staticmethod
    def timeseries_query(table: str, time_field: str, value_field: str,
                        group_by_interval: str = '1 hour',
                        where_clause: str = None) -> str:
        """
        Build time-series query with aggregation
        
        Args:
            table: Table name
            time_field: Timestamp field name
            value_field: Value field to aggregate
            group_by_interval: Time interval (PostgreSQL format: '1 hour', '1 day', etc.)
            where_clause: WHERE condition
        
        Returns:
            SQL query string
        """
        query = f"""
            SELECT
                DATE_TRUNC('{group_by_interval}', {time_field}) as time_bucket,
                COUNT(*) as count,
                AVG(CAST({value_field} AS FLOAT)) as avg_value,
                MIN(CAST({value_field} AS FLOAT)) as min_value,
                MAX(CAST({value_field} AS FLOAT)) as max_value
            FROM {table}
        """
        
        if where_clause:
            query += f" WHERE {where_clause}"
        
        query += f"""
            GROUP BY DATE_TRUNC('{group_by_interval}', {time_field})
            ORDER BY time_bucket DESC
        """
        
        return query.strip()
    
    
    @staticmethod
    def full_text_search(table: str, search_field: str, search_term: str) -> str:
        """
        Build full-text search query
        
        Args:
            table: Table name
            search_field: Field to search in
            search_term: Search term
        
        Returns:
            SQL query string
        """
        escaped_term = search_term.replace("'", "''")
        return f"""
            SELECT * FROM {table}
            WHERE {search_field} ILIKE '%{escaped_term}%'
            ORDER BY similarity({search_field}, '{escaped_term}') DESC
        """
    
    
    @staticmethod
    def pivot_query(table: str, row_field: str, col_field: str,
                   value_field: str, agg_function: str = 'COUNT') -> str:
        """
        Build pivot/crosstab query (PostgreSQL)
        
        Args:
            table: Table name
            row_field: Field for rows
            col_field: Field for columns
            value_field: Field to aggregate
            agg_function: Aggregation function (COUNT, SUM, AVG, etc.)
        
        Returns:
            SQL query string
        """
        return f"""
            SELECT * FROM crosstab(
                'SELECT {row_field}, {col_field}, {agg_function}({value_field}) 
                FROM {table} 
                GROUP BY {row_field}, {col_field}
                ORDER BY {row_field}'
            ) AS ct({row_field} TEXT, val INT)
        """
    
    
    # ========================================================================
    # QUERY VALIDATION & SAFETY
    # ========================================================================
    
    @staticmethod
    def validate_query(query: str) -> tuple[bool, str]:
        """
        Validate query safety
        
        Args:
            query: SQL query to validate
        
        Returns:
            Tuple of (is_safe: bool, message: str)
        """
        dangerous_keywords = ['drop', 'delete', 'truncate', 'alter', 'update', 'insert', 'exec', 'execute']
        
        query_lower = query.lower()
        
        for keyword in dangerous_keywords:
            if keyword in query_lower:
                return False, f"Query contains dangerous keyword: {keyword}"
        
        if query.strip().startswith(';'):
            return False, "Query cannot start with semicolon (command injection)"
        
        return True, "Query is safe"
    
    
    @staticmethod
    def sanitize_identifier(identifier: str) -> str:
        """
        Sanitize table/column names (PostgreSQL)
        
        Args:
            identifier: Table or column name
        
        Returns:
            Sanitized identifier
        """
        # Remove any potentially dangerous characters
        safe_chars = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_')
        sanitized = ''.join(c for c in identifier if c in safe_chars)
        
        # Avoid SQL keywords by using double quotes if needed
        if sanitized.lower() in ['select', 'from', 'where', 'order', 'group', 'having', 'limit']:
            sanitized = f'"{sanitized}"'
        
        return sanitized


# Convenience functions for common queries
def get_integration_patterns_query() -> str:
    """Get integration patterns query"""
    return DatabaseQueries.integration_patterns()


def get_stats_query(table: str, stat_fields: dict) -> str:
    """Build stats query"""
    return DatabaseQueries.build_stats_query(table, stat_fields)


def get_aggregation_query(table: str, group_by: str, **kwargs) -> str:
    """Build aggregation query"""
    return DatabaseQueries.build_aggregation_query(table, group_by, **kwargs)


def get_select_query(table: str, **kwargs) -> str:
    """Build select query"""
    return DatabaseQueries.build_select_query(table, **kwargs)