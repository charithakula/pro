"""
Database Seed Script
Creates initial test users for the application
"""

from app import app
from auth_models import db, User

def seed_database():
    """Seed database with test users"""
    
    with app.app_context():
        # Create tables
        db.create_all()
        print("✅ Database tables created")
        
        # Check if users already exist
        if User.query.count() > 0:
            print("⚠️  Database already contains users. Skipping seed.")
            return
        
        # Create test users
        users = [
            {
                'email': 'admin@360dashboard.com',
                'password': 'admin123',
                'first_name': 'Admin',
                'last_name': 'User',
                'full_name': 'Admin User',
                'role': 'admin',
                'is_active': True,
                'is_verified': True
            },
            {
                'email': 'user@company.com',
                'password': 'user123',
                'first_name': 'John',
                'last_name': 'Doe',
                'full_name': 'John Doe',
                'role': 'user',
                'is_active': True,
                'is_verified': True
            },
            {
                'email': 'demo@360dashboard.com',
                'password': 'demo123',
                'first_name': 'Demo',
                'last_name': 'Account',
                'full_name': 'Demo Account',
                'role': 'user',
                'is_active': True,
                'is_verified': True
            },
            {
                'email': 'test@example.com',
                'password': 'test123',
                'first_name': 'Test',
                'last_name': 'User',
                'full_name': 'Test User',
                'role': 'user',
                'is_active': True,
                'is_verified': True
            }
        ]
        
        # Create users
        for user_data in users:
            user = User(
                email=user_data['email'],
                first_name=user_data['first_name'],
                last_name=user_data['last_name'],
                full_name=user_data['full_name'],
                role=user_data['role'],
                is_active=user_data['is_active'],
                is_verified=user_data['is_verified']
            )
            user.set_password(user_data['password'])
            db.session.add(user)
            print(f"✅ Created user: {user_data['email']} (password: {user_data['password']})")
        
        # Commit to database
        db.session.commit()
        print("\n🎉 Database seeded successfully!")
        print("\n📝 Test Users Created:")
        print("=" * 60)
        for user_data in users:
            print(f"Email: {user_data['email']:<30} Password: {user_data['password']}")
        print("=" * 60)


if __name__ == '__main__':
    seed_database()