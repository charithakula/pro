"""
Authentication Models - SIMPLIFIED & FIXED
Matches igpt.users table schema exactly

Table columns:
  - id
  - email
  - password
  - name
  - created_at
  - last_login
  - is_active

Schema: Works with both PostgreSQL and SQLite
"""

from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class User(db.Model):
    """User Model for Authentication - Simplified & Fixed"""

    __tablename__ = 'users'

    # ✅ SCHEMA HANDLING via db_connector.py
    # Empty table_args allows SQLAlchemy to use the search_path from connection
    # - PostgreSQL: db_connector.py sets search_path=igpt via connection options
    # - SQLite Fallback: No schema prefix needed (SQLite doesn't support schemas)
    # This works seamlessly with both databases!
    __table_args__ = {}
    
    # ==================== COLUMNS ====================
    # Columns matching igpt.users table exactly
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    """User ID - Primary Key"""
    
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    """User email - Unique & Indexed for fast lookups"""
    
    password = db.Column(db.String(255), nullable=False)
    """Hashed password (never store plaintext)"""
    
    name = db.Column(db.String(120), nullable=False)
    """User's full name"""
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    """Account creation timestamp"""
    
    last_login = db.Column(db.DateTime, nullable=True)
    """Last successful login timestamp"""
    
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    """Account active status (False = suspended/deleted)"""
    
    # ==================== METHODS ====================
    
    def __repr__(self):
        """String representation of User"""
        return f'<User {self.email}>'
    
    def set_password(self, password):
        """
        Hash and set password
        Uses werkzeug.security.generate_password_hash
        
        Args:
            password (str): Plaintext password to hash
            
        Example:
            user = User(email='test@example.com', name='Test User')
            user.set_password('MyPassword123')
            db.session.add(user)
            db.session.commit()
        """
        self.password = generate_password_hash(password)
    
    def check_password(self, password):
        """
        Verify password against hash
        Uses werkzeug.security.check_password_hash
        
        Args:
            password (str): Plaintext password to check
            
        Returns:
            bool: True if password matches, False otherwise
            
        Example:
            if user.check_password('MyPassword123'):
                print('Password is correct!')
        """
        return check_password_hash(self.password, password)
    
    def update_last_login(self):
        """
        Update last login timestamp
        Call this after successful login
        
        Example:
            user = User.query.filter_by(email='test@example.com').first()
            user.update_last_login()
        """
        self.last_login = datetime.utcnow()
        db.session.commit()
    
    def to_dict(self):
        """
        Convert user to dictionary
        Useful for JSON responses
        
        Returns:
            dict: User data without password
            
        Example:
            user_dict = user.to_dict()
            return jsonify(user_dict)
        """
        return {
            'id': self.id,
            'email': self.email,
            'name': self.name,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None
        }
    
    def is_password_valid(self, password):
        """
        Check if password meets strength requirements
        Rules: At least 8 characters
        
        Args:
            password (str): Password to validate
            
        Returns:
            tuple: (bool, str) - (is_valid, message)
            
        Example:
            is_valid, msg = User.is_password_valid('MyPass123')
            if not is_valid:
                print(f'Invalid: {msg}')
        """
        if len(password) < 8:
            return False, "Password must be at least 8 characters long"
        return True, "Password is valid"
    
    @staticmethod
    def is_email_valid(email):
        """
        Validate email format
        
        Args:
            email (str): Email to validate
            
        Returns:
            bool: True if valid format, False otherwise
            
        Example:
            if not User.is_email_valid('test@example.com'):
                return error_response()
        """
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def get_by_email(email):
        """
        Get user by email
        Handles case-insensitive lookup
        
        Args:
            email (str): User email
            
        Returns:
            User: User object or None if not found
            
        Example:
            user = User.get_by_email('test@example.com')
            if user:
                print(f'Found: {user.name}')
        """
        return User.query.filter_by(email=email.lower().strip()).first()
    
    @staticmethod
    def get_by_id(user_id):
        """
        Get user by ID
        
        Args:
            user_id (int): User ID
            
        Returns:
            User: User object or None if not found
            
        Example:
            user = User.get_by_id(1)
            if user:
                print(f'User: {user.email}')
        """
        return User.query.get(user_id)
    
    @staticmethod
    def create_user(email, name, password):
        """
        Create new user with hashed password
        
        Args:
            email (str): User email
            name (str): User name
            password (str): Plaintext password (will be hashed)
            
        Returns:
            tuple: (User, error_message) or (User, None)
            
        Example:
            user, error = User.create_user(
                'test@example.com',
                'Test User',
                'MyPassword123'
            )
            if error:
                print(f'Error: {error}')
            else:
                db.session.add(user)
                db.session.commit()
        """
        # Validate inputs
        if not email or not name or not password:
            return None, "All fields are required"
        
        email = email.lower().strip()
        name = name.strip()
        
        # Validate email
        if not User.is_email_valid(email):
            return None, "Invalid email format"
        
        # Validate password
        is_valid, msg = User.is_password_valid(password)
        if not is_valid:
            return None, msg
        
        # Check if email exists
        if User.get_by_email(email):
            return None, "Email already registered"
        
        # Create user
        user = User(email=email, name=name, is_active=True)
        user.set_password(password)
        
        return user, None
    
    @staticmethod
    def authenticate(email, password):
        """
        Authenticate user with email and password
        
        Args:
            email (str): User email
            password (str): User password
            
        Returns:
            tuple: (User, error_message) or (User, None)
            
        Example:
            user, error = User.authenticate('test@example.com', 'MyPassword123')
            if error:
                print(f'Auth failed: {error}')
            else:
                print(f'Authenticated: {user.email}')
        """
        if not email or not password:
            return None, "Email and password are required"
        
        user = User.get_by_email(email)
        
        if not user:
            return None, "Invalid email or password"
        
        if not user.is_active:
            return None, "Account is inactive"
        
        if not user.check_password(password):
            return None, "Invalid email or password"
        
        return user, None
    
    @staticmethod
    def count_active():
        """
        Get count of active users
        
        Returns:
            int: Number of active users
            
        Example:
            active_count = User.count_active()
            print(f'Active users: {active_count}')
        """
        return User.query.filter_by(is_active=True).count()
    
    @staticmethod
    def count_total():
        """
        Get total count of all users
        
        Returns:
            int: Total number of users
            
        Example:
            total_count = User.count_total()
            print(f'Total users: {total_count}')
        """
        return User.query.count()


# ==================== DATABASE INITIALIZATION ====================

def init_db(app):
    """
    Initialize database and create tables
    
    Call this in your Flask app startup:
    
    Example:
        from auth.auth_models import db, init_db
        
        app = Flask(__name__)
        app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://user:pass@localhost/db'
        
        db.init_app(app)
        
        with app.app_context():
            init_db(app)
    """
    with app.app_context():
        db.create_all()
        print('✅ Database tables created/verified')


# ==================== SCHEMA SETUP ====================

def setup_schema(app):
    """
    Ensure igpt schema exists in PostgreSQL
    
    Call this during app initialization:
    
    Example:
        from auth.auth_models import setup_schema
        
        with app.app_context():
            setup_schema(app)
    """
    from sqlalchemy import text
    
    with app.app_context():
        with db.engine.connect() as conn:
            # Check if schema exists
            result = conn.execute(text(
                "SELECT EXISTS(SELECT 1 FROM information_schema.schemata WHERE schema_name = 'igpt')"
            ))
            schema_exists = result.scalar()
            
            if not schema_exists:
                conn.execute(text("CREATE SCHEMA igpt"))
                conn.commit()
                print('✅ Created igpt schema')
            else:
                print('✅ igpt schema already exists')