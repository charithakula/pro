"""
✅ FIXED: Authentication routes - Session properly set on token validation
WITH DEBUG ENDPOINTS FOR SESSION TROUBLESHOOTING
"""

from flask import Blueprint, request, jsonify, session, make_response, current_app
from functools import wraps
from datetime import datetime, timedelta
import jwt
import os
import logging
from .auth_models import db, User  # ✅ FIXED: Changed from "from auth.auth_models"
from werkzeug.security import check_password_hash
from backend.services.database import get_db_connection

logger = logging.getLogger(__name__)

# Create Blueprint
auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

# Configuration
SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'your-secret-key-change-this-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24
ADMIN_REGISTRATION_TOKEN = os.getenv('ADMIN_REG_TOKEN', 'admin-secret-token-change-this')


# ==================== HELPER FUNCTIONS ====================

def validate_email(email):
    """Validate email format"""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    return True, "Password is valid"


def validate_name(name):
    """Validate name"""
    if not name or len(name.strip()) < 2:
        return False, "Name must be at least 2 characters long"
    return True, "Name is valid"


def generate_jwt_token(user_id, email):
    """Generate JWT token"""
    payload = {
        'user_id': user_id,
        'email': email,
        'exp': datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
        'iat': datetime.utcnow()
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)
    return token


def verify_jwt_token(token):
    """Verify and decode JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[JWT_ALGORITHM])
        return payload, None
    except jwt.ExpiredSignatureError:
        return None, "Token has expired"
    except jwt.InvalidTokenError:
        return None, "Invalid token"


def set_user_session(user):
    """
    ✅ CRITICAL: Helper function to set Flask session for a user
    This is called from token_required decorator and login endpoints
    """
    try:
        logger.info(f"📝 Setting Flask session for user_id={user.id}")
        session['user_id'] = user.id
        session['user_email'] = user.email
        session['user_name'] = user.name
        session.permanent = True
        session.modified = True
        logger.info(f"✅ Flask session set successfully")
        return True
    except Exception as e:
        logger.error(f"❌ Error setting session: {e}")
        return False


def token_required(f):
    """
    ✅ FIXED: Decorator to require valid JWT token AND set Flask session
    Uses raw SQL to avoid SQLAlchemy initialization issues with Flask reloader
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        # Get token from Authorization header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer TOKEN
            except IndexError:
                logger.warning("❌ Invalid token format in Authorization header")
                return jsonify({'success': False, 'message': 'Invalid token format'}), 401

        if not token:
            logger.warning("❌ No token provided")
            return jsonify({'success': False, 'message': 'Token is missing'}), 401

        logger.info(f"🔐 Validating JWT token...")
        # Verify token
        payload, error = verify_jwt_token(token)
        if error:
            logger.warning(f"❌ Token validation error: {error}")
            return jsonify({'success': False, 'message': error}), 401

        # Get user using raw SQL (avoids SQLAlchemy init issues)
        user = None
        try:
            import psycopg2
            from backend.connectors.db_connector import get_database_connector
            connector = get_database_connector()

            # Create connection using connector's parameters
            conn = psycopg2.connect(
                host=connector.db_host,
                port=int(connector.db_port),
                database=connector.db_name,
                user=connector.db_user,
                password=connector.db_password,
                options=f'-c search_path={connector.db_schema}'
            )
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, email, name, is_active, created_at, last_login FROM users WHERE id = %s",
                (payload['user_id'],)
            )
            row = cursor.fetchone()
            cursor.close()
            conn.close()

            if row:
                # Create a simple user object with all required attributes
                class SimpleUser:
                    def __init__(self, id, email, name, is_active, created_at, last_login):
                        self.id = id
                        self.email = email
                        self.name = name
                        self.is_active = is_active
                        self.created_at = created_at
                        self.last_login = last_login
                user = SimpleUser(row[0], row[1], row[2], row[3], row[4], row[5])
        except Exception as e:
            logger.error(f"❌ Error fetching user: {e}")
            # Fallback to SQLAlchemy if connector fails
            try:
                user = User.query.get(payload['user_id'])
            except Exception as e2:
                logger.error(f"❌ SQLAlchemy fallback also failed: {e2}")
                return jsonify({'success': False, 'message': 'Database error'}), 500

        if not user or not user.is_active:
            logger.warning(f"❌ User not found or inactive for user_id={payload['user_id']}")
            return jsonify({'success': False, 'message': 'User not found or inactive'}), 401

        logger.info(f"✅ Token valid for user: {user.email}")

        # ✅ CRITICAL: Set Flask session HERE
        if not set_user_session(user):
            logger.error("❌ Failed to set Flask session")
            return jsonify({'success': False, 'message': 'Failed to set session'}), 500

        logger.info(f"✅ Session set. Calling endpoint: {f.__name__}")

        # Pass user to the route
        return f(user, *args, **kwargs)

    return decorated


# ==================== ROLE-BASED ACCESS CONTROL ====================

def get_user_roles(user_id):
    """
    Get all roles for a user from the database.
    Returns list of role names: ['admin', 'user'] etc.
    Uses raw SQL to avoid SQLAlchemy initialization issues.
    """
    try:
        import psycopg2
        from backend.connectors.db_connector import get_database_connector
        import json

        connector = get_database_connector()

        # Create connection using connector's parameters
        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()
        cursor.execute("""
            SELECT r.name, r.permissions
            FROM user_roles ur
            JOIN roles r ON ur.role_id = r.id
            WHERE ur.user_id = %s
        """, (user_id,))

        roles = []
        permissions = {}
        for row in cursor.fetchall():
            roles.append(row[0])
            if row[1]:
                # Handle JSONB - may already be dict or may need parsing
                perms = row[1] if isinstance(row[1], dict) else json.loads(row[1])
                # Merge permissions from all roles
                for key, value in perms.items():
                    if value:  # If permission is True in any role
                        permissions[key] = True

        cursor.close()
        conn.close()

        return roles, permissions
    except Exception as e:
        logger.error(f"❌ Error getting user roles: {e}")
        return [], {}


def user_has_role(user_id, role_name):
    """Check if user has a specific role"""
    roles, _ = get_user_roles(user_id)
    return role_name in roles


def user_has_permission(user_id, permission_name):
    """Check if user has a specific permission"""
    _, permissions = get_user_roles(user_id)
    return permissions.get(permission_name, False)


def role_required(*allowed_roles):
    """
    Decorator to require specific role(s) for an endpoint.

    Usage:
        @role_required('admin')
        def admin_only_endpoint(user):
            ...

        @role_required('admin', 'user')
        def admin_or_user_endpoint(user):
            ...
    """
    def decorator(f):
        @wraps(f)
        @token_required
        def decorated(user, *args, **kwargs):
            user_roles, _ = get_user_roles(user.id)

            # Check if user has any of the allowed roles
            if not any(role in user_roles for role in allowed_roles):
                logger.warning(f"❌ Access denied for user {user.email}. Required: {allowed_roles}, Has: {user_roles}")
                return jsonify({
                    'success': False,
                    'message': f'Access denied. Required role: {", ".join(allowed_roles)}'
                }), 403

            logger.info(f"✅ Role check passed for {user.email}: {user_roles}")
            return f(user, *args, **kwargs)

        return decorated
    return decorator


def permission_required(*required_permissions):
    """
    Decorator to require specific permission(s) for an endpoint.

    Usage:
        @permission_required('upload_data')
        def upload_endpoint(user):
            ...

        @permission_required('manage_users', 'view_admin')
        def admin_endpoint(user):
            ...
    """
    def decorator(f):
        @wraps(f)
        @token_required
        def decorated(user, *args, **kwargs):
            _, user_permissions = get_user_roles(user.id)

            # Check if user has ALL required permissions
            missing = [p for p in required_permissions if not user_permissions.get(p)]
            if missing:
                logger.warning(f"❌ Permission denied for user {user.email}. Missing: {missing}")
                return jsonify({
                    'success': False,
                    'message': f'Permission denied. Missing: {", ".join(missing)}'
                }), 403

            logger.info(f"✅ Permission check passed for {user.email}")
            return f(user, *args, **kwargs)

        return decorated
    return decorator


def admin_required(f):
    """
    Shortcut decorator for admin-only endpoints.
    Equivalent to @role_required('admin')
    """
    @wraps(f)
    @token_required
    def decorated(user, *args, **kwargs):
        user_roles, _ = get_user_roles(user.id)

        if 'admin' not in user_roles:
            logger.warning(f"❌ Admin access denied for user {user.email}")
            return jsonify({
                'success': False,
                'message': 'Admin access required'
            }), 403

        logger.info(f"✅ Admin access granted for {user.email}")
        return f(user, *args, **kwargs)

    return decorated


# ==================== AUTHENTICATION ENDPOINTS ====================

@auth_bp.route('/login', methods=['POST'])
def login():
    """User Login - Returns JWT + Sets Flask Session"""
    
    try:
        logger.info("🔐 Login request received")
        
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        
        if not email or not password:
            return jsonify({'success': False, 'message': 'Email and password required'}), 400
        
        if not validate_email(email):
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        logger.info(f"🔍 Looking up user: {email}")
        user = User.query.filter_by(email=email).first()
        if not user or not user.is_active:
            logger.warning(f"❌ User not found or inactive: {email}")
            return jsonify({'success': False, 'message': 'Invalid credentials'}), 401
        
        if not user.check_password(password):
            logger.warning(f"❌ Wrong password for user: {email}")
            return jsonify({'success': False, 'message': 'Invalid credentials'}), 401
        
        logger.info(f"✅ Password verified for user: {email}")
        
        # Generate JWT token
        token = generate_jwt_token(user.id, user.email)
        expires_at = datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
        
        logger.info(f"✅ JWT token generated")
        
        # Update last login
        try:
            user.last_login = datetime.utcnow()
            db.session.commit()
            logger.info(f"✅ Last login updated for user: {email}")
        except Exception as e:
            logger.warning(f"⚠ Could not update last_login: {e}")
        
        logger.info(f"✅ LOGIN SUCCESSFUL for user: {email}")
        
        # ✅ CRITICAL: Set session with explicit debug logging
        logger.info(f"📝 Setting Flask session for user_id={user.id}")
        
        # Set session values
        from flask import session as flask_session
        flask_session.clear()  # Clear any existing session first
        flask_session['user_id'] = user.id
        flask_session['user_email'] = user.email
        flask_session['user_name'] = user.name
        flask_session['login_time'] = datetime.utcnow().isoformat()
        
        # Make session permanent with 7-day expiration
        flask_session.permanent = True
        from flask import current_app
        current_app.permanent_session_lifetime = timedelta(days=7)
        
        # Force session to be saved
        flask_session.modified = True
        
        logger.info(f"✅ Flask session set BEFORE response creation")
        logger.info(f"   - user_id: {flask_session.get('user_id')}")
        logger.info(f"   - user_email: {flask_session.get('user_email')}")
        logger.info(f"   - permanent: {flask_session.permanent}")
        logger.info(f"   - modified: {flask_session.modified}")
        logger.info(f"   - Session keys: {list(flask_session.keys())}")

        # Get user roles and permissions
        user_roles, user_permissions = get_user_roles(user.id)
        logger.info(f"   - roles: {user_roles}")
        logger.info(f"   - permissions: {user_permissions}")

        # Create response
        response_data = {
            'success': True,
            'message': 'Login successful',
            'data': {
                'token': token,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name,
                    'is_active': user.is_active,
                    'roles': user_roles,
                    'permissions': user_permissions,
                    'is_admin': 'admin' in user_roles
                },
                'expires_at': expires_at.isoformat(),
                'session_set': True
            }
        }

        response = make_response(jsonify(response_data), 200)

        # Set JWT token as httpOnly cookie for secure page navigation
        response.set_cookie(
            'token',
            value=token,
            httponly=True,
            secure=False,  # Set to True in production with HTTPS
            samesite='Lax',
            max_age=JWT_EXPIRATION_HOURS * 3600,  # Convert hours to seconds
            path='/'
        )

        logger.info(f"✅ Response created with JWT cookie - Flask will add Set-Cookie headers")

        return response
        
    except Exception as e:
        logger.error(f"❌ Login error: {e}", exc_info=True)
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST', 'GET'])
def logout():
    """
    User Logout Endpoint
    POST /api/auth/logout (with JWT token)
    GET /api/auth/logout (direct browser access)

    ✅ Clears both JWT and Flask session
    """
    try:
        # Log current session state
        user_email = session.get('user_email')

        if user_email:
            logger.info(f"🔓 Logout request for user: {user_email}")
        else:
            logger.info(f"🔓 Logout request (no active session)")

        # ✅ CRITICAL: Clear Flask session
        session.clear()
        logger.info(f"✅ Session cleared")

        # Return JSON for API calls, redirect for browser
        if request.method == 'POST' or request.headers.get('Content-Type') == 'application/json':
            response = make_response(jsonify({
                'success': True,
                'message': 'Logout successful'
            }), 200)

            # Clear JWT token cookie
            response.set_cookie('token', '', expires=0, path='/')
            logger.info(f"✅ JWT token cookie cleared")

            return response
        else:
            # Browser GET request - redirect to login
            from flask import redirect
            response = make_response(redirect('/login'))

            # Clear JWT token cookie
            response.set_cookie('token', '', expires=0, path='/')
            logger.info(f"✅ JWT token cookie cleared")

            return response

    except Exception as e:
        logger.error(f"❌ Logout error: {e}")
        # Still try to clear session even on error
        try:
            session.clear()
        except:
            pass

        if request.method == 'POST':
            return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500
        else:
            from flask import redirect
            return redirect('/login')


@auth_bp.route('/me', methods=['GET'])
@token_required
def get_current_user(user):
    """
    Get Current User with Roles
    GET /api/auth/me
    Headers: { "Authorization": "Bearer TOKEN" }

    ✅ Token validation automatically sets Flask session (via @token_required decorator)
    """
    try:
        logger.info(f"👤 Getting user info for user_id={user.id}")

        # Get user roles and permissions
        user_roles, user_permissions = get_user_roles(user.id)

        return jsonify({
            'success': True,
            'data': {
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name,
                    'is_active': user.is_active,
                    'created_at': user.created_at.isoformat() if user.created_at else None,
                    'last_login': user.last_login.isoformat() if user.last_login else None,
                    'roles': user_roles,
                    'permissions': user_permissions,
                    'is_admin': 'admin' in user_roles
                }
            }
        }), 200
    except Exception as e:
        logger.error(f"❌ Get user error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/verify', methods=['GET'])
@token_required
def verify_token(user):
    """
    Verify JWT Token
    GET /api/auth/verify
    
    ✅ Also sets Flask session
    """
    try:
        logger.info(f"✅ Token verified for user: {user.email}")
        
        return jsonify({
            'success': True,
            'message': 'Token is valid',
            'data': {
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name,
                    'is_active': user.is_active
                }
            }
        }), 200
    except Exception as e:
        logger.error(f"❌ Verify token error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/update-profile', methods=['PUT'])
@token_required
def update_profile(user):
    """Update User Profile (Name Only) - PUT /api/auth/update-profile"""
    try:
        logger.info(f"📝 Profile update requested for user: {user.email}")

        data = request.get_json()
        if not data:
            logger.warning("❌ No data provided for profile update")
            return jsonify({'success': False, 'message': 'No data provided'}), 400

        name = data.get('name', '').strip()

        # Validate name
        if not name:
            logger.warning("❌ Missing name")
            return jsonify({'success': False, 'message': 'Name is required'}), 400

        is_valid, message = validate_name(name)
        if not is_valid:
            logger.warning(f"❌ Invalid name: {message}")
            return jsonify({'success': False, 'message': message}), 400

        # Update user name only (email is not editable)
        user.name = name
        db.session.commit()

        logger.info(f"✅ Profile updated for user: {user.email} (name changed to: {name})")

        # Update session with new name
        session['user_name'] = name
        session.modified = True

        return jsonify({
            'success': True,
            'message': 'Profile updated successfully',
            'data': {
                'user': {
                    'id': user.id,
                    'name': user.name,
                    'email': user.email,
                    'is_active': user.is_active,
                    'created_at': user.created_at.isoformat() if user.created_at else None,
                    'last_login': user.last_login.isoformat() if user.last_login else None
                }
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Profile update error: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/change-password', methods=['POST'])
@token_required
def change_password(user):
    """Change Password - POST /api/auth/change-password"""
    try:
        logger.info(f"🔒 Password change requested for user: {user.email}")

        data = request.get_json()
        if not data:
            logger.warning("❌ No data provided for password change")
            return jsonify({'success': False, 'message': 'No data provided'}), 400

        current_password = data.get('current_password', '')
        new_password = data.get('new_password', '')

        if not current_password or not new_password:
            logger.warning("❌ Missing current or new password")
            return jsonify({'success': False, 'message': 'Current and new password are required'}), 400

        # Get the full user with password from database using SQLAlchemy
        from sqlalchemy import text
        schema = os.environ.get('DB_SCHEMA', 'public')
        db_session = get_db_connection()

        result = db_session.execute(text(f"""
            SELECT id, password FROM {schema}.users WHERE id = :user_id
        """), {'user_id': user.id})
        user_row = result.fetchone()

        if not user_row:
            logger.warning(f"❌ User not found for password change: {user.email}")
            return jsonify({'success': False, 'message': 'User not found'}), 404

        stored_password_hash = user_row[1]

        # Check current password
        if not check_password_hash(stored_password_hash, current_password):
            logger.warning(f"❌ Wrong current password for user: {user.email}")
            return jsonify({'success': False, 'message': 'Current password is incorrect'}), 401

        is_valid, message = validate_password(new_password)
        if not is_valid:
            logger.warning(f"❌ Invalid new password: {message}")
            return jsonify({'success': False, 'message': message}), 400

        if current_password == new_password:
            logger.warning(f"❌ New password same as old for user: {user.email}")
            return jsonify({'success': False, 'message': 'New password must be different'}), 400

        # Hash new password and update in database
        from werkzeug.security import generate_password_hash
        new_password_hash = generate_password_hash(new_password)

        db_session.execute(text(f"""
            UPDATE {schema}.users SET password = :new_password WHERE id = :user_id
        """), {'new_password': new_password_hash, 'user_id': user.id})

        db_session.commit()

        logger.info(f"✅ Password changed for user: {user.email}")

        return jsonify({
            'success': True,
            'message': 'Password changed successfully'
        }), 200

    except Exception as e:
        logger.error(f"❌ Password change error: {e}")
        try:
            db_session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/register', methods=['POST'])
def register():
    """
    ⚠️ ADMIN REGISTRATION ENDPOINT (RESTRICTED)
    """
    try:
        logger.info("📝 Registration request received")
        
        admin_token = request.headers.get('X-Admin-Token')
        if not admin_token or admin_token != ADMIN_REGISTRATION_TOKEN:
            logger.warning("❌ Invalid or missing admin token")
            return jsonify({
                'success': False,
                'message': 'Unauthorized - Admin token required'
            }), 401
        
        data = request.get_json()
        if not data:
            logger.warning("❌ No data provided for registration")
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        name = data.get('name', '').strip()
        
        if not email or not password or not name:
            logger.warning("❌ Missing email, password, or name")
            return jsonify({'success': False, 'message': 'Email, password, and name are required'}), 400
        
        if not validate_email(email):
            logger.warning(f"❌ Invalid email format: {email}")
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        is_valid, message = validate_password(password)
        if not is_valid:
            logger.warning(f"❌ Invalid password: {message}")
            return jsonify({'success': False, 'message': message}), 400
        
        is_valid, message = validate_name(name)
        if not is_valid:
            logger.warning(f"❌ Invalid name: {message}")
            return jsonify({'success': False, 'message': message}), 400
        
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            logger.warning(f"❌ Email already registered: {email}")
            return jsonify({'success': False, 'message': 'Email already registered'}), 409
        
        user = User(email=email, name=name, is_active=True)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        
        logger.info(f"✅ User registered: {email}")
        
        token = generate_jwt_token(user.id, user.email)
        expires_at = datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
        
        return jsonify({
            'success': True,
            'message': 'User registered successfully',
            'data': {
                'token': token,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name,
                    'is_active': user.is_active
                },
                'expires_at': expires_at.isoformat()
            }
        }), 201
        
    except Exception as e:
        logger.error(f"❌ Registration error: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    """Forgot Password"""
    try:
        logger.info("📧 Forgot password request received")
        
        data = request.get_json()
        if not data:
            logger.warning("❌ No data provided")
            return jsonify({'success': False, 'message': 'No data provided'}), 400
        
        email = data.get('email', '').lower().strip()
        if not email or not validate_email(email):
            logger.warning(f"❌ Invalid email format: {email}")
            return jsonify({'success': False, 'message': 'Invalid email format'}), 400
        
        # Find user (always return success for security)
        user = User.query.filter_by(email=email).first()
        if user and user.is_active:
            logger.info(f"📧 Password reset email would be sent to: {email}")
            # TODO: Send password reset email
        
        return jsonify({
            'success': True,
            'message': 'If the email exists, a password reset link will be sent'
        }), 200
        
    except Exception as e:
        logger.error(f"❌ Forgot password error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@auth_bp.route('/health', methods=['GET'])
def auth_health():
    """Health Check"""
    try:
        logger.info("🏥 Auth health check")
        
        user_count = User.query.count()
        return jsonify({
            'success': True,
            'status': 'healthy',
            'data': {
                'total_users': user_count,
                'jwt_enabled': True,
                'flask_session_support': True,
                'timestamp': datetime.utcnow().isoformat()
            }
        }), 200
    except Exception as e:
        logger.error(f"❌ Auth health check error: {e}")
        return jsonify({
            'success': False,
            'status': 'unhealthy',
            'error': str(e)
        }), 503


# ==================== DEBUG ENDPOINTS ====================
# 🧪 Use these endpoints to troubleshoot session persistence issues

@auth_bp.route('/debug/session-info', methods=['GET'])
def debug_session_info():
    """
    ✅ DEBUG: Get current session info
    GET /api/auth/debug/session-info
    
    Shows what's in the Flask session on the server
    """
    try:
        logger.info("🧪 Session debug info requested")
        
        return jsonify({
            'success': True,
            'session': {
                'user_id': session.get('user_id'),
                'user_email': session.get('user_email'),
                'user_name': session.get('user_name'),
                'permanent': session.get('permanent'),
                'all_keys': list(session.keys()),
                'session_size': len(dict(session))
            },
            'config': {
                'SECRET_KEY_length': len(current_app.config.get('SECRET_KEY', '')),
                'SESSION_COOKIE_SECURE': current_app.config.get('SESSION_COOKIE_SECURE'),
                'SESSION_COOKIE_HTTPONLY': current_app.config.get('SESSION_COOKIE_HTTPONLY'),
                'SESSION_COOKIE_SAMESITE': current_app.config.get('SESSION_COOKIE_SAMESITE'),
                'PERMANENT_SESSION_LIFETIME': str(current_app.config.get('PERMANENT_SESSION_LIFETIME'))
            },
            'request': {
                'cookies_sent': dict(request.cookies),
                'has_session_cookie': 'session' in request.cookies,
                'session_cookie_value': request.cookies.get('session', 'NOT SENT')[:50] if request.cookies.get('session') else 'NOT SENT'
            },
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    except Exception as e:
        logger.error(f"❌ Debug session info error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@auth_bp.route('/debug/set-session', methods=['POST'])
def debug_set_session():
    """
    ✅ DEBUG: Manually set session (for testing)
    POST /api/auth/debug/set-session
    Body: {"user_id": 1, "user_email": "test@example.com", "user_name": "Test"}
    """
    try:
        logger.info("🧪 Manual session set requested")
        
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'No JSON body provided'
            }), 400
        
        user_id = data.get('user_id')
        user_email = data.get('user_email', 'unknown@example.com')
        user_name = data.get('user_name', 'Unknown')
        
        if not user_id:
            return jsonify({
                'success': False,
                'error': 'user_id is required'
            }), 400
        
        logger.info(f"📝 Manually setting session: user_id={user_id}")
        session['user_id'] = user_id
        session['user_email'] = user_email
        session['user_name'] = user_name
        session.permanent = True
        session.modified = True
        
        logger.info(f"✅ Session set manually")
        
        return jsonify({
            'success': True,
            'message': 'Session set manually',
            'session_data': {
                'user_id': session.get('user_id'),
                'user_email': session.get('user_email'),
                'user_name': session.get('user_name'),
                'permanent': session.get('permanent')
            },
            'next_step': 'GET /api/auth/debug/session-info to verify'
        }), 200
    except Exception as e:
        logger.error(f"❌ Debug set session error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@auth_bp.route('/debug/clear-session', methods=['POST'])
def debug_clear_session():
    """
    ✅ DEBUG: Clear session
    POST /api/auth/debug/clear-session
    
    Clears all session data
    """
    try:
        logger.info("🧹 Clearing session via debug endpoint")
        
        old_user_id = session.get('user_id')
        session.clear()
        
        logger.info(f"✅ Session cleared (was: user_id={old_user_id})")
        
        return jsonify({
            'success': True,
            'message': 'Session cleared',
            'session_after_clear': dict(session)
        }), 200
    except Exception as e:
        logger.error(f"❌ Debug clear session error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@auth_bp.route('/debug/test-cookie-persistence', methods=['GET'])
def debug_test_cookie_persistence():
    """
    ✅ DEBUG: Test if cookie can be set and retrieved
    GET /api/auth/debug/test-cookie-persistence
    
    Call this endpoint twice without clearing cookies to test persistence
    """
    try:
        logger.info("🧪 Testing cookie persistence")
        
        existing_test_value = session.get('test_persistence_value')
        
        if not existing_test_value:
            logger.info("📝 Setting test persistence cookie...")
            session['test_persistence_value'] = 'cookie-test-' + str(datetime.utcnow().timestamp())
            session['test_persistence_timestamp'] = datetime.utcnow().isoformat()
            session.permanent = True
            session.modified = True
            
            response_data = {
                'success': True,
                'step': 1,
                'message': 'Test cookie set. Call this endpoint again without clearing cookies to verify persistence.',
                'cookie_set': {
                    'test_value': session.get('test_persistence_value'),
                    'timestamp': session.get('test_persistence_timestamp')
                },
                'next_instruction': 'Refresh page or call GET /api/auth/debug/test-cookie-persistence again'
            }
            
            response = make_response(jsonify(response_data), 200)
            return response
        
        else:
            logger.info(f"✅ Cookie persisted! Value: {existing_test_value}")
            
            return jsonify({
                'success': True,
                'step': 2,
                'message': '✅ COOKIE PERSISTENCE VERIFIED!',
                'persisted_value': existing_test_value,
                'persisted_timestamp': session.get('test_persistence_timestamp'),
                'result': 'Browser successfully sent cookie back to server'
            }), 200
    
    except Exception as e:
        logger.error(f"❌ Debug cookie persistence error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@auth_bp.route('/debug/session-after-login', methods=['GET'])
def debug_session_after_login():
    """
    ✅ DEBUG: Check session status after login
    GET /api/auth/debug/session-after-login
    
    Call this IMMEDIATELY after login to verify session was set
    """
    try:
        logger.info("🧪 Checking session after login...")
        
        return jsonify({
            'debug': {
                'endpoint': 'debug_session_after_login',
                'timestamp': datetime.utcnow().isoformat(),
                'purpose': 'Check if session was set after login'
            },
            'session_status': {
                'user_id_in_session': session.get('user_id'),
                'user_email_in_session': session.get('user_email'),
                'user_name_in_session': session.get('user_name'),
                'session_permanent': session.get('permanent'),
                'session_keys': list(session.keys()),
                'has_session': len(dict(session)) > 0
            },
            'cookies_received': {
                'session_cookie_sent_by_browser': 'session' in request.cookies,
                'all_cookies': dict(request.cookies)
            },
            'diagnosis': {
                'session_set': session.get('user_id') is not None,
                'session_permanent': session.get('permanent') == True,
                'browser_sent_cookie': 'session' in request.cookies,
                'is_ready_for_dashboard': session.get('user_id') is not None and 'session' in request.cookies
            }
        }), 200
    except Exception as e:
        logger.error(f"❌ Debug session after login error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ==================== ADMIN ROLE MANAGEMENT ENDPOINTS ====================

@auth_bp.route('/roles', methods=['GET'])
@admin_required
def get_all_roles(user):
    """
    Get all available roles (Admin only)
    GET /api/auth/roles
    """
    try:
        from sqlalchemy import text
        result = db.session.execute(text("""
            SELECT id, name, description, permissions, created_at
            FROM igpt.roles
            ORDER BY id
        """))

        roles = []
        for row in result.fetchall():
            roles.append({
                'id': row[0],
                'name': row[1],
                'description': row[2],
                'permissions': row[3],
                'created_at': row[4].isoformat() if row[4] else None
            })

        return jsonify({
            'success': True,
            'roles': roles
        }), 200
    except Exception as e:
        logger.error(f"❌ Get roles error: {e}")
        error_msg = str(e)
        if 'relation' in error_msg.lower() and 'does not exist' in error_msg.lower():
            return jsonify({
                'success': False,
                'message': 'Roles table does not exist. Please run migrations/add_roles.sql'
            }), 500
        return jsonify({'success': False, 'message': error_msg}), 500


@auth_bp.route('/users', methods=['GET'])
@admin_required
def get_all_users(user):
    """
    Get all users with their roles (Admin only)
    GET /api/auth/users
    """
    try:
        from sqlalchemy import text
        result = db.session.execute(text("""
            SELECT
                u.id,
                u.email,
                u.name,
                u.is_active,
                u.created_at,
                u.last_login,
                COALESCE(array_agg(r.name) FILTER (WHERE r.name IS NOT NULL), ARRAY[]::varchar[]) as role_names
            FROM igpt.users u
            LEFT JOIN igpt.user_roles ur ON u.id = ur.user_id
            LEFT JOIN igpt.roles r ON ur.role_id = r.id
            GROUP BY u.id, u.email, u.name, u.is_active, u.created_at, u.last_login
            ORDER BY u.id
        """))

        users = []
        for row in result.fetchall():
            users.append({
                'id': row[0],
                'email': row[1],
                'name': row[2],
                'is_active': row[3],
                'created_at': row[4].isoformat() if row[4] else None,
                'last_login': row[5].isoformat() if row[5] else None,
                'roles': list(row[6]) if row[6] else [],
                'is_admin': 'admin' in (row[6] or [])
            })

        return jsonify({
            'success': True,
            'users': users,
            'count': len(users)
        }), 200
    except Exception as e:
        logger.error(f"❌ Get users error: {e}")
        error_msg = str(e)
        if 'relation' in error_msg.lower() and 'does not exist' in error_msg.lower():
            return jsonify({
                'success': False,
                'message': 'Roles tables do not exist. Please run migrations/add_roles.sql'
            }), 500
        return jsonify({'success': False, 'message': error_msg}), 500


@auth_bp.route('/users/<int:user_id>/roles', methods=['GET'])
@token_required
def get_user_roles_api(current_user, user_id):
    """
    Get roles for a specific user
    GET /api/auth/users/<user_id>/roles

    Users can view their own roles, admins can view any user's roles
    """
    try:
        from sqlalchemy import text

        # Check if user is requesting their own roles or is admin
        is_own_roles = current_user.id == user_id
        is_admin = False

        try:
            user_roles, _ = get_user_roles(current_user.id)
            is_admin = 'admin' in user_roles
        except:
            # Legacy check
            is_admin = current_user.id == 1 or current_user.email.endswith('@admin.com')

        if not is_own_roles and not is_admin:
            return jsonify({
                'success': False,
                'message': 'You can only view your own roles'
            }), 403

        # Get user's roles
        roles, permissions = get_user_roles(user_id)

        return jsonify({
            'success': True,
            'user_id': user_id,
            'roles': roles,
            'permissions': permissions
        }), 200

    except Exception as e:
        logger.error(f"❌ Get user roles error: {e}")
        error_msg = str(e)
        if 'relation' in error_msg.lower() and 'does not exist' in error_msg.lower():
            return jsonify({
                'success': False,
                'message': 'Roles tables do not exist. Please run migrations/add_roles.sql'
            }), 500
        return jsonify({'success': False, 'message': error_msg}), 500


@auth_bp.route('/users/<int:user_id>/roles', methods=['POST'])
@admin_required
def assign_user_role(admin_user, user_id):
    """
    Assign a role to a user (Admin only)
    POST /api/auth/users/<user_id>/roles
    Body: {"role": "admin"} or {"role_id": 1}
    """
    try:
        from sqlalchemy import text
        data = request.get_json()

        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400

        role_name = data.get('role')
        role_id = data.get('role_id')

        if not role_name and not role_id:
            return jsonify({'success': False, 'message': 'role or role_id required'}), 400

        # Get role_id from name if needed
        if role_name and not role_id:
            result = db.session.execute(text("""
                SELECT id FROM igpt.roles WHERE name = :name
            """), {'name': role_name})
            row = result.fetchone()
            if not row:
                return jsonify({'success': False, 'message': f'Role "{role_name}" not found'}), 404
            role_id = row[0]

        # Check if target user exists
        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        # Assign role
        db.session.execute(text("""
            INSERT INTO igpt.user_roles (user_id, role_id, assigned_by)
            VALUES (:user_id, :role_id, :assigned_by)
            ON CONFLICT (user_id, role_id) DO NOTHING
        """), {'user_id': user_id, 'role_id': role_id, 'assigned_by': admin_user.id})
        db.session.commit()

        logger.info(f"✅ Role {role_id} assigned to user {user_id} by admin {admin_user.email}")

        return jsonify({
            'success': True,
            'message': f'Role assigned to user {target_user.email}'
        }), 200
    except Exception as e:
        logger.error(f"❌ Assign role error: {e}")
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@auth_bp.route('/users/<int:user_id>/roles/<role_name>', methods=['DELETE'])
@admin_required
def remove_user_role(admin_user, user_id, role_name):
    """
    Remove a role from a user (Admin only)
    DELETE /api/auth/users/<user_id>/roles/<role_name>
    """
    try:
        from sqlalchemy import text

        # Don't allow removing own admin role
        if user_id == admin_user.id and role_name == 'admin':
            return jsonify({
                'success': False,
                'message': 'Cannot remove your own admin role'
            }), 400

        # Check if target user exists
        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        # Remove role
        result = db.session.execute(text("""
            DELETE FROM igpt.user_roles ur
            USING igpt.roles r
            WHERE ur.role_id = r.id
              AND ur.user_id = :user_id
              AND r.name = :role_name
        """), {'user_id': user_id, 'role_name': role_name})
        db.session.commit()

        logger.info(f"✅ Role {role_name} removed from user {user_id} by admin {admin_user.email}")

        return jsonify({
            'success': True,
            'message': f'Role "{role_name}" removed from user {target_user.email}'
        }), 200
    except Exception as e:
        logger.error(f"❌ Remove role error: {e}")
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500


@auth_bp.route('/check-permission/<permission>', methods=['GET'])
@token_required
def check_user_permission(user, permission):
    """
    Check if current user has a specific permission
    GET /api/auth/check-permission/upload_data
    """
    try:
        has_perm = user_has_permission(user.id, permission)

        return jsonify({
            'success': True,
            'user_id': user.id,
            'permission': permission,
            'has_permission': has_perm
        }), 200
    except Exception as e:
        logger.error(f"❌ Check permission error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


# ==================== USER PREFERENCES ENDPOINTS ====================

@auth_bp.route('/preferences', methods=['GET'])
@token_required
def get_user_preferences(user):
    """
    Get user preferences (theme, settings)
    GET /api/auth/preferences

    Returns user preferences from database
    """
    try:
        logger.info(f"📋 Getting preferences for user: {user.email}")

        import psycopg2
        from backend.connectors.db_connector import get_database_connector

        connector = get_database_connector()
        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()

        # Check if user_preferences table exists, create if not
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                theme VARCHAR(20) DEFAULT 'light',
                preferences JSONB DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

        # Get user preferences
        cursor.execute("""
            SELECT theme, preferences, updated_at
            FROM user_preferences
            WHERE user_id = %s
        """, (user.id,))

        row = cursor.fetchone()
        cursor.close()
        conn.close()

        if row:
            return jsonify({
                'success': True,
                'data': {
                    'theme': row[0] or 'light',
                    'preferences': row[1] or {},
                    'updated_at': row[2].isoformat() if row[2] else None
                }
            }), 200
        else:
            # Return defaults if no preferences set
            return jsonify({
                'success': True,
                'data': {
                    'theme': 'light',
                    'preferences': {},
                    'updated_at': None
                }
            }), 200

    except Exception as e:
        logger.error(f"❌ Get preferences error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@auth_bp.route('/preferences', methods=['PUT', 'POST'])
@token_required
def save_user_preferences(user):
    """
    Save user preferences (theme, settings)
    PUT/POST /api/auth/preferences
    Body: { "theme": "dark", "preferences": {...} }

    Saves user preferences to database for persistence across devices
    """
    try:
        logger.info(f"💾 Saving preferences for user: {user.email}")

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400

        theme = data.get('theme', 'light')
        preferences = data.get('preferences', {})

        # Validate theme value
        if theme not in ['light', 'dark', 'system']:
            theme = 'light'

        import psycopg2
        import json
        from backend.connectors.db_connector import get_database_connector

        connector = get_database_connector()
        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()

        # Ensure table exists
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                theme VARCHAR(20) DEFAULT 'light',
                preferences JSONB DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

        # Upsert preferences
        cursor.execute("""
            INSERT INTO user_preferences (user_id, theme, preferences, updated_at)
            VALUES (%s, %s, %s, CURRENT_TIMESTAMP)
            ON CONFLICT (user_id)
            DO UPDATE SET
                theme = EXCLUDED.theme,
                preferences = EXCLUDED.preferences,
                updated_at = CURRENT_TIMESTAMP
            RETURNING id, theme, preferences, updated_at
        """, (user.id, theme, json.dumps(preferences)))

        row = cursor.fetchone()
        conn.commit()
        cursor.close()
        conn.close()

        logger.info(f"✅ Preferences saved for user: {user.email}, theme: {theme}")

        return jsonify({
            'success': True,
            'message': 'Preferences saved successfully',
            'data': {
                'theme': row[1] if row else theme,
                'preferences': row[2] if row else preferences,
                'updated_at': row[3].isoformat() if row and row[3] else None
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Save preferences error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500


@auth_bp.route('/preferences/theme', methods=['PUT', 'POST'])
@token_required
def save_theme_only(user):
    """
    Quick endpoint to save only theme preference
    PUT/POST /api/auth/preferences/theme
    Body: { "theme": "dark" }
    """
    try:
        logger.info(f"🎨 Saving theme for user: {user.email}")

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'message': 'No data provided'}), 400

        theme = data.get('theme', 'light')

        # Validate theme value
        if theme not in ['light', 'dark', 'system']:
            theme = 'light'

        import psycopg2
        from backend.connectors.db_connector import get_database_connector

        connector = get_database_connector()
        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()

        # Ensure table exists
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_preferences (
                id SERIAL PRIMARY KEY,
                user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
                theme VARCHAR(20) DEFAULT 'light',
                preferences JSONB DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

        # Upsert theme only
        cursor.execute("""
            INSERT INTO user_preferences (user_id, theme, updated_at)
            VALUES (%s, %s, CURRENT_TIMESTAMP)
            ON CONFLICT (user_id)
            DO UPDATE SET
                theme = EXCLUDED.theme,
                updated_at = CURRENT_TIMESTAMP
            RETURNING theme
        """, (user.id, theme))

        row = cursor.fetchone()
        conn.commit()
        cursor.close()
        conn.close()

        logger.info(f"✅ Theme saved: {theme} for user: {user.email}")

        return jsonify({
            'success': True,
            'message': 'Theme saved successfully',
            'theme': row[0] if row else theme
        }), 200

    except Exception as e:
        logger.error(f"❌ Save theme error: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500