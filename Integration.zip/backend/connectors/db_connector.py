"""
Database Connector - Updated Version with Schema Support
Handles PostgreSQL database connections with connection pooling and error handling
Reads DB_SCHEMA from config.py automatically
Uses configuration from config.py, environment variables, or defaults
Gracefully handles initialization outside Flask application context
"""

import logging
import os
from typing import Optional, Dict, Any
from datetime import datetime
import traceback

logger = logging.getLogger(__name__)


class DatabaseConnectorError(Exception):
    """Custom exception for database connector errors"""
    pass


class DatabaseConnector:
    """
    Database connector for PostgreSQL with schema support
    Manages connections, pooling, and health checks
    Automatically reads DB_SCHEMA from config.py
    
    Configuration priority:
    1. Flask config (if available)
    2. Environment variables
    3. Default values
    """
    
    def __init__(self, config=None):
        """
        Initialize database connector with configuration
        
        Args:
            config: Flask configuration object (uses environment if not provided)
        """
        try:
            # Get configuration with graceful fallback
            if config is None:
                config = self._get_config()
            
            # Extract configuration
            self.db_type = self._get_config_value(config, 'DB_TYPE', 'postgresql')
            self.db_host = self._get_config_value(config, 'DB_HOST', 'localhost')
            self.db_port = str(self._get_config_value(config, 'DB_PORT', 5434))
            self.db_name = self._get_config_value(config, 'DB_NAME', 'dashboard_360')
            self.db_user = self._get_config_value(config, 'DB_USER', 'dashboard_user')
            self.db_password = self._get_config_value(config, 'DB_PASSWORD', '')
            self.db_sslmode = self._get_config_value(config, 'DB_SSLMODE', 'disable')

            # DEBUG: Log password info
            logger.info(f"DEBUG: Password length: {len(self.db_password)}, starts with: {self.db_password[:7] if len(self.db_password) >= 7 else 'TOO SHORT'}")
            
            # ✅ NEW: Get schema from config.py or environment
            self.db_schema = self._get_config_value(config, 'DB_SCHEMA', 'igpt')
            
            # SQLAlchemy pool configuration
            self.pool_size = int(self._get_config_value(config, 'SQLALCHEMY_POOL_SIZE', 10))
            self.pool_recycle = int(self._get_config_value(config, 'SQLALCHEMY_POOL_RECYCLE', 3600))
            self.pool_timeout = int(self._get_config_value(config, 'SQLALCHEMY_POOL_TIMEOUT', 30))
            self.pool_pre_ping = self._get_config_value(config, 'SQLALCHEMY_POOL_PRE_PING', True)
            
            # Validate database type
            if self.db_type != 'postgresql':
                raise DatabaseConnectorError(
                    f"Unsupported database type: {self.db_type}. Only PostgreSQL is supported."
                )
            
            # Build connection string
            self.connection_string = self._build_connection_string()
            self.is_connected = False
            self.connection_pool = None
            
            logger.info("✓ Database Connector initialized (PostgreSQL)")
            logger.info(f"  - Host: {self.db_host}:{self.db_port}")
            logger.info(f"  - Database: {self.db_name}")
            logger.info(f"  - Schema: {self.db_schema}")  # ✅ Log the schema
            logger.info(f"  - User: {self.db_user}")
            logger.info(f"  - Pool Size: {self.pool_size}")
            
        except DatabaseConnectorError:
            raise
        except Exception as e:
            logger.error(f"✗ Failed to initialize Database Connector: {e}")
            raise DatabaseConnectorError(f"Initialization failed: {str(e)}")
    
    
    @staticmethod
    def _get_config() -> Dict[str, Any]:
        """
        Get configuration with fallback chain
        
        Tries in order:
        1. Flask application config
        2. Environment variables
        3. Returns empty dict for defaults
        
        Returns:
            Configuration dictionary
        """
        try:
            from flask import current_app
            try:
                config = current_app.config
                logger.info("✓ Using Flask application config")
                return config
            except:
                logger.warning("⚠ Flask context not available, trying environment variables")
                return DatabaseConnector._get_env_config()
        except (RuntimeError, ImportError):
            logger.warning("⚠ Flask not available, using environment variables")
            return DatabaseConnector._get_env_config()
    
    
    @staticmethod
    def _get_env_config() -> Dict[str, Any]:
        """
        Get configuration from environment variables
        
        Returns:
            Configuration dictionary from environment
        """
        config = {
            'DB_TYPE': os.getenv('DB_TYPE', 'postgresql'),
            'DB_HOST': os.getenv('DB_HOST', 'localhost'),
            'DB_PORT': os.getenv('DB_PORT', '5434'),
            'DB_NAME': os.getenv('DB_NAME', 'dashboard_360'),
            'DB_USER': os.getenv('DB_USER', 'dashboard_user'),
            'DB_PASSWORD': os.getenv('DB_PASSWORD', ''),
            'DB_SSLMODE': os.getenv('DB_SSLMODE', 'disable'),
            'DB_SCHEMA': os.getenv('DB_SCHEMA', 'igpt'),  # ✅ NEW: Read schema from env
            'SQLALCHEMY_POOL_SIZE': os.getenv('SQLALCHEMY_POOL_SIZE', '10'),
            'SQLALCHEMY_POOL_RECYCLE': os.getenv('SQLALCHEMY_POOL_RECYCLE', '3600'),
            'SQLALCHEMY_POOL_TIMEOUT': os.getenv('SQLALCHEMY_POOL_TIMEOUT', '30'),
            'SQLALCHEMY_POOL_PRE_PING': os.getenv('SQLALCHEMY_POOL_PRE_PING', 'True')
        }
        logger.info("✓ Using environment variables for configuration")
        return config
    
    
    @staticmethod
    def _get_config_value(config: Dict[str, Any], key: str, default: Any) -> Any:
        """
        Safely get configuration value from config dict
        
        Args:
            config: Configuration dictionary
            key: Configuration key
            default: Default value if key not found
            
        Returns:
            Configuration value or default
        """
        # Try dict.get() first
        if isinstance(config, dict):
            value = config.get(key)
            if value is not None:
                return value
        
        # Try getattr for object-like config
        try:
            value = getattr(config, key, None)
            if value is not None:
                return value
        except:
            pass
        
        # Return default
        return default
    
    
    def _build_connection_string(self) -> str:
        """
        Build PostgreSQL connection string
        
        Returns:
            Connection string for SQLAlchemy
        """
        try:
            connection_string = (
                f"postgresql://{self.db_user}:{self.db_password}@"
                f"{self.db_host}:{self.db_port}/{self.db_name}"
            )
            logger.info("✓ PostgreSQL connection string built successfully")
            return connection_string
        
        except Exception as e:
            logger.error(f"✗ Error building connection string: {e}")
            raise DatabaseConnectorError(f"Connection string build failed: {str(e)}")
    
    
    def get_connection_string(self) -> str:
        """
        Get the full database connection string
        
        Returns:
            Database connection string
        """
        return self.connection_string
    
    
    def get_sqlalchemy_config(self) -> Dict[str, Any]:
        """
        Get SQLAlchemy configuration dictionary with schema support
        
        ✅ NEW: Automatically includes schema from config
        
        Returns:
            Dictionary with SQLAlchemy configuration
        """
        try:
            config = {
                'SQLALCHEMY_DATABASE_URI': self.connection_string,
                'SQLALCHEMY_TRACK_MODIFICATIONS': False,
                'SQLALCHEMY_ENGINE_OPTIONS': {
                    'pool_size': self.pool_size,
                    'pool_recycle': self.pool_recycle,
                    'pool_pre_ping': self.pool_pre_ping,
                    'pool_timeout': self.pool_timeout,
                    'max_overflow': 20,
                    'echo': False,
                    'connect_args': {
                        'connect_timeout': 10,
                        'application_name': '360_dashboard',
                        'options': f'-c search_path={self.db_schema}'  # ✅ SCHEMA SUPPORT - reads from config.py
                    }
                }
            }
            
            logger.info(f"✓ SQLAlchemy configuration prepared (schema: {self.db_schema})")
            return config
        
        except Exception as e:
            logger.error(f"✗ Error preparing SQLAlchemy config: {e}")
            raise DatabaseConnectorError(f"Config preparation failed: {str(e)}")
    
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Test database connection
        
        Returns:
            Dictionary with connection test result
        """
        try:
            try:
                import psycopg2
            except ImportError:
                logger.error("✗ psycopg2 not installed. Install with: pip install psycopg2-binary")
                return {
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': 'psycopg2 library not installed',
                    'schema': self.db_schema
                }
            
            try:
                conn_params = {
                    'host': self.db_host,
                    'port': int(self.db_port),
                    'database': self.db_name,
                    'user': self.db_user,
                    'password': self.db_password,
                    'connect_timeout': 10,
                    'options': f'-c search_path={self.db_schema}'  # ✅ Set search_path
                }
                
                if self.db_sslmode != 'disable':
                    conn_params['sslmode'] = self.db_sslmode
                
                conn = psycopg2.connect(**conn_params)
                cursor = conn.cursor()
                
                cursor.execute('SELECT version();')
                version = cursor.fetchone()[0]
                
                # ✅ NEW: Verify schema is being used
                cursor.execute("SELECT current_schema();")
                current_schema = cursor.fetchone()[0]
                
                cursor.close()
                conn.close()
                
                logger.info("✓ Database connection test successful")
                logger.info(f"✓ Using schema: {current_schema}")
                self.is_connected = True
                
                return {
                    'connected': True,
                    'timestamp': datetime.utcnow().isoformat(),
                    'version': version,
                    'host': self.db_host,
                    'database': self.db_name,
                    'schema': current_schema,  # ✅ Return actual schema in use
                    'configured_schema': self.db_schema
                }
            
            except Exception as pg_err:
                logger.error(f"✗ PostgreSQL connection test failed: {pg_err}")
                self.is_connected = False
                
                return {
                    'connected': False,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(pg_err),
                    'host': self.db_host,
                    'database': self.db_name,
                    'schema': self.db_schema
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in connection test: {e}")
            logger.debug(traceback.format_exc())
            
            return {
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e),
                'schema': self.db_schema
            }
    
    
    def health_check(self) -> Dict[str, Any]:
        """
        Perform comprehensive database health check
        
        ✅ NEW: Includes schema verification
        
        Returns:
            Dictionary with health status
        """
        try:
            import time
            import psycopg2
            
            start_time = time.time()
            
            try:
                conn_params = {
                    'host': self.db_host,
                    'port': int(self.db_port),
                    'database': self.db_name,
                    'user': self.db_user,
                    'password': self.db_password,
                    'connect_timeout': 5,
                    'options': f'-c search_path={self.db_schema}'  # ✅ Set search_path
                }
                
                if self.db_sslmode != 'disable':
                    conn_params['sslmode'] = self.db_sslmode
                
                conn = psycopg2.connect(**conn_params)
                cursor = conn.cursor()
                
                cursor.execute('SELECT 1;')
                cursor.fetchone()
                
                # ✅ NEW: Verify schema exists
                cursor.execute("""
                    SELECT EXISTS(
                        SELECT 1 FROM information_schema.schemata 
                        WHERE schema_name = %s
                    );
                """, (self.db_schema,))
                
                schema_exists = cursor.fetchone()[0]
                
                if not schema_exists:
                    logger.warning(f"⚠ Schema '{self.db_schema}' does not exist in database!")
                
                # Get database stats
                cursor.execute("""
                    SELECT 
                        datname,
                        pg_database_size(datname) as size,
                        numbackends
                    FROM pg_stat_database
                    WHERE datname = %s;
                """, (self.db_name,))
                
                db_stats = cursor.fetchone()
                
                cursor.close()
                conn.close()
                
                response_time = (time.time() - start_time) * 1000
                status = 'healthy' if response_time < 1000 and schema_exists else 'degraded'
                
                logger.info(f"✓ Database health check passed ({response_time:.2f}ms)")
                logger.info(f"✓ Schema '{self.db_schema}' exists: {schema_exists}")
                
                return {
                    'status': status,
                    'connected': True,
                    'response_time': response_time,
                    'timestamp': datetime.utcnow().isoformat(),
                    'details': {
                        'host': self.db_host,
                        'database': self.db_name,
                        'schema': self.db_schema,
                        'schema_exists': schema_exists,
                        'port': self.db_port,
                        'db_size': db_stats[1] if db_stats else 'N/A',
                        'active_connections': db_stats[2] if db_stats else 'N/A'
                    }
                }
            
            except Exception as pg_err:
                logger.error(f"✗ Database health check failed: {pg_err}")
                response_time = (time.time() - start_time) * 1000
                
                return {
                    'status': 'unhealthy',
                    'connected': False,
                    'response_time': response_time,
                    'timestamp': datetime.utcnow().isoformat(),
                    'error': str(pg_err),
                    'details': {
                        'host': self.db_host,
                        'database': self.db_name,
                        'schema': self.db_schema
                    }
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error in health check: {e}")
            logger.debug(traceback.format_exc())
            
            return {
                'status': 'unhealthy',
                'connected': False,
                'timestamp': datetime.utcnow().isoformat(),
                'error': str(e),
                'schema': self.db_schema
            }
    
    
    def get_db_info(self) -> Dict[str, Any]:
        """
        Get detailed database information
        
        ✅ NEW: Includes schema information
        
        Returns:
            Dictionary with database information
        """
        try:
            info = {
                'type': self.db_type,
                'host': self.db_host,
                'port': self.db_port,
                'database': self.db_name,
                'user': self.db_user,
                'schema': self.db_schema,  # ✅ NEW: Include schema
                'ssl_mode': self.db_sslmode,
                'pool_size': self.pool_size,
                'connected': self.is_connected,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            return info
        
        except Exception as e:
            logger.error(f"✗ Error getting database info: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }


def get_database_connector(config=None) -> Optional[DatabaseConnector]:
    """
    Factory function to get database connector instance
    
    ✅ NEW: Automatically uses DB_SCHEMA from config.py
    
    Args:
        config: Flask configuration object (optional)
    
    Returns:
        DatabaseConnector instance or None if initialization fails
    """
    try:
        return DatabaseConnector(config=config)
    except DatabaseConnectorError as e:
        logger.error(f"✗ Failed to create database connector: {e}")
        return None
    except Exception as e:
        logger.error(f"✗ Unexpected error creating connector: {e}")
        return None


def get_database_connection_string(config=None) -> Optional[str]:
    """
    Convenience function to get just the connection string
    
    Args:
        config: Flask configuration object (optional)
    
    Returns:
        Connection string or None if initialization fails
    """
    try:
        connector = DatabaseConnector(config=config)
        return connector.get_connection_string()
    except Exception as e:
        logger.error(f"✗ Error getting connection string: {e}")
        return None


def get_database_schema(config=None) -> Optional[str]:
    """
    Convenience function to get the configured schema
    
    ✅ NEW: Get schema from config
    
    Args:
        config: Flask configuration object (optional)
    
    Returns:
        Database schema name or None if initialization fails
    """
    try:
        connector = DatabaseConnector(config=config)
        return connector.db_schema
    except Exception as e:
        logger.error(f"✗ Error getting database schema: {e}")
        return None