"""
Azure OpenAI Connector - PRODUCTION READY
Based on proven working implementation with comprehensive model support
Critical: Both gpt-4o-mini and gpt-5-mini ONLY support temperature=1.0
"""
import logging
import json
import os
from typing import Dict, Any, Optional
from datetime import datetime
import traceback

logger = logging.getLogger(__name__)


class AzureOpenAIConnectorError(Exception):
    """Custom exception for Azure OpenAI connector errors"""
    pass


class AzureOpenAIConnector:
    """
    Production-ready Azure OpenAI connector
    CRITICAL: Both mini models ONLY support temperature=1.0
    """
    
    # ✅ CORRECT Model parameter configurations
    MODEL_CONFIGS = {
        'gpt-5-mini': {
            'use_max_completion_tokens': True,
            'supports_temperature': False,  # ONLY supports 1.0
            'supports_top_p': False,
            'supports_frequency_penalty': False,
            'supports_presence_penalty': False,
            'default_max': 8000,
        },
        'gpt-5': {
            'use_max_completion_tokens': True,
            'supports_temperature': False,  # ONLY supports 1.0
            'supports_top_p': False,
            'supports_frequency_penalty': False,
            'supports_presence_penalty': False,
            'default_max': 8000,
        },
        'gpt-4o-mini': {
            'use_max_completion_tokens': False,
            'supports_temperature': False,  # ONLY supports 1.0
            'supports_top_p': False,
            'supports_frequency_penalty': False,
            'supports_presence_penalty': False,
            'default_max': 800,
        },
        'gpt-4o': {
            'use_max_completion_tokens': False,
            'supports_temperature': True,   # CAN support temperature
            'supports_top_p': True,
            'supports_frequency_penalty': True,
            'supports_presence_penalty': True,
            'default_max': 4000,
        },
        'gpt-4': {
            'use_max_completion_tokens': False,
            'supports_temperature': True,   # CAN support temperature
            'supports_top_p': True,
            'supports_frequency_penalty': True,
            'supports_presence_penalty': True,
            'default_max': 8000,
        },
        'gpt-4-turbo': {
            'use_max_completion_tokens': False,
            'supports_temperature': True,   # CAN support temperature
            'supports_top_p': True,
            'supports_frequency_penalty': True,
            'supports_presence_penalty': True,
            'default_max': 4000,
        },
        'gpt-35-turbo': {
            'use_max_completion_tokens': False,
            'supports_temperature': True,   # CAN support temperature
            'supports_top_p': True,
            'supports_frequency_penalty': True,
            'supports_presence_penalty': True,
            'default_max': 4000,
        }
    }
    
    def __init__(self, config=None, api_key=None, endpoint=None, deployment=None):
        """Initialize Azure OpenAI connector with multiple configuration sources"""
        try:
            self.client = None
            self.is_connected = False
            self.endpoint = None
            self.api_key = None
            self.deployment = None
            self.api_version = None
            self.max_tokens = 2048
            self.temperature = 0.7
            
            logger.info("🔌 Initializing Azure OpenAI Connector...")
            
            # Load configuration
            self._load_configuration(config, api_key, endpoint, deployment)
            
            # Get model config
            self.model_config = self._get_model_config(self.deployment)
            
            # Log configuration
            logger.info("  Configuration values:")
            logger.info(f"    Endpoint: {self.endpoint[:50] + '...' if self.endpoint else 'NOT SET'}")
            logger.info(f"    API Key: {'SET' if self.api_key else 'NOT SET'}")
            logger.info(f"    Deployment: {self.deployment}")
            logger.info(f"    API Version: {self.api_version}")
            logger.info(f"    Max Tokens: {self.max_tokens}")
            logger.info(f"    Temperature (config): {self.temperature}")
            
            # Validate
            if not self._validate_configuration():
                logger.warning("⚠ Missing required configuration")
                self.is_connected = False
                return
            
            # Initialize client
            self._initialize_client()
            
        except AzureOpenAIConnectorError as e:
            logger.error(f"❌ Configuration error: {e}")
            self.is_connected = False
        except Exception as e:
            logger.error(f"❌ Unexpected error initializing connector: {e}")
            logger.debug(traceback.format_exc())
            self.is_connected = False
    
    
    def _load_configuration(self, config, api_key, endpoint, deployment):
        """Load configuration from multiple sources"""
        logger.debug("  Loading configuration...")
        
        # Priority 1: Explicit parameters
        if api_key:
            self.api_key = api_key
        if endpoint:
            self.endpoint = endpoint
        if deployment:
            self.deployment = deployment
        
        # Priority 2: Flask config
        if config:
            try:
                if not self.endpoint:
                    self.endpoint = config.get('AZURE_OPENAI_ENDPOINT') if hasattr(config, 'get') else None
                    if not self.endpoint:
                        self.endpoint = getattr(config, 'AZURE_OPENAI_ENDPOINT', None)
                
                if not self.api_key:
                    self.api_key = config.get('AZURE_OPENAI_API_KEY') if hasattr(config, 'get') else None
                    if not self.api_key:
                        self.api_key = getattr(config, 'AZURE_OPENAI_API_KEY', None)
                
                if not self.deployment:
                    self.deployment = config.get('AZURE_OPENAI_DEPLOYMENT') if hasattr(config, 'get') else None
                    if not self.deployment:
                        self.deployment = getattr(config, 'AZURE_OPENAI_DEPLOYMENT', None)
                
                if not self.api_version:
                    self.api_version = config.get('AZURE_OPENAI_API_VERSION') if hasattr(config, 'get') else None
                    if not self.api_version:
                        self.api_version = getattr(config, 'AZURE_OPENAI_API_VERSION', None)
                
                max_tokens = config.get('AZURE_OPENAI_MAX_TOKENS') if hasattr(config, 'get') else None
                if not max_tokens:
                    max_tokens = getattr(config, 'AZURE_OPENAI_MAX_TOKENS', None)
                if max_tokens:
                    self.max_tokens = int(max_tokens)
                
                temperature = config.get('AZURE_OPENAI_TEMPERATURE') if hasattr(config, 'get') else None
                if not temperature:
                    temperature = getattr(config, 'AZURE_OPENAI_TEMPERATURE', None)
                if temperature:
                    self.temperature = float(temperature)
                
                logger.debug("    ✓ Flask config loaded")
            except Exception as e:
                logger.debug(f"    ⚠ Error reading Flask config: {e}")
        
        # Priority 3: Environment variables
        self.endpoint = self.endpoint or os.getenv('AZURE_OPENAI_ENDPOINT')
        self.api_key = self.api_key or os.getenv('AZURE_OPENAI_API_KEY')
        self.deployment = self.deployment or os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-5-mini')
        self.api_version = self.api_version or os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
        
        logger.debug("    ✓ Configuration complete")
    
    
    def _validate_configuration(self) -> bool:
        """Validate all required configuration is present"""
        logger.info("  Validating configuration:")
        
        missing = []
        
        if not self.endpoint:
            missing.append('AZURE_OPENAI_ENDPOINT')
            logger.warning("    ❌ AZURE_OPENAI_ENDPOINT not found")
        else:
            logger.info(f"    ✅ Endpoint: {self.endpoint[:50]}...")
        
        if not self.api_key:
            missing.append('AZURE_OPENAI_API_KEY')
            logger.warning("    ❌ AZURE_OPENAI_API_KEY not found")
        else:
            logger.info(f"    ✅ API Key: configured")
        
        if not self.deployment:
            missing.append('AZURE_OPENAI_DEPLOYMENT')
            logger.warning("    ❌ AZURE_OPENAI_DEPLOYMENT not found")
        else:
            logger.info(f"    ✅ Deployment: {self.deployment}")
        
        if not self.api_version:
            missing.append('AZURE_OPENAI_API_VERSION')
            logger.warning("    ❌ AZURE_OPENAI_API_VERSION not found")
        else:
            logger.info(f"    ✅ API Version: {self.api_version}")
        
        if missing:
            logger.error(f"  ❌ Missing: {', '.join(missing)}")
            return False
        
        return True
    
    
    def _get_model_config(self, deployment: str) -> Dict[str, Any]:
        """Get configuration for a specific model/deployment"""
        deployment_lower = deployment.lower()
        
        # Try exact match
        if deployment_lower in self.MODEL_CONFIGS:
            return self.MODEL_CONFIGS[deployment_lower]
        
        # Try partial match
        for model_name, config in self.MODEL_CONFIGS.items():
            if model_name in deployment_lower:
                logger.info(f"  Model detected: {model_name}")
                return config
        
        # Default to gpt-4o-mini configuration (safest)
        logger.warning(f"  Unknown deployment {deployment}, using gpt-4o-mini defaults")
        return self.MODEL_CONFIGS['gpt-4o-mini'].copy()
    
    
    def _build_chat_completion_params(
        self,
        deployment: str,
        messages: list,
        temperature: float = 0.7,
        max_tokens: int = None
    ) -> Dict[str, Any]:
        """Build model-aware parameters - CRITICAL FIX"""
        
        model_config = self._get_model_config(deployment)
        
        logger.info(f"📋 Building params for {deployment}")
        logger.info(f"   Use max_completion_tokens: {model_config['use_max_completion_tokens']}")
        logger.info(f"   Supports temperature: {model_config['supports_temperature']}")
        
        params = {
            "model": deployment,
            "messages": messages,
            "stream": False
        }
        
        # Set max tokens parameter based on model
        if max_tokens is None:
            max_tokens = model_config['default_max']
        
        if model_config['use_max_completion_tokens']:
            logger.info(f"   ✅ Using max_completion_tokens={max_tokens}")
            params["max_completion_tokens"] = max_tokens
        else:
            logger.info(f"   ✅ Using max_tokens={max_tokens}")
            params["max_tokens"] = max_tokens
        
        # ✅ CRITICAL: Only add temperature if model supports it!
        if model_config['supports_temperature']:
            params["temperature"] = temperature
            logger.info(f"   ✅ Added temperature={temperature}")
        else:
            logger.info(f"   ℹ️ Model doesn't support temperature - skipping (uses default 1.0)")
        
        if model_config['supports_top_p']:
            params["top_p"] = 0.95
            logger.info(f"   ✅ Added top_p=0.95")
        
        if model_config['supports_frequency_penalty']:
            params["frequency_penalty"] = 0
            logger.info(f"   ✅ Added frequency_penalty=0")
        
        if model_config['supports_presence_penalty']:
            params["presence_penalty"] = 0
            logger.info(f"   ✅ Added presence_penalty=0")
        
        return params
    
    
    def _initialize_client(self):
        """Create Azure OpenAI client"""
        try:
            logger.info("  Creating Azure OpenAI client...")
            
            try:
                from openai import AzureOpenAI
            except ImportError:
                raise AzureOpenAIConnectorError("openai library not installed. pip install openai --upgrade")
            
            self.client = AzureOpenAI(
                api_key=self.api_key,
                api_version=self.api_version,
                azure_endpoint=self.endpoint
            )
            
            self.is_connected = True
            logger.info("✅ Azure OpenAI connector initialized successfully!")
            logger.info(f"   Deployment: {self.deployment}")
            logger.info(f"   Token param: {'max_completion_tokens' if self.model_config['use_max_completion_tokens'] else 'max_tokens'}")
            logger.info(f"   Temperature: {'supported' if self.model_config['supports_temperature'] else 'NOT supported - uses 1.0'}")
            
        except AzureOpenAIConnectorError as e:
            logger.error(f"  ❌ {e}")
            self.is_connected = False
            raise
        except Exception as e:
            logger.error(f"  ❌ Client creation failed: {e}")
            self.is_connected = False
            raise AzureOpenAIConnectorError(f"Client creation failed: {str(e)}")
    
    
    def is_available(self) -> bool:
        """Check if service is available"""
        return self.is_connected and self.client is not None
    
    
    def test_connection(self) -> Dict[str, Any]:
        """Test Azure OpenAI connection with model-aware parameters"""
        if not self.is_available():
            return {
                'status': 'error',
                'message': 'Azure OpenAI not initialized'
            }
        
        try:
            logger.info(f"Testing connection to {self.deployment}...")
            
            # Use model's default settings
            test_max_tokens = min(500, self.model_config['default_max'])
            
            api_params = self._build_chat_completion_params(
                deployment=self.deployment,
                messages=[{"role": "user", "content": "Say 'ok'"}],
                temperature=0.7,
                max_tokens=test_max_tokens
            )
            
            logger.info(f"Calling API with parameters: {list(api_params.keys())}")
            response = self.client.chat.completions.create(**api_params)
            
            result_text = response.choices[0].message.content
            
            logger.info(f"✅ Connection successful!")
            logger.info(f"   Model: {self.deployment}")
            logger.info(f"   Response: {result_text}\n")
            
            return {
                'status': 'success',
                'message': 'Azure OpenAI connected successfully',
                'model': self.deployment,
                'response': result_text
            }
            
        except Exception as e:
            error_msg = str(e)
            logger.error(f"❌ Connection failed: {error_msg}\n")
            
            return {
                'status': 'error',
                'message': f'Connection failed: {error_msg}',
                'deployment': self.deployment
            }
    
    
    def generate_text(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        top_p: float = 0.95,
        user_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Generate text using Azure OpenAI"""
        try:
            if not self.is_available():
                return {
                    'success': False,
                    'error': 'Azure OpenAI client not connected',
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            if max_tokens is None:
                max_tokens = self.max_tokens
            if temperature is None:
                temperature = self.temperature
            
            if not prompt or not isinstance(prompt, str):
                raise ValueError("Prompt must be a non-empty string")
            
            max_limit = self.model_config['default_max']
            if max_tokens < 1 or max_tokens > max_limit:
                logger.warning(f"⚠ max_tokens {max_tokens} clamping to {max_limit}")
                max_tokens = min(max_tokens, max_limit)
            
            logger.info(f"🤖 Generating text (model: {self.deployment}, tokens: {max_tokens})")
            
            try:
                api_params = self._build_chat_completion_params(
                    deployment=self.deployment,
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=temperature,
                    max_tokens=max_tokens
                )
                
                response = self.client.chat.completions.create(**api_params)
                
                generated_text = response.choices[0].message.content
                tokens_used = response.usage.total_tokens if response.usage else 0
                finish_reason = response.choices[0].finish_reason
                
                logger.info(f"✓ Text generated (tokens: {tokens_used}, model: {self.deployment})")
                
                return {
                    'success': True,
                    'text': generated_text,
                    'tokens_used': tokens_used,
                    'finish_reason': finish_reason,
                    'timestamp': datetime.utcnow().isoformat(),
                    'model': self.deployment
                }
            
            except Exception as api_err:
                logger.error(f"✗ API error: {api_err}")
                logger.debug(traceback.format_exc())
                return {
                    'success': False,
                    'text': None,
                    'error': str(api_err),
                    'timestamp': datetime.utcnow().isoformat()
                }
        
        except Exception as e:
            logger.error(f"✗ Unexpected error: {e}")
            logger.debug(traceback.format_exc())
            return {
                'success': False,
                'text': None,
                'error': f'Unexpected error: {str(e)}',
                'timestamp': datetime.utcnow().isoformat()
            }


def get_azure_openai_connector(config=None) -> Optional[AzureOpenAIConnector]:
    """Factory function to get Azure OpenAI connector instance"""
    try:
        connector = AzureOpenAIConnector(config=config)
        if connector.is_available():
            return connector
        return None
    except Exception as e:
        logger.error(f"❌ Failed to create connector: {e}")
        return None