"""
Admin Routes - User Management & System Configuration
Restricted to admin users only

FIXED: Lazy imports to avoid circular dependencies
"""

from flask import Blueprint, request, jsonify
from functools import wraps
import logging
import os
import platform
import psutil
from datetime import datetime

logger = logging.getLogger(__name__)

# Create Blueprint FIRST - before any risky imports
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')


# ============================================================================
# LAZY IMPORT FUNCTION - Avoid circular dependencies
# ============================================================================

def get_auth_modules():
    """Lazy load auth modules to avoid circular imports"""
    try:
        from backend.auth.auth_models import db, User
        from backend.auth.auth import token_required, get_user_roles
        return db, User, token_required, get_user_roles
    except ImportError:
        try:
            from auth.auth_models import db, User
            from auth.auth import token_required, get_user_roles
            return db, User, token_required, get_user_roles
        except ImportError as e:
            logger.error(f"❌ Could not import auth modules: {e}")
            raise


# ============================================================================
# ADMIN-ONLY DECORATOR
# ============================================================================

def admin_required(f):
    """Decorator to require admin privileges - uses RBAC system"""
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            # Get auth modules (lazy load)
            db, User, token_required, get_user_roles = get_auth_modules()
            
            # Get Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                logger.warning(f"❌ No Bearer token in Authorization header")
                return jsonify({
                    'success': False,
                    'message': 'Authorization header with Bearer token required'
                }), 401
            
            token = auth_header[7:]  # Remove 'Bearer ' prefix
            
            # Verify token
            from backend.auth.auth import verify_jwt_token
            payload, error = verify_jwt_token(token)
            if error:
                logger.warning(f"❌ Token verification failed: {error}")
                return jsonify({
                    'success': False,
                    'message': 'Invalid or expired token'
                }), 401
            
            user_id = payload.get('user_id')
            if not user_id:
                return jsonify({
                    'success': False,
                    'message': 'Invalid token payload'
                }), 401
            
            # Get user
            try:
                user = User.query.get(user_id)
            except Exception as query_err:
                logger.warning(f"❌ Could not query user from database: {query_err}")
                return jsonify({
                    'success': False,
                    'message': 'User lookup failed'
                }), 500
            
            if not user:
                logger.warning(f"❌ User not found: user_id={user_id}")
                return jsonify({
                    'success': False,
                    'message': 'User not found'
                }), 404
            
            # Check admin role via RBAC first
            try:
                user_roles, _ = get_user_roles(user_id)
                if 'admin' not in user_roles:
                    logger.warning(f"❌ User {user.email} does not have admin role. Roles: {user_roles}")
                    return jsonify({
                        'success': False,
                        'message': 'Admin privileges required. Please ensure you have the admin role.'
                    }), 403
                
                logger.info(f"✅ Admin access granted for {user.email} (via RBAC)")
                return f(user, *args, **kwargs)
                
            except Exception as rbac_err:
                # RBAC tables might not exist - fall back to legacy check
                logger.warning(f"⚠️ RBAC check failed, using legacy check: {rbac_err}")
                
                if user.id == 1 or user.email.endswith('@admin.com'):
                    logger.info(f"✅ Admin access granted for {user.email} (via legacy check)")
                    return f(user, *args, **kwargs)
                else:
                    logger.warning(f"❌ Unauthorized admin access attempt by user: {user.email}")
                    return jsonify({
                        'success': False,
                        'message': 'Admin privileges required. Please ensure you have the admin role.'
                    }), 403
                    
        except Exception as e:
            logger.error(f"❌ Admin decorator error: {e}", exc_info=True)
            return jsonify({
                'success': False,
                'message': 'Authorization error'
            }), 500

    return decorated


# ============================================================================
# HEALTH CHECK - No auth required
# ============================================================================

@admin_bp.route('/health', methods=['GET'])
def admin_health():
    """Quick health check for admin routes"""
    logger.info("🏥 Admin health check requested")
    return jsonify({
        'status': 'ok',
        'message': 'Admin routes are loaded and accessible',
        'endpoints': [
            'GET /api/admin/health',
            'GET /api/admin/users',
            'DELETE /api/admin/users/<id>',
            'POST /api/admin/users/<id>/activate',
            'POST /api/admin/users/<id>/deactivate',
            'GET /api/admin/settings',
            'GET /api/admin/system-info',
            'GET /api/admin/stats'
        ]
    }), 200


# ==================== USER MANAGEMENT ====================

@admin_bp.route('/users', methods=['GET'])
@admin_required
def get_all_users(user):
    """
    Get All Users
    GET /api/admin/users
    Admin only - Uses raw SQL to avoid SQLAlchemy init issues
    """
    try:
        logger.info(f"📋 Admin {user.email} requesting user list")

        import psycopg2
        from backend.connectors.db_connector import get_database_connector
        connector = get_database_connector()

        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, email, is_active, created_at, last_login FROM users ORDER BY id")
        rows = cursor.fetchall()
        cursor.close()
        conn.close()

        users_data = []
        active_count = 0
        for row in rows:
            users_data.append({
                'id': row[0],
                'name': row[1],
                'email': row[2],
                'is_active': row[3],
                'created_at': row[4].isoformat() if row[4] else None,
                'last_login': row[5].isoformat() if row[5] else None
            })
            if row[3]:  # is_active
                active_count += 1

        total_users = len(users_data)
        logger.info(f"✅ Retrieved {total_users} users")

        return jsonify({
            'success': True,
            'data': {
                'users': users_data,
                'stats': {
                    'total': total_users,
                    'active': active_count,
                    'inactive': total_users - active_count
                }
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Get users error: {e}", exc_info=True)
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user, user_id):
    """
    Delete User
    DELETE /api/admin/users/<id>
    Admin only
    """
    try:
        logger.info(f"🗑️ Admin {user.email} requesting deletion of user_id={user_id}")

        db, User, _, _ = get_auth_modules()

        # Prevent admin from deleting themselves
        if user.id == user_id:
            logger.warning(f"❌ Admin attempted to delete their own account")
            return jsonify({
                'success': False,
                'message': 'Cannot delete your own account'
            }), 400

        target_user = User.query.get(user_id)
        if not target_user:
            logger.warning(f"❌ User not found: user_id={user_id}")
            return jsonify({'success': False, 'message': 'User not found'}), 404

        user_email = target_user.email
        db.session.delete(target_user)
        db.session.commit()

        logger.info(f"✅ User deleted: {user_email}")

        return jsonify({
            'success': True,
            'message': f'User {user_email} deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"❌ Delete user error: {e}", exc_info=True)
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>/deactivate', methods=['POST'])
@admin_required
def deactivate_user(user, user_id):
    """
    Deactivate User
    POST /api/admin/users/<id>/deactivate
    Admin only
    """
    try:
        logger.info(f"🔒 Admin {user.email} deactivating user_id={user_id}")

        db, User, _, _ = get_auth_modules()

        if user.id == user_id:
            return jsonify({
                'success': False,
                'message': 'Cannot deactivate your own account'
            }), 400

        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        target_user.is_active = False
        db.session.commit()

        logger.info(f"✅ User deactivated: {target_user.email}")

        return jsonify({
            'success': True,
            'message': f'User {target_user.email} deactivated'
        }), 200

    except Exception as e:
        logger.error(f"❌ Deactivate user error: {e}", exc_info=True)
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>/activate', methods=['POST'])
@admin_required
def activate_user(user, user_id):
    """
    Activate User
    POST /api/admin/users/<id>/activate
    Admin only
    """
    try:
        logger.info(f"✅ Admin {user.email} activating user_id={user_id}")

        db, User, _, _ = get_auth_modules()

        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        target_user.is_active = True
        db.session.commit()

        logger.info(f"✅ User activated: {target_user.email}")

        return jsonify({
            'success': True,
            'message': f'User {target_user.email} activated'
        }), 200

    except Exception as e:
        logger.error(f"❌ Activate user error: {e}", exc_info=True)
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== SETTINGS MANAGEMENT ====================

@admin_bp.route('/settings', methods=['GET'])
@admin_required
def get_settings(user):
    """
    Get Environment Settings
    GET /api/admin/settings
    Admin only

    Note: Sensitive values are masked for security
    """
    try:
        logger.info(f"⚙️ Admin {user.email} requesting settings")

        # Get non-sensitive environment variables
        safe_settings = {}

        # Configuration settings (safe to show)
        config_keys = [
            'FLASK_ENV',
            'FLASK_DEBUG',
            'FLASK_HOST',
            'FLASK_PORT',
            'DB_TYPE',
            'DB_HOST',
            'DB_PORT',
            'DB_NAME',
            'DB_USER',
            'DB_SCHEMA',
            'DB_SSLMODE',
            'SQLALCHEMY_POOL_SIZE',
            'SQLALCHEMY_POOL_RECYCLE',
            'SQLALCHEMY_POOL_TIMEOUT',
            'CORS_ORIGINS',
            'AZURE_TENANT_ID',
            'AZURE_SUBSCRIPTION_ID',
            'AZURE_OPENAI_ENDPOINT',
            'AZURE_OPENAI_DEPLOYMENT',
            'AZURE_OPENAI_API_VERSION',
            'AZURE_STORAGE_ACCOUNT_NAME',
            'AZURE_STORAGE_CONTAINER_NAME',
            'JWT_EXPIRATION_HOURS',
            'SESSION_COOKIE_SECURE',
            'SESSION_COOKIE_HTTPONLY',
            'LOG_LEVEL',
            'ENABLE_RAG',
            'ENABLE_VECTOR_SEARCH',
            'EMBEDDING_MODEL'
        ]

        for key in config_keys:
            value = os.getenv(key)
            if value is not None:
                safe_settings[key] = value

        # Sensitive keys (show as masked)
        sensitive_keys = [
            'SECRET_KEY',
            'FLASK_SECRET_KEY',
            'JWT_SECRET_KEY',
            'DB_PASSWORD',
            'AZURE_CLIENT_SECRET',
            'AZURE_OPENAI_API_KEY',
            'AZURE_STORAGE_ACCOUNT_KEY',
            'ADMIN_REG_TOKEN'
        ]

        for key in sensitive_keys:
            value = os.getenv(key)
            if value:
                # Check if it's a Key Vault reference
                if value.startswith('@Microsoft.KeyVault'):
                    safe_settings[key] = '[Key Vault Reference]'
                else:
                    safe_settings[key] = '••••••••'

        logger.info(f"✅ Retrieved {len(safe_settings)} settings")

        return jsonify({
            'success': True,
            'data': {
                'settings': safe_settings,
                'total_count': len(safe_settings),
                'note': 'Sensitive values are masked for security'
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Get settings error: {e}", exc_info=True)
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== SYSTEM INFORMATION ====================

@admin_bp.route('/system-info', methods=['GET'])
@admin_required
def get_system_info(user):
    """
    Get System Information
    GET /api/admin/system-info
    Admin only
    """
    try:
        logger.info(f"💻 Admin {user.email} requesting system info")

        # Get system info
        info = {
            'python_version': platform.python_version(),
            'platform': platform.system(),
            'platform_release': platform.release(),
            'platform_version': platform.version(),
            'architecture': platform.machine(),
            'hostname': platform.node(),
            'processor': platform.processor() or 'Unknown',
            'cpu_count': psutil.cpu_count(),
            'cpu_percent': f"{psutil.cpu_percent(interval=1)}%",
            'memory_total': f"{psutil.virtual_memory().total / (1024**3):.2f} GB",
            'memory_available': f"{psutil.virtual_memory().available / (1024**3):.2f} GB",
            'memory_percent': f"{psutil.virtual_memory().percent}%",
            'disk_usage': f"{psutil.disk_usage('/').percent}%",
            'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat()
        }

        logger.info(f"✅ System info retrieved")

        return jsonify({
            'success': True,
            'data': info
        }), 200

    except Exception as e:
        logger.error(f"❌ Get system info error: {e}", exc_info=True)
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== DATABASE STATISTICS ====================

@admin_bp.route('/stats', methods=['GET'])
@admin_required
def get_stats(user):
    """
    Get System Statistics
    GET /api/admin/stats
    Admin only - Uses raw SQL to avoid SQLAlchemy init issues
    """
    try:
        logger.info(f"📊 Admin {user.email} requesting statistics")

        import psycopg2
        from backend.connectors.db_connector import get_database_connector
        connector = get_database_connector()

        conn = psycopg2.connect(
            host=connector.db_host,
            port=int(connector.db_port),
            database=connector.db_name,
            user=connector.db_user,
            password=connector.db_password,
            options=f'-c search_path={connector.db_schema}'
        )
        cursor = conn.cursor()

        # User statistics
        cursor.execute("SELECT COUNT(*) FROM users")
        total_users = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM users WHERE is_active = true")
        active_users = cursor.fetchone()[0]

        # Recent logins
        cursor.execute("""
            SELECT email, name, last_login FROM users
            WHERE last_login IS NOT NULL
            ORDER BY last_login DESC LIMIT 5
        """)
        recent_logins = [
            {'email': row[0], 'name': row[1], 'last_login': row[2].isoformat() if row[2] else None}
            for row in cursor.fetchall()
        ]

        # Recent registrations
        cursor.execute("""
            SELECT email, name, created_at FROM users
            ORDER BY created_at DESC LIMIT 5
        """)
        recent_registrations = [
            {'email': row[0], 'name': row[1], 'created_at': row[2].isoformat() if row[2] else None}
            for row in cursor.fetchall()
        ]

        cursor.close()
        conn.close()

        stats = {
            'users': {
                'total': total_users,
                'active': active_users,
                'inactive': total_users - active_users
            },
            'recent_logins': recent_logins,
            'recent_registrations': recent_registrations
        }

        logger.info(f"✅ Statistics retrieved")

        return jsonify({
            'success': True,
            'data': stats
        }), 200

    except Exception as e:
        logger.error(f"❌ Get stats error: {e}", exc_info=True)
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500