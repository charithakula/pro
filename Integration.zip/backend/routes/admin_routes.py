"""
Admin Routes - User Management & System Configuration
Restricted to admin users only
"""

from flask import Blueprint, request, jsonify
from functools import wraps
import logging
import os
import platform
import psutil
from datetime import datetime

# Import from auth module
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from auth.auth_models import db, User
from auth.auth import token_required

logger = logging.getLogger(__name__)

# Create Blueprint
admin_bp = Blueprint('admin', __name__, url_prefix='/api/admin')


# Admin-only decorator
def admin_required(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    @token_required
    def decorated(user, *args, **kwargs):
        # For now, we'll use a simple check - can be enhanced with role-based access
        # Add is_admin field to User model later
        # For now, check if user is the first user (ID=1) or has admin email pattern
        if user.id != 1 and not user.email.endswith('@admin.com'):
            logger.warning(f"❌ Unauthorized admin access attempt by user: {user.email}")
            return jsonify({
                'success': False,
                'message': 'Admin privileges required'
            }), 403

        return f(user, *args, **kwargs)

    return decorated


# ==================== USER MANAGEMENT ====================

@admin_bp.route('/users', methods=['GET'])
@admin_required
def get_all_users(user):
    """
    Get All Users
    GET /api/admin/users
    Admin only
    """
    try:
        logger.info(f"📋 Admin {user.email} requesting user list")

        users = User.query.all()

        users_data = []
        for u in users:
            users_data.append({
                'id': u.id,
                'name': u.name,
                'email': u.email,
                'is_active': u.is_active,
                'created_at': u.created_at.isoformat() if u.created_at else None,
                'last_login': u.last_login.isoformat() if u.last_login else None
            })

        # Calculate stats
        total_users = len(users)
        active_users = sum(1 for u in users if u.is_active)

        logger.info(f"✅ Retrieved {total_users} users")

        return jsonify({
            'success': True,
            'data': {
                'users': users_data,
                'stats': {
                    'total': total_users,
                    'active': active_users,
                    'inactive': total_users - active_users
                }
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Get users error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(user, user_id):
    """
    Delete User
    DELETE /api/admin/users/<id>
    Admin only
    """
    try:
        logger.info(f"🗑️ Admin {user.email} requesting deletion of user_id={user_id}")

        # Prevent admin from deleting themselves
        if user.id == user_id:
            logger.warning(f"❌ Admin attempted to delete their own account")
            return jsonify({
                'success': False,
                'message': 'Cannot delete your own account'
            }), 400

        target_user = User.query.get(user_id)
        if not target_user:
            logger.warning(f"❌ User not found: user_id={user_id}")
            return jsonify({'success': False, 'message': 'User not found'}), 404

        user_email = target_user.email
        db.session.delete(target_user)
        db.session.commit()

        logger.info(f"✅ User deleted: {user_email}")

        return jsonify({
            'success': True,
            'message': f'User {user_email} deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"❌ Delete user error: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>/deactivate', methods=['POST'])
@admin_required
def deactivate_user(user, user_id):
    """
    Deactivate User
    POST /api/admin/users/<id>/deactivate
    Admin only
    """
    try:
        logger.info(f"🔒 Admin {user.email} deactivating user_id={user_id}")

        if user.id == user_id:
            return jsonify({
                'success': False,
                'message': 'Cannot deactivate your own account'
            }), 400

        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        target_user.is_active = False
        db.session.commit()

        logger.info(f"✅ User deactivated: {target_user.email}")

        return jsonify({
            'success': True,
            'message': f'User {target_user.email} deactivated'
        }), 200

    except Exception as e:
        logger.error(f"❌ Deactivate user error: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


@admin_bp.route('/users/<int:user_id>/activate', methods=['POST'])
@admin_required
def activate_user(user, user_id):
    """
    Activate User
    POST /api/admin/users/<id>/activate
    Admin only
    """
    try:
        logger.info(f"✅ Admin {user.email} activating user_id={user_id}")

        target_user = User.query.get(user_id)
        if not target_user:
            return jsonify({'success': False, 'message': 'User not found'}), 404

        target_user.is_active = True
        db.session.commit()

        logger.info(f"✅ User activated: {target_user.email}")

        return jsonify({
            'success': True,
            'message': f'User {target_user.email} activated'
        }), 200

    except Exception as e:
        logger.error(f"❌ Activate user error: {e}")
        try:
            db.session.rollback()
        except:
            pass
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== SETTINGS MANAGEMENT ====================

@admin_bp.route('/settings', methods=['GET'])
@admin_required
def get_settings(user):
    """
    Get Environment Settings
    GET /api/admin/settings
    Admin only

    Note: Sensitive values are masked for security
    """
    try:
        logger.info(f"⚙️ Admin {user.email} requesting settings")

        # Get non-sensitive environment variables
        safe_settings = {}

        # Configuration settings (safe to show)
        config_keys = [
            'FLASK_ENV',
            'FLASK_DEBUG',
            'FLASK_HOST',
            'FLASK_PORT',
            'DB_TYPE',
            'DB_HOST',
            'DB_PORT',
            'DB_NAME',
            'DB_USER',
            'DB_SCHEMA',
            'DB_SSLMODE',
            'SQLALCHEMY_POOL_SIZE',
            'SQLALCHEMY_POOL_RECYCLE',
            'SQLALCHEMY_POOL_TIMEOUT',
            'CORS_ORIGINS',
            'AZURE_TENANT_ID',
            'AZURE_SUBSCRIPTION_ID',
            'AZURE_OPENAI_ENDPOINT',
            'AZURE_OPENAI_DEPLOYMENT',
            'AZURE_OPENAI_API_VERSION',
            'AZURE_STORAGE_ACCOUNT_NAME',
            'AZURE_STORAGE_CONTAINER_NAME',
            'JWT_EXPIRATION_HOURS',
            'SESSION_COOKIE_SECURE',
            'SESSION_COOKIE_HTTPONLY',
            'LOG_LEVEL',
            'ENABLE_RAG',
            'ENABLE_VECTOR_SEARCH',
            'EMBEDDING_MODEL'
        ]

        for key in config_keys:
            value = os.getenv(key)
            if value is not None:
                safe_settings[key] = value

        # Sensitive keys (show as masked)
        sensitive_keys = [
            'SECRET_KEY',
            'FLASK_SECRET_KEY',
            'JWT_SECRET_KEY',
            'DB_PASSWORD',
            'AZURE_CLIENT_SECRET',
            'AZURE_OPENAI_API_KEY',
            'AZURE_STORAGE_ACCOUNT_KEY',
            'ADMIN_REG_TOKEN'
        ]

        for key in sensitive_keys:
            value = os.getenv(key)
            if value:
                # Check if it's a Key Vault reference
                if value.startswith('@Microsoft.KeyVault'):
                    safe_settings[key] = '[Key Vault Reference]'
                else:
                    safe_settings[key] = '••••••••'

        logger.info(f"✅ Retrieved {len(safe_settings)} settings")

        return jsonify({
            'success': True,
            'data': {
                'settings': safe_settings,
                'total_count': len(safe_settings),
                'note': 'Sensitive values are masked for security'
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Get settings error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== SYSTEM INFORMATION ====================

@admin_bp.route('/system-info', methods=['GET'])
@admin_required
def get_system_info(user):
    """
    Get System Information
    GET /api/admin/system-info
    Admin only
    """
    try:
        logger.info(f"💻 Admin {user.email} requesting system info")

        # Get system info
        info = {
            'python_version': platform.python_version(),
            'platform': platform.system(),
            'platform_release': platform.release(),
            'platform_version': platform.version(),
            'architecture': platform.machine(),
            'hostname': platform.node(),
            'processor': platform.processor() or 'Unknown',
            'cpu_count': psutil.cpu_count(),
            'cpu_percent': f"{psutil.cpu_percent(interval=1)}%",
            'memory_total': f"{psutil.virtual_memory().total / (1024**3):.2f} GB",
            'memory_available': f"{psutil.virtual_memory().available / (1024**3):.2f} GB",
            'memory_percent': f"{psutil.virtual_memory().percent}%",
            'disk_usage': f"{psutil.disk_usage('/').percent}%",
            'boot_time': datetime.fromtimestamp(psutil.boot_time()).isoformat()
        }

        logger.info(f"✅ System info retrieved")

        return jsonify({
            'success': True,
            'data': info
        }), 200

    except Exception as e:
        logger.error(f"❌ Get system info error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500


# ==================== DATABASE STATISTICS ====================

@admin_bp.route('/stats', methods=['GET'])
@admin_required
def get_stats(user):
    """
    Get System Statistics
    GET /api/admin/stats
    Admin only
    """
    try:
        logger.info(f"📊 Admin {user.email} requesting statistics")

        # User statistics
        total_users = User.query.count()
        active_users = User.query.filter_by(is_active=True).count()

        # Recent activity
        recent_logins = User.query.filter(User.last_login.isnot(None)).order_by(User.last_login.desc()).limit(5).all()
        recent_registrations = User.query.order_by(User.created_at.desc()).limit(5).all()

        stats = {
            'users': {
                'total': total_users,
                'active': active_users,
                'inactive': total_users - active_users
            },
            'recent_logins': [
                {
                    'email': u.email,
                    'name': u.name,
                    'last_login': u.last_login.isoformat() if u.last_login else None
                }
                for u in recent_logins
            ],
            'recent_registrations': [
                {
                    'email': u.email,
                    'name': u.name,
                    'created_at': u.created_at.isoformat() if u.created_at else None
                }
                for u in recent_registrations
            ]
        }

        logger.info(f"✅ Statistics retrieved")

        return jsonify({
            'success': True,
            'data': stats
        }), 200

    except Exception as e:
        logger.error(f"❌ Get stats error: {e}")
        return jsonify({'success': False, 'message': f'Server error: {str(e)}'}), 500
