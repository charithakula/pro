"""
Backend Routes Package
======================
Contains Flask blueprints for the 360° Integration Dashboard.

Active Blueprints:
- chat.py: chat_bp - Hybrid RAG Chat (/chat/*)
- admin_routes.py: admin_bp - Admin API (/api/admin/*)
- splunk.py: splunk_bp - Splunk integration (/api/splunk/*)
- generic_db_routes.py: db_bp - Database queries (/api/db/*)
- sharepoint.py: sharepoint_bp - SharePoint (/api/sharepoint/*)
- azure_storage.py: Azure blob storage routes
"""

from .chat import chat_bp

__all__ = ['chat_bp']
