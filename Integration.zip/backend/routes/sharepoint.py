"""
360° Enterprise Dashboard - SharePoint Integration Routes
Example Flask routes demonstrating the updated connector usage
"""

from flask import Blueprint, jsonify, request, current_app
from backend.connectors.sharepoint_connector import get_sharepoint_connector
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Create Blueprint
sharepoint_bp = Blueprint('sharepoint', __name__, url_prefix='/api/sharepoint')


@sharepoint_bp.route('/health', methods=['GET'])
def sharepoint_health():
    """
    Health check endpoint for SharePoint connector
    
    Returns:
        - 200: SharePoint is healthy
        - 503: SharePoint not configured
    """
    connector = get_sharepoint_connector(current_app.config)
    health_status = connector.health_check()
    
    if health_status['status'] == 'healthy':
        return jsonify(health_status), 200
    elif health_status['status'] == 'unavailable':
        return jsonify(health_status), 503
    else:
        return jsonify(health_status), 500


@sharepoint_bp.route('/site-info', methods=['GET'])
def get_site_info():
    """
    Get SharePoint site information
    
    Returns:
        Site metadata including title, URL, creation date
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    result = connector.get_site_info()
    return jsonify(result), 200 if result['success'] else 500


@sharepoint_bp.route('/statistics', methods=['GET'])
def get_statistics():
    """
    Get SharePoint site statistics
    
    Returns:
        - site_name: Display name of the site
        - total_libraries: Number of document libraries
        - total_documents: Total document count
        - last_updated: Timestamp of last update
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    stats = connector.get_sharepoint_stats()
    return jsonify(stats), 200


@sharepoint_bp.route('/libraries', methods=['GET'])
def list_libraries():
    """
    Get all document libraries (drives) from SharePoint
    
    Returns:
        List of libraries with:
        - id: Library/Drive ID (use for subsequent calls)
        - title: Display name
        - web_url: URL to library
        - quota: Storage quota info
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    result = connector.get_document_libraries()
    return jsonify(result), 200 if result['success'] else 500


@sharepoint_bp.route('/documents/<library_id>', methods=['GET'])
def list_documents(library_id):
    """
    Get documents from specific library
    
    Query Parameters:
        - folder: Optional folder path (e.g., "subfolder/nested")
    
    Args:
        library_id: ID of the document library (from /libraries endpoint)
    
    Returns:
        List of documents with:
        - id: Document ID (for download/delete)
        - name: Filename
        - size: File size in bytes
        - created: Creation date
        - modified: Last modification date
        - created_by: User who created it
        - file_url: Direct link to file
        - mime_type: File type
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    folder_path = request.args.get('folder', '')
    
    result = connector.get_documents(library_id, folder_path)
    return jsonify(result), 200 if result['success'] else 500


@sharepoint_bp.route('/upload/<library_id>', methods=['POST'])
def upload_document(library_id):
    """
    ⚠️ UPLOAD NOT SUPPORTED
    
    This endpoint is disabled because only GET method (read-only) is allowed
    
    Returns:
        Error message indicating operation not supported
    """
    return jsonify({
        'error': 'Upload operation is not allowed',
        'message': 'Only GET method (read-only) is supported',
        'timestamp': datetime.utcnow().isoformat()
    }), 405  # Method Not Allowed


@sharepoint_bp.route('/download/<library_id>/<item_id>', methods=['GET'])
def download_document(library_id, item_id):
    """
    Get download URL for a document
    
    Args:
        library_id: ID of the document library
        item_id: ID of the document item
    
    Returns:
        - download_url: Direct download URL (valid for limited time)
        - web_url: URL to open in browser
        - file_name: Original filename
        - size: File size in bytes
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    result = connector.download_document(library_id, item_id)
    return jsonify(result), 200 if result['success'] else 500


@sharepoint_bp.route('/delete/<library_id>/<item_id>', methods=['DELETE'])
def delete_document(library_id, item_id):
    """
    ⚠️ DELETE NOT SUPPORTED
    
    This endpoint is disabled because only GET method (read-only) is allowed
    
    Returns:
        Error message indicating operation not supported
    """
    return jsonify({
        'error': 'Delete operation is not allowed',
        'message': 'Only GET method (read-only) is supported',
        'timestamp': datetime.utcnow().isoformat()
    }), 405  # Method Not Allowed


@sharepoint_bp.route('/search', methods=['GET'])
def search_documents():
    """
    Search documents across SharePoint site
    
    Query Parameters:
        - q: Search query (required)
    
    Returns:
        List of matching documents with:
        - id: Document ID
        - name: Filename
        - size: File size
        - modified: Last modified date
        - file_url: Link to file
        - mime_type: File type
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    search_term = request.args.get('q')
    
    if not search_term:
        return jsonify({'error': 'Search query (q) is required'}), 400
    
    result = connector.search_documents(search_term)
    return jsonify(result), 200 if result['success'] else 500


@sharepoint_bp.route('/lists', methods=['GET'])
def list_sharepoint_lists():
    """
    Get all lists from SharePoint site
    
    Returns:
        List of lists with:
        - id: List ID
        - title: Display name
        - item_count: Number of items
        - created: Creation date
        - last_modified: Last modification date
    """
    connector = get_sharepoint_connector(current_app.config)
    
    if not connector or not connector.is_configured:
        return jsonify({'error': 'SharePoint not configured'}), 503
    
    result = connector.get_lists()
    return jsonify(result), 200 if result['success'] else 500


# ============================================================================
# Example Usage Patterns
# ============================================================================

def example_download_document_flow():
    """
    Example: Complete flow to download a document
    """
    connector = get_sharepoint_connector(current_app.config)
    
    # Step 1: Get available libraries
    libs_result = connector.get_document_libraries()
    if not libs_result['success']:
        return {'error': libs_result['error']}
    
    # Step 2: Pick first library
    library_id = libs_result['libraries'][0]['id']
    
    # Step 3: Get documents in library
    docs_result = connector.get_documents(library_id)
    if not docs_result['success']:
        return {'error': docs_result['error']}
    
    # Step 4: Pick first document
    item_id = docs_result['documents'][0]['id']
    
    # Step 5: Get download URL
    download_result = connector.download_document(library_id, item_id)
    
    return download_result


def example_upload_document_flow(file_path):
    """
    Example: Complete flow to upload a document
    """
    connector = get_sharepoint_connector(current_app.config)
    
    # Step 1: Get available libraries
    libs_result = connector.get_document_libraries()
    if not libs_result['success']:
        return {'error': libs_result['error']}
    
    # Step 2: Pick first library
    library_id = libs_result['libraries'][0]['id']
    
    # Step 3: Read file
    with open(file_path, 'rb') as f:
        file_content = f.read()
    
    # Step 4: Upload
    upload_result = connector.upload_document(
        library_id=library_id,
        file_name='uploaded_file.xlsx',
        file_content=file_content,
        folder_path='reports'  # Optional subfolder
    )
    
    return upload_result


def example_search_and_delete():
    """
    Example: Search for a file and delete it
    """
    connector = get_sharepoint_connector(current_app.config)
    
    # Step 1: Search for documents
    search_result = connector.search_documents('Integration_Interface')
    if not search_result['success']:
        return {'error': search_result['error']}
    
    # Step 2: Delete first match
    if search_result['results']:
        item = search_result['results'][0]
        
        # Need to find library_id for this item
        # This requires querying the item's parent drive
        delete_result = connector.delete_document(
            library_id='b!example',  # Would need to determine from context
            item_id=item['id']
        )
        
        return delete_result
    
    return {'message': 'No files found'}


# ============================================================================
# Error Handling Middleware
# ============================================================================

@sharepoint_bp.errorhandler(Exception)
def handle_sharepoint_error(e):
    """
    Handle SharePoint connector errors
    """
    logger.error(f"SharePoint error: {e}")
    return jsonify({
        'error': 'SharePoint integration error',
        'detail': str(e)
    }), 500


# ============================================================================
# Registration
# ============================================================================

def register_sharepoint_routes(app):
    """
    Register SharePoint routes with Flask app
    
    Usage:
        from routes.sharepoint_routes import register_sharepoint_routes
        register_sharepoint_routes(app)
    """
    app.register_blueprint(sharepoint_bp)
    logger.info("✓ SharePoint routes registered")