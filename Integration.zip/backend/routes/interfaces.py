"""
Interface Routes - CRUD Operations for Integration Interfaces
=============================================================

Provides REST API endpoints for managing integration interface data.
Includes automatic embedding regeneration when interfaces are created/updated.

Endpoints:
- GET /api/interfaces - List all interfaces with optional filtering
- GET /api/interfaces/<id> - Get single interface
- POST /api/interfaces - Create new interface (admin only) + auto-generate unique ID
- PUT /api/interfaces/<id> - Update interface (admin only) + regenerate embedding
- DELETE /api/interfaces/<id> - Delete interface (admin only)
- POST /api/interfaces/request-deletion - Request deletion (pending admin approval)
- GET /api/interfaces/pending-deletions - Get pending deletion requests (admin only)
- POST /api/interfaces/<id>/regenerate-embedding - Regenerate embedding for interface
- POST /api/interfaces/regenerate-all-embeddings - Regenerate all embeddings (admin only)
"""

import logging
from flask import Blueprint, request, jsonify, current_app
from functools import wraps
from datetime import datetime

logger = logging.getLogger(__name__)

# Create Blueprint
interfaces_bp = Blueprint('interfaces', __name__, url_prefix='/api/interfaces')


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """Get schema from Flask config"""
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        return 'igpt'


def get_db_connection():
    """Get database connection using psycopg2"""
    import psycopg2
    from backend.connectors.db_connector import get_database_connector

    connector = get_database_connector()
    conn = psycopg2.connect(
        host=connector.db_host,
        port=int(connector.db_port),
        database=connector.db_name,
        user=connector.db_user,
        password=connector.db_password,
        options=f'-c search_path={connector.db_schema}'
    )
    return conn


def get_auth_modules():
    """Lazy load auth modules to avoid circular imports"""
    try:
        from backend.auth.auth_models import db, User
        from backend.auth.auth import token_required, get_user_roles, verify_jwt_token
        return db, User, token_required, get_user_roles, verify_jwt_token
    except ImportError:
        from auth.auth_models import db, User
        from auth.auth import token_required, get_user_roles, verify_jwt_token
        return db, User, token_required, get_user_roles, verify_jwt_token


def get_current_user():
    """Get current user from JWT token"""
    try:
        _, User, _, _, verify_jwt_token = get_auth_modules()

        auth_header = request.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            return None

        token = auth_header[7:]
        payload, error = verify_jwt_token(token)
        if error:
            return None

        user_id = payload.get('user_id')
        if not user_id:
            return None

        user = User.query.get(user_id)
        return user
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        return None


def is_admin_user():
    """Check if current user is admin"""
    try:
        user = get_current_user()
        if not user:
            logger.warning("is_admin_user: No current user found")
            return False

        user_id = user.id
        user_email = getattr(user, 'email', '') or ''

        logger.info(f"is_admin_user: Checking admin status for user_id={user_id}, email={user_email}")

        # Method 1: Check user_roles table for 'admin' role
        try:
            _, _, _, get_user_roles, _ = get_auth_modules()
            user_roles, _ = get_user_roles(user_id)
            logger.info(f"is_admin_user: User roles from DB: {user_roles}")
            if 'admin' in user_roles:
                logger.info(f"is_admin_user: User {user_id} is admin via roles table")
                return True
        except Exception as role_err:
            logger.warning(f"Role check failed: {role_err}")

        # Method 2: Check if user ID is 1 (first user is typically admin)
        if user_id == 1:
            logger.info(f"is_admin_user: User {user_id} is admin (user_id=1)")
            return True

        # Method 3: Check if email ends with @admin.com
        if user_email.endswith('@admin.com'):
            logger.info(f"is_admin_user: User {user_id} is admin via @admin.com email")
            return True

        logger.info(f"is_admin_user: User {user_id} is NOT admin")
        return False
    except Exception as e:
        logger.error(f"Admin check error: {e}")
        return False


def admin_required(f):
    """Decorator to require admin privileges"""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not is_admin_user():
            return jsonify({
                'success': False,
                'message': 'Admin privileges required'
            }), 403
        return f(*args, **kwargs)
    return decorated


def auth_required(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user:
            return jsonify({
                'success': False,
                'message': 'Authentication required'
            }), 401
        return f(*args, **kwargs)
    return decorated


# ============================================================================
# EMBEDDING REGENERATION
# ============================================================================

def regenerate_interface_embedding(interface_id: int):
    """
    Regenerate vector embedding for a specific interface.
    Called automatically when an interface is updated.
    """
    try:
        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get interface data
        cursor.execute(f"""
            SELECT interface_id, interface_name, interface_platform, interface_description,
                   source_name, target_name, interface_pattern, status, process_area
            FROM {schema}.integration_interfaces
            WHERE id = %s
        """, (interface_id,))

        row = cursor.fetchone()
        if not row:
            cursor.close()
            conn.close()
            return False, "Interface not found"

        # Create text for embedding
        embedding_text = f"""
        Interface ID: {row[0] or ''}
        Name: {row[1] or ''}
        Platform: {row[2] or ''}
        Description: {row[3] or ''}
        Source: {row[4] or ''}
        Target: {row[5] or ''}
        Pattern: {row[6] or ''}
        Status: {row[7] or ''}
        Process Area: {row[8] or ''}
        """.strip()

        # Generate embedding using local model
        try:
            from backend.services.local_embeddings import get_local_embedding_service
            embedding_service = get_local_embedding_service()

            if embedding_service:
                embedding = embedding_service.generate_embedding(embedding_text)

                if embedding:
                    # Update or insert embedding
                    cursor.execute(f"""
                        INSERT INTO {schema}.interface_embeddings
                        (interface_id, embedding_text, embedding, created_at)
                        VALUES (%s, %s, %s, NOW())
                        ON CONFLICT (interface_id)
                        DO UPDATE SET embedding_text = EXCLUDED.embedding_text,
                                      embedding = EXCLUDED.embedding,
                                      created_at = NOW()
                    """, (interface_id, embedding_text, embedding))

                    conn.commit()
                    logger.info(f"✅ Embedding regenerated for interface {interface_id}")
                    cursor.close()
                    conn.close()
                    return True, "Embedding regenerated successfully"
        except Exception as emb_error:
            logger.warning(f"Embedding service error: {emb_error}")

        cursor.close()
        conn.close()
        return False, "Embedding service not available"

    except Exception as e:
        logger.error(f"Error regenerating embedding: {e}")
        return False, str(e)


# ============================================================================
# LIST INTERFACES
# ============================================================================

@interfaces_bp.route('', methods=['GET'])
@interfaces_bp.route('/', methods=['GET'])
@auth_required
def get_interfaces():
    """
    Get all interfaces with optional filtering (requires authentication).

    Query Parameters:
    - platform: Filter by platform
    - status: Filter by status
    - owner: Filter by owner
    - search: Search in ID, name, description
    - limit: Number of records (default 1000)
    - offset: Pagination offset

    Returns:
        List of interfaces
    """
    try:
        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Build query
        base_query = f"""
            SELECT id, interface_id, interface_name, interface_platform as platform,
                   status, source_name as interface_owner, source_name as source_system,
                   target_name as target_system, interface_description as description,
                   created_at
            FROM {schema}.integration_interfaces
        """

        conditions = []
        params = []

        # Filters
        platform = request.args.get('platform')
        status = request.args.get('status')
        owner = request.args.get('owner')
        search = request.args.get('search')

        if platform:
            conditions.append("interface_platform = %s")
            params.append(platform)

        if status:
            conditions.append("status = %s")
            params.append(status)

        if owner:
            conditions.append("source_name = %s")
            params.append(owner)

        if search:
            conditions.append("(interface_id ILIKE %s OR interface_name ILIKE %s OR interface_description ILIKE %s)")
            search_term = f"%{search}%"
            params.extend([search_term, search_term, search_term])

        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)

        base_query += " ORDER BY id"

        # Pagination
        limit = request.args.get('limit', 10000, type=int)  # Increased default to handle larger datasets
        offset = request.args.get('offset', 0, type=int)
        base_query += f" LIMIT {limit} OFFSET {offset}"

        cursor.execute(base_query, params)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        interfaces = []
        for row in rows:
            interface = dict(zip(columns, row))
            # Convert datetime to ISO format
            if interface.get('created_at'):
                interface['created_at'] = interface['created_at'].isoformat()
            interfaces.append(interface)

        cursor.close()
        conn.close()

        logger.info(f"✅ Retrieved {len(interfaces)} interfaces")

        return jsonify({
            'success': True,
            'interfaces': interfaces,
            'count': len(interfaces)
        }), 200

    except Exception as e:
        logger.error(f"❌ Get interfaces error: {e}")
        return jsonify({
            'success': False,
            'message': str(e),
            'interfaces': []
        }), 500


# ============================================================================
# CREATE INTERFACE (Admin Only)
# ============================================================================

def generate_unique_interface_id(cursor, schema: str) -> str:
    """Generate a unique interface ID like INT-YYYYMMDD-XXXX"""
    from datetime import datetime
    import random
    import string

    date_part = datetime.now().strftime('%Y%m%d')

    # Try up to 10 times to generate a unique ID
    for _ in range(10):
        # Generate random 4-character suffix
        suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
        new_id = f"INT-{date_part}-{suffix}"

        # Check if it exists
        cursor.execute(f"""
            SELECT COUNT(*) FROM {schema}.integration_interfaces WHERE interface_id = %s
        """, (new_id,))

        if cursor.fetchone()[0] == 0:
            return new_id

    # Fallback: use timestamp with milliseconds
    timestamp = datetime.now().strftime('%Y%m%d%H%M%S%f')[:17]
    return f"INT-{timestamp}"


@interfaces_bp.route('', methods=['POST'])
@interfaces_bp.route('/', methods=['POST'])
@admin_required
def create_interface():
    """
    Create a new interface (admin only).
    Auto-generates a unique interface_id if not provided.
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400

        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        # Generate unique interface_id if not provided
        interface_id = data.get('interface_id')
        if not interface_id:
            interface_id = generate_unique_interface_id(cursor, schema)
            logger.info(f"Generated unique interface_id: {interface_id}")

        # All insertable database columns (direct mapping)
        insertable_columns = [
            'interface_name', 'sub_interface', 'operation_name', 'api_product_name',
            'interface_platform', 'status', 'dependency_id', 'process_area',
            'interface_pattern', 'interface_description',
            # Source system
            'source_name', 'source_ci_type', 'source_service_url', 'source_protocol',
            'source_data_format', 'source_trust_level', 'source_resolver_contact', 'source_intermediary',
            # Target system
            'target_name', 'target_ci_type', 'target_service_url', 'target_protocol',
            'target_data_format', 'target_trust_level', 'target_resolver_contact', 'target_intermediary',
            # Communication & timing
            'communication_mode', 'volume', 'frequency', 'schedule',
            # Quality & management
            'interface_resolver_group', 'qos', 'retention_period', 'priority',
            # Project & metadata
            'project_name', 'production_migration_date', 'pid_wo', 'reuse_status',
            'integration_pattern', 'interface_mode', 'ou', 'comments', 'interface_build_type'
        ]

        # Build insert data
        columns = ['interface_id']
        values = [interface_id]
        placeholders = ['%s']

        for column in insertable_columns:
            if column in data and data[column]:
                columns.append(column)
                values.append(data[column])
                placeholders.append('%s')

        insert_query = f"""
            INSERT INTO {schema}.integration_interfaces ({', '.join(columns)})
            VALUES ({', '.join(placeholders)})
            RETURNING id, interface_id
        """

        cursor.execute(insert_query, values)
        result = cursor.fetchone()
        new_id = result[0]
        generated_interface_id = result[1]

        conn.commit()
        cursor.close()
        conn.close()

        # Generate embedding for the new interface
        emb_success, emb_message = regenerate_interface_embedding(new_id)

        logger.info(f"✅ Interface created with id={new_id}, interface_id={generated_interface_id}")

        return jsonify({
            'success': True,
            'message': 'Interface created successfully',
            'id': new_id,
            'interface_id': generated_interface_id,
            'embedding_generated': emb_success,
            'embedding_message': emb_message
        }), 201

    except Exception as e:
        logger.error(f"❌ Create interface error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# ============================================================================
# GET SINGLE INTERFACE
# ============================================================================

@interfaces_bp.route('/<int:interface_id>', methods=['GET'])
@auth_required
def get_interface(interface_id):
    """Get a single interface by ID (requires authentication)"""
    try:
        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(f"""
            SELECT * FROM {schema}.integration_interfaces WHERE id = %s
        """, (interface_id,))

        columns = [desc[0] for desc in cursor.description]
        row = cursor.fetchone()

        cursor.close()
        conn.close()

        if not row:
            return jsonify({
                'success': False,
                'message': 'Interface not found'
            }), 404

        interface = dict(zip(columns, row))
        # Convert datetime fields
        for key in ['created_at', 'updated_at']:
            if interface.get(key):
                interface[key] = interface[key].isoformat()

        return jsonify({
            'success': True,
            'interface': interface
        }), 200

    except Exception as e:
        logger.error(f"❌ Get interface error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# ============================================================================
# UPDATE INTERFACE (Admin Only)
# ============================================================================

@interfaces_bp.route('/<int:interface_id>', methods=['PUT'])
@admin_required
def update_interface(interface_id):
    """
    Update an interface (admin only).
    Automatically regenerates embedding after update.
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'message': 'No data provided'
            }), 400

        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        # All editable database columns (direct mapping)
        editable_columns = [
            'interface_name', 'sub_interface', 'operation_name', 'api_product_name',
            'interface_platform', 'status', 'dependency_id', 'process_area',
            'interface_pattern', 'interface_description',
            # Source system
            'source_name', 'source_ci_type', 'source_service_url', 'source_protocol',
            'source_data_format', 'source_trust_level', 'source_resolver_contact', 'source_intermediary',
            # Target system
            'target_name', 'target_ci_type', 'target_service_url', 'target_protocol',
            'target_data_format', 'target_trust_level', 'target_resolver_contact', 'target_intermediary',
            # Communication & timing
            'communication_mode', 'volume', 'frequency', 'schedule',
            # Quality & management
            'interface_resolver_group', 'qos', 'retention_period', 'priority',
            # Project & metadata
            'project_name', 'production_migration_date', 'pid_wo', 'reuse_status',
            'integration_pattern', 'interface_mode', 'ou', 'comments', 'interface_build_type'
        ]

        # Build update query
        updates = []
        params = []

        for column in editable_columns:
            if column in data:
                updates.append(f"{column} = %s")
                params.append(data[column] if data[column] else None)

        if not updates:
            return jsonify({
                'success': False,
                'message': 'No valid fields to update'
            }), 400

        # Add updated_at
        updates.append("updated_at = NOW()")
        params.append(interface_id)

        update_query = f"""
            UPDATE {schema}.integration_interfaces
            SET {', '.join(updates)}
            WHERE id = %s
            RETURNING id
        """

        cursor.execute(update_query, params)
        result = cursor.fetchone()

        if not result:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'message': 'Interface not found'
            }), 404

        conn.commit()
        cursor.close()
        conn.close()

        # Regenerate embedding for the updated interface
        emb_success, emb_message = regenerate_interface_embedding(interface_id)

        logger.info(f"✅ Interface {interface_id} updated. Embedding: {emb_message}")

        return jsonify({
            'success': True,
            'message': 'Interface updated successfully',
            'embedding_regenerated': emb_success,
            'embedding_message': emb_message
        }), 200

    except Exception as e:
        logger.error(f"❌ Update interface error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# ============================================================================
# DELETE INTERFACE (Admin Only)
# ============================================================================

@interfaces_bp.route('/<int:interface_id>', methods=['DELETE'])
@admin_required
def delete_interface(interface_id):
    """Delete an interface (admin only)"""
    try:
        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        # First get the string interface_id for embedding deletion
        cursor.execute(f"""
            SELECT interface_id FROM {schema}.integration_interfaces WHERE id = %s
        """, (interface_id,))
        interface_row = cursor.fetchone()

        if interface_row:
            string_interface_id = interface_row[0]
            # Delete embedding first (if exists) - using string interface_id
            cursor.execute(f"""
                DELETE FROM {schema}.interface_embeddings WHERE interface_id = %s
            """, (string_interface_id,))

        # Delete interface
        cursor.execute(f"""
            DELETE FROM {schema}.integration_interfaces WHERE id = %s RETURNING id
        """, (interface_id,))

        result = cursor.fetchone()

        if not result:
            cursor.close()
            conn.close()
            return jsonify({
                'success': False,
                'message': 'Interface not found'
            }), 404

        conn.commit()
        cursor.close()
        conn.close()

        logger.info(f"✅ Interface {interface_id} deleted")

        return jsonify({
            'success': True,
            'message': 'Interface deleted successfully'
        }), 200

    except Exception as e:
        logger.error(f"❌ Delete interface error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# ============================================================================
# REGENERATE EMBEDDING MANUALLY
# ============================================================================

@interfaces_bp.route('/<int:interface_id>/regenerate-embedding', methods=['POST'])
@admin_required
def regenerate_embedding_endpoint(interface_id):
    """Manually regenerate embedding for an interface (admin only)"""
    try:
        success, message = regenerate_interface_embedding(interface_id)

        return jsonify({
            'success': success,
            'message': message
        }), 200 if success else 500

    except Exception as e:
        logger.error(f"❌ Regenerate embedding error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500


# ============================================================================
# PENDING DELETION REQUESTS (Stored in database in future, now returns empty)
# ============================================================================

@interfaces_bp.route('/pending-deletions', methods=['GET'])
@admin_required
def get_pending_deletions():
    """Get pending deletion requests (admin only)"""
    # Note: Currently using localStorage on frontend
    # This endpoint is a placeholder for future database-backed implementation
    return jsonify({
        'success': True,
        'pending_deletions': []
    }), 200


@interfaces_bp.route('/request-deletion', methods=['POST'])
@auth_required
def request_deletion():
    """Submit a deletion request (requires authentication)"""
    # Note: Currently using localStorage on frontend
    # This endpoint is a placeholder for future database-backed implementation
    data = request.get_json()
    logger.info(f"📝 Deletion request received: {data}")

    return jsonify({
        'success': True,
        'message': 'Deletion request submitted'
    }), 200


# ============================================================================
# BULK REGENERATE EMBEDDINGS
# ============================================================================

@interfaces_bp.route('/regenerate-all-embeddings', methods=['POST'])
@admin_required
def regenerate_all_embeddings():
    """Regenerate embeddings for all interfaces (admin only)"""
    try:
        schema = get_db_schema()
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute(f"SELECT id FROM {schema}.integration_interfaces")
        interface_ids = [row[0] for row in cursor.fetchall()]

        cursor.close()
        conn.close()

        success_count = 0
        fail_count = 0

        for iid in interface_ids:
            success, _ = regenerate_interface_embedding(iid)
            if success:
                success_count += 1
            else:
                fail_count += 1

        logger.info(f"✅ Bulk embedding regeneration: {success_count} success, {fail_count} failed")

        return jsonify({
            'success': True,
            'message': f'Regenerated {success_count} embeddings, {fail_count} failed',
            'success_count': success_count,
            'fail_count': fail_count,
            'total': len(interface_ids)
        }), 200

    except Exception as e:
        logger.error(f"❌ Bulk regenerate error: {e}")
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500
