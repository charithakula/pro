"""
Chat Routes - WITH IMPROVED RAG SERVICE INITIALIZATION
WITH DETAILED ERROR HANDLING & DIAGNOSTICS
✅ FIXED: Added DB_SCHEMA (igpt) support to all SQL queries
"""

from flask import Blueprint, request, jsonify, current_app
import logging
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from typing import Dict, Any, Optional
import traceback

logger = logging.getLogger(__name__)

# ============================================================================
# CREATE BLUEPRINT
# ============================================================================

chat_bp = Blueprint('chat', __name__, url_prefix='/chat')

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    ✅ NEW: Get schema from Flask config (config.py)
    
    Returns:
        Schema name (e.g., 'igpt')
    """
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        # Outside application context, default to 'igpt'
        return 'igpt'


def get_db():
    """Get database connection"""
    try:
        from backend.services.database import get_db_connection
        db = get_db_connection()
        if db:
            logger.info("✓ Database connection obtained")
        else:
            logger.warning("⚠️ get_db_connection returned None")
        return db
    except ImportError as ie:
        logger.error(f"❌ Cannot import get_db_connection: {ie}")
        return None
    except Exception as e:
        logger.warning(f"⚠️ Database connection failed: {e}")
        return None


def get_llm_client():
    """Get Azure OpenAI client from app.extensions"""
    try:
        # ✅ GET FROM APP.EXTENSIONS (initialized in app.py)
        if hasattr(current_app, 'extensions') and 'openai_client' in current_app.extensions:
            client = current_app.extensions['openai_client']
            if client is not None:
                logger.info("✓ Azure OpenAI client retrieved from app.extensions")
                return client
            else:
                logger.info("⚠️ openai_client in app.extensions is None")
                return None
        
        logger.info("⚠️ openai_client not in app.extensions")
        return None
    
    except Exception as e:
        logger.warning(f"⚠️ Failed to get LLM client: {e}")
        return None


def get_rag_service():
    """Get or initialize RAG service with detailed error handling"""
    
    # ✅ Check if already cached
    if hasattr(current_app, 'rag_service') and current_app.rag_service is not None:
        logger.info("✓ RAG service already cached")
        return current_app.rag_service
    
    try:
        logger.info("\n" + "="*80)
        logger.info("🚀 Initializing RAG Service...")
        logger.info("="*80)
        
        # Step 1: Import the service
        logger.info("\n📋 Step 1: Importing HybridRAGService...")
        try:
            from backend.services.hybrid_rag_service import HybridRAGService
            logger.info("✓ HybridRAGService imported successfully")
        except ImportError as ie:
            logger.error(f"❌ Cannot import HybridRAGService: {ie}")
            logger.error(f"   Check: services/hybrid_rag_service.py exists?")
            logger.error(f"   Check: Python path includes services/")
            current_app.rag_service = None
            return None
        except Exception as e:
            logger.error(f"❌ Error importing HybridRAGService: {e}")
            logger.error(traceback.format_exc())
            current_app.rag_service = None
            return None
        
        # Step 2: Get database connection
        logger.info("\n📋 Step 2: Getting database connection...")
        db = get_db()
        if db is None:
            logger.error("❌ Database connection is None")
            logger.error("   Check: services/database.py has get_db_connection()?")
            logger.error("   Check: Database is initialized?")
            current_app.rag_service = None
            return None
        logger.info("✓ Database connection obtained")
        
        # Step 3: Get LLM client
        logger.info("\n📋 Step 3: Getting LLM client...")
        llm_client = get_llm_client()
        if llm_client:
            logger.info("✓ LLM client available")
        else:
            logger.info("⚠️ LLM client not available (optional, will work without it)")
        
        # Step 4: Get configuration
        logger.info("\n📋 Step 4: Getting Flask configuration...")
        cfg = current_app.config
        if not cfg:
            logger.error("❌ App config is None")
            current_app.rag_service = None
            return None
        logger.info("✓ Configuration obtained")
        
        # Step 5: Create RAG service
        logger.info("\n📋 Step 5: Creating HybridRAGService instance...")
        try:
            logger.info("   Creating with:")
            logger.info(f"   - db_connection: {type(db).__name__}")
            logger.info(f"   - openai_client: {type(llm_client).__name__ if llm_client else 'None'}")
            logger.info(f"   - config: {type(cfg).__name__}")
            
            current_app.rag_service = HybridRAGService(
                db_connection=db,
                openai_client=llm_client,
                config={'flask_config': cfg}
            )
            
            logger.info("✅ RAG Service initialized successfully!")
            logger.info("="*80 + "\n")
            return current_app.rag_service
        
        except Exception as rag_err:
            logger.error(f"❌ HybridRAGService initialization failed!")
            logger.error(f"   Error type: {type(rag_err).__name__}")
            logger.error(f"   Error message: {str(rag_err)}")
            logger.error(f"   Full traceback:")
            logger.error(traceback.format_exc())
            
            # Try to extract more info
            logger.error("\n   Debugging info:")
            logger.error(f"   - db type: {type(db)}")
            logger.error(f"   - llm_client type: {type(llm_client)}")
            logger.error(f"   - config type: {type(cfg)}")
            
            current_app.rag_service = None
            return None
    
    except Exception as e:
        logger.error(f"❌ Unexpected error in get_rag_service!")
        logger.error(f"   Error: {e}")
        logger.error(f"   Type: {type(e).__name__}")
        logger.error(traceback.format_exc())
        current_app.rag_service = None
        return None


def get_llm_formatted_response(question: str, context: str) -> Optional[str]:
    """Get formatted response from LLM"""
    try:
        llm_client = get_llm_client()
        
        if not llm_client:
            logger.warning("⚠️ LLM client not available")
            return None
        
        cfg = current_app.config
        deployment = cfg.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
        
        logger.info("🧠 Sending to Azure OpenAI for formatting...")
        logger.info(f"   Question: {question[:80]}")
        logger.info(f"   Context length: {len(context)} chars")
        
        # Build message
        user_content = f"Question: {question}\n\nData: {context}\n\nBriefly answer the question using the data above."
        
        logger.info(f"   Prompt length: {len(user_content)} chars")
        
        response = llm_client.chat.completions.create(
            model=deployment,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant for querying an integration interface catalog. Be concise and professional."
                },
                {
                    "role": "user",
                    "content": user_content
                }
            ],
            max_completion_tokens=200
        )
        
        logger.info(f"   ✓ Response received")
        
        if response.choices[0].finish_reason == 'length':
            logger.warning("⚠️ Response truncated (token limit)")
        
        if not response or not response.choices:
            logger.warning("⚠️ No response choices")
            return None
        
        message = response.choices[0].message
        if not message:
            logger.warning("⚠️ No message object")
            return None
        
        answer = message.content if hasattr(message, 'content') else str(message)
        
        if not answer or not answer.strip():
            logger.warning("⚠️ LLM returned empty response")
            return None
        
        logger.info(f"   ✓ Response: {len(answer)} chars")
        return answer.strip()
    
    except Exception as e:
        logger.warning(f"⚠️ LLM formatting failed: {e}")
        return None

# ============================================================================
# DIAGNOSTIC ENDPOINTS
# ============================================================================

@chat_bp.route('/pre-check', methods=['GET'])
def pre_check():
    """Pre-flight diagnostic check for chat system"""
    logger.info("\n" + "="*80)
    logger.info("🔍 PRE-CHECK DIAGNOSTIC")
    logger.info("="*80)
    
    checks = {
        'database': False,
        'rag_service': False,
        'llm_client': False,
        'services_available': False,
        'errors': [],
        'timestamp': datetime.utcnow().isoformat()
    }
    
    # Check database
    logger.info("\n1. Checking database...")
    try:
        db = get_db()
        checks['database'] = db is not None
        if checks['database']:
            logger.info("   ✓ Database OK")
        else:
            logger.warning("   ❌ Database is None")
            checks['errors'].append('Database connection returned None')
    except Exception as e:
        logger.error(f"   ❌ Database error: {e}")
        checks['errors'].append(f'Database error: {str(e)}')
    
    # Check RAG service
    logger.info("\n2. Checking RAG service...")
    try:
        rag = get_rag_service()
        checks['rag_service'] = rag is not None
        if checks['rag_service']:
            logger.info("   ✓ RAG Service OK")
        else:
            logger.warning("   ❌ RAG service is None")
            checks['errors'].append('RAG service is None - check logs above')
    except Exception as e:
        logger.error(f"   ❌ RAG service error: {e}")
        checks['errors'].append(f'RAG service error: {str(e)}')
    
    # Check LLM
    logger.info("\n3. Checking LLM client...")
    try:
        llm = get_llm_client()
        checks['llm_client'] = llm is not None
        if checks['llm_client']:
            logger.info("   ✓ LLM Client OK")
        else:
            logger.info("   ⚠️ LLM client not available (optional)")
    except Exception as e:
        logger.error(f"   ❌ LLM error: {e}")
        checks['errors'].append(f'LLM error: {str(e)}')
    
    checks['services_available'] = checks['database'] and checks['rag_service']
    
    if checks['services_available']:
        logger.info("\n✅ ALL SYSTEMS READY")
    else:
        logger.error("\n❌ SOME SYSTEMS UNAVAILABLE - Check errors above")
    
    logger.info("="*80 + "\n")
    
    return jsonify(checks), 200

# ============================================================================
# MAIN ROUTES
# ============================================================================

@chat_bp.route('/send_message', methods=['POST'])
def send_message():
    """Process chat message with Hybrid RAG + LLM"""
    try:
        logger.info("\n" + "="*80)
        logger.info("🔵 SEND_MESSAGE ENDPOINT CALLED")
        logger.info("="*80)
        
        # Step 1: Get message
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No JSON data provided'}), 400
        
        user_message = data.get('message', '').strip()
        logger.info(f"✓ Received message: {user_message[:100]}")
        
        if not user_message:
            return jsonify({'success': False, 'error': 'Message cannot be empty'}), 400
        
        # Step 2: Initialize RAG service (with crash protection)
        logger.info("📋 Initializing RAG Service...")
        try:
            rag_service = get_rag_service()
        except Exception as rag_init_err:
            logger.error(f"❌ RAG service init crashed: {rag_init_err}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'RAG service initialization failed: {str(rag_init_err)[:100]}',
                'response': 'Sorry, the AI service is temporarily unavailable. Please try again.'
            }), 500
        
        if rag_service is None:
            logger.error("❌ RAG service is None")
            return jsonify({
                'success': False,
                'error': 'RAG service unavailable',
                'response': 'Sorry, the AI service is not available right now.'
            }), 500
        
        logger.info("✓ RAG service ready")
        
        # Step 3: Process with RAG (with crash protection)
        logger.info(f"📋 Processing question: {user_message}")
        try:
            rag_result = rag_service.process_question(user_message)
        except Exception as process_err:
            logger.error(f"❌ RAG processing crashed: {process_err}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'Processing failed: {str(process_err)[:100]}',
                'response': 'Sorry, I encountered an error processing your question. Please try again.'
            }), 500
        
        if not rag_result:
            return jsonify({
                'success': False,
                'error': 'No result from RAG',
                'response': 'Sorry, I could not process your question.'
            }), 500
        
        answer = rag_result.get('answer', 'No answer')
        method = rag_result.get('method', 'unknown')
        
        logger.info(f"✓ RAG answer: {answer[:100]}")
        logger.info(f"✓ RAG method: {method}")
        
        return jsonify({
            'success': True,
            'response': answer,
            'metadata': {
                'method': method,
                'processing_time': rag_result.get('performance', {}).get('processing_time_seconds', 0)
            }
        }), 200
    
    except Exception as e:
        logger.error(f"❌ send_message crashed: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e),
            'response': 'Sorry, an unexpected error occurred.'
        }), 500

@chat_bp.route('/upload', methods=['POST', 'OPTIONS'])
def upload_file():
    """Upload Excel file with automatic column mapping"""
    
    if request.method == 'OPTIONS':
        return '', 204
    
    try:
        logger.info("📁 Upload request received")
        
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400
        
        file = request.files['file']
        if not file or file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400
        
        filename = file.filename.lower()
        if not filename.endswith(('.xlsx', '.xls', '.csv')):
            return jsonify({'success': False, 'error': 'Only Excel or CSV files allowed'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        logger.info(f"✅ File saved: {filepath}")
        
        # Get database and RAG service
        db = get_db()
        if db is None:
            return jsonify({'success': False, 'error': 'Database connection failed'}), 500
        
        rag_service = get_rag_service()
        if rag_service is None:
            return jsonify({'success': False, 'error': 'RAG service unavailable'}), 500
        
        # Use DataImportService for column mapping
        try:
            from backend.services.data_import_service import DataImportService
            
            logger.info("🔄 Using DataImportService for column mapping...")
            import_service = DataImportService(db, rag_service)
            
            result = import_service.import_excel_file(filepath)
            
            logger.info(f"✅ Import complete: {result['inserted_rows']} rows, {result['embeddings_created']} embeddings")
            
            return jsonify({
                'success': True,
                'message': 'Data uploaded and processed successfully',
                'details': {
                    'inserted_rows': result['inserted_rows'],
                    'failed_rows': result['skipped_rows'],
                    'total_embeddings': result['embeddings_created'],
                    'file_name': filename,
                    'timestamp': result['timestamp']
                }
            }), 200
        
        except Exception as import_err:
            logger.error(f"❌ Import service failed: {import_err}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'Import failed: {str(import_err)}'
            }), 500
    
    except Exception as e:
        logger.error(f"❌ Upload error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/stats', methods=['GET'])
def stats():
    """Get statistics"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database'}), 500
        
        from sqlalchemy import text
        schema = get_db_schema()  # ✅ NEW: Get schema
        
        # ✅ FIXED: Use schema prefix
        result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
        total_interfaces = result.scalar() or 0
        
        result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.interface_embeddings"))
        total_embeddings = result.scalar() or 0
        
        llm_client = get_llm_client()
        
        return jsonify({
            'success': True,
            'stats': {
                'total_interfaces': total_interfaces,
                'total_embeddings': total_embeddings,
                'rag_available': True,
                'llm_enabled': llm_client is not None
            }
        }), 200
    
    except Exception as e:
        logger.error(f"❌ Stats error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/health', methods=['GET'])
def health():
    """System health check - CRASH PROTECTED"""
    try:
        logger.info("🏥 Health check starting...")
        
        # Check database (safe)
        db_status = 'unavailable'
        try:
            db = get_db()
            if db:
                from sqlalchemy import text
                schema = get_db_schema()
                db.execute(text(f"SELECT 1"))
                db_status = 'healthy'
        except Exception as db_err:
            logger.error(f"❌ DB check failed: {db_err}")
            db_status = 'error'
        
        # Check LLM (safe)  
        llm_status = 'unavailable'
        try:
            llm_client = get_llm_client()
            llm_status = 'healthy' if llm_client else 'unavailable'
        except Exception as llm_err:
            logger.error(f"❌ LLM check failed: {llm_err}")
            llm_status = 'error'
        
        # Skip RAG service check - it's causing the crash
        # Just check if it's cached
        rag_status = 'unavailable'
        try:
            if hasattr(current_app, 'rag_service') and current_app.rag_service:
                rag_status = 'healthy'
            else:
                rag_status = 'not_initialized'
        except:
            rag_status = 'error'
        
        overall = 'healthy' if db_status == 'healthy' else 'degraded'
        
        logger.info(f"🏥 Health check complete: {overall}")
        
        return jsonify({
            'status': overall,
            'components': {
                'database': db_status,
                'rag_service': rag_status,
                'llm': llm_status
            },
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"❌ Health check crashed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500
    
@chat_bp.route('/llm-status', methods=['GET'])
def llm_status():
    """Check LLM status"""
    try:
        llm_client = get_llm_client()
        cfg = current_app.config
        
        return jsonify({
            'llm_enabled': llm_client is not None,
            'api_key_configured': bool(cfg.get('AZURE_OPENAI_API_KEY')),
            'endpoint_configured': bool(cfg.get('AZURE_OPENAI_ENDPOINT')),
            'deployment': cfg.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo'),
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"❌ LLM status error: {e}")
        return jsonify({'llm_enabled': False, 'error': str(e)})


@chat_bp.route('/clear-data', methods=['POST'])
def clear_data():
    """Clear all data"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database'}), 500
        
        from sqlalchemy import text
        schema = get_db_schema()  # ✅ NEW: Get schema
        
        # ✅ FIXED: Use schema prefix
        db.execute(text(f"DELETE FROM {schema}.interface_embeddings"))
        db.execute(text(f"DELETE FROM {schema}.integration_interfaces"))
        db.commit()
        
        logger.info("✅ Data cleared")
        return jsonify({'success': True, 'message': 'Data cleared'}), 200
    
    except Exception as e:
        logger.error(f"❌ Clear error: {e}")
        try:
            db.rollback()
        except:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# EXPORT & LOGGING
# ============================================================================

logger.info("✅ Chat blueprint loaded successfully")
logger.info("   Routes configured:")
logger.info("     GET  /chat/pre-check          - Diagnostic check")
logger.info("     POST /chat/send_message       - Send message (WITH LLM)")
logger.info("     GET  /chat/stats              - Statistics")
logger.info("     GET  /chat/health             - Health check")
logger.info("     GET  /chat/llm-status         - LLM status")
logger.info("     POST /chat/upload             - Upload file")
logger.info("     POST /chat/clear-data         - Clear data")
logger.info("   ✅ DB_SCHEMA (igpt) support added to all queries!")

__all__ = ['chat_bp']