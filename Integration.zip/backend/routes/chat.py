"""
Chat Routes - WITH IMPROVED RAG SERVICE INITIALIZATION
WITH DETAILED ERROR HANDLING & DIAGNOSTICS
✅ FIXED: Added DB_SCHEMA (igpt) support to all SQL queries
✅ SECURITY: Added JWT authentication to all protected endpoints
"""

from flask import Blueprint, request, jsonify, current_app
from sqlalchemy import text
import logging
from werkzeug.utils import secure_filename
import os
from datetime import datetime
from typing import Dict, Any, Optional
import traceback
from functools import wraps

logger = logging.getLogger(__name__)


# ============================================================================
# AUTHENTICATION DECORATOR
# ============================================================================

def get_auth_modules():
    """Lazy load auth modules to avoid circular imports"""
    try:
        from backend.auth.auth import verify_jwt_token
        from backend.auth.auth_models import User
        return verify_jwt_token, User
    except ImportError:
        try:
            from auth.auth import verify_jwt_token
            from auth.auth_models import User
            return verify_jwt_token, User
        except ImportError as e:
            logger.error(f"❌ Could not import auth modules: {e}")
            raise


def token_required(f):
    """Decorator to require valid JWT token for API endpoints"""
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            verify_jwt_token, User = get_auth_modules()

            # Get token from Authorization header
            auth_header = request.headers.get('Authorization', '')
            if not auth_header.startswith('Bearer '):
                logger.warning("❌ No Bearer token in Authorization header")
                return jsonify({
                    'success': False,
                    'error': 'Authorization header with Bearer token required'
                }), 401

            token = auth_header[7:]  # Remove 'Bearer ' prefix

            # Verify token
            payload, error = verify_jwt_token(token)
            if error:
                logger.warning(f"❌ Token verification failed: {error}")
                return jsonify({
                    'success': False,
                    'error': 'Invalid or expired token'
                }), 401

            user_id = payload.get('user_id')
            if not user_id:
                return jsonify({
                    'success': False,
                    'error': 'Invalid token payload'
                }), 401

            # Store user_id in request context for use in endpoints
            request.user_id = user_id
            request.user_email = payload.get('email')

            return f(*args, **kwargs)

        except Exception as e:
            logger.error(f"❌ Authentication error: {e}", exc_info=True)
            return jsonify({
                'success': False,
                'error': 'Authentication error'
            }), 500

    return decorated

# ============================================================================
# CREATE BLUEPRINT
# ============================================================================

chat_bp = Blueprint('chat', __name__, url_prefix='/chat')

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    Get schema from Flask config (reads from .env via config.py)

    Returns:
        Schema name from DB_SCHEMA env variable
    """
    try:
        return current_app.config.get('DB_SCHEMA', 'public')
    except RuntimeError:
        # Outside application context, read from env directly
        import os
        return os.getenv('DB_SCHEMA', 'public')


def get_db():
    """Get database connection"""
    try:
        from backend.services.database import get_db_connection
        db = get_db_connection()
        if db:
            logger.info("✓ Database connection obtained")
        else:
            logger.warning("⚠️ get_db_connection returned None")
        return db
    except ImportError as ie:
        logger.error(f"❌ Cannot import get_db_connection: {ie}")
        return None
    except Exception as e:
        logger.warning(f"⚠️ Database connection failed: {e}")
        return None


def get_llm_client():
    """Get Azure OpenAI client from app.extensions"""
    try:
        # ✅ GET FROM APP.EXTENSIONS (initialized in app.py)
        if hasattr(current_app, 'extensions') and 'openai_client' in current_app.extensions:
            client = current_app.extensions['openai_client']
            if client is not None:
                logger.info("✓ Azure OpenAI client retrieved from app.extensions")
                return client
            else:
                logger.info("⚠️ openai_client in app.extensions is None")
                return None
        
        logger.info("⚠️ openai_client not in app.extensions")
        return None
    
    except Exception as e:
        logger.warning(f"⚠️ Failed to get LLM client: {e}")
        return None


def get_rag_service():
    """Get or initialize RAG service with detailed error handling"""
    
    # ✅ Check if already cached
    if hasattr(current_app, 'rag_service') and current_app.rag_service is not None:
        logger.info("✓ RAG service already cached")
        return current_app.rag_service
    
    try:
        logger.info("\n" + "="*80)
        logger.info("🚀 Initializing RAG Service...")
        logger.info("="*80)
        
        # Step 1: Import the service
        logger.info("\n📋 Step 1: Importing HybridRAGService...")
        try:
            from backend.services.hybrid_rag_service import HybridRAGService
            logger.info("✓ HybridRAGService imported successfully")
        except ImportError as ie:
            logger.error(f"❌ Cannot import HybridRAGService: {ie}")
            logger.error(f"   Check: services/hybrid_rag_service.py exists?")
            logger.error(f"   Check: Python path includes services/")
            current_app.rag_service = None
            return None
        except Exception as e:
            logger.error(f"❌ Error importing HybridRAGService: {e}")
            logger.error(traceback.format_exc())
            current_app.rag_service = None
            return None
        
        # Step 2: Get database connection
        logger.info("\n📋 Step 2: Getting database connection...")
        db = get_db()
        if db is None:
            logger.error("❌ Database connection is None")
            logger.error("   Check: services/database.py has get_db_connection()?")
            logger.error("   Check: Database is initialized?")
            current_app.rag_service = None
            return None
        logger.info("✓ Database connection obtained")
        
        # Step 3: Get LLM client
        logger.info("\n📋 Step 3: Getting LLM client...")
        llm_client = get_llm_client()
        if llm_client:
            logger.info("✓ LLM client available")
        else:
            logger.info("⚠️ LLM client not available (optional, will work without it)")
        
        # Step 4: Get configuration
        logger.info("\n📋 Step 4: Getting Flask configuration...")
        cfg = current_app.config
        if not cfg:
            logger.error("❌ App config is None")
            current_app.rag_service = None
            return None
        logger.info("✓ Configuration obtained")
        
        # Step 5: Create RAG service
        logger.info("\n📋 Step 5: Creating HybridRAGService instance...")
        try:
            logger.info("   Creating with:")
            logger.info(f"   - db_connection: {type(db).__name__}")
            logger.info(f"   - openai_client: {type(llm_client).__name__ if llm_client else 'None'}")
            logger.info(f"   - config: {type(cfg).__name__}")
            
            current_app.rag_service = HybridRAGService(
                db_connection=db,
                openai_client=llm_client,
                config={'flask_config': cfg}
            )
            
            logger.info("✅ RAG Service initialized successfully!")
            logger.info("="*80 + "\n")
            return current_app.rag_service
        
        except Exception as rag_err:
            logger.error(f"❌ HybridRAGService initialization failed!")
            logger.error(f"   Error type: {type(rag_err).__name__}")
            logger.error(f"   Error message: {str(rag_err)}")
            logger.error(f"   Full traceback:")
            logger.error(traceback.format_exc())
            
            # Try to extract more info
            logger.error("\n   Debugging info:")
            logger.error(f"   - db type: {type(db)}")
            logger.error(f"   - llm_client type: {type(llm_client)}")
            logger.error(f"   - config type: {type(cfg)}")
            
            current_app.rag_service = None
            return None
    
    except Exception as e:
        logger.error(f"❌ Unexpected error in get_rag_service!")
        logger.error(f"   Error: {e}")
        logger.error(f"   Type: {type(e).__name__}")
        logger.error(traceback.format_exc())
        current_app.rag_service = None
        return None


def get_llm_formatted_response(question: str, context: str) -> Optional[str]:
    """Get formatted response from LLM"""
    try:
        llm_client = get_llm_client()
        
        if not llm_client:
            logger.warning("⚠️ LLM client not available")
            return None
        
        cfg = current_app.config
        deployment = cfg.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo')
        
        logger.info("🧠 Sending to Azure OpenAI for formatting...")
        logger.info(f"   Question: {question[:80]}")
        logger.info(f"   Context length: {len(context)} chars")
        
        # Build message
        user_content = f"Question: {question}\n\nData: {context}\n\nBriefly answer the question using the data above."
        
        logger.info(f"   Prompt length: {len(user_content)} chars")
        
        response = llm_client.chat.completions.create(
            model=deployment,
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful assistant for querying an integration interface catalog. Be concise and professional."
                },
                {
                    "role": "user",
                    "content": user_content
                }
            ],
            max_completion_tokens=200
        )
        
        logger.info(f"   ✓ Response received")
        
        if response.choices[0].finish_reason == 'length':
            logger.warning("⚠️ Response truncated (token limit)")
        
        if not response or not response.choices:
            logger.warning("⚠️ No response choices")
            return None
        
        message = response.choices[0].message
        if not message:
            logger.warning("⚠️ No message object")
            return None
        
        answer = message.content if hasattr(message, 'content') else str(message)
        
        if not answer or not answer.strip():
            logger.warning("⚠️ LLM returned empty response")
            return None
        
        logger.info(f"   ✓ Response: {len(answer)} chars")
        return answer.strip()
    
    except Exception as e:
        logger.warning(f"⚠️ LLM formatting failed: {e}")
        return None

# ============================================================================
# DIAGNOSTIC ENDPOINTS
# ============================================================================

@chat_bp.route('/pre-check', methods=['GET'])
def pre_check():
    """Pre-flight diagnostic check for chat system"""
    logger.info("\n" + "="*80)
    logger.info("🔍 PRE-CHECK DIAGNOSTIC")
    logger.info("="*80)
    
    checks = {
        'database': False,
        'rag_service': False,
        'llm_client': False,
        'services_available': False,
        'errors': [],
        'timestamp': datetime.utcnow().isoformat()
    }
    
    # Check database
    logger.info("\n1. Checking database...")
    try:
        db = get_db()
        checks['database'] = db is not None
        if checks['database']:
            logger.info("   ✓ Database OK")
        else:
            logger.warning("   ❌ Database is None")
            checks['errors'].append('Database connection returned None')
    except Exception as e:
        logger.error(f"   ❌ Database error: {e}")
        checks['errors'].append(f'Database error: {str(e)}')
    
    # Check RAG service
    logger.info("\n2. Checking RAG service...")
    try:
        rag = get_rag_service()
        checks['rag_service'] = rag is not None
        if checks['rag_service']:
            logger.info("   ✓ RAG Service OK")
        else:
            logger.warning("   ❌ RAG service is None")
            checks['errors'].append('RAG service is None - check logs above')
    except Exception as e:
        logger.error(f"   ❌ RAG service error: {e}")
        checks['errors'].append(f'RAG service error: {str(e)}')
    
    # Check LLM
    logger.info("\n3. Checking LLM client...")
    try:
        llm = get_llm_client()
        checks['llm_client'] = llm is not None
        if checks['llm_client']:
            logger.info("   ✓ LLM Client OK")
        else:
            logger.info("   ⚠️ LLM client not available (optional)")
    except Exception as e:
        logger.error(f"   ❌ LLM error: {e}")
        checks['errors'].append(f'LLM error: {str(e)}')
    
    checks['services_available'] = checks['database'] and checks['rag_service']
    
    if checks['services_available']:
        logger.info("\n✅ ALL SYSTEMS READY")
    else:
        logger.error("\n❌ SOME SYSTEMS UNAVAILABLE - Check errors above")
    
    logger.info("="*80 + "\n")
    
    return jsonify(checks), 200

# ============================================================================
# MAIN ROUTES
# ============================================================================

@chat_bp.route('/send_message', methods=['POST'])
@token_required
def send_message():
    """Process chat message with Hybrid RAG + LLM (requires authentication)"""
    try:
        logger.info("\n" + "="*80)
        logger.info("🔵 SEND_MESSAGE ENDPOINT CALLED")
        logger.info("="*80)

        # Step 1: Get message and pagination params
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No JSON data provided'}), 400

        user_message = data.get('message', '').strip()
        offset = data.get('offset', 0)  # Pagination offset
        limit = data.get('limit', 50)   # Results per page
        logger.info(f"✓ Received message: {user_message[:100]}")
        logger.info(f"✓ Pagination: offset={offset}, limit={limit}")

        if not user_message:
            return jsonify({'success': False, 'error': 'Message cannot be empty'}), 400

        # Step 2: Initialize RAG service (with crash protection)
        logger.info("📋 Initializing RAG Service...")
        try:
            rag_service = get_rag_service()
        except Exception as rag_init_err:
            logger.error(f"❌ RAG service init crashed: {rag_init_err}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'RAG service initialization failed: {str(rag_init_err)[:100]}',
                'response': 'Sorry, the AI service is temporarily unavailable. Please try again.'
            }), 500

        if rag_service is None:
            logger.error("❌ RAG service is None")
            return jsonify({
                'success': False,
                'error': 'RAG service unavailable',
                'response': 'Sorry, the AI service is not available right now.'
            }), 500

        logger.info("✓ RAG service ready")

        # Step 3: Process with RAG (with crash protection)
        logger.info(f"📋 Processing question: {user_message}")
        try:
            # Pass pagination params to RAG service
            rag_result = rag_service.process_question(user_message, offset=offset, limit=limit)
        except Exception as process_err:
            logger.error(f"❌ RAG processing crashed: {process_err}", exc_info=True)
            return jsonify({
                'success': False,
                'error': f'Processing failed: {str(process_err)[:100]}',
                'response': 'Sorry, I encountered an error processing your question. Please try again.'
            }), 500

        if not rag_result:
            return jsonify({
                'success': False,
                'error': 'No result from RAG',
                'response': 'Sorry, I could not process your question.'
            }), 500

        answer = rag_result.get('answer', 'No answer')
        method = rag_result.get('method', 'unknown')

        logger.info(f"✓ RAG answer: {answer[:100]}")
        logger.info(f"✓ RAG method: {method}")

        return jsonify({
            'success': True,
            'response': answer,
            'metadata': {
                'method': method,
                'processing_time': rag_result.get('performance', {}).get('processing_time_seconds', 0),
                'pagination': {
                    'offset': offset,
                    'limit': limit
                }
            }
        }), 200
    
    except Exception as e:
        logger.error(f"❌ send_message crashed: {e}", exc_info=True)
        return jsonify({
            'success': False,
            'error': str(e),
            'response': 'Sorry, an unexpected error occurred.'
        }), 500

@chat_bp.route('/upload', methods=['POST', 'OPTIONS'])
@token_required
def upload_file():
    """Upload Excel file with automatic column mapping (requires authentication)"""
    
    if request.method == 'OPTIONS':
        return '', 204
    
    try:
        logger.info("📁 Upload request received")
        
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No file provided'}), 400
        
        file = request.files['file']
        if not file or file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'}), 400
        
        filename = file.filename.lower()
        if not filename.endswith(('.xlsx', '.xls', '.csv')):
            return jsonify({'success': False, 'error': 'Only Excel or CSV files allowed'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        logger.info(f"✅ File saved: {filepath}")
        
        # Get database and RAG service
        db = get_db()
        if db is None:
            return jsonify({'success': False, 'error': 'Database connection failed'}), 500
        
        rag_service = get_rag_service()
        if rag_service is None:
            return jsonify({'success': False, 'error': 'RAG service unavailable'}), 500
        
        # Use DataImportService for column mapping
        try:
            from backend.services.data_import_service import DataImportService
            import time

            logger.info("🔄 Using DataImportService for column mapping...")
            import_service = DataImportService(db, rag_service)

            start_time = time.time()
            result = import_service.import_excel_file(filepath)
            processing_time = int((time.time() - start_time) * 1000)

            logger.info(f"✅ Import complete: {result['inserted_rows']} rows, {result['embeddings_created']} embeddings")

            # Get file info
            file_size = os.path.getsize(filepath)
            file_ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else 'unknown'

            # Get user_id from JWT token
            user_id = 1  # Default user
            try:
                from flask_jwt_extended import get_jwt_identity
                jwt_user_id = get_jwt_identity()
                if jwt_user_id:
                    user_id = jwt_user_id
            except:
                pass

            # Save to import history
            save_import_history(
                db=db,
                user_id=user_id,
                filename=filename,
                file_size=file_size,
                file_type=file_ext,
                rows_imported=result['inserted_rows'],
                embeddings_created=result['embeddings_created'],
                status='success',
                processing_time_ms=processing_time
            )

            return jsonify({
                'success': True,
                'message': 'Data uploaded and processed successfully',
                'details': {
                    'inserted_rows': result['inserted_rows'],
                    'failed_rows': result['skipped_rows'],
                    'total_embeddings': result['embeddings_created'],
                    'file_name': filename,
                    'timestamp': result['timestamp']
                }
            }), 200

        except Exception as import_err:
            logger.error(f"❌ Import service failed: {import_err}", exc_info=True)

            # Save failed import to history
            try:
                file_size = os.path.getsize(filepath) if os.path.exists(filepath) else 0
                file_ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else 'unknown'
                user_id = 1
                try:
                    from flask_jwt_extended import get_jwt_identity
                    jwt_user_id = get_jwt_identity()
                    if jwt_user_id:
                        user_id = jwt_user_id
                except:
                    pass

                save_import_history(
                    db=db,
                    user_id=user_id,
                    filename=filename,
                    file_size=file_size,
                    file_type=file_ext,
                    rows_imported=0,
                    embeddings_created=0,
                    status='failed',
                    error_message=str(import_err)
                )
            except:
                pass

            return jsonify({
                'success': False,
                'error': f'Import failed: {str(import_err)}'
            }), 500
    
    except Exception as e:
        logger.error(f"❌ Upload error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/stats', methods=['GET'])
@token_required
def stats():
    """Get statistics (requires authentication)"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database'}), 500

        from sqlalchemy import text
        schema = get_db_schema()  # ✅ NEW: Get schema

        # ✅ FIXED: Use schema prefix
        result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
        total_interfaces = result.scalar() or 0

        result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.interface_embeddings"))
        total_embeddings = result.scalar() or 0

        # Get total records from import history
        result = db.execute(text(f"SELECT COALESCE(SUM(rows_imported), 0) FROM {schema}.import_history WHERE status = 'success'"))
        total_records = result.scalar() or 0

        # Get total imports count
        result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.import_history"))
        total_imports = result.scalar() or 0

        llm_client = get_llm_client()

        return jsonify({
            'success': True,
            'stats': {
                'total_interfaces': total_interfaces,
                'total_embeddings': total_embeddings,
                'total_records': total_records,
                'total_tables': total_imports,
                'rag_available': True,
                'llm_enabled': llm_client is not None
            }
        }), 200

    except Exception as e:
        logger.error(f"❌ Stats error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# IMPORT HISTORY ENDPOINTS
# ============================================================================

@chat_bp.route('/import-history', methods=['GET'])
@token_required
def get_import_history():
    """Get import history for the current user (requires authentication)"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database'}), 500

        schema = get_db_schema()

        # Get user_id from JWT token if available, otherwise get all (for now)
        user_id = None
        try:
            from flask_jwt_extended import get_jwt_identity
            user_id = get_jwt_identity()
        except:
            pass

        # Build query
        if user_id:
            query = text(f"""
                SELECT id, filename, file_size, file_type, rows_imported,
                       embeddings_created, status, error_message, processing_time_ms,
                       created_at AT TIME ZONE 'America/Los_Angeles' as created_at
                FROM {schema}.import_history
                WHERE user_id = :user_id
                ORDER BY created_at DESC
                LIMIT 50
            """)
            result = db.execute(query, {'user_id': user_id})
        else:
            query = text(f"""
                SELECT id, filename, file_size, file_type, rows_imported,
                       embeddings_created, status, error_message, processing_time_ms,
                       created_at AT TIME ZONE 'America/Los_Angeles' as created_at
                FROM {schema}.import_history
                ORDER BY created_at DESC
                LIMIT 50
            """)
            result = db.execute(query)

        history = []
        for row in result:
            history.append({
                'id': row.id,
                'fileName': row.filename,
                'fileSize': row.file_size,
                'fileType': row.file_type,
                'rows': row.rows_imported,
                'embeddings': row.embeddings_created,
                'success': row.status == 'success',
                'status': row.status,
                'errorMessage': row.error_message,
                'processingTime': row.processing_time_ms,
                'timestamp': row.created_at.isoformat() if row.created_at else None
            })

        return jsonify({
            'success': True,
            'history': history
        }), 200

    except Exception as e:
        logger.error(f"❌ Import history error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


def save_import_history(db, user_id: int, filename: str, file_size: int, file_type: str,
                        rows_imported: int, embeddings_created: int, status: str,
                        error_message: str = None, processing_time_ms: int = None):
    """Save import record to database"""
    try:
        schema = get_db_schema()
        query = text(f"""
            INSERT INTO {schema}.import_history
            (user_id, filename, file_size, file_type, rows_imported, embeddings_created,
             status, error_message, processing_time_ms)
            VALUES (:user_id, :filename, :file_size, :file_type, :rows_imported,
                    :embeddings_created, :status, :error_message, :processing_time_ms)
            RETURNING id
        """)
        result = db.execute(query, {
            'user_id': user_id,
            'filename': filename,
            'file_size': file_size,
            'file_type': file_type,
            'rows_imported': rows_imported,
            'embeddings_created': embeddings_created,
            'status': status,
            'error_message': error_message,
            'processing_time_ms': processing_time_ms
        })
        db.commit()
        return result.scalar()
    except Exception as e:
        logger.error(f"❌ Failed to save import history: {e}")
        return None


# ============================================================================
# RAG ANALYTICS ENDPOINT
# ============================================================================

@chat_bp.route('/rag-analytics', methods=['GET'])
@token_required
def get_rag_analytics():
    """Get comprehensive RAG system analytics from database (requires authentication)"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database connection'}), 500

        schema = get_db_schema()
        analytics = {}

        # 1. RAG Query Statistics (from rag_query_logs)
        try:
            query_stats = db.execute(text(f"""
                SELECT
                    COUNT(*) as total_queries,
                    COUNT(CASE WHEN status = 'success' THEN 1 END) as successful_queries,
                    COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_queries,
                    COALESCE(AVG(execution_time_ms), 0) as avg_execution_time_ms,
                    COALESCE(SUM(tokens_used), 0) as total_tokens_used,
                    COALESCE(AVG(tokens_used), 0) as avg_tokens_per_query
                FROM {schema}.rag_query_logs
                WHERE created_at >= NOW() - INTERVAL '30 days'
            """)).fetchone()

            analytics['queryStats'] = {
                'totalQueries': int(query_stats.total_queries or 0),
                'successfulQueries': int(query_stats.successful_queries or 0),
                'failedQueries': int(query_stats.failed_queries or 0),
                'successRate': round((query_stats.successful_queries / query_stats.total_queries * 100), 1) if query_stats.total_queries > 0 else 0,
                'avgExecutionTimeMs': round(float(query_stats.avg_execution_time_ms or 0), 1),
                'totalTokensUsed': int(query_stats.total_tokens_used or 0),
                'avgTokensPerQuery': round(float(query_stats.avg_tokens_per_query or 0), 1)
            }
        except Exception as e:
            logger.warning(f"Query stats error: {e}")
            analytics['queryStats'] = {
                'totalQueries': 0, 'successfulQueries': 0, 'failedQueries': 0,
                'successRate': 0, 'avgExecutionTimeMs': 0, 'totalTokensUsed': 0, 'avgTokensPerQuery': 0
            }

        # 2. Query Type Distribution (direct_llm, sql_first, hybrid)
        try:
            query_types = db.execute(text(f"""
                SELECT
                    query_type,
                    COUNT(*) as count
                FROM {schema}.rag_query_logs
                WHERE created_at >= NOW() - INTERVAL '30 days'
                GROUP BY query_type
                ORDER BY count DESC
            """)).fetchall()

            analytics['queryTypeDistribution'] = [
                {'type': row.query_type or 'unknown', 'count': int(row.count)}
                for row in query_types
            ]
        except Exception as e:
            logger.warning(f"Query type distribution error: {e}")
            analytics['queryTypeDistribution'] = []

        # 3. Embedding Statistics
        try:
            embedding_stats = db.execute(text(f"""
                SELECT
                    COUNT(*) as total_embeddings,
                    COUNT(DISTINCT interface_id) as interfaces_with_embeddings,
                    COUNT(CASE WHEN content_type = 'name' THEN 1 END) as name_embeddings,
                    COUNT(CASE WHEN content_type = 'description' THEN 1 END) as description_embeddings
                FROM {schema}.interface_embeddings
            """)).fetchone()

            analytics['embeddingStats'] = {
                'totalEmbeddings': int(embedding_stats.total_embeddings or 0),
                'interfacesWithEmbeddings': int(embedding_stats.interfaces_with_embeddings or 0),
                'nameEmbeddings': int(embedding_stats.name_embeddings or 0),
                'descriptionEmbeddings': int(embedding_stats.description_embeddings or 0)
            }
        except Exception as e:
            logger.warning(f"Embedding stats error: {e}")
            analytics['embeddingStats'] = {
                'totalEmbeddings': 0, 'interfacesWithEmbeddings': 0,
                'nameEmbeddings': 0, 'descriptionEmbeddings': 0
            }

        # 4. Import History Statistics
        try:
            import_stats = db.execute(text(f"""
                SELECT
                    COUNT(*) as total_imports,
                    COUNT(CASE WHEN status = 'success' THEN 1 END) as successful_imports,
                    COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_imports,
                    COALESCE(SUM(rows_imported), 0) as total_rows_imported,
                    COALESCE(SUM(embeddings_created), 0) as total_embeddings_created,
                    COALESCE(AVG(processing_time_ms), 0) as avg_processing_time_ms
                FROM {schema}.import_history
                WHERE created_at >= NOW() - INTERVAL '30 days'
            """)).fetchone()

            analytics['importStats'] = {
                'totalImports': int(import_stats.total_imports or 0),
                'successfulImports': int(import_stats.successful_imports or 0),
                'failedImports': int(import_stats.failed_imports or 0),
                'successRate': round((import_stats.successful_imports / import_stats.total_imports * 100), 1) if import_stats.total_imports > 0 else 0,
                'totalRowsImported': int(import_stats.total_rows_imported or 0),
                'totalEmbeddingsCreated': int(import_stats.total_embeddings_created or 0),
                'avgProcessingTimeMs': round(float(import_stats.avg_processing_time_ms or 0), 1)
            }
        except Exception as e:
            logger.warning(f"Import stats error: {e}")
            analytics['importStats'] = {
                'totalImports': 0, 'successfulImports': 0, 'failedImports': 0,
                'successRate': 0, 'totalRowsImported': 0, 'totalEmbeddingsCreated': 0, 'avgProcessingTimeMs': 0
            }

        # 5. Daily Query Trend (last 7 days)
        try:
            daily_trend = db.execute(text(f"""
                SELECT
                    DATE(created_at AT TIME ZONE 'America/Los_Angeles') as query_date,
                    COUNT(*) as query_count,
                    COUNT(CASE WHEN status = 'success' THEN 1 END) as success_count,
                    COALESCE(AVG(execution_time_ms), 0) as avg_time_ms
                FROM {schema}.rag_query_logs
                WHERE created_at >= NOW() - INTERVAL '7 days'
                GROUP BY DATE(created_at AT TIME ZONE 'America/Los_Angeles')
                ORDER BY query_date DESC
            """)).fetchall()

            analytics['dailyTrend'] = [
                {
                    'date': row.query_date.strftime('%Y-%m-%d') if row.query_date else '',
                    'queries': int(row.query_count),
                    'successful': int(row.success_count),
                    'avgTimeMs': round(float(row.avg_time_ms or 0), 1)
                }
                for row in daily_trend
            ]
        except Exception as e:
            logger.warning(f"Daily trend error: {e}")
            analytics['dailyTrend'] = []

        # 6. Chat Session Statistics
        try:
            chat_stats = db.execute(text(f"""
                SELECT
                    COUNT(DISTINCT cs.id) as total_sessions,
                    COUNT(cm.id) as total_messages,
                    COALESCE(AVG(cs.message_count), 0) as avg_messages_per_session
                FROM {schema}.chat_sessions cs
                LEFT JOIN {schema}.chat_messages cm ON cs.session_id = cm.session_id
                WHERE cs.created_at >= NOW() - INTERVAL '30 days'
            """)).fetchone()

            analytics['chatStats'] = {
                'totalSessions': int(chat_stats.total_sessions or 0),
                'totalMessages': int(chat_stats.total_messages or 0),
                'avgMessagesPerSession': round(float(chat_stats.avg_messages_per_session or 0), 1)
            }
        except Exception as e:
            logger.warning(f"Chat stats error: {e}")
            analytics['chatStats'] = {
                'totalSessions': 0, 'totalMessages': 0, 'avgMessagesPerSession': 0
            }

        # 7. Interface Statistics
        try:
            interface_stats = db.execute(text(f"""
                SELECT
                    COUNT(*) as total_interfaces,
                    COUNT(DISTINCT interface_platform) as platforms,
                    COUNT(DISTINCT interface_pattern) as patterns
                FROM {schema}.integration_interfaces
            """)).fetchone()

            analytics['interfaceStats'] = {
                'totalInterfaces': int(interface_stats.total_interfaces or 0),
                'platforms': int(interface_stats.platforms or 0),
                'patterns': int(interface_stats.patterns or 0)
            }
        except Exception as e:
            logger.warning(f"Interface stats error: {e}")
            analytics['interfaceStats'] = {
                'totalInterfaces': 0, 'platforms': 0, 'patterns': 0
            }

        # 8. Recent Imports (last 5)
        try:
            recent_imports = db.execute(text(f"""
                SELECT filename, file_type, rows_imported, embeddings_created, status,
                       processing_time_ms, created_at AT TIME ZONE 'America/Los_Angeles' as created_at
                FROM {schema}.import_history
                ORDER BY created_at DESC
                LIMIT 5
            """)).fetchall()

            analytics['recentImports'] = [
                {
                    'filename': row.filename,
                    'fileType': row.file_type,
                    'rowsImported': int(row.rows_imported or 0),
                    'embeddingsCreated': int(row.embeddings_created or 0),
                    'status': row.status,
                    'processingTimeMs': int(row.processing_time_ms or 0),
                    'createdAt': row.created_at.isoformat() if row.created_at else None
                }
                for row in recent_imports
            ]
        except Exception as e:
            logger.warning(f"Recent imports error: {e}")
            analytics['recentImports'] = []

        return jsonify({
            'success': True,
            'analytics': analytics,
            'generatedAt': datetime.now().isoformat()
        }), 200

    except Exception as e:
        logger.error(f"❌ RAG Analytics error: {e}")
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/health', methods=['GET'])
def health():
    """System health check - CRASH PROTECTED"""
    try:
        logger.info("🏥 Health check starting...")
        
        # Check database (safe)
        db_status = 'unavailable'
        try:
            db = get_db()
            if db:
                from sqlalchemy import text
                schema = get_db_schema()
                db.execute(text(f"SELECT 1"))
                db_status = 'healthy'
        except Exception as db_err:
            logger.error(f"❌ DB check failed: {db_err}")
            db_status = 'error'
        
        # Check LLM (safe)  
        llm_status = 'unavailable'
        try:
            llm_client = get_llm_client()
            llm_status = 'healthy' if llm_client else 'unavailable'
        except Exception as llm_err:
            logger.error(f"❌ LLM check failed: {llm_err}")
            llm_status = 'error'
        
        # Skip RAG service check - it's causing the crash
        # Just check if it's cached
        rag_status = 'unavailable'
        try:
            if hasattr(current_app, 'rag_service') and current_app.rag_service:
                rag_status = 'healthy'
            else:
                rag_status = 'not_initialized'
        except:
            rag_status = 'error'
        
        overall = 'healthy' if db_status == 'healthy' else 'degraded'
        
        logger.info(f"🏥 Health check complete: {overall}")
        
        return jsonify({
            'status': overall,
            'components': {
                'database': db_status,
                'rag_service': rag_status,
                'llm': llm_status
            },
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"❌ Health check crashed: {e}", exc_info=True)
        return jsonify({
            'status': 'error',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500
    
@chat_bp.route('/llm-status', methods=['GET'])
@token_required
def llm_status():
    """Check LLM status (requires authentication)"""
    try:
        llm_client = get_llm_client()
        cfg = current_app.config

        return jsonify({
            'llm_enabled': llm_client is not None,
            'api_key_configured': bool(cfg.get('AZURE_OPENAI_API_KEY')),
            'endpoint_configured': bool(cfg.get('AZURE_OPENAI_ENDPOINT')),
            'deployment': cfg.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-35-turbo'),
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"❌ LLM status error: {e}")
        return jsonify({'llm_enabled': False, 'error': str(e)})


# ============================================================================
# EMBEDDING STATUS ENDPOINT - For background processing monitoring
# ============================================================================

@chat_bp.route('/embedding-status', methods=['GET'])
@token_required
def embedding_status():
    """
    Get status of background embedding job

    ✅ Usage:
        GET /chat/embedding-status              → Get latest job status
        GET /chat/embedding-status?job_id=abc123 → Get specific job status

    ✅ Response:
        {
            "success": true,
            "job": {
                "job_id": "abc123",
                "status": "processing",  # pending, processing, completed, failed
                "total_records": 5000,
                "processed_records": 2500,
                "progress_percent": 50.0,
                "embeddings_created": 4800,
                "embeddings_failed": 200,
                "started_at": "2025-01-15T10:30:00",
                "completed_at": null,
                "duration_seconds": null,
                "error_message": null
            }
        }
    """
    try:
        job_id = request.args.get('job_id')

        from backend.services.background_embedding_processor import get_embedding_status, EmbeddingProcessor

        if job_id:
            # Get specific job
            job_status = get_embedding_status(job_id)
            if job_status:
                return jsonify({
                    'success': True,
                    'job': job_status
                }), 200
            else:
                return jsonify({
                    'success': False,
                    'error': f'Job {job_id} not found'
                }), 404
        else:
            # Get latest job
            job_status = get_embedding_status()
            if job_status:
                return jsonify({
                    'success': True,
                    'job': job_status
                }), 200
            else:
                return jsonify({
                    'success': True,
                    'job': None,
                    'message': 'No embedding jobs found'
                }), 200

    except ImportError as ie:
        logger.error(f"❌ Background processor not available: {ie}")
        return jsonify({
            'success': False,
            'error': 'Background embedding processor not available'
        }), 500
    except Exception as e:
        logger.error(f"❌ Embedding status error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@chat_bp.route('/embedding-jobs', methods=['GET'])
@token_required
def embedding_jobs():
    """
    Get all embedding jobs

    ✅ Usage:
        GET /chat/embedding-jobs → Get all jobs
    """
    try:
        from backend.services.background_embedding_processor import EmbeddingProcessor

        jobs = EmbeddingProcessor.get_all_jobs()

        return jsonify({
            'success': True,
            'total_jobs': len(jobs),
            'jobs': jobs
        }), 200

    except ImportError as ie:
        logger.error(f"❌ Background processor not available: {ie}")
        return jsonify({
            'success': False,
            'error': 'Background embedding processor not available'
        }), 500
    except Exception as e:
        logger.error(f"❌ Embedding jobs error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@chat_bp.route('/clear-data', methods=['POST'])
@token_required
def clear_data():
    """Clear all data (requires authentication - DESTRUCTIVE)"""
    try:
        db = get_db()
        if not db:
            return jsonify({'success': False, 'error': 'No database'}), 500
        
        from sqlalchemy import text
        schema = get_db_schema()  # ✅ NEW: Get schema
        
        # ✅ FIXED: Use schema prefix
        db.execute(text(f"DELETE FROM {schema}.interface_embeddings"))
        db.execute(text(f"DELETE FROM {schema}.integration_interfaces"))
        db.commit()
        
        logger.info("✅ Data cleared")
        return jsonify({'success': True, 'message': 'Data cleared'}), 200
    
    except Exception as e:
        logger.error(f"❌ Clear error: {e}")
        try:
            db.rollback()
        except:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# CHAT SESSIONS API - Conversation History Management
# ============================================================================

@chat_bp.route('/sessions', methods=['GET'])
@token_required
def get_chat_sessions():
    """Get list of chat sessions for the current user

    Query params:
        user_id: int - User ID (optional, None for anonymous)
        limit: int - Max sessions to return (default 20, max 100)
    """
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        # Get user_id from query params (None means get sessions without user)
        user_id = request.args.get('user_id', type=int)
        # Get limit with default of 20, max of 100
        limit = min(request.args.get('limit', 20, type=int), 100)

        # Build query based on whether user_id is provided
        if user_id:
            result = db.execute(text(f"""
                SELECT
                    session_id::text,
                    title,
                    first_message,
                    message_count,
                    created_at,
                    updated_at
                FROM {schema}.chat_sessions
                WHERE user_id = :user_id
                  AND status = 'active'
                ORDER BY updated_at DESC
                LIMIT :limit
            """), {'user_id': user_id, 'limit': limit})
        else:
            # Get sessions without user_id (anonymous sessions)
            result = db.execute(text(f"""
                SELECT
                    session_id::text,
                    title,
                    first_message,
                    message_count,
                    created_at,
                    updated_at
                FROM {schema}.chat_sessions
                WHERE user_id IS NULL
                  AND status = 'active'
                ORDER BY updated_at DESC
                LIMIT :limit
            """), {'limit': limit})

        sessions = []
        for row in result.fetchall():
            sessions.append({
                'session_id': row[0],
                'title': row[1],
                'first_message': row[2],
                'message_count': row[3],
                'created_at': row[4].isoformat() if row[4] else None,
                'updated_at': row[5].isoformat() if row[5] else None
            })

        return jsonify({
            'success': True,
            'sessions': sessions,
            'count': len(sessions)
        }), 200

    except Exception as e:
        logger.error(f"❌ get_chat_sessions error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions', methods=['POST'])
@token_required
def create_chat_session():
    """Create a new chat session (requires authentication)"""
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        data = request.get_json() or {}
        user_id = data.get('user_id')
        title = data.get('title', 'New Chat')

        # Validate user_id exists if provided, otherwise create session without user
        if user_id:
            user_check = db.execute(text(f"""
                SELECT id FROM {schema}.users WHERE id = :user_id
            """), {'user_id': user_id})
            if not user_check.fetchone():
                logger.warning(f"⚠️ User {user_id} not found, creating session without user_id")
                user_id = None

        result = db.execute(text(f"""
            INSERT INTO {schema}.chat_sessions (user_id, title, status)
            VALUES (:user_id, :title, 'active')
            RETURNING session_id::text, created_at
        """), {'user_id': user_id, 'title': title})

        row = result.fetchone()
        db.commit()

        return jsonify({
            'success': True,
            'session_id': row[0],
            'title': title,
            'created_at': row[1].isoformat() if row[1] else None
        }), 201

    except Exception as e:
        logger.error(f"❌ create_chat_session error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions/<session_id>', methods=['GET'])
@token_required
def get_session_messages(session_id):
    """Get messages for a specific chat session

    Query params:
        limit: int - Max messages to return (default 100, max 500)
        offset: int - Offset for pagination (default 0)
    """
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        # Get pagination params
        limit = min(request.args.get('limit', 100, type=int), 500)
        offset = request.args.get('offset', 0, type=int)

        # Get session info
        session_result = db.execute(text(f"""
            SELECT title, message_count, created_at, updated_at
            FROM {schema}.chat_sessions
            WHERE session_id = CAST(:session_id AS uuid) AND status = 'active'
        """), {'session_id': session_id})

        session_row = session_result.fetchone()
        if not session_row:
            return jsonify({'success': False, 'error': 'Session not found'}), 404

        # Get messages with limit and offset
        msg_result = db.execute(text(f"""
            SELECT
                role,
                content,
                method,
                metadata,
                created_at
            FROM {schema}.chat_messages
            WHERE session_id = CAST(:session_id AS uuid)
            ORDER BY created_at ASC
            LIMIT :limit OFFSET :offset
        """), {'session_id': session_id, 'limit': limit, 'offset': offset})

        messages = []
        for row in msg_result.fetchall():
            messages.append({
                'role': row[0],
                'content': row[1],
                'method': row[2],
                'metadata': row[3],
                'created_at': row[4].isoformat() if row[4] else None
            })

        return jsonify({
            'success': True,
            'session_id': session_id,
            'title': session_row[0],
            'message_count': session_row[1],
            'created_at': session_row[2].isoformat() if session_row[2] else None,
            'updated_at': session_row[3].isoformat() if session_row[3] else None,
            'messages': messages
        }), 200

    except Exception as e:
        logger.error(f"❌ get_session_messages error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions/<session_id>/messages', methods=['POST'])
@token_required
def add_session_message(session_id):
    """Add a message to a chat session (requires authentication)"""
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        role = data.get('role', 'user')
        content = data.get('content', '')
        method = data.get('method')
        metadata = data.get('metadata')
        processing_time_ms = data.get('processing_time_ms')

        if not content:
            return jsonify({'success': False, 'error': 'Content is required'}), 400

        # Verify session exists
        check_result = db.execute(text(f"""
            SELECT id FROM {schema}.chat_sessions
            WHERE session_id = CAST(:session_id AS uuid) AND status = 'active'
        """), {'session_id': session_id})

        if not check_result.fetchone():
            return jsonify({'success': False, 'error': 'Session not found'}), 404

        # Insert message
        import json
        result = db.execute(text(f"""
            INSERT INTO {schema}.chat_messages
            (session_id, role, content, method, metadata, processing_time_ms)
            VALUES (CAST(:session_id AS uuid), :role, :content, :method, :metadata, :processing_time_ms)
            RETURNING id, created_at
        """), {
            'session_id': session_id,
            'role': role,
            'content': content,
            'method': method,
            'metadata': json.dumps(metadata) if metadata else None,
            'processing_time_ms': processing_time_ms
        })

        row = result.fetchone()
        db.commit()

        return jsonify({
            'success': True,
            'message_id': row[0],
            'created_at': row[1].isoformat() if row[1] else None
        }), 201

    except Exception as e:
        logger.error(f"❌ add_session_message error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions/<session_id>', methods=['DELETE'])
@token_required
def delete_chat_session(session_id):
    """Delete (archive) a chat session (requires authentication)"""
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        result = db.execute(text(f"""
            UPDATE {schema}.chat_sessions
            SET status = 'deleted', updated_at = CURRENT_TIMESTAMP
            WHERE session_id = CAST(:session_id AS uuid)
            RETURNING id
        """), {'session_id': session_id})

        row = result.fetchone()
        db.commit()

        if not row:
            return jsonify({'success': False, 'error': 'Session not found'}), 404

        return jsonify({'success': True, 'message': 'Session deleted'}), 200

    except Exception as e:
        logger.error(f"❌ delete_chat_session error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions/<session_id>/title', methods=['PUT'])
@token_required
def update_session_title(session_id):
    """Update session title (requires authentication)"""
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        data = request.get_json()
        title = data.get('title', 'Untitled')

        result = db.execute(text(f"""
            UPDATE {schema}.chat_sessions
            SET title = :title, updated_at = CURRENT_TIMESTAMP
            WHERE session_id = CAST(:session_id AS uuid) AND status = 'active'
            RETURNING id
        """), {'title': title, 'session_id': session_id})

        row = result.fetchone()
        db.commit()

        if not row:
            return jsonify({'success': False, 'error': 'Session not found'}), 404

        return jsonify({'success': True, 'title': title}), 200

    except Exception as e:
        logger.error(f"❌ update_session_title error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# CHAT HISTORY CLEANUP - Reduce Session Count
# ============================================================================

@chat_bp.route('/sessions/cleanup', methods=['POST'])
@token_required
def cleanup_chat_sessions():
    """
    Cleanup old chat sessions to reduce database size

    Policy:
    - Hard delete sessions with status='deleted' older than 7 days
    - Keep only the last 50 active sessions per user (delete oldest)
    - Delete orphaned messages (messages without valid session)

    Request body (optional):
        {
            "user_id": 1,           // Cleanup for specific user (optional)
            "max_sessions": 50,     // Max sessions to keep per user (default 50)
            "deleted_days": 7       // Days before hard-deleting 'deleted' sessions
        }

    Response:
        {
            "success": true,
            "cleanup_results": {
                "deleted_sessions_purged": 15,
                "old_sessions_removed": 25,
                "orphaned_messages_deleted": 100,
                "total_cleaned": 140
            }
        }
    """
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        data = request.get_json() or {}
        user_id = data.get('user_id')
        max_sessions = data.get('max_sessions', 50)
        deleted_days = data.get('deleted_days', 7)

        cleanup_results = {
            'deleted_sessions_purged': 0,
            'old_sessions_removed': 0,
            'orphaned_messages_deleted': 0,
            'total_cleaned': 0
        }

        logger.info(f"🧹 Starting chat history cleanup (max_sessions={max_sessions}, deleted_days={deleted_days})")

        # Step 1: Hard delete sessions marked as 'deleted' older than X days
        logger.info("   Step 1: Purging old deleted sessions...")

        # First delete messages for these sessions
        purge_messages_result = db.execute(text(f"""
            DELETE FROM {schema}.chat_messages
            WHERE session_id IN (
                SELECT session_id FROM {schema}.chat_sessions
                WHERE status = 'deleted'
                AND updated_at < NOW() - INTERVAL '{deleted_days} days'
            )
        """))

        # Then delete the sessions
        purge_result = db.execute(text(f"""
            DELETE FROM {schema}.chat_sessions
            WHERE status = 'deleted'
            AND updated_at < NOW() - INTERVAL '{deleted_days} days'
            RETURNING id
        """))
        purged_rows = purge_result.fetchall()
        cleanup_results['deleted_sessions_purged'] = len(purged_rows)
        logger.info(f"   ✓ Purged {len(purged_rows)} deleted sessions")

        # Step 2: Keep only max_sessions per user (delete oldest active sessions)
        logger.info(f"   Step 2: Limiting to {max_sessions} sessions per user...")

        if user_id:
            # Cleanup for specific user
            old_sessions_result = db.execute(text(f"""
                WITH ranked_sessions AS (
                    SELECT session_id,
                           ROW_NUMBER() OVER (ORDER BY updated_at DESC) as rn
                    FROM {schema}.chat_sessions
                    WHERE user_id = :user_id AND status = 'active'
                )
                SELECT session_id FROM ranked_sessions WHERE rn > :max_sessions
            """), {'user_id': user_id, 'max_sessions': max_sessions})
            old_session_ids = [row[0] for row in old_sessions_result.fetchall()]
        else:
            # Cleanup for all users
            old_sessions_result = db.execute(text(f"""
                WITH ranked_sessions AS (
                    SELECT session_id, user_id,
                           ROW_NUMBER() OVER (PARTITION BY COALESCE(user_id, 0) ORDER BY updated_at DESC) as rn
                    FROM {schema}.chat_sessions
                    WHERE status = 'active'
                )
                SELECT session_id FROM ranked_sessions WHERE rn > :max_sessions
            """), {'max_sessions': max_sessions})
            old_session_ids = [row[0] for row in old_sessions_result.fetchall()]

        if old_session_ids:
            # Delete messages first
            for session_id in old_session_ids:
                db.execute(text(f"""
                    DELETE FROM {schema}.chat_messages
                    WHERE session_id = :session_id
                """), {'session_id': session_id})

            # Delete the sessions
            for session_id in old_session_ids:
                db.execute(text(f"""
                    DELETE FROM {schema}.chat_sessions
                    WHERE session_id = :session_id
                """), {'session_id': session_id})

            cleanup_results['old_sessions_removed'] = len(old_session_ids)
            logger.info(f"   ✓ Removed {len(old_session_ids)} old sessions")

        # Step 3: Delete orphaned messages (no matching session)
        logger.info("   Step 3: Cleaning orphaned messages...")
        orphan_result = db.execute(text(f"""
            DELETE FROM {schema}.chat_messages
            WHERE session_id NOT IN (
                SELECT session_id FROM {schema}.chat_sessions
            )
            RETURNING id
        """))
        orphaned_rows = orphan_result.fetchall()
        cleanup_results['orphaned_messages_deleted'] = len(orphaned_rows)
        logger.info(f"   ✓ Deleted {len(orphaned_rows)} orphaned messages")

        db.commit()

        cleanup_results['total_cleaned'] = (
            cleanup_results['deleted_sessions_purged'] +
            cleanup_results['old_sessions_removed'] +
            cleanup_results['orphaned_messages_deleted']
        )

        logger.info(f"🧹 Cleanup complete! Total items cleaned: {cleanup_results['total_cleaned']}")

        return jsonify({
            'success': True,
            'cleanup_results': cleanup_results
        }), 200

    except Exception as e:
        logger.error(f"❌ cleanup_chat_sessions error: {e}", exc_info=True)
        try:
            db.rollback()
        except:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500


@chat_bp.route('/sessions/stats', methods=['GET'])
@token_required
def get_session_stats():
    """
    Get chat session statistics for monitoring

    Response:
        {
            "success": true,
            "stats": {
                "total_sessions": 150,
                "active_sessions": 120,
                "deleted_sessions": 30,
                "total_messages": 5000,
                "sessions_by_user": [
                    {"user_id": 1, "session_count": 50},
                    {"user_id": 2, "session_count": 40}
                ]
            }
        }
    """
    try:
        db = get_db()
        schema = get_db_schema()

        if db is None:
            return jsonify({'success': False, 'error': 'Database unavailable'}), 500

        stats = {}

        # Total sessions by status
        status_result = db.execute(text(f"""
            SELECT
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
                COUNT(CASE WHEN status = 'deleted' THEN 1 END) as deleted
            FROM {schema}.chat_sessions
        """))
        status_row = status_result.fetchone()
        stats['total_sessions'] = status_row[0] or 0
        stats['active_sessions'] = status_row[1] or 0
        stats['deleted_sessions'] = status_row[2] or 0

        # Total messages
        msg_result = db.execute(text(f"""
            SELECT COUNT(*) FROM {schema}.chat_messages
        """))
        stats['total_messages'] = msg_result.scalar() or 0

        # Sessions by user (top 10)
        user_result = db.execute(text(f"""
            SELECT
                COALESCE(user_id, 0) as user_id,
                COUNT(*) as session_count
            FROM {schema}.chat_sessions
            WHERE status = 'active'
            GROUP BY COALESCE(user_id, 0)
            ORDER BY session_count DESC
            LIMIT 10
        """))
        stats['sessions_by_user'] = [
            {'user_id': row[0], 'session_count': row[1]}
            for row in user_result.fetchall()
        ]

        # Oldest active session
        oldest_result = db.execute(text(f"""
            SELECT created_at FROM {schema}.chat_sessions
            WHERE status = 'active'
            ORDER BY created_at ASC
            LIMIT 1
        """))
        oldest_row = oldest_result.fetchone()
        stats['oldest_session_date'] = oldest_row[0].isoformat() if oldest_row and oldest_row[0] else None

        return jsonify({
            'success': True,
            'stats': stats
        }), 200

    except Exception as e:
        logger.error(f"❌ get_session_stats error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# EXPORT & LOGGING
# ============================================================================

logger.info("✅ Chat blueprint loaded successfully")
logger.info("   Routes configured:")
logger.info("     GET  /chat/pre-check          - Diagnostic check")
logger.info("     POST /chat/send_message       - Send message (WITH LLM)")
logger.info("     GET  /chat/stats              - Statistics")
logger.info("     GET  /chat/health             - Health check")
logger.info("     GET  /chat/llm-status         - LLM status")
logger.info("     POST /chat/upload             - Upload file")
logger.info("     POST /chat/clear-data         - Clear data")
logger.info("     GET  /chat/sessions           - List chat sessions")
logger.info("     POST /chat/sessions           - Create new session")
logger.info("     GET  /chat/sessions/<id>      - Get session messages")
logger.info("     POST /chat/sessions/<id>/messages - Add message")
logger.info("     DELETE /chat/sessions/<id>    - Delete session")
logger.info("     POST /chat/sessions/cleanup   - Cleanup old sessions")
logger.info("     GET  /chat/sessions/stats     - Session statistics")
logger.info("   ✅ DB_SCHEMA (igpt) support added to all queries!")

__all__ = ['chat_bp']