"""
Splunk Routes - Flask API Endpoints
360° Enterprise Dashboard - Splunk Integration
Handles search queries, analytics, and monitoring
"""

import logging
from flask import Blueprint, request, jsonify, current_app
from functools import wraps
from datetime import datetime
from ..connectors.splunk_connector import get_splunk_connector

logger = logging.getLogger(__name__)

# Create Blueprint
splunk_bp = Blueprint('splunk', __name__, url_prefix='/api/splunk')


# ============================================================================
# DECORATORS
# ============================================================================

def require_splunk(f):
    """Decorator to check if Splunk is configured and available"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        splunk = get_splunk_connector(current_app.config)
        
        if splunk is None:
            return jsonify({
                'error': 'Splunk connector not initialized',
                'status': 'error'
            }), 503
        
        health = splunk.health_check()
        if health['status'] != 'healthy':
            return jsonify({
                'error': 'Splunk is not available',
                'status': health['status'],
                'message': health.get('message', 'Unknown error')
            }), 503
        
        return f(splunk, *args, **kwargs)
    
    return decorated_function


def require_feature_flag(feature_flag):
    """Decorator to check if a feature is enabled"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_app.config.get(feature_flag, False):
                return jsonify({
                    'error': f'Feature {feature_flag} is not enabled',
                    'status': 'disabled'
                }), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ============================================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================================

@splunk_bp.route('/health', methods=['GET'])
def health_check():
    """
    Check Splunk connector health
    
    Returns:
        200: Healthy status
        503: Service unavailable
    
    Response:
        {
            'status': 'healthy|unhealthy|unavailable|error',
            'message': 'status message',
            'host': 'splunk.example.com',
            'port': 8089,
            'auth_method': 'username_password|bearer_token',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        splunk = get_splunk_connector(current_app.config)
        
        if splunk is None:
            return jsonify({
                'status': 'error',
                'message': 'Splunk connector not initialized',
                'timestamp': datetime.utcnow().isoformat()
            }), 503
        
        health = splunk.health_check()
        status_code = 200 if health['status'] == 'healthy' else 503
        
        logger.info(f"Health check: {health['status']}")
        return jsonify(health), status_code
    
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/status', methods=['GET'])
@require_splunk
def get_status(splunk):
    """
    Get current Splunk connector status
    
    Returns:
        200: Current status
        503: Service unavailable
    
    Response:
        {
            'configured': true,
            'auth_method': 'username_password|bearer_token',
            'host': 'splunk.example.com',
            'port': 8089,
            'base_url': 'https://splunk.example.com:8089',
            'timeout': 30,
            'verify_ssl': false,
            'has_session_key': true,
            'session_expiry': 'ISO-8601',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        status = splunk.get_status()
        logger.info("Status retrieved successfully")
        return jsonify(status), 200
    
    except Exception as e:
        logger.error(f"Status endpoint error: {e}")
        return jsonify({
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/test', methods=['POST'])
def test_connection():
    """
    Test Splunk connection
    
    Returns:
        200: Connection successful
        503: Connection failed
    
    Response:
        {
            'success': true,
            'message': 'Connection test passed',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        splunk = get_splunk_connector(current_app.config)
        
        if splunk is None:
            return jsonify({
                'success': False,
                'message': 'Splunk connector not initialized',
                'timestamp': datetime.utcnow().isoformat()
            }), 503
        
        if splunk.test_connection():
            logger.info("Connection test passed")
            return jsonify({
                'success': True,
                'message': 'Connection test passed',
                'timestamp': datetime.utcnow().isoformat()
            }), 200
        else:
            logger.warning("Connection test failed")
            return jsonify({
                'success': False,
                'message': 'Connection test failed',
                'timestamp': datetime.utcnow().isoformat()
            }), 503
    
    except Exception as e:
        logger.error(f"Test connection error: {e}")
        return jsonify({
            'success': False,
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# SEARCH ENDPOINTS
# ============================================================================

@splunk_bp.route('/search', methods=['POST'])
@require_feature_flag('FEATURE_SPLUNK_QUERIES')
@require_splunk
def execute_search(splunk):
    """
    Execute Splunk search query
    
    Request Body:
        {
            'query': 'index=main | stats count',  # Required
            'earliest_time': '-7d@d',              # Optional, default: -30d@d
            'latest_time': 'now',                  # Optional, default: now
            'timeout': 30                          # Optional, default: from config
        }
    
    Returns:
        200: Query executed successfully
        400: Bad request (missing query)
        503: Splunk unavailable
    
    Response:
        {
            'success': true,
            'results': [
                {'field1': 'value1', 'field2': 'value2'},
                ...
            ],
            'count': 42,
            'job_sid': 'ABC123_1234567890',
            'execution_time': 2.5,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'query' not in data:
            return jsonify({
                'error': 'Missing required field: query',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        query = data.get('query', '').strip()
        earliest_time = data.get('earliest_time', '-30d@d')
        latest_time = data.get('latest_time', 'now')
        timeout = data.get('timeout')
        
        # Validate query length
        if len(query) > 10000:
            return jsonify({
                'error': 'Query too long (max 10000 characters)',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        logger.info(f"Executing search query: {query[:100]}...")
        
        result = splunk.execute_query(
            query=query,
            earliest_time=earliest_time,
            latest_time=latest_time,
            timeout=timeout
        )
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Search error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/search/stats', methods=['POST'])
@require_feature_flag('FEATURE_SPLUNK_QUERIES')
@require_splunk
def search_stats(splunk):
    """
    Execute Splunk statistics query
    
    Request Body:
        {
            'index': 'main',                    # Optional, default: main
            'stat': 'count|avg|sum|min|max',   # Required
            'field': 'fieldname',               # Optional (required for avg, sum, min, max)
            'group_by': 'fieldname',            # Optional
            'earliest_time': '-7d@d',           # Optional
            'latest_time': 'now'                # Optional
        }
    
    Returns:
        200: Query executed successfully
        400: Bad request
        503: Splunk unavailable
    
    Response:
        {
            'success': true,
            'results': [...],
            'count': 42,
            'stat_type': 'count',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'stat' not in data:
            return jsonify({
                'error': 'Missing required field: stat',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        index = data.get('index', 'main')
        stat = data.get('stat').lower()
        field = data.get('field', '')
        group_by = data.get('group_by', '')
        earliest_time = data.get('earliest_time', '-7d@d')
        latest_time = data.get('latest_time', 'now')
        
        # Build query
        query = f"search index={index}"
        
        if stat == 'count':
            query += " | stats count"
        elif stat in ['avg', 'sum', 'min', 'max']:
            if not field:
                return jsonify({
                    'error': f'Field required for {stat} aggregation',
                    'timestamp': datetime.utcnow().isoformat()
                }), 400
            query += f" | stats {stat}({field})"
        else:
            return jsonify({
                'error': f'Unsupported stat type: {stat}',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        if group_by:
            query += f" by {group_by}"
        
        logger.info(f"Executing stats query: {stat} on {field}")
        
        result = splunk.execute_query(
            query=query,
            earliest_time=earliest_time,
            latest_time=latest_time
        )
        
        if result['success']:
            result['stat_type'] = stat
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Stats search error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/search/timechart', methods=['POST'])
@require_feature_flag('FEATURE_SPLUNK_QUERIES')
@require_splunk
def search_timechart(splunk):
    """
    Execute Splunk timechart query for time-series data
    
    Request Body:
        {
            'index': 'main',              # Optional
            'field': 'fieldname',         # Required
            'stat': 'count|avg|sum',      # Required
            'span': '10m|1h|1d',          # Optional, default: auto
            'earliest_time': '-7d@d',     # Optional
            'latest_time': 'now'          # Optional
        }
    
    Returns:
        200: Query executed successfully
        400: Bad request
        503: Splunk unavailable
    
    Response:
        {
            'success': true,
            'results': [
                {'_time': '2025-11-18T10:00:00', 'count': 100},
                ...
            ],
            'count': 42,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'field' not in data or 'stat' not in data:
            return jsonify({
                'error': 'Missing required fields: field, stat',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        index = data.get('index', 'main')
        field = data.get('field')
        stat = data.get('stat', 'count').lower()
        span = data.get('span', 'auto')
        earliest_time = data.get('earliest_time', '-7d@d')
        latest_time = data.get('latest_time', 'now')
        
        # Build query
        query = f"search index={index} | timechart {stat}({field}) span={span}"
        
        logger.info(f"Executing timechart query: {stat} on {field}")
        
        result = splunk.execute_query(
            query=query,
            earliest_time=earliest_time,
            latest_time=latest_time
        )
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Timechart search error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# ANALYTICS ENDPOINTS
# ============================================================================

@splunk_bp.route('/analytics/top-events', methods=['POST'])
@require_feature_flag('FEATURE_SPLUNK_QUERIES')
@require_splunk
def top_events(splunk):
    """
    Get top events by count
    
    Request Body:
        {
            'index': 'main',              # Optional
            'field': 'source|host|user',  # Required
            'limit': 10,                  # Optional, default: 10
            'earliest_time': '-7d@d',     # Optional
            'latest_time': 'now'          # Optional
        }
    
    Returns:
        200: Query executed successfully
        400: Bad request
        503: Splunk unavailable
    
    Response:
        {
            'success': true,
            'results': [
                {'field': 'value', 'count': 100},
                ...
            ],
            'count': 10,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'field' not in data:
            return jsonify({
                'error': 'Missing required field: field',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        index = data.get('index', 'main')
        field = data.get('field')
        limit = min(data.get('limit', 10), 100)  # Max 100
        earliest_time = data.get('earliest_time', '-7d@d')
        latest_time = data.get('latest_time', 'now')
        
        query = f"search index={index} | top limit={limit} {field}"
        
        logger.info(f"Getting top {limit} events for field: {field}")
        
        result = splunk.execute_query(
            query=query,
            earliest_time=earliest_time,
            latest_time=latest_time
        )
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Top events error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/analytics/index-stats', methods=['GET'])
@require_feature_flag('FEATURE_SPLUNK_QUERIES')
@require_splunk
def index_stats(splunk):
    """
    Get statistics for all indexes
    
    Query Parameters:
        index: Optional, specific index to get stats for
    
    Returns:
        200: Stats retrieved successfully
        503: Splunk unavailable
    
    Response:
        {
            'success': true,
            'results': [
                {
                    'index': 'main',
                    'count': 1000000,
                    'size': '5.2 GB'
                },
                ...
            ],
            'count': 5,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        index = request.args.get('index')
        
        if index:
            query = f"search index={index} | stats count"
        else:
            query = "search * | stats count by index"
        
        logger.info(f"Getting index statistics")
        
        result = splunk.execute_query(
            query=query,
            earliest_time='-30d@d',
            latest_time='now'
        )
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Index stats error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# UTILITY ENDPOINTS
# ============================================================================

@splunk_bp.route('/query/validate', methods=['POST'])
def validate_query():
    """
    Validate Splunk query syntax (basic validation)
    
    Request Body:
        {
            'query': 'index=main | stats count'
        }
    
    Returns:
        200: Query is valid
        400: Query is invalid
    
    Response:
        {
            'valid': true,
            'message': 'Query is syntactically valid',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'query' not in data:
            return jsonify({
                'valid': False,
                'message': 'Missing required field: query',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        query = data.get('query', '').strip()
        
        # Basic validation
        if not query:
            return jsonify({
                'valid': False,
                'message': 'Query cannot be empty',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        if len(query) > 10000:
            return jsonify({
                'valid': False,
                'message': 'Query too long (max 10000 characters)',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        # Check for dangerous operations
        dangerous_keywords = ['delete', 'drop', 'insert', 'update', 'create', 'alter']
        if any(keyword in query.lower() for keyword in dangerous_keywords):
            return jsonify({
                'valid': False,
                'message': 'Query contains potentially dangerous operations',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        logger.info("Query validation passed")
        
        return jsonify({
            'valid': True,
            'message': 'Query is syntactically valid',
            'query': query,
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"Query validation error: {e}")
        return jsonify({
            'valid': False,
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@splunk_bp.route('/query/examples', methods=['GET'])
def get_query_examples():
    """
    Get example Splunk queries
    
    Returns:
        200: Examples retrieved successfully
    
    Response:
        {
            'examples': [
                {
                    'name': 'Count events',
                    'query': 'search index=main | stats count',
                    'description': 'Count total events in main index'
                },
                ...
            ],
            'timestamp': 'ISO-8601'
        }
    """
    examples = [
        {
            'name': 'Count all events',
            'query': 'search index=main | stats count',
            'description': 'Count total events in main index'
        },
        {
            'name': 'Top sources',
            'query': 'search index=main | top limit=10 source',
            'description': 'Get top 10 sources by event count'
        },
        {
            'name': 'Events by host',
            'query': 'search index=main | stats count by host',
            'description': 'Count events grouped by host'
        },
        {
            'name': 'Time chart',
            'query': 'search index=main | timechart count span=1h',
            'description': 'Events over time (hourly)'
        },
        {
            'name': 'Error events',
            'query': 'search index=main error OR ERROR OR fail',
            'description': 'Find error events'
        },
        {
            'name': 'Last 1000 events',
            'query': 'search index=main | head 1000',
            'description': 'Get last 1000 events'
        }
    ]
    
    return jsonify({
        'examples': examples,
        'count': len(examples),
        'timestamp': datetime.utcnow().isoformat()
    }), 200


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@splunk_bp.errorhandler(400)
def bad_request(e):
    """Handle 400 Bad Request"""
    return jsonify({
        'error': 'Bad request',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 400


@splunk_bp.errorhandler(404)
def not_found(e):
    """Handle 404 Not Found"""
    return jsonify({
        'error': 'Not found',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 404


@splunk_bp.errorhandler(500)
def internal_error(e):
    """Handle 500 Internal Server Error"""
    logger.error(f"Internal server error: {e}")
    return jsonify({
        'error': 'Internal server error',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 500