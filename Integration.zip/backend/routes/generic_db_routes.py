"""
Generic Database Query API Routes - Updated with Schema Support
Flexible endpoints for executing various database queries
Used by dashboard and other components
✅ NEW: Automatically prefixes tables with igpt schema from config.py
"""

import logging
from flask import Blueprint, request, jsonify, current_app
from functools import wraps
from datetime import datetime
from backend.services.generic_db_service import get_generic_db_service

logger = logging.getLogger(__name__)


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def get_db_schema() -> str:
    """
    ✅ FIXED: Get schema from Flask config (config.py)
    Uses current_app instead of undefined 'app'
    
    Returns:
        Schema name (e.g., 'igpt')
    """
    try:
        schema = current_app.config.get('DB_SCHEMA', 'igpt')
        return schema
    except RuntimeError:
        # Outside application context, default to 'igpt'
        return 'igpt'


def get_schema_prefixed_table(table_name: str) -> str:
    """
    ✅ FIXED: Get table name with schema prefix
    Now calls get_db_schema() instead of using undefined DB_SCHEMA
    
    Args:
        table_name: Table name (e.g., 'integration_interfaces')
    
    Returns:
        Schema-prefixed table name (e.g., 'igpt.integration_interfaces')
    """
    if not table_name:
        return None
    
    # If already prefixed, return as-is
    if '.' in table_name:
        return table_name
    
    # ✅ FIXED: Call get_db_schema() instead of using undefined DB_SCHEMA
    schema = get_db_schema()
    
    # Add schema prefix
    prefixed = f"{schema}.{table_name}"
    logger.debug(f"Table prefix applied: {table_name} → {prefixed}")
    return prefixed


# Create Blueprint
db_bp = Blueprint('database', __name__, url_prefix='/api/db')


# ============================================================================
# DECORATORS
# ============================================================================

def require_db_service(f):
    """Decorator to check if database service is available"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        service = get_generic_db_service()
        
        if service is None:
            return jsonify({
                'error': 'Database service not initialized',
                'status': 'unavailable'
            }), 503
        
        if not service.is_available():
            return jsonify({
                'error': 'Database not available',
                'status': 'unavailable'
            }), 503
        
        return f(service, *args, **kwargs)
    
    return decorated_function


# ============================================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================================

@db_bp.route('/health', methods=['GET'])
def health_check():
    """Check database service health"""
    try:
        service = get_generic_db_service()
        schema = get_db_schema()  # ✅ FIXED: Call function instead of using undefined DB_SCHEMA
        
        if service is None:
            return jsonify({
                'status': 'unavailable',
                'message': 'Service not initialized',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 503
        
        if service.is_available():
            return jsonify({
                'status': 'healthy',
                'message': 'Database service is operational',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 200
        else:
            return jsonify({
                'status': 'unavailable',
                'message': 'Database not available',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 503
    
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e),
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# AGGREGATION ENDPOINTS
# ============================================================================

@db_bp.route('/aggregate', methods=['POST'])
@require_db_service
def execute_aggregation(service):
    """
    Execute aggregation query (GROUP BY)
    ✅ NEW: Automatically prefixes table with schema
    
    Request Body:
        {
            'table': 'integration_interfaces',  # No schema prefix needed!
            'group_by_field': 'interface_pattern',
            'count_field': 'interface_pattern',  // optional
            'where_clause': 'interface_category = "API"',  // optional
            'order_by': 'count_desc',  // optional: count_asc, count_desc, field_asc, field_desc
            'limit': 20  // optional
        }
    
    Returns:
        200: Aggregation successful
        400: Bad request
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'data': [
                {
                    'field': 'Request-Reply',
                    'count': 145,
                    'percentage': 28.5
                },
                ...
            ],
            'total': 509,
            'count': 6,
            'group_by': 'interface_pattern',
            'schema': 'igpt',  // ✅ NEW
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        schema = get_db_schema()  # ✅ FIXED: Call function
        
        if not data or 'table' not in data or 'group_by_field' not in data:
            return jsonify({
                'error': 'Missing required fields: table, group_by_field',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        table = data.get('table')
        # ✅ NEW: Add schema prefix
        table = get_schema_prefixed_table(table)
        
        group_by_field = data.get('group_by_field')
        count_field = data.get('count_field')
        where_clause = data.get('where_clause')
        order_by = data.get('order_by', 'count_desc')
        limit = data.get('limit')
        
        logger.info(f"📊 Aggregation: {table}.{group_by_field}")
        
        result = service.execute_aggregation_query(
            table=table,
            group_by_field=group_by_field,
            count_field=count_field,
            where_clause=where_clause,
            order_by=order_by,
            limit=limit
        )
        
        # ✅ NEW: Add schema to response
        if result.get('success'):
            result['schema'] = schema
        
        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Aggregation error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@db_bp.route('/aggregate/chart', methods=['POST'])
@require_db_service
def get_aggregation_chart_data(service):
    """
    Get aggregation data formatted for Chart.js
    Perfect for bar/pie/doughnut charts
    ✅ NEW: Automatically prefixes table with schema
    
    Request Body:
        {
            'table': 'integration_interfaces',  # No schema prefix needed!
            'group_by_field': 'interface_pattern',
            'count_field': 'interface_pattern',  // optional
            'where_clause': 'interface_category = "API"',  // optional
            'colors': ['#2d8659', '#40b89f', ...],  // optional custom colors
            'limit': 10  // optional
        }
    
    Returns:
        {
            'success': true,
            'labels': ['Request-Reply', 'Pub-Sub', 'Batch', ...],
            'data': [145, 89, 67, ...],
            'colors': ['#2d8659', '#40b89f', ...],
            'total': 509,
            'count': 6,
            'group_by': 'interface_pattern',
            'schema': 'igpt',  // ✅ NEW
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        schema = get_db_schema()  # ✅ FIXED: Call function
        
        if not data or 'table' not in data or 'group_by_field' not in data:
            return jsonify({
                'error': 'Missing required fields: table, group_by_field',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        table = data.get('table')
        # ✅ NEW: Add schema prefix
        table = get_schema_prefixed_table(table)
        
        group_by_field = data.get('group_by_field')
        count_field = data.get('count_field')
        where_clause = data.get('where_clause')
        colors = data.get('colors')
        limit = data.get('limit')
        
        logger.info(f"📈 Chart data: {table}.{group_by_field}")
        
        result = service.get_chart_data(
            table=table,
            group_by_field=group_by_field,
            count_field=count_field,
            where_clause=where_clause,
            colors=colors,
            limit=limit
        )
        
        # ✅ NEW: Add schema to response
        if result.get('success'):
            result['schema'] = schema
        
        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Chart data error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'labels': [],
            'data': [],
            'colors': [],
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# STATISTICS ENDPOINTS
# ============================================================================

@db_bp.route('/stats', methods=['POST'])
@require_db_service
def get_statistics(service):
    """
    Get statistical information from table
    ✅ NEW: Automatically prefixes table with schema
    
    Request Body:
        {
            'table': 'integration_interfaces',  # No schema prefix needed!
            'stat_fields': {
                'interface_id': 'count',
                'response_time': 'avg',
                'error_rate': 'sum',
                'user_id': 'distinct'
            },
            'where_clause': 'status = "active"'  // optional
        }
    
    Returns:
        {
            'success': true,
            'stats': {
                'interface_id_count': 509,
                'response_time_avg': 156.5,
                'error_rate_sum': 45.2,
                'user_id_distinct': 23
            },
            'schema': 'igpt',  // ✅ NEW
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        schema = get_db_schema()  # ✅ FIXED: Call function
        
        if not data or 'table' not in data or 'stat_fields' not in data:
            return jsonify({
                'error': 'Missing required fields: table, stat_fields',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        table = data.get('table')
        # ✅ NEW: Add schema prefix
        table = get_schema_prefixed_table(table)
        
        stat_fields = data.get('stat_fields')
        where_clause = data.get('where_clause')
        
        logger.info(f"📈 Stats: {table}")
        
        result = service.get_stats(
            table=table,
            stat_fields=stat_fields,
            where_clause=where_clause
        )
        
        # ✅ NEW: Add schema to response
        if result.get('success'):
            result['schema'] = schema
        
        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Stats error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'stats': {},
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# RECORDS ENDPOINTS
# ============================================================================

@db_bp.route('/records', methods=['POST'])
@require_db_service
def get_records(service):
    """
    Get records from table with optional filtering
    ✅ NEW: Automatically prefixes table with schema
    
    Request Body:
        {
            'table': 'integration_interfaces',  # No schema prefix needed!
            'filters': {
                'interface_category': 'API',
                'status': 'active'
            },  // optional
            'order_by': 'created_date DESC',  // optional
            'limit': 100,  // optional, default 100
            'offset': 0  // optional, default 0
        }
    
    Returns:
        {
            'success': true,
            'records': [...],
            'count': 45,
            'limit': 100,
            'offset': 0,
            'schema': 'igpt',  // ✅ NEW
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        schema = get_db_schema()  # ✅ FIXED: Call function
        
        if not data or 'table' not in data:
            return jsonify({
                'error': 'Missing required field: table',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        table = data.get('table')
        # ✅ NEW: Add schema prefix
        table = get_schema_prefixed_table(table)
        
        filters = data.get('filters')
        order_by = data.get('order_by')
        limit = data.get('limit', 100)
        offset = data.get('offset', 0)
        
        logger.info(f"📋 Records: {table}")
        
        result = service.get_records(
            table=table,
            filters=filters,
            order_by=order_by,
            limit=limit,
            offset=offset
        )
        
        # ✅ NEW: Add schema to response
        if result.get('success'):
            result['schema'] = schema
        
        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Records error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'records': [],
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# RAW QUERY ENDPOINTS
# ============================================================================

@db_bp.route('/query', methods=['POST'])
@require_db_service
def execute_raw_query(service):
    """
    Execute raw SQL query (with safety validation)
    
    ⚠️  NOTE: For raw queries, you MUST include schema prefix manually!
    
    Request Body:
        {
            'query': 'SELECT interface_pattern, COUNT(*) FROM igpt.integration_interfaces GROUP BY interface_pattern',
            'validate': true  // optional, default true (blocks dangerous keywords)
        }
    
    Returns:
        {
            'success': true,
            'results': [...],
            'count': 45,
            'execution_time': 0.45,
            'schema': 'igpt',  // ✅ NEW
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        schema = get_db_schema()  # ✅ FIXED: Call function
        
        if not data or 'query' not in data:
            return jsonify({
                'error': 'Missing required field: query',
                'schema': schema,  # ✅ FIXED
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        query = data.get('query')
        validate = data.get('validate', True)
        
        logger.info(f"🔍 Raw query: {query[:80]}...")
        logger.info(f"ℹ️  Using schema from config.py: {schema}")  # ✅ FIXED
        
        result = service.execute_raw_query(query, validate=validate)
        
        # ✅ NEW: Add schema to response
        if result:
            result['schema'] = schema
        
        status_code = 200 if result.get('success') else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Raw query error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'results': [],
            'schema': get_db_schema(),  # ✅ FIXED
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@db_bp.errorhandler(400)
def bad_request(e):
    return jsonify({
        'error': 'Bad request',
        'message': str(e),
        'schema': get_db_schema(),  # ✅ FIXED
        'timestamp': datetime.utcnow().isoformat()
    }), 400


@db_bp.errorhandler(404)
def not_found(e):
    return jsonify({
        'error': 'Not found',
        'message': str(e),
        'schema': get_db_schema(),  # ✅ FIXED
        'timestamp': datetime.utcnow().isoformat()
    }), 404


@db_bp.errorhandler(500)
def internal_error(e):
    logger.error(f"Internal server error: {e}")
    return jsonify({
        'error': 'Internal server error',
        'message': str(e),
        'schema': get_db_schema(),  # ✅ FIXED
        'timestamp': datetime.utcnow().isoformat()
    }), 500