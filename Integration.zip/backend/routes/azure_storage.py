"""
Azure Storage Routes - Flask API Endpoints
360° Enterprise Dashboard - File Management Integration
Handles file uploads, downloads, and storage operations
"""

import logging
import os
import io
from flask import Blueprint, request, jsonify, current_app, send_file
from functools import wraps
from datetime import datetime
from werkzeug.utils import secure_filename
from backend.connectors.azure_storage_connector import get_azure_storage_connector

logger = logging.getLogger(__name__)

# Create Blueprint
storage_bp = Blueprint('storage', __name__, url_prefix='/api/storage')


# ============================================================================
# DECORATORS
# ============================================================================

def require_storage(f):
    """Decorator to check if Azure Storage is configured and available"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        storage = get_azure_storage_connector(current_app.config)
        
        if storage is None:
            return jsonify({
                'error': 'Azure Storage connector not initialized',
                'status': 'error'
            }), 503
        
        health = storage.health_check()
        if health['status'] != 'healthy':
            return jsonify({
                'error': 'Azure Storage is not available',
                'status': health['status'],
                'message': health.get('message', 'Unknown error')
            }), 503
        
        return f(storage, *args, **kwargs)
    
    return decorated_function


def require_feature_flag(feature_flag):
    """Decorator to check if a feature is enabled"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_app.config.get(feature_flag, False):
                return jsonify({
                    'error': f'Feature {feature_flag} is not enabled',
                    'status': 'disabled'
                }), 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator


# ============================================================================
# HEALTH & STATUS ENDPOINTS
# ============================================================================

@storage_bp.route('/health', methods=['GET'])
def health_check():
    """
    Check Azure Storage service health
    
    Returns:
        200: Healthy status
        503: Service unavailable
    
    Response:
        {
            'status': 'healthy|unhealthy',
            'connected': bool,
            'account': 'storage_account_name',
            'container': 'container_name',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        storage = get_azure_storage_connector(current_app.config)
        
        if storage is None:
            return jsonify({
                'status': 'error',
                'message': 'Storage connector not initialized',
                'timestamp': datetime.utcnow().isoformat()
            }), 503
        
        health = storage.health_check()
        status_code = 200 if health['status'] == 'healthy' else 503
        
        logger.info(f"Storage health check: {health['status']}")
        return jsonify(health), status_code
    
    except Exception as e:
        logger.error(f"Health check error: {e}")
        return jsonify({
            'status': 'error',
            'message': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@storage_bp.route('/stats', methods=['GET'])
@require_storage
def get_stats(storage):
    """
    Get storage account statistics
    
    Returns:
        200: Statistics retrieved
        503: Service unavailable
    
    Response:
        {
            'account_name': 'storage_account',
            'container_name': 'uploads',
            'total_files': 150,
            'total_size': 1073741824,
            'total_size_mb': 1024.0,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        stats = storage.get_storage_stats()
        logger.info("Storage statistics retrieved")
        return jsonify(stats), 200
    
    except Exception as e:
        logger.error(f"Stats endpoint error: {e}")
        return jsonify({
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# FILE UPLOAD ENDPOINTS
# ============================================================================

@storage_bp.route('/upload', methods=['POST'])
@require_feature_flag('FEATURE_STORAGE_MANAGEMENT')
@require_storage
def upload_file(storage):
    """
    Upload a file to Azure Storage
    
    Request (multipart/form-data):
        file: File to upload (required)
        blob_name: Custom blob name (optional)
        user_id: User identifier (optional)
    
    Returns:
        200: Upload successful
        400: Bad request (missing file)
        413: File too large
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'blob_name': 'filename.pdf',
            'blob_url': 'https://storage.blob.core.windows.net/uploads/filename.pdf',
            'file_size': 1024000,
            'container': 'uploads',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        # Check if file in request
        if 'file' not in request.files:
            return jsonify({
                'error': 'No file provided',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'error': 'No file selected',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        # Get optional parameters
        blob_name = request.form.get('blob_name')
        user_id = request.form.get('user_id')
        
        # Secure filename
        if not blob_name:
            blob_name = secure_filename(file.filename)
        
        # Read file content
        file_content = file.read()
        
        logger.info(f"Uploading file: {blob_name} (size: {len(file_content)} bytes)")
        
        # Upload to storage
        result = storage.upload_bytes(
            data=file_content,
            blob_name=blob_name,
            user_id=user_id
        )
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Upload error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@storage_bp.route('/upload/url', methods=['POST'])
@require_feature_flag('FEATURE_STORAGE_MANAGEMENT')
@require_storage
def get_upload_url(storage):
    """
    Get storage URL for client-side uploads
    
    Request Body:
        {
            'blob_name': 'filename.pdf',
            'user_id': 'user123' (optional)
        }
    
    Returns:
        200: URL generated
        400: Bad request
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'upload_url': 'https://storage.blob.core.windows.net/uploads/filename.pdf',
            'blob_name': 'filename.pdf',
            'container': 'uploads',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'blob_name' not in data:
            return jsonify({
                'error': 'Missing required field: blob_name',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        blob_name = data.get('blob_name')
        user_id = data.get('user_id')
        
        logger.info(f"Getting upload URL for: {blob_name}")
        
        # Get URL
        result = storage.get_file_url(blob_name, user_id=user_id)
        
        if result['success']:
            result['upload_url'] = result.pop('url')
        
        status_code = 200 if result['success'] else 400
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Upload URL error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# FILE DOWNLOAD ENDPOINTS
# ============================================================================

@storage_bp.route('/download/<path:blob_name>', methods=['GET'])
@require_storage
def download_file(storage, blob_name):
    """
    Download a file from Azure Storage
    
    Query Parameters:
        user_id: User identifier (optional)
        as_attachment: Download as attachment (default: true)
    
    Returns:
        200: File content
        404: File not found
        503: Service unavailable
    """
    try:
        user_id = request.args.get('user_id')
        as_attachment = request.args.get('as_attachment', 'true').lower() == 'true'
        
        logger.info(f"Downloading file: {blob_name} (user: {user_id or 'anonymous'})")
        
        # Download bytes
        result = storage.download_bytes(blob_name, user_id=user_id)
        
        if not result['success']:
            return jsonify({
                'error': result.get('error', 'Download failed'),
                'timestamp': result.get('timestamp')
            }), 404
        
        # Return file
        return send_file(
            io.BytesIO(result['data']),
            as_attachment=as_attachment,
            download_name=os.path.basename(blob_name)
        )
    
    except Exception as e:
        logger.error(f"Download error: {e}")
        return jsonify({
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@storage_bp.route('/download-url/<path:blob_name>', methods=['GET'])
@require_storage
def get_download_url(storage, blob_name):
    """
    Get download URL for a file
    
    Query Parameters:
        user_id: User identifier (optional)
        expires_hours: Hours until URL expires (default: 24)
    
    Returns:
        200: Download URL
        404: File not found
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'url': 'https://storage.blob.core.windows.net/uploads/filename.pdf',
            'blob_name': 'filename.pdf',
            'expires_at': 'ISO-8601',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        user_id = request.args.get('user_id')
        expires_hours = int(request.args.get('expires_hours', 24))
        
        logger.info(f"Getting download URL for: {blob_name}")
        
        result = storage.get_file_url(blob_name, user_id=user_id, sas_expiry_hours=expires_hours)
        
        status_code = 200 if result['success'] else 404
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Download URL error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# FILE MANAGEMENT ENDPOINTS
# ============================================================================

@storage_bp.route('/list', methods=['GET'])
@require_storage
def list_files(storage):
    """
    List files in storage container
    
    Query Parameters:
        prefix: Folder/prefix filter (optional)
        user_id: List user's files only (optional)
    
    Returns:
        200: File list retrieved
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'files': [
                {
                    'name': 'filename.pdf',
                    'size': 102400,
                    'last_modified': 'ISO-8601',
                    'content_type': 'application/pdf'
                },
                ...
            ],
            'count': 10,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        prefix = request.args.get('prefix')
        user_id = request.args.get('user_id')
        
        logger.info(f"Listing files (prefix: {prefix or 'none'}, user: {user_id or 'all'})")
        
        result = storage.list_files(prefix=prefix, user_id=user_id)
        
        return jsonify(result), 200
    
    except Exception as e:
        logger.error(f"List files error: {e}")
        return jsonify({
            'success': False,
            'files': [],
            'count': 0,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@storage_bp.route('/delete/<path:blob_name>', methods=['DELETE'])
@require_feature_flag('FEATURE_STORAGE_MANAGEMENT')
@require_storage
def delete_file(storage, blob_name):
    """
    Delete a file from Azure Storage
    
    Query Parameters:
        user_id: User identifier (optional)
    
    Returns:
        200: File deleted successfully
        404: File not found
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'blob_name': 'filename.pdf',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        user_id = request.args.get('user_id')
        
        logger.info(f"Deleting file: {blob_name} (user: {user_id or 'anonymous'})")
        
        result = storage.delete_file(blob_name, user_id=user_id)
        
        status_code = 200 if result['success'] else 404
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"Delete file error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


@storage_bp.route('/info/<path:blob_name>', methods=['GET'])
@require_storage
def get_file_info(storage, blob_name):
    """
    Get file information (size, URL, metadata)
    
    Query Parameters:
        user_id: User identifier (optional)
    
    Returns:
        200: File info retrieved
        404: File not found
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'blob_name': 'filename.pdf',
            'url': 'https://storage.blob.core.windows.net/uploads/filename.pdf',
            'timestamp': 'ISO-8601'
        }
    """
    try:
        user_id = request.args.get('user_id')
        
        logger.info(f"Getting file info: {blob_name}")
        
        result = storage.get_file_url(blob_name, user_id=user_id)
        
        if result['success']:
            result['blob_url'] = result.pop('url')
        
        status_code = 200 if result['success'] else 404
        return jsonify(result), status_code
    
    except Exception as e:
        logger.error(f"File info error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# BATCH OPERATIONS
# ============================================================================

@storage_bp.route('/batch/delete', methods=['POST'])
@require_feature_flag('FEATURE_STORAGE_MANAGEMENT')
@require_storage
def batch_delete(storage):
    """
    Delete multiple files in batch
    
    Request Body:
        {
            'blob_names': ['file1.pdf', 'file2.pdf', ...],
            'user_id': 'user123' (optional)
        }
    
    Returns:
        200: Batch operation completed
        400: Bad request
        503: Service unavailable
    
    Response:
        {
            'success': true,
            'deleted': ['file1.pdf', 'file2.pdf'],
            'failed': [],
            'count': 2,
            'timestamp': 'ISO-8601'
        }
    """
    try:
        data = request.get_json()
        
        if not data or 'blob_names' not in data:
            return jsonify({
                'error': 'Missing required field: blob_names',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        blob_names = data.get('blob_names', [])
        user_id = data.get('user_id')
        
        if not isinstance(blob_names, list):
            return jsonify({
                'error': 'blob_names must be a list',
                'timestamp': datetime.utcnow().isoformat()
            }), 400
        
        logger.info(f"Batch deleting {len(blob_names)} files")
        
        deleted = []
        failed = []
        
        for blob_name in blob_names:
            result = storage.delete_file(blob_name, user_id=user_id)
            if result['success']:
                deleted.append(blob_name)
            else:
                failed.append({
                    'blob_name': blob_name,
                    'error': result.get('error')
                })
        
        return jsonify({
            'success': len(failed) == 0,
            'deleted': deleted,
            'failed': failed,
            'count': len(deleted),
            'timestamp': datetime.utcnow().isoformat()
        }), 200
    
    except Exception as e:
        logger.error(f"Batch delete error: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500


# ============================================================================
# ERROR HANDLERS
# ============================================================================

@storage_bp.errorhandler(400)
def bad_request(e):
    """Handle 400 Bad Request"""
    return jsonify({
        'error': 'Bad request',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 400


@storage_bp.errorhandler(404)
def not_found(e):
    """Handle 404 Not Found"""
    return jsonify({
        'error': 'Not found',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 404


@storage_bp.errorhandler(413)
def request_entity_too_large(e):
    """Handle 413 Payload Too Large"""
    return jsonify({
        'error': 'File too large',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 413


@storage_bp.errorhandler(500)
def internal_error(e):
    """Handle 500 Internal Server Error"""
    logger.error(f"Internal server error: {e}")
    return jsonify({
        'error': 'Internal server error',
        'message': str(e),
        'timestamp': datetime.utcnow().isoformat()
    }), 500