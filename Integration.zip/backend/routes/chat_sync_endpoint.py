"""
SharePoint Sync Endpoint - Add to chat.py
 
This endpoint allows syncing Excel files from SharePoint directly to the database.
It handles:
1. Download file from SharePoint
2. Clear existing data (override)
3. Import new data
4. Create embeddings
5. Return statistics
"""

from flask import request, jsonify
import logging
import os
import tempfile
from datetime import datetime
import traceback

logger = logging.getLogger(__name__)


def add_sync_endpoint_to_chat_bp(chat_bp, get_db, get_rag_service, get_db_schema):
    """
    Add SharePoint sync endpoint to existing chat blueprint
    
    Usage in chat.py:
        from chat_sync_endpoint import add_sync_endpoint_to_chat_bp
        add_sync_endpoint_to_chat_bp(chat_bp, get_db, get_rag_service, get_db_schema)
    """
    
    @chat_bp.route('/sync-sharepoint', methods=['POST'])
    def sync_sharepoint():
        """
        🔄 Sync Excel file from SharePoint
        
        Request JSON:
        {
            "library_id": "Documents",  // Optional, defaults to 'ICoE'
            "file_name": "interfaces.xlsx"
        }
        
        Response:
        {
            "success": true,
            "message": "SharePoint sync completed successfully",
            "details": {
                "file_name": "interfaces.xlsx",
                "inserted_rows": 150,
                "embeddings_created": 300,
                "columns_mapped": 44,
                "timestamp": "2025-12-02T00:59:38"
            }
        }
        """
        try:
            logger.info("\n" + "="*80)
            logger.info("🔄 SHAREPOINT SYNC INITIATED")
            logger.info("="*80)
            
            # Step 1: Parse request
            logger.info(f"\n📋 STEP 1: Parse Request Data")
            data = request.get_json()
            if not data:
                logger.error("❌ No JSON data provided")
                return jsonify({'success': False, 'error': 'No JSON data provided'}), 400
            
            sharepoint_library = data.get('library_id', '')
            sharepoint_file = data.get('file_name', 'interfaces.xlsx')
            
            logger.info(f"   Library: {sharepoint_library or 'Default (ICoE)'}")
            logger.info(f"   File: {sharepoint_file}")
            
            if not sharepoint_file:
                logger.error("❌ File name required")
                return jsonify({'success': False, 'error': 'File name required'}), 400
            
            # Step 2: Initialize SharePoint connector
            logger.info(f"\n📋 STEP 2: Initialize SharePoint Connector")
            try:
                from backend.connectors.sharepoint_connector import get_sharepoint_connector
                sp_connector = get_sharepoint_connector()
                
                if not sp_connector:
                    logger.error("❌ SharePoint connector not available")
                    return jsonify({
                        'success': False, 
                        'error': 'SharePoint connector not initialized. Check Azure credentials in .env'
                    }), 500
                
                logger.info("✓ SharePoint connector initialized")
            
            except ImportError as ie:
                logger.error(f"❌ Cannot import SharePoint connector: {ie}")
                return jsonify({'success': False, 'error': 'SharePoint module not found'}), 500
            
            except Exception as sp_init_err:
                logger.error(f"❌ SharePoint init failed: {sp_init_err}")
                return jsonify({'success': False, 'error': f'SharePoint init failed: {str(sp_init_err)}'}), 500
            
            # Step 3: Download file from SharePoint
            logger.info(f"\n📋 STEP 3: Download File from SharePoint")
            logger.info(f"   Target file: {sharepoint_file}")
            
            try:
                # Call SharePoint connector to download
                file_content = sp_connector.download_file(
                    library_name=sharepoint_library or 'ICoE',
                    file_name=sharepoint_file
                )
                
                if not file_content:
                    logger.error("❌ File download returned no content")
                    return jsonify({
                        'success': False,
                        'error': f'File not found in SharePoint: {sharepoint_file}. Check library and file name.'
                    }), 404
                
                logger.info(f"✓ Downloaded {len(file_content):,} bytes")
            
            except Exception as download_err:
                logger.error(f"❌ Download failed: {download_err}")
                logger.error(f"   Traceback: {traceback.format_exc()}")
                return jsonify({
                    'success': False,
                    'error': f'Failed to download from SharePoint: {str(download_err)}'
                }), 500
            
            # Step 4: Save to temporary file
            logger.info(f"\n📋 STEP 4: Save to Temporary File")
            
            temp_file = None
            
            try:
                # Create temp file with appropriate extension
                suffix = '.xlsx' if sharepoint_file.lower().endswith('.xlsx') else '.csv'
                
                with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
                    tmp.write(file_content if isinstance(file_content, bytes) else file_content.encode())
                    temp_file = tmp.name
                
                logger.info(f"✓ Saved to: {temp_file}")
            
            except Exception as save_err:
                logger.error(f"❌ Save failed: {save_err}")
                return jsonify({'success': False, 'error': f'File save failed: {str(save_err)}'}), 500
            
            # Step 5: Get database connection
            logger.info(f"\n📋 STEP 5: Connect to Database")
            
            try:
                db = get_db()
                if not db:
                    logger.error("❌ Database connection failed")
                    return jsonify({'success': False, 'error': 'Database connection failed'}), 500
                
                logger.info("✓ Database connected")
            
            except Exception as db_err:
                logger.error(f"❌ Database error: {db_err}")
                return jsonify({'success': False, 'error': f'Database error: {str(db_err)}'}), 500
            
            # Step 6: Clear existing data (OVERRIDE MODE)
            logger.info(f"\n📋 STEP 6: Clear Existing Data (Override Mode)")
            
            try:
                from sqlalchemy import text
                schema = get_db_schema()
                
                # Count before
                count_result = db.execute(text(f"SELECT COUNT(*) FROM {schema}.integration_interfaces"))
                count_before = count_result.scalar() or 0
                logger.info(f"   Records before clear: {count_before:,}")
                
                # Delete embeddings first (foreign key constraint)
                logger.info("   Deleting embeddings...")
                db.execute(text(f"DELETE FROM {schema}.interface_embeddings"))
                
                # Delete interfaces
                logger.info("   Deleting interfaces...")
                db.execute(text(f"DELETE FROM {schema}.integration_interfaces"))
                
                # Commit
                db.commit()
                logger.info(f"   ✓ Cleared {count_before:,} records")
            
            except Exception as clear_err:
                logger.error(f"❌ Clear failed: {clear_err}")
                logger.error(f"   Traceback: {traceback.format_exc()}")
                try:
                    db.rollback()
                except:
                    pass
                
                # Clean up temp file before returning error
                if temp_file and os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except:
                        pass
                
                return jsonify({'success': False, 'error': f'Clear failed: {str(clear_err)}'}), 500
            
            # Step 7: Import new data
            logger.info(f"\n📋 STEP 7: Import New Data from File")
            
            import_result = None

            try:
                from backend.services.data_import_service import DataImportService
                
                rag_service = get_rag_service()
                import_service = DataImportService(db, rag_service)
                
                logger.info(f"   Processing: {temp_file}")
                import_result = import_service.import_excel_file(temp_file)
                
                if not import_result.get('success'):
                    logger.error(f"❌ Import failed: {import_result.get('error')}")
                    
                    # Clean up temp file
                    if temp_file and os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                        except:
                            pass
                    
                    return jsonify({
                        'success': False,
                        'error': f"Import failed: {import_result.get('error')}"
                    }), 500
                
                logger.info(f"   ✓ Imported {import_result['inserted_rows']:,} rows")
                logger.info(f"   ✓ Created {import_result['embeddings_created']} embeddings")
                logger.info(f"   ✓ Mapped {import_result.get('columns_mapped', 0)}/44 columns")
            
            except Exception as import_err:
                logger.error(f"❌ Import error: {import_err}")
                logger.error(f"   Traceback: {traceback.format_exc()}")
                
                # Clean up temp file
                if temp_file and os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except:
                        pass
                
                return jsonify({
                    'success': False,
                    'error': f'Import failed: {str(import_err)}'
                }), 500
            
            finally:
                # Always clean up temp file
                if temp_file and os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                        logger.info("   ✓ Cleaned up temp file")
                    except Exception as cleanup_err:
                        logger.warning(f"   ⚠️ Cleanup warning: {cleanup_err}")
            
            # Step 8: Return success response
            logger.info(f"\n✅ SHAREPOINT SYNC COMPLETED SUCCESSFULLY")
            logger.info("="*80 + "\n")
            
            return jsonify({
                'success': True,
                'message': 'SharePoint sync completed successfully',
                'details': {
                    'file_name': sharepoint_file,
                    'library': sharepoint_library or 'ICoE',
                    'inserted_rows': import_result.get('inserted_rows', 0),
                    'embeddings_created': import_result.get('embeddings_created', 0),
                    'columns_mapped': import_result.get('columns_mapped', 0),
                    'timestamp': datetime.utcnow().isoformat()
                }
            }), 200
        
        except Exception as e:
            logger.error(f"❌ Sync error: {e}")
            logger.error(f"   Type: {type(e).__name__}")
            logger.error(f"   Traceback: {traceback.format_exc()}")
            return jsonify({'success': False, 'error': str(e)}), 500
    
    
    logger.info("✅ SharePoint sync endpoint added to chat blueprint")
    logger.info("   Route: POST /chat/sync-sharepoint")
    logger.info("   Feature: Download Excel from SharePoint and update database")