"""
Flask Configuration Management with Environment Variables (✅ ENHANCED WITH SHAREPOINT)
Handles different environment configurations:
- development, production, testing
- Azure services, SharePoint (ENHANCED), Database, Splunk
- Security, Logging, Caching, File uploads

ENHANCEMENTS APPLIED:
1. Comprehensive SharePoint configuration fields ✅
2. SharePoint authentication (client credentials) ✅
3. SharePoint advanced settings (retry, timeout, batch) ✅
4. SharePoint file operation settings ✅
5. All config fields from the improved service ✅
6. Hugging Face SSL certificate fix ✅ NEW
7. ✅ CRITICAL FIX: Explicit .env path loading from config directory
"""

# ============================================================================
# STEP 1: LOAD .env FIRST (BEFORE ANY CONFIGURATION)
# THIS MUST BE FIRST AND OUTSIDE OF ANY CLASS
# ============================================================================
from dotenv import load_dotenv
import os

# ✅ CRITICAL FIX: Explicitly load .env from config.py's directory
# This works regardless of which directory you run Flask from
PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
ENV_FILE = os.path.join(PROJECT_ROOT, '.env')

print(f"\n{'='*80}")
print(f"📁 Config Loading Debug")
print(f"{'='*80}")
print(f"📁 Backend directory: {PROJECT_ROOT}")
print(f"📄 .env path: {ENV_FILE}")
print(f"✅ .env exists: {os.path.exists(ENV_FILE)}")

loaded = load_dotenv(dotenv_path=ENV_FILE, override=True)  # Force reload to pick up password changes
print(f"✅ .env loaded: {loaded}")
flask_secret = os.getenv('FLASK_SECRET_KEY', 'NOT FOUND')
print(f"🔑 FLASK_SECRET_KEY: {flask_secret[:20]}..." if flask_secret != 'NOT FOUND' else f"🔑 FLASK_SECRET_KEY: NOT FOUND")
print(f"{'='*80}\n")

from datetime import timedelta

# ============================================================================
# STEP 2: SSL CERTIFICATE FIX FOR HUGGING FACE & HTTPS REQUESTS (✅ NEW)
# This fixes: "SSL: CERTIFICATE_VERIFY_FAILED" errors
# Must be set BEFORE importing huggingface_hub or making HTTPS requests
# ============================================================================
SSL_CERT_PATH = os.getenv('SSL_CERT_PATH', './nscacert_combined.pem')
HF_DISABLE_SSL = os.getenv('HF_HUB_DISABLE_SSL_VERIFY', 'False').lower() == 'true'

if HF_DISABLE_SSL:
    # Development only: Disable SSL verification
    os.environ['HF_HUB_DISABLE_SSL_VERIFY'] = '1'
    os.environ['REQUESTS_CA_BUNDLE'] = ''
    os.environ['CURL_CA_BUNDLE'] = ''
    
    # Suppress SSL warnings
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    print("⚠️  SSL verification disabled (development mode)")
    
elif os.path.exists(SSL_CERT_PATH):
    # Production: Use corporate certificate
    os.environ['REQUESTS_CA_BUNDLE'] = SSL_CERT_PATH
    os.environ['SSL_CERT_FILE'] = SSL_CERT_PATH
    os.environ['CURL_CA_BUNDLE'] = SSL_CERT_PATH
    print(f"✅ SSL certificates configured: {SSL_CERT_PATH}")
    
else:
    # Fallback: Try system certificates
    print(f"⚠️  Certificate file not found: {SSL_CERT_PATH}")
    print("   Using system default certificates")


class Config:
    """Base configuration shared across all environments"""
    
    # ========================================================================
    # FLASK CORE CONFIGURATION
    # ========================================================================
    
    SECRET_KEY = os.getenv('FLASK_SECRET_KEY', 'dev-secret-key-change-in-production')
    DEBUG = False
    TESTING = False
    ENV = 'production'
    
    # ========================================================================
    # SSL CERTIFICATE CONFIGURATION (✅ NEW)
    # ========================================================================
    SSL_CERT_PATH = os.getenv('SSL_CERT_PATH', './nscacert_combined.pem')
    SSL_VERIFY = os.getenv('SSL_VERIFY', 'True').lower() == 'true'
    HF_HUB_DISABLE_SSL_VERIFY = os.getenv('HF_HUB_DISABLE_SSL_VERIFY', 'False').lower() == 'true'
    
    # ========================================================================
    # DATABASE CONFIGURATION (✅ CORRECTED PORT)
    # ========================================================================
    DB_SCHEMA = os.getenv('DB_SCHEMA', 'igpt')
    DB_TYPE = os.getenv('DB_TYPE', 'postgresql')
    DB_HOST = os.getenv('DB_HOST', 'localhost')
    DB_PORT = int(os.getenv('DB_PORT', 5434))  # ✅ Changed default from 5432 to 5434
    DB_NAME = os.getenv('DB_NAME', 'api_dev')
    DB_USER = os.getenv('DB_USER', 'icoe_api_dev')
    DB_PASSWORD = os.getenv('DB_PASSWORD', 'password')
    DB_SSLMODE = os.getenv('DB_SSLMODE', 'disable')
    
    # Construct SQLAlchemy URI
    if DB_TYPE == 'postgresql':
        SQLALCHEMY_DATABASE_URI = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    elif DB_TYPE == 'mysql':
        SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    else:
        SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///app.db')
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ECHO = os.getenv('SQLALCHEMY_ECHO', 'False').lower() == 'true'
    SQLALCHEMY_POOL_SIZE = int(os.getenv('SQLALCHEMY_POOL_SIZE', 10))
    SQLALCHEMY_POOL_RECYCLE = int(os.getenv('SQLALCHEMY_POOL_RECYCLE', 3600))
    SQLALCHEMY_POOL_PRE_PING = True
    SQLALCHEMY_POOL_TIMEOUT = int(os.getenv('SQLALCHEMY_POOL_TIMEOUT', 30))
    
    # ========================================================================
    # SESSION CONFIGURATION
    # ========================================================================
    
    PERMANENT_SESSION_LIFETIME = timedelta(days=int(os.getenv('SESSION_LIFETIME_DAYS', 7)))
    SESSION_COOKIE_SECURE = os.getenv('SESSION_COOKIE_SECURE', 'True').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = os.getenv('SESSION_COOKIE_SAMESITE', 'Lax')
    SESSION_COOKIE_NAME = 'session'
    
    # ========================================================================
    # JWT CONFIGURATION
    # ========================================================================
    
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
    JWT_ALGORITHM = os.getenv('JWT_ALGORITHM', 'HS256')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=int(os.getenv('JWT_EXPIRATION_HOURS', 24)))
    
    # ========================================================================
    # CORS CONFIGURATION
    # ========================================================================
    
    CORS_ORIGINS = os.getenv('CORS_ORIGINS', 'http://localhost:3000,http://localhost:5000').split(',')
    CORS_ALLOW_HEADERS = os.getenv('CORS_ALLOW_HEADERS', 'Content-Type,Authorization,X-Requested-With').split(',')
    CORS_ALLOW_METHODS = os.getenv('CORS_ALLOW_METHODS', 'GET,POST,PUT,DELETE,OPTIONS,PATCH').split(',')
    CORS_SUPPORTS_CREDENTIALS = True
    CORS_EXPOSE_HEADERS = ['Content-Type', 'Authorization']
    
    # ========================================================================
    # AZURE AUTHENTICATION
    # ========================================================================
    
    AZURE_CLIENT_ID = os.getenv('AZURE_CLIENT_ID', '')
    AZURE_CLIENT_SECRET = os.getenv('AZURE_CLIENT_SECRET', '')
    AZURE_TENANT_ID = os.getenv('AZURE_TENANT_ID', '')
    AZURE_SUBSCRIPTION_ID = os.getenv('AZURE_SUBSCRIPTION_ID', '')
    
    # ========================================================================
    # AZURE API MANAGEMENT (APIM)
    # ========================================================================
    
    AZURE_APIM_RESOURCE_GROUP = os.getenv('AZURE_APIM_RESOURCE_GROUP', '')
    AZURE_APIM_SERVICE_NAME = os.getenv('AZURE_APIM_SERVICE_NAME', '')
    AZURE_APIM_BASE_URL = os.getenv('AZURE_APIM_BASE_URL', 'https://management.azure.com')
    AZURE_APIM_API_VERSION = os.getenv('AZURE_APIM_API_VERSION', '2023-09-01')
    
    # ========================================================================
    # AZURE OPENAI CONFIGURATION (✅ FULLY CORRECTED)
    # ========================================================================
    
    AZURE_OPENAI_ENDPOINT = os.getenv('AZURE_OPENAI_ENDPOINT', '')
    AZURE_OPENAI_API_KEY = os.getenv('AZURE_OPENAI_API_KEY', '')
    AZURE_OPENAI_DEPLOYMENT = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-5-mini')
    AZURE_OPENAI_API_VERSION = os.getenv('AZURE_OPENAI_API_VERSION', '2025-01-01-preview')
    AZURE_OPENAI_MAX_TOKENS = int(os.getenv('AZURE_OPENAI_MAX_TOKENS', 4096))
    AZURE_OPENAI_TEMPERATURE = float(os.getenv('AZURE_OPENAI_TEMPERATURE', 0.7))
    
    # Backward compatibility
    AZURE_OPENAI_KEY = AZURE_OPENAI_API_KEY
    
    # ========================================================================
    # AZURE STORAGE CONFIGURATION
    # ========================================================================
    
    AZURE_STORAGE_ACCOUNT_NAME = os.getenv('AZURE_STORAGE_ACCOUNT_NAME', '')
    AZURE_STORAGE_ACCOUNT_KEY = os.getenv('AZURE_STORAGE_ACCOUNT_KEY', '')
    AZURE_STORAGE_CONTAINER_NAME = os.getenv('AZURE_STORAGE_CONTAINER_NAME', 'uploads')
    AZURE_STORAGE_CONNECTION_STRING = os.getenv('AZURE_STORAGE_CONNECTION_STRING', '')
    AZURE_STORAGE_MAX_FILE_SIZE = int(os.getenv('AZURE_STORAGE_MAX_FILE_SIZE', 10485760))
    AZURE_STORAGE_ALLOWED_TYPES = os.getenv('AZURE_STORAGE_ALLOWED_TYPES', 'pdf,docx,xlsx,csv,txt,png,jpg').split(',')
    
    # ========================================================================
    # HUGGING FACE CONFIGURATION (✅ NEW)
    # ========================================================================
    
    HF_HOME = os.getenv('HF_HOME', './hf_cache')
    HF_HUB_CACHE = os.getenv('HF_HUB_CACHE', './hf_cache/hub')
    HF_DATASETS_CACHE = os.getenv('HF_DATASETS_CACHE', './hf_cache/datasets')
    HF_TOKEN = os.getenv('HF_TOKEN', '')  # Optional: For private models
    
    # Create Hugging Face cache directories
    os.makedirs(HF_HOME, exist_ok=True)
    os.makedirs(HF_HUB_CACHE, exist_ok=True)
    os.makedirs(HF_DATASETS_CACHE, exist_ok=True)
    
    # ========================================================================
    # SHAREPOINT CONFIGURATION (✅ FULLY ENHANCED)
    # ========================================================================
    # Comprehensive SharePoint configuration for production-ready integration
    # Supports: file downloads, uploads, metadata retrieval, batch operations
    # ========================================================================
    
    # --- CORE SHAREPOINT SETTINGS ---
    
    # SharePoint Site URL (Full URL to your SharePoint site)
    SHAREPOINT_SITE_URL = os.getenv('SHAREPOINT_SITE_URL', '')
    
    # SharePoint Site Path (Relative path like "teams/ICoE")
    SHAREPOINT_SITE_PATH = os.getenv('SHAREPOINT_SITE_PATH', 'teams/ICoE')
    
    # --- AUTHENTICATION SETTINGS ---
    
    # SharePoint Client ID (Application ID from Azure AD)
    SHAREPOINT_CLIENT_ID = os.getenv('SHAREPOINT_CLIENT_ID', '')
    
    # SharePoint Client Secret (Secret value from Azure AD App Registration)
    SHAREPOINT_CLIENT_SECRET = os.getenv('SHAREPOINT_CLIENT_SECRET', '')
    
    # SharePoint Tenant ID (Azure AD Tenant ID, can reuse AZURE_TENANT_ID)
    SHAREPOINT_TENANT_ID = os.getenv('SHAREPOINT_TENANT_ID', os.getenv('AZURE_TENANT_ID', ''))
    
    # --- CONNECTION SETTINGS ---
    
    # SharePoint Timeout (seconds for HTTP requests)
    SHAREPOINT_TIMEOUT = int(os.getenv('SHAREPOINT_TIMEOUT', 30))
    
    # SharePoint Retry Count (number of retry attempts on failure)
    SHAREPOINT_RETRY_COUNT = int(os.getenv('SHAREPOINT_RETRY_COUNT', 3))
    
    # SharePoint Max Retry Delay (maximum delay between retries in seconds)
    SHAREPOINT_MAX_RETRY_DELAY = int(os.getenv('SHAREPOINT_MAX_RETRY_DELAY', 60))
    
    # SharePoint Rate Limit Cooldown (seconds to wait after rate limit)
    SHAREPOINT_RATE_LIMIT_COOLDOWN = int(os.getenv('SHAREPOINT_RATE_LIMIT_COOLDOWN', 60))
    
    # --- SSL/TLS SETTINGS ---
    
    # SharePoint SSL Certificate Path (for custom certificate verification)
    SHAREPOINT_CERT_PATH = os.getenv('SHAREPOINT_CERT_PATH', './nscacert_combined.pem')
    
    # SharePoint Verify SSL (whether to verify SSL certificates)
    SHAREPOINT_VERIFY_SSL = os.getenv('SHAREPOINT_VERIFY_SSL', 'True').lower() == 'true'
    
    # --- TOKEN MANAGEMENT ---
    
    # SharePoint Token Cache Duration (seconds, default 1 hour)
    SHAREPOINT_TOKEN_CACHE_DURATION = int(os.getenv('SHAREPOINT_TOKEN_CACHE_DURATION', 3600))
    
    # SharePoint Token Refresh Buffer (refresh token N seconds before expiry)
    SHAREPOINT_TOKEN_REFRESH_BUFFER = int(os.getenv('SHAREPOINT_TOKEN_REFRESH_BUFFER', 300))
    
    # --- FILE OPERATION SETTINGS ---
    
    # SharePoint Default Folder Path (default folder for file operations)
    SHAREPOINT_DEFAULT_FOLDER = os.getenv('SHAREPOINT_DEFAULT_FOLDER', 'Gen2-Transition Deliverables')
    
    # SharePoint Download Path (local directory for downloads)
    SHAREPOINT_DOWNLOAD_PATH = os.getenv('SHAREPOINT_DOWNLOAD_PATH', './downloads')
    
    # SharePoint Upload Path (local directory for uploads staging)
    SHAREPOINT_UPLOAD_PATH = os.getenv('SHAREPOINT_UPLOAD_PATH', './uploads')
    
    # SharePoint Temp Path (temporary file storage)
    SHAREPOINT_TEMP_PATH = os.getenv('SHAREPOINT_TEMP_PATH', './temp/sharepoint')
    
    # --- BATCH OPERATION SETTINGS ---
    
    # SharePoint Enable Batch Operations (True/False)
    SHAREPOINT_ENABLE_BATCH = os.getenv('SHAREPOINT_ENABLE_BATCH', 'True').lower() == 'true'
    
    # SharePoint Batch Size (number of files per batch operation)
    SHAREPOINT_BATCH_SIZE = int(os.getenv('SHAREPOINT_BATCH_SIZE', 10))
    
    # SharePoint Max Concurrent Requests (for parallel operations)
    SHAREPOINT_MAX_CONCURRENT_REQUESTS = int(os.getenv('SHAREPOINT_MAX_CONCURRENT_REQUESTS', 5))
    
    # --- STREAMING SETTINGS ---
    
    # SharePoint Stream Downloads (enable streaming for large files)
    SHAREPOINT_STREAM_DOWNLOADS = os.getenv('SHAREPOINT_STREAM_DOWNLOADS', 'True').lower() == 'true'
    
    # SharePoint Chunk Size (bytes per chunk for streaming)
    SHAREPOINT_CHUNK_SIZE = int(os.getenv('SHAREPOINT_CHUNK_SIZE', 8192))
    
    # SharePoint Max File Size (maximum file size for downloads in bytes)
    SHAREPOINT_MAX_FILE_SIZE = int(os.getenv('SHAREPOINT_MAX_FILE_SIZE', 104857600))  # 100MB
    
    # --- CONNECTION POOLING ---
    
    # SharePoint Connection Pool Size (number of persistent connections)
    SHAREPOINT_POOL_SIZE = int(os.getenv('SHAREPOINT_POOL_SIZE', 5))
    
    # SharePoint Connection Pool Timeout (seconds)
    SHAREPOINT_POOL_TIMEOUT = int(os.getenv('SHAREPOINT_POOL_TIMEOUT', 30))
    
    # SharePoint Pool Recycle (recycle connections after N seconds)
    SHAREPOINT_POOL_RECYCLE = int(os.getenv('SHAREPOINT_POOL_RECYCLE', 3600))
    
    # --- CACHING SETTINGS ---
    
    # SharePoint Enable Cache (cache file metadata and list results)
    SHAREPOINT_ENABLE_CACHE = os.getenv('SHAREPOINT_ENABLE_CACHE', 'True').lower() == 'true'
    
    # SharePoint Cache TTL (time-to-live for cached data in seconds)
    SHAREPOINT_CACHE_TTL = int(os.getenv('SHAREPOINT_CACHE_TTL', 300))
    
    # --- LOGGING SETTINGS ---
    
    # SharePoint Log Level (DEBUG, INFO, WARNING, ERROR)
    SHAREPOINT_LOG_LEVEL = os.getenv('SHAREPOINT_LOG_LEVEL', 'INFO')
    
    # SharePoint Enable Request Logging (log all HTTP requests)
    SHAREPOINT_LOG_REQUESTS = os.getenv('SHAREPOINT_LOG_REQUESTS', 'False').lower() == 'true'
    
    # SharePoint Enable Stats Logging (log operation statistics)
    SHAREPOINT_LOG_STATS = os.getenv('SHAREPOINT_LOG_STATS', 'True').lower() == 'true'
    
    # --- MICROSOFT GRAPH API SETTINGS ---
    
    # SharePoint Graph API Endpoint (Microsoft Graph API base URL)
    SHAREPOINT_GRAPH_ENDPOINT = os.getenv('SHAREPOINT_GRAPH_ENDPOINT', 'https://graph.microsoft.com/v1.0')
    
    # SharePoint Graph API Version (API version)
    SHAREPOINT_GRAPH_API_VERSION = os.getenv('SHAREPOINT_GRAPH_API_VERSION', 'v1.0')
    
    # SharePoint Auth Endpoint (Microsoft login endpoint)
    SHAREPOINT_AUTH_ENDPOINT = os.getenv('SHAREPOINT_AUTH_ENDPOINT', 'https://login.microsoftonline.com')
    
    # SharePoint Scope (OAuth scope for Microsoft Graph)
    SHAREPOINT_SCOPE = os.getenv('SHAREPOINT_SCOPE', 'https://graph.microsoft.com/.default')
    
    # --- ADVANCED SETTINGS ---
    
    # SharePoint Enable Metadata Caching (cache file/folder metadata)
    SHAREPOINT_ENABLE_METADATA_CACHE = os.getenv('SHAREPOINT_ENABLE_METADATA_CACHE', 'True').lower() == 'true'
    
    # SharePoint Enable Progress Callbacks (support progress tracking)
    SHAREPOINT_ENABLE_PROGRESS = os.getenv('SHAREPOINT_ENABLE_PROGRESS', 'True').lower() == 'true'
    
    # SharePoint Enable Compression (compress data in transit)
    SHAREPOINT_ENABLE_COMPRESSION = os.getenv('SHAREPOINT_ENABLE_COMPRESSION', 'True').lower() == 'true'
    
    # SharePoint Enable Auto Retry (automatically retry failed operations)
    SHAREPOINT_ENABLE_AUTO_RETRY = os.getenv('SHAREPOINT_ENABLE_AUTO_RETRY', 'True').lower() == 'true'
    
    # SharePoint Backoff Factor (exponential backoff multiplier)
    SHAREPOINT_BACKOFF_FACTOR = float(os.getenv('SHAREPOINT_BACKOFF_FACTOR', 2.0))
    
    # --- FEATURE FLAGS ---
    
    # SharePoint Enable File Upload (allow file uploads to SharePoint)
    SHAREPOINT_ENABLE_UPLOAD = os.getenv('SHAREPOINT_ENABLE_UPLOAD', 'True').lower() == 'true'
    
    # SharePoint Enable File Download (allow file downloads from SharePoint)
    SHAREPOINT_ENABLE_DOWNLOAD = os.getenv('SHAREPOINT_ENABLE_DOWNLOAD', 'True').lower() == 'true'
    
    # SharePoint Enable File Delete (allow file deletion from SharePoint)
    SHAREPOINT_ENABLE_DELETE = os.getenv('SHAREPOINT_ENABLE_DELETE', 'False').lower() == 'true'
    
    # SharePoint Enable Folder Operations (allow folder creation/deletion)
    SHAREPOINT_ENABLE_FOLDER_OPS = os.getenv('SHAREPOINT_ENABLE_FOLDER_OPS', 'True').lower() == 'true'
    
    # SharePoint Enable Search (enable SharePoint search functionality)
    SHAREPOINT_ENABLE_SEARCH = os.getenv('SHAREPOINT_ENABLE_SEARCH', 'True').lower() == 'true'
    
    # --- ERROR HANDLING ---
    
    # SharePoint Raise On Error (raise exceptions vs return None)
    SHAREPOINT_RAISE_ON_ERROR = os.getenv('SHAREPOINT_RAISE_ON_ERROR', 'False').lower() == 'true'
    
    # SharePoint Error Email (email address for error notifications)
    SHAREPOINT_ERROR_EMAIL = os.getenv('SHAREPOINT_ERROR_EMAIL', '')
    
    # SharePoint Enable Error Notifications (send email on errors)
    SHAREPOINT_ENABLE_ERROR_NOTIFICATIONS = os.getenv('SHAREPOINT_ENABLE_ERROR_NOTIFICATIONS', 'False').lower() == 'true'
    
    # Create necessary directories
    os.makedirs(SHAREPOINT_DOWNLOAD_PATH, exist_ok=True)
    os.makedirs(SHAREPOINT_UPLOAD_PATH, exist_ok=True)
    os.makedirs(SHAREPOINT_TEMP_PATH, exist_ok=True)
    
    # ========================================================================
    # SPLUNK CONFIGURATION (✅ UPDATED)
    # ========================================================================
    
    SPLUNK_HOST = os.getenv('SPLUNK_HOST', '')
    SPLUNK_PORT = int(os.getenv('SPLUNK_PORT', 8089))
    SPLUNK_SCHEME = os.getenv('SPLUNK_SCHEME', 'https')
    SPLUNK_USERNAME = os.getenv('SPLUNK_USERNAME', '')
    SPLUNK_PASSWORD = os.getenv('SPLUNK_PASSWORD', '')
    SPLUNK_BEARER_TOKEN = os.getenv('SPLUNK_BEARER_TOKEN', '')
    SPLUNK_TOKEN_TYPE = os.getenv('SPLUNK_TOKEN_TYPE', 'Splunk')
    SPLUNK_VERIFY_SSL = os.getenv('SPLUNK_VERIFY_SSL', 'False').lower() == 'true'
    SPLUNK_TIMEOUT = int(os.getenv('SPLUNK_TIMEOUT', 30))
    SPLUNK_MAX_RETRIES = int(os.getenv('SPLUNK_MAX_RETRIES', 3))
    SPLUNK_CONNECTION_COOLDOWN = int(os.getenv('SPLUNK_CONNECTION_COOLDOWN', 30))
    
    # ========================================================================
    # API CONFIGURATION
    # ========================================================================
    
    API_RATE_LIMIT = int(os.getenv('API_RATE_LIMIT', 1000))
    API_RATE_LIMIT_WINDOW = int(os.getenv('API_RATE_LIMIT_WINDOW', 3600))
    API_TIMEOUT = int(os.getenv('API_TIMEOUT', 30))
    JSON_SORT_KEYS = False
    JSONIFY_PRETTYPRINT_REGULAR = False
    
    # ========================================================================
    # SECURITY CONFIGURATION
    # ========================================================================
    
    PASSWORD_MIN_LENGTH = int(os.getenv('PASSWORD_MIN_LENGTH', 8))
    PASSWORD_REQUIRE_UPPERCASE = os.getenv('PASSWORD_REQUIRE_UPPERCASE', 'True').lower() == 'true'
    PASSWORD_REQUIRE_LOWERCASE = os.getenv('PASSWORD_REQUIRE_LOWERCASE', 'True').lower() == 'true'
    PASSWORD_REQUIRE_NUMBERS = os.getenv('PASSWORD_REQUIRE_NUMBERS', 'True').lower() == 'true'
    PASSWORD_REQUIRE_SPECIAL = os.getenv('PASSWORD_REQUIRE_SPECIAL', 'True').lower() == 'true'
    
    CSRF_ENABLED = os.getenv('CSRF_ENABLED', 'True').lower() == 'true'
    
    # ========================================================================
    # FILE UPLOAD CONFIGURATION
    # ========================================================================
    
    MAX_FILE_SIZE = int(os.getenv('MAX_FILE_SIZE', 10485760))  # 10MB
    MAX_CONTENT_LENGTH = MAX_FILE_SIZE
    ALLOWED_FILE_EXTENSIONS = set(os.getenv('ALLOWED_FILE_EXTENSIONS', 'txt,pdf,png,jpg,jpeg,gif,doc,docx,xls,xlsx,csv,py,js,java,cpp,c').split(','))
    UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'uploads')
    TEMP_FOLDER = os.getenv('TEMP_FOLDER', 'temp')
    
    # Create folders if they don't exist
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(TEMP_FOLDER, exist_ok=True)
    
    # ========================================================================
    # LOGGING CONFIGURATION
    # ========================================================================
    
    LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE = os.getenv('LOG_FILE', 'logs/app.log')
    LOG_FILE_MAX_BYTES = int(os.getenv('LOG_FILE_MAX_BYTES', 10485760))
    LOG_FILE_BACKUP_COUNT = int(os.getenv('LOG_FILE_BACKUP_COUNT', 10))
    LOG_FORMAT = os.getenv('LOG_FORMAT', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    LOG_DATE_FORMAT = os.getenv('LOG_DATE_FORMAT', '%Y-%m-%d %H:%M:%S')
    
    # Create logs directory
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
    
    # ========================================================================
    # CACHING CONFIGURATION
    # ========================================================================
    
    CACHE_TYPE = os.getenv('CACHE_TYPE', 'simple')
    CACHE_DEFAULT_TIMEOUT = int(os.getenv('CACHE_DEFAULT_TIMEOUT', 300))
    REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
    REDIS_PORT = int(os.getenv('REDIS_PORT', 6379))
    REDIS_PASSWORD = os.getenv('REDIS_PASSWORD', None)
    REDIS_DB = int(os.getenv('REDIS_DB', 0))
    
    # ========================================================================
    # EMAIL CONFIGURATION
    # ========================================================================
    
    EMAIL_PROVIDER = os.getenv('EMAIL_PROVIDER', 'smtp')
    EMAIL_HOST = os.getenv('EMAIL_HOST', 'smtp.gmail.com')
    EMAIL_PORT = int(os.getenv('EMAIL_PORT', 587))
    EMAIL_USERNAME = os.getenv('EMAIL_USERNAME', '')
    EMAIL_PASSWORD = os.getenv('EMAIL_PASSWORD', '')
    EMAIL_FROM = os.getenv('EMAIL_FROM', 'noreply@dashboard.com')
    EMAIL_USE_TLS = os.getenv('EMAIL_USE_TLS', 'True').lower() == 'true'
    
    # ========================================================================
    # MONITORING & ANALYTICS
    # ========================================================================
    
    APPINSIGHTS_INSTRUMENTATION_KEY = os.getenv('APPINSIGHTS_INSTRUMENTATION_KEY', '')
    APPINSIGHTS_ENABLED = os.getenv('APPINSIGHTS_ENABLED', 'False').lower() == 'true'
    
    SENTRY_DSN = os.getenv('SENTRY_DSN', '')
    SENTRY_ENABLED = os.getenv('SENTRY_ENABLED', 'False').lower() == 'true'
    SENTRY_TRACES_SAMPLE_RATE = float(os.getenv('SENTRY_TRACES_SAMPLE_RATE', 1.0))
    
    # ========================================================================
    # FEATURE FLAGS
    # ========================================================================
    
    FEATURE_AZURE_INTEGRATION = os.getenv('FEATURE_AZURE_INTEGRATION', 'True').lower() == 'true'
    FEATURE_AZURE_APIM_INTEGRATION = os.getenv('FEATURE_AZURE_APIM_INTEGRATION', 'True').lower() == 'true'
    FEATURE_SHAREPOINT_INTEGRATION = os.getenv('FEATURE_SHAREPOINT_INTEGRATION', 'True').lower() == 'true'
    FEATURE_AI_SERVICES = os.getenv('FEATURE_AI_SERVICES', 'True').lower() == 'true'
    FEATURE_STORAGE_MANAGEMENT = os.getenv('FEATURE_STORAGE_MANAGEMENT', 'True').lower() == 'true'
    FEATURE_SPLUNK_QUERIES = os.getenv('FEATURE_SPLUNK_QUERIES', 'True').lower() == 'true'
    FEATURE_EMAIL_NOTIFICATIONS = os.getenv('FEATURE_EMAIL_NOTIFICATIONS', 'False').lower() == 'true'
    FEATURE_SLACK_INTEGRATION = os.getenv('FEATURE_SLACK_INTEGRATION', 'False').lower() == 'true'
    FEATURE_CHATBOT = os.getenv('FEATURE_CHATBOT', 'True').lower() == 'true'
    
    # ========================================================================
    # APPLICATION METADATA
    # ========================================================================
    
    APP_NAME = os.getenv('APP_NAME', '360° Enterprise Dashboard')
    APP_VERSION = '4.3.0'
    APP_DESCRIPTION = os.getenv('APP_DESCRIPTION', 'Enterprise Integration Dashboard with AI')
    TIMEZONE = os.getenv('TIMEZONE', 'UTC')


class DevelopmentConfig(Config):
    """Development configuration"""
    ENV = 'development'
    DEBUG = True
    TESTING = False
    SESSION_COOKIE_SECURE = False
    SQLALCHEMY_ECHO = True
    LOG_LEVEL = 'DEBUG'
    FEATURE_EMAIL_NOTIFICATIONS = True
    SHAREPOINT_LOG_LEVEL = 'DEBUG'
    SHAREPOINT_LOG_REQUESTS = True


class ProductionConfig(Config):
    """Production configuration"""
    ENV = 'production'
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_SECURE = True
    SQLALCHEMY_ECHO = False
    LOG_LEVEL = 'WARNING'
    SHAREPOINT_LOG_LEVEL = 'WARNING'
    SHAREPOINT_LOG_REQUESTS = False


class TestingConfig(Config):
    """Testing configuration"""
    ENV = 'testing'
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    SESSION_COOKIE_SECURE = False
    WTF_CSRF_ENABLED = False
    LOG_LEVEL = 'DEBUG'
    SHAREPOINT_LOG_LEVEL = 'DEBUG'
    SHAREPOINT_ENABLE_CACHE = False


# Configuration dictionary for easy access
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}


def get_config(env=None):
    """Get configuration object for the specified environment"""
    if env is None:
        env = os.getenv('FLASK_ENV', 'development')
    return config.get(env, config['default'])