-- ============================================================================
-- 360° ENTERPRISE DASHBOARD - PRODUCTION DATABASE INITIALIZATION
-- ============================================================================
-- Version: 4.5.0
-- Date: December 2025
-- Purpose: Complete database schema for Azure PostgreSQL deployment
-- Schema: igpt
-- ============================================================================
-- USAGE:
--   psql -h <host> -U <user> -d <database> -f init-production.sql
--   OR paste into Azure Data Studio / pgAdmin
-- ============================================================================

SET timezone = 'America/Los_Angeles';

-- ============================================================================
-- SECTION 1: CREATE SCHEMA AND EXTENSIONS
-- ============================================================================

CREATE SCHEMA IF NOT EXISTS igpt;
SET search_path TO igpt;

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS vector;

SELECT '✅ Schema and extensions created' as status;

-- ============================================================================
-- SECTION 2: DROP EXISTING OBJECTS (FOR CLEAN INSTALL)
-- ============================================================================

-- Drop views first (they depend on tables)
DROP VIEW IF EXISTS igpt.dashboard_360_summary CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_storage_usage CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_ai_usage CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_integration_status CASCADE;
DROP VIEW IF EXISTS igpt.dashboard_360_user_stats CASCADE;
DROP VIEW IF EXISTS igpt.rag_performance_stats CASCADE;
DROP VIEW IF EXISTS igpt.rag_query_logs_view CASCADE;
DROP VIEW IF EXISTS igpt.vector_search_results CASCADE;
DROP VIEW IF EXISTS igpt.interface_embeddings_summary CASCADE;
DROP VIEW IF EXISTS igpt.users_with_roles CASCADE;
DROP VIEW IF EXISTS igpt.chat_sessions_view CASCADE;

-- Drop functions
DROP FUNCTION IF EXISTS igpt.update_session_on_message() CASCADE;
DROP FUNCTION IF EXISTS igpt.update_user_preferences_updated_at() CASCADE;
DROP FUNCTION IF EXISTS igpt.user_has_role(INTEGER, VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS igpt.user_has_permission(INTEGER, VARCHAR) CASCADE;
DROP FUNCTION IF EXISTS igpt.assign_role(INTEGER, VARCHAR, INTEGER) CASCADE;
DROP FUNCTION IF EXISTS igpt.remove_role(INTEGER, VARCHAR) CASCADE;

-- Drop tables (order matters due to foreign keys)
DROP TABLE IF EXISTS igpt.chat_messages CASCADE;
DROP TABLE IF EXISTS igpt.chat_sessions CASCADE;
DROP TABLE IF EXISTS igpt.rag_query_logs CASCADE;
DROP TABLE IF EXISTS igpt.rag_interactions CASCADE;
DROP TABLE IF EXISTS igpt.embedding_cache CASCADE;
DROP TABLE IF EXISTS igpt.interface_embeddings CASCADE;
DROP TABLE IF EXISTS igpt.integration_interfaces CASCADE;
DROP TABLE IF EXISTS igpt.storage_files CASCADE;
DROP TABLE IF EXISTS igpt.ai_interactions CASCADE;
DROP TABLE IF EXISTS igpt.sharepoint_integrations CASCADE;
DROP TABLE IF EXISTS igpt.azure_integrations CASCADE;
DROP TABLE IF EXISTS igpt.import_history CASCADE;
DROP TABLE IF EXISTS igpt.user_preferences CASCADE;
DROP TABLE IF EXISTS igpt.user_roles CASCADE;
DROP TABLE IF EXISTS igpt.roles CASCADE;
DROP TABLE IF EXISTS igpt.users CASCADE;

SELECT '✅ Old objects dropped' as status;

-- ============================================================================
-- SECTION 3: CORE TABLES
-- ============================================================================

-- 3.1 USERS TABLE
CREATE TABLE igpt.users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(120) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    CONSTRAINT email_check CHECK (email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}$')
);

CREATE INDEX idx_users_email ON igpt.users(email);
CREATE INDEX idx_users_created_at ON igpt.users(created_at DESC);
CREATE INDEX idx_users_is_active ON igpt.users(is_active);

COMMENT ON TABLE igpt.users IS '360° Dashboard - User accounts';

-- 3.2 ROLES TABLE
CREATE TABLE igpt.roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO igpt.roles (name, description, permissions) VALUES
    ('admin', 'Full system access - can upload data, manage users, access admin pages',
     '{"upload_data": true, "manage_users": true, "view_admin": true, "delete_data": true, "view_reports": true, "use_chat": true}'),
    ('user', 'Standard user - can view data, use chat, view reports',
     '{"upload_data": false, "manage_users": false, "view_admin": false, "delete_data": false, "view_reports": true, "use_chat": true}'),
    ('readonly', 'Read-only access - can only view data and reports',
     '{"upload_data": false, "manage_users": false, "view_admin": false, "delete_data": false, "view_reports": true, "use_chat": false}')
ON CONFLICT (name) DO NOTHING;

CREATE INDEX idx_roles_name ON igpt.roles(name);

COMMENT ON TABLE igpt.roles IS '360° Dashboard - User roles for access control';

-- 3.3 USER_ROLES TABLE (Many-to-Many)
CREATE TABLE igpt.user_roles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    role_id INTEGER NOT NULL REFERENCES igpt.roles(id) ON DELETE CASCADE,
    assigned_by INTEGER REFERENCES igpt.users(id) ON DELETE SET NULL,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_role UNIQUE(user_id, role_id)
);

CREATE INDEX idx_user_roles_user_id ON igpt.user_roles(user_id);
CREATE INDEX idx_user_roles_role_id ON igpt.user_roles(role_id);

COMMENT ON TABLE igpt.user_roles IS '360° Dashboard - User to role assignments';

-- 3.4 USER_PREFERENCES TABLE
CREATE TABLE igpt.user_preferences (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL UNIQUE REFERENCES igpt.users(id) ON DELETE CASCADE,
    theme VARCHAR(20) DEFAULT 'light' CHECK (theme IN ('light', 'dark', 'system')),
    preferences JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_user_preferences_user_id ON igpt.user_preferences(user_id);

COMMENT ON TABLE igpt.user_preferences IS '360° Dashboard - User preferences for theme and settings';

-- 3.5 IMPORT_HISTORY TABLE
CREATE TABLE igpt.import_history (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    file_size INTEGER NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    rows_imported INTEGER DEFAULT 0,
    embeddings_created INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'processing')),
    error_message TEXT,
    processing_time_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_import_history_user_id ON igpt.import_history(user_id);
CREATE INDEX idx_import_history_status ON igpt.import_history(status);
CREATE INDEX idx_import_history_created_at ON igpt.import_history(created_at DESC);

COMMENT ON TABLE igpt.import_history IS '360° Dashboard - Data import history tracking';

SELECT '✅ Core tables created (users, roles, preferences, import_history)' as status;

-- ============================================================================
-- SECTION 4: INTEGRATION TABLES
-- ============================================================================

-- 4.1 AZURE INTEGRATIONS
CREATE TABLE igpt.azure_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    subscription_id VARCHAR(255) NOT NULL,
    tenant_id VARCHAR(255) NOT NULL,
    client_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    resources_count INTEGER DEFAULT 24,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_subscription UNIQUE(user_id, subscription_id)
);

CREATE INDEX idx_azure_user_id ON igpt.azure_integrations(user_id);
CREATE INDEX idx_azure_status ON igpt.azure_integrations(status);
CREATE INDEX idx_azure_created_at ON igpt.azure_integrations(created_at DESC);

COMMENT ON TABLE igpt.azure_integrations IS '360° Dashboard - Azure subscription integrations';

-- 4.2 SHAREPOINT INTEGRATIONS
CREATE TABLE igpt.sharepoint_integrations (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    site_url VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'connected' CHECK (status IN ('connected', 'disconnected', 'error')),
    last_sync TIMESTAMP WITH TIME ZONE,
    documents_count INTEGER DEFAULT 0,
    sites_count INTEGER DEFAULT 8,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_user_site UNIQUE(user_id, site_url)
);

CREATE INDEX idx_sharepoint_user_id ON igpt.sharepoint_integrations(user_id);
CREATE INDEX idx_sharepoint_status ON igpt.sharepoint_integrations(status);
CREATE INDEX idx_sharepoint_created_at ON igpt.sharepoint_integrations(created_at DESC);

COMMENT ON TABLE igpt.sharepoint_integrations IS '360° Dashboard - SharePoint site integrations';

SELECT '✅ Integration tables created (azure, sharepoint)' as status;

-- ============================================================================
-- SECTION 5: AI & STORAGE TABLES
-- ============================================================================

-- 5.1 AI INTERACTIONS
CREATE TABLE igpt.ai_interactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    interaction_type VARCHAR(50) NOT NULL CHECK (interaction_type IN ('code_review', 'summary', 'generation')),
    input_text TEXT NOT NULL,
    output_text TEXT,
    tokens_used INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success', 'failed')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ai_user_id ON igpt.ai_interactions(user_id);
CREATE INDEX idx_ai_type ON igpt.ai_interactions(interaction_type);
CREATE INDEX idx_ai_status ON igpt.ai_interactions(status);
CREATE INDEX idx_ai_created_at ON igpt.ai_interactions(created_at DESC);
CREATE INDEX idx_ai_interactions_user_type ON igpt.ai_interactions(user_id, interaction_type);

COMMENT ON TABLE igpt.ai_interactions IS '360° Dashboard - Azure OpenAI interaction logs';

-- 5.2 STORAGE FILES
CREATE TABLE igpt.storage_files (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,
    blob_name VARCHAR(255) NOT NULL,
    blob_url VARCHAR(500) NOT NULL,
    file_size INTEGER NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'failed', 'deleted')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT file_size_check CHECK (file_size > 0 AND file_size <= 10485760)
);

CREATE INDEX idx_storage_user_id ON igpt.storage_files(user_id);
CREATE INDEX idx_storage_status ON igpt.storage_files(status);
CREATE INDEX idx_storage_type ON igpt.storage_files(file_type);
CREATE INDEX idx_storage_created_at ON igpt.storage_files(created_at DESC);
CREATE INDEX idx_storage_filename ON igpt.storage_files(filename);
CREATE INDEX idx_storage_files_user_type ON igpt.storage_files(user_id, file_type);

COMMENT ON TABLE igpt.storage_files IS '360° Dashboard - Files uploaded to Azure Blob Storage';

SELECT '✅ AI and Storage tables created' as status;

-- ============================================================================
-- SECTION 6: INTEGRATION INTERFACES & EMBEDDINGS (RAG)
-- ============================================================================

-- 6.1 INTEGRATION INTERFACES
CREATE TABLE igpt.integration_interfaces (
    id SERIAL PRIMARY KEY,
    interface_platform VARCHAR(255),
    interface_id VARCHAR(255) UNIQUE NOT NULL,
    sub_interface VARCHAR(255),
    interface_name VARCHAR(500),
    operation_name VARCHAR(255),
    api_product_name VARCHAR(255),
    interface_description TEXT,
    dependency_id VARCHAR(255),
    process_area VARCHAR(255),
    interface_pattern VARCHAR(255),

    -- Source system info
    source_ci_type VARCHAR(255),
    source_name VARCHAR(255),
    source_service_url VARCHAR(500),
    source_protocol VARCHAR(255),
    source_data_format VARCHAR(255),
    source_trust_level VARCHAR(255),
    source_resolver_contact VARCHAR(255),
    source_intermediary VARCHAR(255),

    -- Target system info
    target_ci_type VARCHAR(255),
    target_name VARCHAR(255),
    target_service_url VARCHAR(500),
    target_protocol VARCHAR(255),
    target_data_format VARCHAR(255),
    target_trust_level VARCHAR(255),
    target_resolver_contact VARCHAR(255),
    target_intermediary VARCHAR(255),

    -- Communication & timing
    communication_mode VARCHAR(255),
    volume VARCHAR(255),
    frequency VARCHAR(255),
    schedule VARCHAR(255),

    -- Quality & management
    interface_resolver_group VARCHAR(255),
    qos VARCHAR(255),
    retention_period VARCHAR(255),
    priority VARCHAR(50),
    status VARCHAR(100),

    -- Project & metadata
    project_name VARCHAR(255),
    production_migration_date VARCHAR(255),
    pid_wo VARCHAR(255),
    reuse_status VARCHAR(100),
    integration_pattern VARCHAR(255),
    interface_mode VARCHAR(255),
    ou VARCHAR(255),
    comments TEXT,
    interface_build_type VARCHAR(255),

    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_integration_interfaces_id ON igpt.integration_interfaces(interface_id);
CREATE INDEX idx_integration_interfaces_platform ON igpt.integration_interfaces(interface_platform);
CREATE INDEX idx_integration_interfaces_pattern ON igpt.integration_interfaces(interface_pattern);
CREATE INDEX idx_integration_interfaces_reuse_status ON igpt.integration_interfaces(reuse_status);
CREATE INDEX idx_integration_interfaces_status ON igpt.integration_interfaces(status);
CREATE INDEX idx_integration_interfaces_created_at ON igpt.integration_interfaces(created_at DESC);
CREATE INDEX idx_integration_interfaces_source_target ON igpt.integration_interfaces(source_name, target_name);

COMMENT ON TABLE igpt.integration_interfaces IS '360° Dashboard - Integration interface catalog';

-- 6.2 INTERFACE EMBEDDINGS (Vector)
CREATE TABLE igpt.interface_embeddings (
    id SERIAL PRIMARY KEY,
    interface_id VARCHAR(255) NOT NULL REFERENCES igpt.integration_interfaces(interface_id) ON DELETE CASCADE,
    content_type VARCHAR(100) NOT NULL,
    content TEXT NOT NULL,
    embedding vector(384),
    embedding_model VARCHAR(100) DEFAULT 'all-MiniLM-L6-v2',
    embedding_dimensions INTEGER DEFAULT 384,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_interface_content_type UNIQUE(interface_id, content_type)
);

-- Vector similarity index (for fast semantic search)
CREATE INDEX idx_interface_embeddings_vector ON igpt.interface_embeddings
    USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 100);

CREATE INDEX idx_interface_embeddings_interface_id ON igpt.interface_embeddings(interface_id);
CREATE INDEX idx_interface_embeddings_content_type ON igpt.interface_embeddings(content_type);
CREATE INDEX idx_interface_embeddings_created_at ON igpt.interface_embeddings(created_at DESC);
CREATE INDEX idx_interface_embeddings_model ON igpt.interface_embeddings(embedding_model);

COMMENT ON TABLE igpt.interface_embeddings IS '360° Dashboard - Vector embeddings for RAG semantic search';

SELECT '✅ Integration interfaces and embeddings tables created' as status;

-- ============================================================================
-- SECTION 7: RAG LOGGING TABLES
-- ============================================================================

-- 7.1 RAG QUERY LOGS
CREATE TABLE igpt.rag_query_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    query_text TEXT NOT NULL,
    query_type VARCHAR(100),
    status VARCHAR(50) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'timeout')),
    response_text TEXT,
    tokens_used INTEGER DEFAULT 0,
    execution_time_ms INTEGER,
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_rag_query_logs_user_id ON igpt.rag_query_logs(user_id);
CREATE INDEX idx_rag_query_logs_timestamp ON igpt.rag_query_logs(created_at DESC);
CREATE INDEX idx_rag_query_logs_status ON igpt.rag_query_logs(status);
CREATE INDEX idx_rag_query_logs_query_type ON igpt.rag_query_logs(query_type);

COMMENT ON TABLE igpt.rag_query_logs IS '360° Dashboard - RAG query logs';

-- 7.2 RAG INTERACTIONS
CREATE TABLE igpt.rag_interactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES igpt.users(id) ON DELETE CASCADE,
    query_type VARCHAR(100) NOT NULL,
    input_query TEXT NOT NULL,
    retrieved_documents INTEGER DEFAULT 0,
    output_response TEXT,
    confidence_score NUMERIC(3,2),
    tokens_used INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'partial')),
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_rag_interactions_user_id ON igpt.rag_interactions(user_id);
CREATE INDEX idx_rag_interactions_created_at ON igpt.rag_interactions(created_at DESC);
CREATE INDEX idx_rag_interactions_query_type ON igpt.rag_interactions(query_type);
CREATE INDEX idx_rag_interactions_status ON igpt.rag_interactions(status);

COMMENT ON TABLE igpt.rag_interactions IS '360° Dashboard - RAG user interactions';

-- 7.3 EMBEDDING CACHE
CREATE TABLE igpt.embedding_cache (
    id SERIAL PRIMARY KEY,
    content_hash VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    embedding vector(384),
    embedding_model VARCHAR(100) DEFAULT 'all-MiniLM-L6-v2',
    cache_hits INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_embedding_cache_hash ON igpt.embedding_cache(content_hash);
CREATE INDEX idx_embedding_cache_created_at ON igpt.embedding_cache(created_at DESC);
CREATE INDEX idx_embedding_cache_model ON igpt.embedding_cache(embedding_model);

COMMENT ON TABLE igpt.embedding_cache IS '360° Dashboard - Embedding cache for performance';

SELECT '✅ RAG logging tables created' as status;

-- ============================================================================
-- SECTION 8: CHAT TABLES
-- ============================================================================

-- 8.1 CHAT SESSIONS
CREATE TABLE igpt.chat_sessions (
    id SERIAL PRIMARY KEY,
    session_id UUID DEFAULT uuid_generate_v4() UNIQUE NOT NULL,
    user_id INTEGER REFERENCES igpt.users(id) ON DELETE CASCADE,
    title VARCHAR(255) DEFAULT 'New Chat',
    first_message TEXT,
    last_message TEXT,
    message_count INTEGER DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'archived', 'deleted')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_chat_sessions_user_id ON igpt.chat_sessions(user_id);
CREATE INDEX idx_chat_sessions_session_id ON igpt.chat_sessions(session_id);
CREATE INDEX idx_chat_sessions_status ON igpt.chat_sessions(status);
CREATE INDEX idx_chat_sessions_updated_at ON igpt.chat_sessions(updated_at DESC);

COMMENT ON TABLE igpt.chat_sessions IS '360° Dashboard - Chat conversation sessions';

-- 8.2 CHAT MESSAGES
CREATE TABLE igpt.chat_messages (
    id SERIAL PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES igpt.chat_sessions(session_id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    method VARCHAR(100),
    tokens_used INTEGER DEFAULT 0,
    processing_time_ms INTEGER,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_chat_messages_session_id ON igpt.chat_messages(session_id);
CREATE INDEX idx_chat_messages_role ON igpt.chat_messages(role);
CREATE INDEX idx_chat_messages_created_at ON igpt.chat_messages(created_at);

COMMENT ON TABLE igpt.chat_messages IS '360° Dashboard - Individual chat messages';

SELECT '✅ Chat tables created' as status;

-- ============================================================================
-- SECTION 9: FUNCTIONS & TRIGGERS
-- ============================================================================

-- 9.1 Auto-update session on new message
CREATE OR REPLACE FUNCTION igpt.update_session_on_message()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE igpt.chat_sessions
    SET
        message_count = message_count + 1,
        last_message = CASE WHEN NEW.role = 'user' THEN NEW.content ELSE last_message END,
        first_message = COALESCE(first_message, CASE WHEN NEW.role = 'user' THEN NEW.content ELSE NULL END),
        title = CASE
            WHEN title = 'New Chat' AND NEW.role = 'user'
            THEN LEFT(NEW.content, 50) || CASE WHEN LENGTH(NEW.content) > 50 THEN '...' ELSE '' END
            ELSE title
        END,
        updated_at = CURRENT_TIMESTAMP
    WHERE session_id = NEW.session_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_session_on_message
    AFTER INSERT ON igpt.chat_messages
    FOR EACH ROW
    EXECUTE FUNCTION igpt.update_session_on_message();

-- 9.2 Auto-update user_preferences updated_at
CREATE OR REPLACE FUNCTION igpt.update_user_preferences_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_user_preferences_updated_at
    BEFORE UPDATE ON igpt.user_preferences
    FOR EACH ROW
    EXECUTE FUNCTION igpt.update_user_preferences_updated_at();

-- 9.3 Role helper functions
CREATE OR REPLACE FUNCTION igpt.user_has_role(p_user_id INTEGER, p_role_name VARCHAR)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM igpt.user_roles ur
        JOIN igpt.roles r ON ur.role_id = r.id
        WHERE ur.user_id = p_user_id AND r.name = p_role_name
    );
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION igpt.user_has_permission(p_user_id INTEGER, p_permission VARCHAR)
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM igpt.user_roles ur
        JOIN igpt.roles r ON ur.role_id = r.id
        WHERE ur.user_id = p_user_id
          AND (r.permissions->>p_permission)::boolean = true
    );
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION igpt.assign_role(p_user_id INTEGER, p_role_name VARCHAR, p_assigned_by INTEGER DEFAULT NULL)
RETURNS BOOLEAN AS $$
DECLARE
    v_role_id INTEGER;
BEGIN
    SELECT id INTO v_role_id FROM igpt.roles WHERE name = p_role_name;
    IF v_role_id IS NULL THEN
        RETURN FALSE;
    END IF;

    INSERT INTO igpt.user_roles (user_id, role_id, assigned_by)
    VALUES (p_user_id, v_role_id, p_assigned_by)
    ON CONFLICT (user_id, role_id) DO NOTHING;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION igpt.remove_role(p_user_id INTEGER, p_role_name VARCHAR)
RETURNS BOOLEAN AS $$
BEGIN
    DELETE FROM igpt.user_roles ur
    USING igpt.roles r
    WHERE ur.role_id = r.id
      AND ur.user_id = p_user_id
      AND r.name = p_role_name;

    RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

SELECT '✅ Functions and triggers created' as status;

-- ============================================================================
-- SECTION 10: VIEWS
-- ============================================================================

-- 10.1 Users with roles view
CREATE VIEW igpt.users_with_roles AS
SELECT
    u.id,
    u.email,
    u.name,
    u.is_active,
    u.created_at,
    u.last_login,
    COALESCE(
        json_agg(
            json_build_object(
                'role_id', r.id,
                'role_name', r.name,
                'permissions', r.permissions
            )
        ) FILTER (WHERE r.id IS NOT NULL),
        '[]'::json
    ) as roles,
    COALESCE(
        array_agg(r.name) FILTER (WHERE r.name IS NOT NULL),
        ARRAY[]::varchar[]
    ) as role_names,
    COALESCE(bool_or(r.name = 'admin'), false) as is_admin,
    COALESCE(bool_or((r.permissions->>'upload_data')::boolean), false) as can_upload,
    COALESCE(bool_or((r.permissions->>'view_admin')::boolean), false) as can_view_admin,
    COALESCE(bool_or((r.permissions->>'manage_users')::boolean), false) as can_manage_users
FROM igpt.users u
LEFT JOIN igpt.user_roles ur ON u.id = ur.user_id
LEFT JOIN igpt.roles r ON ur.role_id = r.id
GROUP BY u.id, u.email, u.name, u.is_active, u.created_at, u.last_login;

COMMENT ON VIEW igpt.users_with_roles IS 'Users with their assigned roles and permissions';

-- 10.2 Chat sessions view
CREATE VIEW igpt.chat_sessions_view AS
SELECT
    cs.id,
    cs.session_id,
    cs.user_id,
    cs.title,
    cs.first_message,
    cs.message_count,
    cs.status,
    cs.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    cs.updated_at AT TIME ZONE 'America/Los_Angeles' as updated_at_pst,
    u.email as user_email,
    u.name as user_name
FROM igpt.chat_sessions cs
LEFT JOIN igpt.users u ON cs.user_id = u.id
WHERE cs.status = 'active'
ORDER BY cs.updated_at DESC;

COMMENT ON VIEW igpt.chat_sessions_view IS 'Active chat sessions with user info';

-- 10.3 User stats view
CREATE VIEW igpt.dashboard_360_user_stats AS
SELECT
    u.id,
    u.email,
    u.name,
    u.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    u.last_login AT TIME ZONE 'America/Los_Angeles' as last_login_pst,
    u.is_active,
    COUNT(DISTINCT ai.id) as ai_interactions_count,
    COUNT(DISTINCT sf.id) as storage_files_count,
    COUNT(DISTINCT azi.id) as azure_integrations_count,
    COUNT(DISTINCT spi.id) as sharepoint_integrations_count,
    COALESCE(SUM(sf.file_size), 0) as total_storage_used_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_storage_used_mb
FROM igpt.users u
LEFT JOIN igpt.ai_interactions ai ON u.id = ai.user_id
LEFT JOIN igpt.storage_files sf ON u.id = sf.user_id AND sf.status = 'uploaded'
LEFT JOIN igpt.azure_integrations azi ON u.id = azi.user_id
LEFT JOIN igpt.sharepoint_integrations spi ON u.id = spi.user_id
GROUP BY u.id, u.email, u.name, u.created_at, u.last_login, u.is_active;

COMMENT ON VIEW igpt.dashboard_360_user_stats IS 'User statistics and usage metrics';

-- 10.4 Integration status view
CREATE VIEW igpt.dashboard_360_integration_status AS
SELECT
    'Azure' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN azi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN azi.status = 'error' THEN 1 END) as error_count,
    COUNT(azi.id) as total_count,
    MAX(azi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM igpt.users u
LEFT JOIN igpt.azure_integrations azi ON u.id = azi.user_id
WHERE azi.id IS NOT NULL
GROUP BY u.id, u.email
UNION ALL
SELECT
    'SharePoint' as integration_type,
    u.id as user_id,
    u.email,
    COUNT(CASE WHEN spi.status = 'connected' THEN 1 END) as connected_count,
    COUNT(CASE WHEN spi.status = 'error' THEN 1 END) as error_count,
    COUNT(spi.id) as total_count,
    MAX(spi.last_sync) AT TIME ZONE 'America/Los_Angeles' as last_sync_pst
FROM igpt.users u
LEFT JOIN igpt.sharepoint_integrations spi ON u.id = spi.user_id
WHERE spi.id IS NOT NULL
GROUP BY u.id, u.email;

COMMENT ON VIEW igpt.dashboard_360_integration_status IS 'Integration connection status by user';

-- 10.5 AI usage view
CREATE VIEW igpt.dashboard_360_ai_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    ai.interaction_type,
    COUNT(ai.id) as interaction_count,
    COUNT(CASE WHEN ai.status = 'success' THEN 1 END) as success_count,
    COUNT(CASE WHEN ai.status = 'failed' THEN 1 END) as failed_count,
    SUM(ai.tokens_used) as total_tokens_used,
    ROUND((AVG(ai.tokens_used)::NUMERIC), 2) as avg_tokens_per_interaction,
    MAX(ai.created_at) AT TIME ZONE 'America/Los_Angeles' as last_interaction_pst
FROM igpt.users u
LEFT JOIN igpt.ai_interactions ai ON u.id = ai.user_id
GROUP BY u.id, u.email, u.name, ai.interaction_type
ORDER BY u.id, ai.interaction_type;

COMMENT ON VIEW igpt.dashboard_360_ai_usage IS 'AI service usage analytics';

-- 10.6 Storage usage view
CREATE VIEW igpt.dashboard_360_storage_usage AS
SELECT
    u.id,
    u.email,
    u.name,
    COUNT(sf.id) as file_count,
    COUNT(CASE WHEN sf.status = 'uploaded' THEN 1 END) as uploaded_count,
    COUNT(CASE WHEN sf.status = 'failed' THEN 1 END) as failed_count,
    COALESCE(SUM(sf.file_size), 0) as total_size_bytes,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024))::NUMERIC, 2), 0) as total_size_mb,
    COALESCE(ROUND((SUM(sf.file_size)::NUMERIC / (1024 * 1024 * 1024))::NUMERIC, 2), 0) as total_size_gb,
    MAX(sf.created_at) AT TIME ZONE 'America/Los_Angeles' as last_upload_pst
FROM igpt.users u
LEFT JOIN igpt.storage_files sf ON u.id = sf.user_id
GROUP BY u.id, u.email, u.name
ORDER BY total_size_bytes DESC;

COMMENT ON VIEW igpt.dashboard_360_storage_usage IS 'Storage usage statistics by user';

-- 10.7 System summary view
CREATE VIEW igpt.dashboard_360_summary AS
SELECT
    (SELECT COUNT(*) FROM igpt.users) as total_users,
    (SELECT COUNT(*) FROM igpt.users WHERE is_active = true) as active_users,
    (SELECT COUNT(*) FROM igpt.azure_integrations) as total_azure_integrations,
    (SELECT COUNT(*) FROM igpt.sharepoint_integrations) as total_sharepoint_integrations,
    (SELECT COUNT(*) FROM igpt.ai_interactions) as total_ai_interactions,
    (SELECT COUNT(*) FROM igpt.ai_interactions WHERE status = 'success') as successful_ai_interactions,
    (SELECT COUNT(*) FROM igpt.storage_files WHERE status = 'uploaded') as uploaded_files,
    (SELECT COALESCE(SUM(file_size), 0) FROM igpt.storage_files WHERE status = 'uploaded') as total_storage_bytes,
    ROUND((SELECT COALESCE(SUM(file_size)::NUMERIC, 0) FROM igpt.storage_files WHERE status = 'uploaded') / (1024 * 1024), 2) as total_storage_mb,
    (SELECT COUNT(*) FROM igpt.integration_interfaces) as total_interfaces,
    (SELECT COUNT(*) FROM igpt.interface_embeddings) as total_embeddings,
    NOW() AT TIME ZONE 'America/Los_Angeles' as last_updated_pst;

COMMENT ON VIEW igpt.dashboard_360_summary IS 'Overall system summary statistics';

-- 10.8 RAG performance stats view
CREATE VIEW igpt.rag_performance_stats AS
SELECT
    DATE(rql.created_at AT TIME ZONE 'America/Los_Angeles') as query_date,
    COUNT(*) as total_queries,
    COUNT(CASE WHEN rql.status = 'success' THEN 1 END) as successful_queries,
    COUNT(CASE WHEN rql.status = 'failed' THEN 1 END) as failed_queries,
    ROUND(AVG(rql.execution_time_ms)::NUMERIC, 2) as avg_execution_time_ms,
    MAX(rql.execution_time_ms) as max_execution_time_ms,
    SUM(rql.tokens_used) as total_tokens_used,
    ROUND(AVG(rql.tokens_used)::NUMERIC, 2) as avg_tokens_per_query
FROM igpt.rag_query_logs rql
GROUP BY DATE(rql.created_at AT TIME ZONE 'America/Los_Angeles')
ORDER BY query_date DESC;

COMMENT ON VIEW igpt.rag_performance_stats IS 'RAG system performance statistics by date';

-- 10.9 RAG query logs view
CREATE VIEW igpt.rag_query_logs_view AS
SELECT
    rql.id,
    u.email as user_email,
    rql.query_text,
    rql.query_type,
    rql.status,
    rql.tokens_used,
    rql.execution_time_ms,
    rql.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst
FROM igpt.rag_query_logs rql
JOIN igpt.users u ON rql.user_id = u.id
ORDER BY rql.created_at DESC;

COMMENT ON VIEW igpt.rag_query_logs_view IS 'RAG query logs with user information';

-- 10.10 Interface embeddings summary view
CREATE VIEW igpt.interface_embeddings_summary AS
SELECT
    ii.interface_id,
    ii.interface_name,
    ii.interface_platform,
    COUNT(ie.id) as total_embeddings,
    COUNT(CASE WHEN ie.content_type = 'name' THEN 1 END) as name_embeddings,
    COUNT(CASE WHEN ie.content_type = 'description' THEN 1 END) as description_embeddings,
    MAX(ie.updated_at) AT TIME ZONE 'America/Los_Angeles' as last_updated_pst
FROM igpt.integration_interfaces ii
LEFT JOIN igpt.interface_embeddings ie ON ii.interface_id = ie.interface_id
GROUP BY ii.interface_id, ii.interface_name, ii.interface_platform
ORDER BY total_embeddings DESC;

COMMENT ON VIEW igpt.interface_embeddings_summary IS 'Summary of embeddings by interface';

-- 10.11 Vector search results view
CREATE VIEW igpt.vector_search_results AS
SELECT
    ie.interface_id,
    ii.interface_name,
    ii.interface_platform,
    ie.content_type,
    ie.content,
    ie.embedding_model,
    ie.created_at AT TIME ZONE 'America/Los_Angeles' as created_at_pst,
    ii.reuse_status,
    ii.interface_pattern
FROM igpt.interface_embeddings ie
JOIN igpt.integration_interfaces ii ON ie.interface_id = ii.interface_id
ORDER BY ie.created_at DESC;

COMMENT ON VIEW igpt.vector_search_results IS 'Vector search results from embeddings';

SELECT '✅ All views created' as status;

-- ============================================================================
-- SECTION 11: VERIFICATION
-- ============================================================================

SELECT '============================================' as separator;
SELECT '✅ PRODUCTION DATABASE INITIALIZATION COMPLETE' as status;
SELECT '============================================' as separator;

SELECT COUNT(*) as total_tables
FROM information_schema.tables
WHERE table_schema = 'igpt' AND table_type = 'BASE TABLE';

SELECT COUNT(*) as total_views
FROM information_schema.views
WHERE table_schema = 'igpt';

SELECT COUNT(*) as total_indexes
FROM pg_indexes
WHERE schemaname = 'igpt';

SELECT extname, extversion FROM pg_extension
WHERE extname IN ('vector', 'uuid-ossp');

-- ============================================================================
-- SUMMARY
-- ============================================================================
/*
PRODUCTION DATABASE INITIALIZED
===============================

SCHEMA: igpt

TABLES (15):
  1. users              - User accounts
  2. roles              - Access control roles
  3. user_roles         - User-role assignments
  4. user_preferences   - User settings/theme
  5. import_history     - Data import tracking
  6. azure_integrations - Azure connections
  7. sharepoint_integrations - SharePoint connections
  8. ai_interactions    - AI service logs
  9. storage_files      - Uploaded files
  10. integration_interfaces - Interface catalog
  11. interface_embeddings - Vector embeddings
  12. rag_query_logs    - RAG query logs
  13. rag_interactions  - RAG interactions
  14. embedding_cache   - Embedding cache
  15. chat_sessions     - Chat sessions
  16. chat_messages     - Chat messages

VIEWS (11):
  1. users_with_roles
  2. chat_sessions_view
  3. dashboard_360_user_stats
  4. dashboard_360_integration_status
  5. dashboard_360_ai_usage
  6. dashboard_360_storage_usage
  7. dashboard_360_summary
  8. rag_performance_stats
  9. rag_query_logs_view
  10. interface_embeddings_summary
  11. vector_search_results

FUNCTIONS (6):
  1. update_session_on_message()
  2. update_user_preferences_updated_at()
  3. user_has_role()
  4. user_has_permission()
  5. assign_role()
  6. remove_role()

TRIGGERS (2):
  1. trg_update_session_on_message
  2. trg_user_preferences_updated_at

EXTENSIONS:
  - uuid-ossp (UUID generation)
  - vector (pgvector for embeddings)
*/
-- ============================================================================
-- END OF PRODUCTION INITIALIZATION
-- ============================================================================
