#!/bin/bash

#######################################################################
# 360° Integration Dashboard - Firewall Validation Script
# Version: 1.0.0
# Purpose: Validates firewall rules and network connectivity for
#          the web application on Linux systems
#######################################################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Counters
PASSED=0
FAILED=0
WARNINGS=0

# Configuration - Customize these based on your environment
APP_PORT=${APP_PORT:-8000}
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}
REDIS_HOST=${REDIS_HOST:-localhost}
REDIS_PORT=${REDIS_PORT:-6379}
SPLUNK_HOST=${SPLUNK_HOST:-""}
SPLUNK_PORT=${SPLUNK_PORT:-8089}
SMTP_HOST=${SMTP_HOST:-smtp.gmail.com}
SMTP_PORT=${SMTP_PORT:-587}

# Azure/Cloud endpoints
AZURE_OPENAI_ENDPOINT=${AZURE_OPENAI_ENDPOINT:-"charith-open-001.openai.azure.com"}
AZURE_STORAGE_ENDPOINT=${AZURE_STORAGE_ENDPOINT:-"aiappstorage123.blob.core.windows.net"}
SHAREPOINT_DOMAIN=${SHAREPOINT_DOMAIN:-"sharepoint.com"}

#######################################################################
# Helper Functions
#######################################################################

print_header() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════════${NC}"
}

print_section() {
    echo ""
    echo -e "${CYAN}───────────────────────────────────────────────────────────────${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}───────────────────────────────────────────────────────────────${NC}"
}

check_pass() {
    echo -e "  ${GREEN}✓${NC} $1"
    ((PASSED++))
}

check_fail() {
    echo -e "  ${RED}✗${NC} $1"
    ((FAILED++))
}

check_warn() {
    echo -e "  ${YELLOW}⚠${NC} $1"
    ((WARNINGS++))
}

check_info() {
    echo -e "  ${BLUE}ℹ${NC} $1"
}

#######################################################################
# Dependency Checks
#######################################################################

check_dependencies() {
    print_section "Checking Required Tools"

    local tools=("nc" "curl" "ss" "ip" "timeout")
    local missing=()

    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            check_pass "$tool is installed"
        else
            check_warn "$tool is not installed (some checks may be skipped)"
            missing+=("$tool")
        fi
    done

    # Check for firewall management tools
    if command -v ufw &> /dev/null; then
        check_info "UFW firewall detected"
        FIREWALL_TYPE="ufw"
    elif command -v firewall-cmd &> /dev/null; then
        check_info "firewalld detected"
        FIREWALL_TYPE="firewalld"
    elif command -v iptables &> /dev/null; then
        check_info "iptables detected"
        FIREWALL_TYPE="iptables"
    else
        check_warn "No firewall management tool detected"
        FIREWALL_TYPE="none"
    fi
}

#######################################################################
# Firewall Status Check
#######################################################################

check_firewall_status() {
    print_section "Firewall Status"

    case $FIREWALL_TYPE in
        "ufw")
            if sudo ufw status | grep -q "Status: active"; then
                check_pass "UFW firewall is active"
                echo ""
                echo "  Current UFW rules:"
                sudo ufw status numbered 2>/dev/null | head -20 | sed 's/^/    /'
            else
                check_warn "UFW firewall is inactive"
            fi
            ;;
        "firewalld")
            if systemctl is-active --quiet firewalld; then
                check_pass "firewalld is active"
                echo ""
                echo "  Active zones:"
                sudo firewall-cmd --get-active-zones 2>/dev/null | sed 's/^/    /'
            else
                check_warn "firewalld is inactive"
            fi
            ;;
        "iptables")
            if sudo iptables -L -n 2>/dev/null | grep -q "Chain"; then
                check_pass "iptables has rules configured"
                echo ""
                echo "  Current INPUT rules (first 10):"
                sudo iptables -L INPUT -n --line-numbers 2>/dev/null | head -12 | sed 's/^/    /'
            else
                check_warn "iptables may not be configured"
            fi
            ;;
        *)
            check_warn "Cannot determine firewall status"
            ;;
    esac
}

#######################################################################
# Port Availability Checks
#######################################################################

check_port_listening() {
    local port=$1
    local service=$2
    local required=$3

    if ss -tuln 2>/dev/null | grep -q ":${port} "; then
        check_pass "Port $port ($service) is listening"
        return 0
    else
        if [ "$required" = "required" ]; then
            check_fail "Port $port ($service) is NOT listening - REQUIRED"
        else
            check_warn "Port $port ($service) is not listening (optional)"
        fi
        return 1
    fi
}

check_local_ports() {
    print_section "Local Service Ports"

    echo -e "  ${BLUE}Checking if required ports are available for binding...${NC}"
    echo ""

    # Application port
    check_port_listening $APP_PORT "Flask/Gunicorn App" "required"

    # Database port (only if localhost)
    if [ "$DB_HOST" = "localhost" ] || [ "$DB_HOST" = "127.0.0.1" ]; then
        check_port_listening $DB_PORT "PostgreSQL" "required"
    else
        check_info "Database is remote ($DB_HOST:$DB_PORT)"
    fi

    # Redis port (optional)
    if [ "$REDIS_HOST" = "localhost" ] || [ "$REDIS_HOST" = "127.0.0.1" ]; then
        check_port_listening $REDIS_PORT "Redis Cache" "optional"
    fi
}

#######################################################################
# Inbound Firewall Rules Check
#######################################################################

check_inbound_rules() {
    print_section "Inbound Firewall Rules"

    echo -e "  ${BLUE}Checking if required inbound ports are allowed...${NC}"
    echo ""

    case $FIREWALL_TYPE in
        "ufw")
            # Check application port
            if sudo ufw status | grep -qE "^${APP_PORT}.*ALLOW"; then
                check_pass "Inbound port $APP_PORT (App Server) is allowed"
            else
                check_fail "Inbound port $APP_PORT (App Server) is NOT allowed"
                echo -e "    ${YELLOW}Fix: sudo ufw allow ${APP_PORT}/tcp${NC}"
            fi

            # Check if HTTP/HTTPS are allowed (for reverse proxy)
            if sudo ufw status | grep -qE "^80.*ALLOW|Nginx.*ALLOW|Apache.*ALLOW"; then
                check_pass "Inbound port 80 (HTTP) is allowed"
            else
                check_warn "Inbound port 80 (HTTP) may not be allowed"
            fi

            if sudo ufw status | grep -qE "^443.*ALLOW|Nginx.*ALLOW|Apache.*ALLOW"; then
                check_pass "Inbound port 443 (HTTPS) is allowed"
            else
                check_warn "Inbound port 443 (HTTPS) may not be allowed"
            fi
            ;;
        "firewalld")
            local zone=$(sudo firewall-cmd --get-default-zone 2>/dev/null)

            if sudo firewall-cmd --zone=$zone --query-port=${APP_PORT}/tcp 2>/dev/null; then
                check_pass "Inbound port $APP_PORT (App Server) is allowed"
            else
                check_fail "Inbound port $APP_PORT (App Server) is NOT allowed"
                echo -e "    ${YELLOW}Fix: sudo firewall-cmd --zone=$zone --add-port=${APP_PORT}/tcp --permanent${NC}"
            fi
            ;;
        "iptables")
            if sudo iptables -L INPUT -n 2>/dev/null | grep -qE "dpt:${APP_PORT}.*ACCEPT"; then
                check_pass "Inbound port $APP_PORT (App Server) is allowed"
            else
                check_warn "Inbound port $APP_PORT (App Server) rule not found in iptables"
            fi
            ;;
        *)
            check_info "Cannot check inbound rules - firewall type unknown"
            ;;
    esac
}

#######################################################################
# Outbound Connectivity Tests
#######################################################################

test_tcp_connection() {
    local host=$1
    local port=$2
    local service=$3
    local required=$4
    local timeout_sec=${5:-5}

    if [ -z "$host" ]; then
        check_info "$service - Host not configured (skipping)"
        return 0
    fi

    if timeout $timeout_sec bash -c "echo >/dev/tcp/$host/$port" 2>/dev/null; then
        check_pass "$service ($host:$port) - Connection successful"
        return 0
    elif command -v nc &> /dev/null && nc -z -w $timeout_sec "$host" "$port" 2>/dev/null; then
        check_pass "$service ($host:$port) - Connection successful"
        return 0
    else
        if [ "$required" = "required" ]; then
            check_fail "$service ($host:$port) - Connection FAILED - REQUIRED"
        else
            check_warn "$service ($host:$port) - Connection failed (optional)"
        fi
        return 1
    fi
}

test_https_endpoint() {
    local url=$1
    local service=$2
    local required=$3
    local timeout_sec=${4:-10}

    if curl -s --connect-timeout $timeout_sec --max-time $timeout_sec -o /dev/null -w "%{http_code}" "https://$url" 2>/dev/null | grep -qE "^[234]"; then
        check_pass "$service (https://$url) - HTTPS reachable"
        return 0
    else
        if [ "$required" = "required" ]; then
            check_fail "$service (https://$url) - HTTPS NOT reachable - REQUIRED"
        else
            check_warn "$service (https://$url) - HTTPS not reachable (optional)"
        fi
        return 1
    fi
}

check_outbound_connectivity() {
    print_section "Outbound Connectivity Tests"

    echo -e "  ${BLUE}Testing connections to required external services...${NC}"
    echo ""

    # Critical - Database
    if [ "$DB_HOST" != "localhost" ] && [ "$DB_HOST" != "127.0.0.1" ]; then
        test_tcp_connection "$DB_HOST" "$DB_PORT" "PostgreSQL Database" "required"
    fi

    # Critical - Azure OpenAI
    test_tcp_connection "$AZURE_OPENAI_ENDPOINT" "443" "Azure OpenAI API" "required"

    # Critical - Azure Storage
    test_tcp_connection "$AZURE_STORAGE_ENDPOINT" "443" "Azure Blob Storage" "required"

    # Important - SharePoint
    test_tcp_connection "login.microsoftonline.com" "443" "Microsoft Auth" "required"

    # Important - General Azure
    test_tcp_connection "management.azure.com" "443" "Azure Management API" "required"

    # Optional - Splunk
    if [ -n "$SPLUNK_HOST" ]; then
        test_tcp_connection "$SPLUNK_HOST" "$SPLUNK_PORT" "Splunk API" "optional"
    else
        check_info "Splunk - Not configured (skipping)"
    fi

    # Optional - SMTP
    test_tcp_connection "$SMTP_HOST" "$SMTP_PORT" "SMTP Email Server" "optional"

    # Optional - Redis (remote)
    if [ "$REDIS_HOST" != "localhost" ] && [ "$REDIS_HOST" != "127.0.0.1" ]; then
        test_tcp_connection "$REDIS_HOST" "$REDIS_PORT" "Redis Cache" "optional"
    fi

    # Model downloads
    test_tcp_connection "huggingface.co" "443" "HuggingFace (Model Hub)" "optional"
}

#######################################################################
# DNS Resolution Tests
#######################################################################

check_dns_resolution() {
    print_section "DNS Resolution Tests"

    local domains=(
        "login.microsoftonline.com"
        "management.azure.com"
        "$AZURE_OPENAI_ENDPOINT"
        "$AZURE_STORAGE_ENDPOINT"
        "huggingface.co"
    )

    for domain in "${domains[@]}"; do
        if [ -n "$domain" ]; then
            if host "$domain" &>/dev/null || nslookup "$domain" &>/dev/null || getent hosts "$domain" &>/dev/null; then
                check_pass "DNS resolution for $domain"
            else
                check_fail "DNS resolution FAILED for $domain"
            fi
        fi
    done
}

#######################################################################
# Security Recommendations
#######################################################################

print_security_recommendations() {
    print_section "Security Recommendations"

    echo -e "  ${BLUE}Review these security best practices:${NC}"
    echo ""

    # Check if running as root
    if [ "$EUID" -eq 0 ]; then
        check_warn "Script is running as root - avoid running app as root"
    else
        check_pass "Not running as root"
    fi

    # Check for open database port to internet
    if ss -tuln 2>/dev/null | grep -E "0\.0\.0\.0:${DB_PORT}|:::${DB_PORT}" &>/dev/null; then
        check_warn "Database port $DB_PORT is bound to all interfaces (security risk)"
    fi

    # Check SSH port
    if ss -tuln 2>/dev/null | grep -E ":22 " &>/dev/null; then
        check_info "SSH (port 22) is listening - ensure it's properly secured"
    fi

    echo ""
    echo -e "  ${CYAN}Recommended Firewall Configuration:${NC}"
    echo ""
    echo "    # Allow application port"
    echo "    sudo ufw allow ${APP_PORT}/tcp comment '360 Dashboard App'"
    echo ""
    echo "    # Allow HTTP/HTTPS (if using reverse proxy)"
    echo "    sudo ufw allow 80/tcp comment 'HTTP'"
    echo "    sudo ufw allow 443/tcp comment 'HTTPS'"
    echo ""
    echo "    # Deny direct database access from internet"
    echo "    sudo ufw deny ${DB_PORT}/tcp comment 'Block external DB access'"
    echo ""
    echo "    # Enable firewall"
    echo "    sudo ufw enable"
}

#######################################################################
# Generate Firewall Rules Script
#######################################################################

generate_firewall_script() {
    print_section "Generated Firewall Rules"

    local script_file="/tmp/setup_firewall_360dashboard.sh"

    cat > "$script_file" << 'SCRIPT_EOF'
#!/bin/bash
# Auto-generated firewall rules for 360° Integration Dashboard
# Run with sudo

set -e

echo "Setting up firewall rules for 360° Integration Dashboard..."

# Detect firewall type
if command -v ufw &> /dev/null; then
    echo "Configuring UFW..."

    # Reset to default (optional - uncomment if needed)
    # ufw --force reset

    # Default policies
    ufw default deny incoming
    ufw default allow outgoing

    # Allow SSH (important - don't lock yourself out!)
    ufw allow 22/tcp comment 'SSH'

    # Allow application port
    ufw allow 8000/tcp comment '360 Dashboard - Gunicorn'

    # Allow HTTP/HTTPS for reverse proxy
    ufw allow 80/tcp comment 'HTTP'
    ufw allow 443/tcp comment 'HTTPS'

    # Allow local PostgreSQL (if running locally)
    # ufw allow from 127.0.0.1 to any port 5432 proto tcp comment 'PostgreSQL local'

    # Allow local Redis (if running locally)
    # ufw allow from 127.0.0.1 to any port 6379 proto tcp comment 'Redis local'

    # Enable firewall
    ufw --force enable

    echo "UFW configuration complete!"
    ufw status verbose

elif command -v firewall-cmd &> /dev/null; then
    echo "Configuring firewalld..."

    # Get default zone
    ZONE=$(firewall-cmd --get-default-zone)

    # Add application port
    firewall-cmd --zone=$ZONE --add-port=8000/tcp --permanent

    # Add HTTP/HTTPS
    firewall-cmd --zone=$ZONE --add-service=http --permanent
    firewall-cmd --zone=$ZONE --add-service=https --permanent

    # Add SSH
    firewall-cmd --zone=$ZONE --add-service=ssh --permanent

    # Reload
    firewall-cmd --reload

    echo "firewalld configuration complete!"
    firewall-cmd --list-all

else
    echo "Configuring iptables..."

    # Flush existing rules (be careful!)
    # iptables -F

    # Default policies
    iptables -P INPUT DROP
    iptables -P FORWARD DROP
    iptables -P OUTPUT ACCEPT

    # Allow loopback
    iptables -A INPUT -i lo -j ACCEPT

    # Allow established connections
    iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

    # Allow SSH
    iptables -A INPUT -p tcp --dport 22 -j ACCEPT

    # Allow application port
    iptables -A INPUT -p tcp --dport 8000 -j ACCEPT

    # Allow HTTP/HTTPS
    iptables -A INPUT -p tcp --dport 80 -j ACCEPT
    iptables -A INPUT -p tcp --dport 443 -j ACCEPT

    echo "iptables configuration complete!"
    iptables -L -n -v
fi

echo ""
echo "Firewall setup complete!"
SCRIPT_EOF

    chmod +x "$script_file"

    echo -e "  ${GREEN}Firewall setup script generated: ${script_file}${NC}"
    echo ""
    echo "  To apply the firewall rules, run:"
    echo -e "    ${YELLOW}sudo $script_file${NC}"
    echo ""
    echo -e "  ${RED}WARNING: Review the script before running!${NC}"
    echo "  Make sure SSH access is preserved to avoid lockout."
}

#######################################################################
# Summary Report
#######################################################################

print_summary() {
    print_header "VALIDATION SUMMARY"

    echo ""
    echo -e "  ${GREEN}Passed:${NC}   $PASSED"
    echo -e "  ${RED}Failed:${NC}   $FAILED"
    echo -e "  ${YELLOW}Warnings:${NC} $WARNINGS"
    echo ""

    if [ $FAILED -eq 0 ]; then
        echo -e "  ${GREEN}════════════════════════════════════════════════════════════${NC}"
        echo -e "  ${GREEN}  ✓ All critical checks passed! Firewall appears configured.${NC}"
        echo -e "  ${GREEN}════════════════════════════════════════════════════════════${NC}"
    else
        echo -e "  ${RED}════════════════════════════════════════════════════════════${NC}"
        echo -e "  ${RED}  ✗ $FAILED critical check(s) failed. Review issues above.${NC}"
        echo -e "  ${RED}════════════════════════════════════════════════════════════${NC}"
    fi

    if [ $WARNINGS -gt 0 ]; then
        echo ""
        echo -e "  ${YELLOW}Note: $WARNINGS warning(s) detected. Review recommended.${NC}"
    fi

    echo ""
}

#######################################################################
# Main Execution
#######################################################################

main() {
    print_header "360° Integration Dashboard - Firewall Validation"
    echo ""
    echo "  Validating firewall configuration for web application deployment"
    echo "  Timestamp: $(date)"
    echo ""

    # Load environment variables if .env exists
    if [ -f ".env" ]; then
        check_info "Loading configuration from .env file"
        export $(grep -v '^#' .env | xargs -d '\n' 2>/dev/null) || true
    fi

    # Run all checks
    check_dependencies
    check_firewall_status
    check_local_ports
    check_inbound_rules
    check_dns_resolution
    check_outbound_connectivity
    print_security_recommendations
    generate_firewall_script
    print_summary

    # Exit with appropriate code
    if [ $FAILED -gt 0 ]; then
        exit 1
    else
        exit 0
    fi
}

# Handle command line arguments
case "${1:-}" in
    -h|--help)
        echo "Usage: $0 [OPTIONS]"
        echo ""
        echo "Validates firewall configuration for 360° Integration Dashboard"
        echo ""
        echo "Options:"
        echo "  -h, --help     Show this help message"
        echo "  -q, --quick    Quick check (skip slow connectivity tests)"
        echo "  -g, --generate Only generate firewall setup script"
        echo ""
        echo "Environment Variables:"
        echo "  APP_PORT       Application port (default: 8000)"
        echo "  DB_HOST        Database host (default: localhost)"
        echo "  DB_PORT        Database port (default: 5432)"
        echo "  REDIS_HOST     Redis host (default: localhost)"
        echo "  REDIS_PORT     Redis port (default: 6379)"
        echo ""
        exit 0
        ;;
    -q|--quick)
        print_header "360° Integration Dashboard - Quick Firewall Check"
        check_dependencies
        check_firewall_status
        check_local_ports
        check_inbound_rules
        print_summary
        ;;
    -g|--generate)
        generate_firewall_script
        ;;
    *)
        main
        ;;
esac