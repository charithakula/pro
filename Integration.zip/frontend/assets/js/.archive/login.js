/**
 * PRODUCTION-GRADE AUTHENTICATION MANAGER
 * 
 * Key Features:
 * - JWT token storage and retrieval
 * - Flask session initialization from JWT
 * - CORS cookie support with credentials: 'include'
 * - Automatic session validation
 * - Secure logout with token cleanup
 * - Password change handling
 * - User profile management
 * 
 * Flow:
 * 1. Login → JWT token stored in localStorage
 * 2. Protected route accessed → initializeSessionFromToken()
 * 3. Backend validates JWT → Sets Flask session cookie
 * 4. Subsequent requests include both JWT header + session cookie
 * 5. Logout → Clears JWT + Flask session
 */

// ============================================================================
// AUTHENTICATION STATE
// ============================================================================

const AuthState = {
    isAuthenticated: false,
    isValidating: false,
    lastValidationTime: 0,
    validationInterval: 5000,  // Re-validate every 5 seconds for protected routes
    hasShownSessionError: false,
    sessionInitAttempts: 0,
    maxInitAttempts: 3
};

// ============================================================================
// TOKEN MANAGEMENT
// ============================================================================

/**
 * Check if user has a valid JWT token
 */
function isAuthenticated() {
    const token = localStorage.getItem('token');
    return !!token && token.length > 0;
}

/**
 * Get JWT token from localStorage
 */
function getAuthToken() {
    try {
        return localStorage.getItem('token') || null;
    } catch (e) {
        console.warn('⚠️ Could not retrieve token:', e);
        return null;
    }
}

/**
 * Get authorization headers with JWT Bearer token
 */
function getAuthHeaders() {
    const token = getAuthToken();
    const headers = { 'Content-Type': 'application/json' };
    
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    
    return headers;
}

/**
 * Store JWT token and user data
 */
function storeAuthData(token, user) {
    console.log('💾 Storing authentication data...');
    
    try {
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('user_id', String(user.id));
        localStorage.setItem('user_email', user.email);
        localStorage.setItem('user_name', user.name);
        localStorage.setItem('logged_in', 'true');
        localStorage.setItem('auth_timestamp', String(Date.now()));
        
        AuthState.isAuthenticated = true;
        AuthState.hasShownSessionError = false;
        AuthState.sessionInitAttempts = 0;
        
        console.log('✅ Auth data stored:', {
            user_id: user.id,
            user_email: user.email,
            user_name: user.name
        });
    } catch (e) {
        console.error('❌ Failed to store auth data:', e);
    }
}

/**
 * Clear all authentication data
 */
function clearAuthData() {
    console.log('🗑️  Clearing all authentication data...');
    
    try {
        const keysToRemove = [
            'token',
            'user',
            'user_id',
            'user_email',
            'user_name',
            'logged_in',
            'auth_timestamp',
            'rememberedEmail'
        ];
        
        keysToRemove.forEach(key => {
            localStorage.removeItem(key);
        });
        
        AuthState.isAuthenticated = false;
        AuthState.isValidating = false;
        AuthState.hasShownSessionError = false;
        AuthState.sessionInitAttempts = 0;
        
        console.log('✅ All auth data cleared');
    } catch (e) {
        console.error('❌ Error clearing auth data:', e);
    }
}

// ============================================================================
// SESSION MANAGEMENT
// ============================================================================

// In your login form submission handler (login.js or inline script)
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',  // ✅ CRITICAL: Include cookies
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            console.log('✅ Login successful');
            
            // Store token in localStorage (for API calls)
            storeAuthData(data.data.token, data.data.user);
            
            // ✅ CRITICAL: Small delay to ensure cookies are set
            console.log('⏳ Waiting for cookies to be set...');
            await new Promise(resolve => setTimeout(resolve, 200));
            
            // Redirect to dashboard
            console.log('🔄 Redirecting to dashboard...');
            window.location.replace('/dashboard');
        } else {
            showToast('error', 'Login Failed', data.message);
        }
    } catch (error) {
        console.error('❌ Login error:', error);
        showToast('error', 'Connection Error', error.message);
    }
}

/**
 * Initialize Flask session from JWT token
 * This creates a server-side session from the JWT token
 */
async function initializeSessionFromToken() {
    const token = getAuthToken();
    
    console.log('🔍 [DEBUG] Checking for token in localStorage...');
    console.log('   Token exists:', !!token);
    console.log('   Token length:', token ? token.length : 0);
    console.log('   All localStorage keys:', Object.keys(localStorage));
    
    if (!token) {
        console.error('❌ No token found in localStorage!');
        console.error('   This means login.js failed to store the token');
        console.error('   Check browser console on login page for errors');
        return false;
    }
    
    if (AuthState.sessionInitAttempts >= AuthState.maxInitAttempts) {
        console.error('❌ Max session init attempts reached');
        return false;
    }
    
    AuthState.sessionInitAttempts++;
    
    try {
        console.log(`🔄 Initializing Flask session from JWT token (attempt ${AuthState.sessionInitAttempts})...`);
        
        const response = await fetch('/api/auth/me', {
            method: 'GET',
            headers: getAuthHeaders(),
            credentials: 'include'  // ✅ CRITICAL: Include cookies to set Flask session
        });
        
        console.log('📊 Session init response status:', response.status);
        
        if (!response.ok) {
            console.warn(`❌ Session init failed - HTTP ${response.status}`);
            
            if (response.status === 401) {
                console.log('🔑 Token expired or invalid - clearing auth');
                clearAuthData();
            }
            
            return false;
        }
        
        const data = await response.json();
        
        if (data.success && data.data) {
            console.log('✅ Session initialized successfully');
            console.log('   User:', data.data.user.email);
            
            // Reset attempts on success
            AuthState.sessionInitAttempts = 0;
            return true;
        } else {
            console.warn('❌ Session initialization failed:', data.message);
            return false;
        }
        
    } catch (error) {
        console.error('❌ Session initialization error:', error);
        return false;
    }
}

/**
 * Validate token with backend
 */
async function validateTokenWithBackend(token) {
    try {
        console.log('🔐 Validating token with backend...');
        
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);
        
        const response = await fetch('/api/auth/me', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        console.log('📊 Validation response status:', response.status);
        
        if (!response.ok) {
            console.log(`❌ Token invalid/expired (HTTP ${response.status})`);
            return false;
        }
        
        const data = await response.json();
        
        if (data.success && data.data) {
            console.log('✅ Token validated:', data.data.user.email);
            return true;
        } else {
            console.log('❌ Token validation failed:', data.message);
            return false;
        }
        
    } catch (error) {
        if (error.name === 'AbortError') {
            console.error('❌ Validation timeout');
        } else {
            console.error('❌ Validation error:', error);
        }
        return false;
    }
}

/**
 * Check if current route is protected
 */
function isProtectedRoute() {
    const protectedPaths = [
        '/dashboard',
        '/profile',
        '/settings',
        '/analytics',
        '/integrations',
        '/chat',
        '/data-management',
        '/services',
        '/resources'
    ];
    
    return protectedPaths.some(path => 
        window.location.pathname.startsWith(path)
    );
}

/**
 * Auto-initialize session on protected routes
 */
async function autoInitializeSession() {
    if (!isProtectedRoute()) {
        console.log('📄 Not a protected route - skipping session init');
        return true;
    }
    
    const token = getAuthToken();
    
    if (!token) {
        console.log('⚠️ No token in localStorage');
        return false;
    }
    
    console.log('🔄 Auto-initializing session from token...');
    
    const success = await initializeSessionFromToken();
    
    if (!success) {
        console.error('❌ Failed to initialize session');
        
        if (!AuthState.hasShownSessionError) {
            AuthState.hasShownSessionError = true;
            showToast('error', 'Session Failed', 'Please login again to continue');
        }
        
        // Clear auth and redirect
        clearAuthData();
        setTimeout(() => {
            window.location.href = '/login';
        }, 1500);
        
        return false;
    }
    
    console.log('✅ Session initialized successfully');
    return true;
}

// ============================================================================
// LOGOUT HANDLER
// ============================================================================

/**
 * Logout user and clear all sessions
 */
async function logout(event) {
    if (event) event.preventDefault();
    
    console.log('═'.repeat(60));
    console.log('🔓 LOGOUT INITIATED');
    console.log('═'.repeat(60));
    
    try {
        const token = localStorage.getItem('token');
        
        if (!token) {
            console.warn('⚠️ No token found - clearing local session');
            clearAuthData();
            showToast('info', 'Logged Out', 'Session cleared');
            
            setTimeout(() => {
                window.location.href = '/login';
            }, 1000);
            return;
        }
        
        console.log('✅ Token found - notifying backend...');
        console.log('📨 Calling /api/auth/logout with Bearer token...');
        
        const response = await fetch('/api/auth/logout', {
            method: 'POST',
            headers: getAuthHeaders(),
            credentials: 'include'  // ✅ Include cookies to clear Flask session
        });
        
        console.log('✅ Response received - Status:', response.status);
        
        let data;
        try {
            data = await response.json();
            console.log('📦 Response data:', data);
        } catch (parseErr) {
            console.warn('⚠️ Could not parse response JSON');
            data = { success: false };
        }
        
        // Always clear local auth data regardless of backend response
        console.log('🗑️  Clearing local authentication data...');
        clearAuthData();
        
        if (response.ok && data.success) {
            console.log('✅ LOGOUT SUCCESSFUL');
            showToast('success', 'Logged Out', 'You have been logged out successfully');
        } else {
            console.log('⚠️ Backend logout issue - cleared local session');
            showToast('info', 'Logged Out', 'Session cleared');
        }
        
        console.log('🔄 Redirecting to login...');
        setTimeout(() => {
            window.location.href = '/login';
        }, 1000);
        
    } catch (error) {
        console.error('❌ LOGOUT ERROR:', error);
        
        // Clear local session even on error
        clearAuthData();
        showToast('error', 'Logout Error', 'Clearing session and redirecting...');
        
        setTimeout(() => {
            window.location.href = '/login';
        }, 1500);
    }
    
    console.log('═'.repeat(60));
}

// ============================================================================
// PASSWORD MANAGEMENT
// ============================================================================

/**
 * Change user password
 */
async function handlePasswordChange(event) {
    if (event) event.preventDefault();
    
    console.log('🔒 Password change initiated...');
    
    const form = event.target;
    const inputs = form.querySelectorAll('input[type="password"]');
    
    if (inputs.length < 3) {
        showToast('error', 'Form Error', 'Missing password fields');
        return;
    }
    
    const currentPassword = inputs[0].value?.trim();
    const newPassword = inputs[1].value?.trim();
    const confirmPassword = inputs[2].value?.trim();
    
    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
        showToast('error', 'Validation Error', 'All fields are required');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showToast('error', 'Password Mismatch', 'New passwords do not match');
        return;
    }
    
    if (newPassword.length < 8) {
        showToast('error', 'Password Too Short', 'Password must be at least 8 characters');
        return;
    }
    
    if (newPassword === currentPassword) {
        showToast('error', 'Same Password', 'New password must be different from current');
        return;
    }
    
    try {
        const token = getAuthToken();
        
        if (!token) {
            showToast('error', 'Not Authenticated', 'Please login again');
            window.location.href = '/login';
            return;
        }
        
        console.log('📨 Sending password change request...');
        
        const response = await fetch('/api/auth/change-password', {
            method: 'POST',
            headers: getAuthHeaders(),
            body: JSON.stringify({
                current_password: currentPassword,
                new_password: newPassword
            }),
            credentials: 'include'
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            console.log('✅ Password changed successfully');
            showToast('success', 'Success!', 'Password changed successfully');
            form.reset();
            
            // Optional: Re-login or redirect
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 2000);
        } else {
            const errorMsg = data.message || data.error || 'Failed to change password';
            console.error('❌ Password change failed:', errorMsg);
            showToast('error', 'Error', errorMsg);
        }
        
    } catch (error) {
        console.error('❌ Password change error:', error);
        showToast('error', 'Connection Error', error.message);
    }
}

// ============================================================================
// USER PROFILE MANAGEMENT
// ============================================================================

/**
 * Load current user information
 */
async function loadUserInfo() {
    try {
        const token = getAuthToken();
        
        if (!token) {
            console.log('⚠️ No token - skipping user info load');
            return null;
        }
        
        console.log('👤 Loading user information...');
        
        const response = await fetch('/api/auth/me', {
            method: 'GET',
            headers: getAuthHeaders(),
            credentials: 'include'
        });
        
        if (!response.ok) {
            console.log('❌ Failed to load user info - status:', response.status);
            if (response.status === 401) {
                clearAuthData();
            }
            return null;
        }
        
        const data = await response.json();
        
        if (data.success && data.data) {
            const user = data.data.user;
            console.log('✅ User info loaded:', user.email);
            
            // Update DOM elements
            updateUserDisplay(user);
            
            return user;
        } else {
            console.log('❌ User info response error:', data.message);
            return null;
        }
        
    } catch (error) {
        console.error('❌ Error loading user info:', error);
        return null;
    }
}

/**
 * Update user display elements
 */
function updateUserDisplay(user) {
    // Update user name
    const userNameEl = document.getElementById('userName');
    if (userNameEl) {
        userNameEl.textContent = `Welcome, ${user.name || user.email}`;
    }
    
    // Update user avatar/initial
    const userAvatarEl = document.getElementById('userAvatar');
    if (userAvatarEl) {
        const initial = (user.name || user.email).charAt(0).toUpperCase();
        userAvatarEl.textContent = initial;
        userAvatarEl.title = user.email;
    }
    
    // Update user email in profile
    const userEmailEl = document.getElementById('userEmail');
    if (userEmailEl) {
        userEmailEl.textContent = user.email;
    }
    
    // Update other profile elements as needed
    const userIdEl = document.getElementById('userId');
    if (userIdEl) {
        userIdEl.textContent = `ID: ${user.id}`;
    }
}

// ============================================================================
// NOTIFICATIONS
// ============================================================================

/**
 * Show toast notification
 */
function showToast(type, title, message) {
    const container = document.getElementById('toastContainer');
    
    if (!container) {
        console.warn('⚠️ Toast container not found');
        console.log(`[${type.toUpperCase()}] ${title}: ${message}`);
        return;
    }
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-times-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="fas ${icons[type] || icons.info}"></i>
        </div>
        <div class="toast-content">
            <div class="toast-title">${escapeHtml(title)}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    container.appendChild(toast);
    
    // Auto-remove after 4 seconds
    setTimeout(() => {
        if (toast.parentElement) {
            toast.style.animation = 'slideInRight 0.4s ease reverse';
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 400);
        }
    }, 4000);
}

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * Escape HTML special characters
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

/**
 * Get time elapsed since auth
 */
function getAuthAge() {
    const timestamp = localStorage.getItem('auth_timestamp');
    if (!timestamp) return null;
    
    const elapsed = Date.now() - parseInt(timestamp);
    return Math.floor(elapsed / 1000);  // seconds
}

/**
 * Check if token is stale (older than 1 hour)
 */
function isTokenStale() {
    const age = getAuthAge();
    return age && age > 3600;  // 1 hour
}

// ============================================================================
// INITIALIZATION
// ============================================================================

/**
 * Initialize authentication on page load
 */
window.addEventListener('load', async function() {
    console.log('═'.repeat(60));
    console.log('🚀 PAGE LOADED - Initializing authentication');
    console.log('═'.repeat(60));
    console.log('📍 URL:', window.location.pathname);
    console.log('🔑 Has token:', !!getAuthToken());
    console.log('🛡️  Protected route:', isProtectedRoute());
    
    // ✅ NEW: If on login page and already authenticated, redirect to dashboard
    if (window.location.pathname === '/login' && isAuthenticated()) {
        console.log('✅ Already authenticated! Has valid token in localStorage');
        console.log('   Token user:', localStorage.getItem('user_email'));
        console.log('   Redirecting directly to dashboard...');
        console.log('   The dashboard will handle session validation');
        
        // Simple direct redirect without session init
        // The dashboard will call /api/auth/me which will validate the token
        // and set/maintain the Flask session
        setTimeout(() => {
            console.log('🔄 REDIRECT: window.location.replace(/dashboard)');
            window.location.replace('/dashboard');
        }, 100);  // Minimal delay
        
        return;  // Don't continue with normal initialization
    }
    
    // Initialize session on protected routes
    if (isProtectedRoute()) {
        console.log('🔐 Protected route detected');
        console.log('⏳ Initializing session from token...');
        autoInitializeSession();
    }
    
    // Load user info if authenticated
    if (isAuthenticated()) {
        console.log('👤 Loading user profile...');
        loadUserInfo();
    }
    
    console.log('✅ Authentication initialization complete');
    console.log('═'.repeat(60));
});

/**
 * Periodic session validation (every 5 seconds for protected routes)
 */
setInterval(function() {
    if (!isProtectedRoute() || !isAuthenticated()) {
        return;
    }
    
    const now = Date.now();
    
    // Only validate if enough time has passed
    if (now - AuthState.lastValidationTime < AuthState.validationInterval) {
        return;
    }
    
    AuthState.lastValidationTime = now;
    
    // Silently validate token in background
    const token = getAuthToken();
    if (token && !AuthState.isValidating) {
        AuthState.isValidating = true;
        
        validateTokenWithBackend(token).then(isValid => {
            AuthState.isValidating = false;
            
            if (!isValid) {
                console.warn('⚠️ Token validation failed - clearing auth');
                clearAuthData();
                showToast('error', 'Session Expired', 'Please login again');
                setTimeout(() => {
                    window.location.href = '/login';
                }, 1500);
            }
        });
    }
}, 1000);

// ============================================================================
// EXPORT FOR TESTING
// ============================================================================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        isAuthenticated,
        getAuthToken,
        getAuthHeaders,
        storeAuthData,
        clearAuthData,
        initializeSessionFromToken,
        validateTokenWithBackend,
        logout,
        loadUserInfo,
        AuthState
    };
}