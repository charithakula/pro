/**
 * THEME MANAGER
 * Handles light/dark theme switching with localStorage and database sync
 *
 * Features:
 * - Immediate theme application from localStorage (no flash)
 * - Database sync for persistence across devices
 * - System preference detection
 * - Smooth transitions
 */

const ThemeManager = {
    // Current theme state
    currentTheme: 'light',
    systemPreference: 'light',
    dbSyncEnabled: true,
    dbSyncPending: false,

    /**
     * Initialize theme manager
     * Called on every page load
     */
    init: function() {
        // Detect system preference
        this.systemPreference = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';

        // Listen for system preference changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            this.systemPreference = e.matches ? 'dark' : 'light';
            if (localStorage.getItem('theme') === 'system') {
                this.applyTheme('system');
            }
        });

        // Load theme from localStorage (already applied in head script)
        const savedTheme = localStorage.getItem('theme') || 'light';
        this.currentTheme = savedTheme;

        // Sync with database if user is authenticated
        if (this.isAuthenticated()) {
            this.loadFromDatabase();
        }

        console.log('[ThemeManager] Initialized with theme:', savedTheme);
    },

    /**
     * Check if user is authenticated
     */
    isAuthenticated: function() {
        return !!localStorage.getItem('token');
    },

    /**
     * Get the resolved theme (handles 'system' preference)
     */
    getResolvedTheme: function(theme) {
        if (theme === 'system') {
            return this.systemPreference;
        }
        return theme;
    },

    /**
     * Apply theme to the page
     */
    applyTheme: function(theme) {
        const resolvedTheme = this.getResolvedTheme(theme);
        document.documentElement.setAttribute('data-theme', resolvedTheme);
        this.currentTheme = theme;
        console.log('[ThemeManager] Applied theme:', theme, '(resolved:', resolvedTheme + ')');
    },

    /**
     * Set theme and save to localStorage + database
     */
    setTheme: function(theme, syncToDb = true) {
        // Validate theme
        if (!['light', 'dark', 'system'].includes(theme)) {
            theme = 'light';
        }

        // Apply immediately
        this.applyTheme(theme);

        // Save to localStorage
        localStorage.setItem('theme', theme);

        // Sync to database if authenticated
        if (syncToDb && this.dbSyncEnabled && this.isAuthenticated()) {
            this.saveToDatabase(theme);
        }

        // Dispatch event for other components
        window.dispatchEvent(new CustomEvent('themeChanged', {
            detail: { theme: theme, resolved: this.getResolvedTheme(theme) }
        }));

        return theme;
    },

    /**
     * Toggle between light and dark theme
     */
    toggle: function() {
        const resolvedTheme = this.getResolvedTheme(this.currentTheme);
        const newTheme = resolvedTheme === 'dark' ? 'light' : 'dark';
        return this.setTheme(newTheme);
    },

    /**
     * Load theme from database
     */
    loadFromDatabase: async function() {
        if (!this.isAuthenticated()) return;

        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/auth/preferences', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            });

            if (response.ok) {
                const data = await response.json();
                if (data.success && data.data && data.data.theme) {
                    const dbTheme = data.data.theme;
                    const localTheme = localStorage.getItem('theme');

                    // If database has a theme and it's different from local, use database
                    if (dbTheme && dbTheme !== localTheme) {
                        console.log('[ThemeManager] Syncing theme from database:', dbTheme);
                        this.setTheme(dbTheme, false); // Don't sync back to avoid loop
                    }
                }
            }
        } catch (error) {
            console.warn('[ThemeManager] Failed to load theme from database:', error);
        }
    },

    /**
     * Save theme to database
     */
    saveToDatabase: async function(theme) {
        if (!this.isAuthenticated() || this.dbSyncPending) return;

        this.dbSyncPending = true;

        try {
            const token = localStorage.getItem('token');
            const response = await fetch('/api/auth/preferences/theme', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify({ theme: theme })
            });

            if (response.ok) {
                console.log('[ThemeManager] Theme saved to database:', theme);
            } else {
                console.warn('[ThemeManager] Failed to save theme to database');
            }
        } catch (error) {
            console.warn('[ThemeManager] Error saving theme to database:', error);
        } finally {
            this.dbSyncPending = false;
        }
    },

    /**
     * Get current theme
     */
    getTheme: function() {
        return this.currentTheme;
    },

    /**
     * Get resolved theme (actual light/dark value)
     */
    getResolvedCurrentTheme: function() {
        return this.getResolvedTheme(this.currentTheme);
    }
};

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    ThemeManager.init();
});

// Also initialize immediately if DOM is already loaded
if (document.readyState !== 'loading') {
    ThemeManager.init();
}

// Export for use in other scripts
window.ThemeManager = ThemeManager;
