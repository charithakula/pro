/**
 * RAG CHAT WIDGET - Full-Featured Chat Engine
 * Shared JavaScript for floating chat widget across all pages
 * Works with header.html chat panel and modal
 * Includes: Tables, Charts, Formatting, History
 */

(function() {
    'use strict';

    // =========================================================================
    // CHART TRACKING
    // =========================================================================
    let pendingCharts = [];
    let chartInstances = {};

    // =========================================================================
    // RAG ENGINE - Core Chat Functionality
    // =========================================================================
    window.RAG_ENGINE = {
        config: {
            chatEndpoint: '/chat/send_message',
            statsEndpoint: '/chat/stats',
            sessionsEndpoint: '/chat/sessions',
            // Limits
            maxSessionsToLoad: 20,      // Max chat sessions to show in history
            maxMessagesPerSession: 100  // Max messages to load per session
        },

        state: {
            hasData: false,
            history: [],
            totalEmbeddings: 0,
            totalRecords: 0,
            currentSessionId: null,
            userId: null  // Will be set from auth
        },

        // Initialize the engine
        init: function() {
            console.log('🚀 RAG ENGINE INITIALIZING...');
            this.getUserId();
            this.checkDataStatus();
            this.loadUserHistory();
        },

        // Get user ID from auth (stored in localStorage or session)
        getUserId: function() {
            // Try direct user_id from localStorage (set by auth.js)
            const directUserId = localStorage.getItem('user_id');
            if (directUserId) {
                this.state.userId = parseInt(directUserId);
                console.log('✓ User ID from localStorage (user_id):', this.state.userId);
                return;
            }

            // Try localStorage 'user' object (set by auth.js)
            const userData = localStorage.getItem('user');
            if (userData) {
                try {
                    const user = JSON.parse(userData);
                    this.state.userId = user.id || user.user_id || null;
                    if (this.state.userId) {
                        console.log('✓ User ID from localStorage (user):', this.state.userId);
                        return;
                    }
                } catch (e) {
                    console.warn('Failed to parse user data');
                }
            }

            // Try 'auth_user' (legacy fallback)
            const authData = localStorage.getItem('auth_user');
            if (authData) {
                try {
                    const user = JSON.parse(authData);
                    this.state.userId = user.id || user.user_id || null;
                    if (this.state.userId) {
                        console.log('✓ User ID from localStorage (auth_user):', this.state.userId);
                        return;
                    }
                } catch (e) {
                    console.warn('Failed to parse auth_user');
                }
            }

            // Fallback: check session storage
            const sessionUserId = sessionStorage.getItem('user_id');
            if (sessionUserId) {
                this.state.userId = parseInt(sessionUserId);
                console.log('✓ User ID from sessionStorage:', this.state.userId);
                return;
            }

            // No user found - will create anonymous sessions
            this.state.userId = null;
            console.log('⚠️ No user ID found, sessions will be anonymous');
        },

        // Load user's chat history from backend
        loadUserHistory: function() {
            console.log('📜 Loading user chat history...');

            // Build URL with user_id and limit
            let url = `${this.config.sessionsEndpoint}?limit=${this.config.maxSessionsToLoad}`;
            if (this.state.userId) {
                url += `&user_id=${this.state.userId}`;
            }

            fetch(url, {
                credentials: 'include'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.sessions) {
                    // Convert sessions to history format
                    this.state.history = data.sessions.map(session => ({
                        session_id: session.session_id,
                        message: session.first_message || session.title,
                        timestamp: new Date(session.updated_at || session.created_at),
                        message_count: session.message_count
                    }));

                    console.log(`✓ Loaded ${this.state.history.length} chat sessions`);
                    this.updateHistory();

                    // Set current session to most recent
                    if (data.sessions.length > 0) {
                        this.state.currentSessionId = data.sessions[0].session_id;
                    }
                }
            })
            .catch(err => {
                console.warn('⚠️ Failed to load chat history:', err);
            });
        },

        // Create a new chat session
        createSession: function(firstMessage) {
            const payload = {
                title: firstMessage.substring(0, 50) + (firstMessage.length > 50 ? '...' : '')
            };

            // Only include user_id if authenticated
            if (this.state.userId) {
                payload.user_id = this.state.userId;
            }

            return fetch(this.config.sessionsEndpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(payload)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    this.state.currentSessionId = data.session_id;
                    console.log('✓ Created new session:', data.session_id);
                    return data.session_id;
                }
                return null;
            })
            .catch(err => {
                console.warn('⚠️ Failed to create session:', err);
                return null;
            });
        },

        // Save message to session
        saveMessageToSession: function(content, role, method = null, metadata = null) {
            if (!this.state.currentSessionId) return Promise.resolve();

            return fetch(`${this.config.sessionsEndpoint}/${this.state.currentSessionId}/messages`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({
                    role: role,
                    content: content,
                    method: method,
                    metadata: metadata
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    console.log('✓ Message saved to session');
                }
            })
            .catch(err => {
                console.warn('⚠️ Failed to save message:', err);
            });
        },

        // Check if data is available
        checkDataStatus: function() {
            console.log('📊 Checking RAG data availability...');

            fetch(this.config.statsEndpoint, {
                credentials: 'include'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.stats) {
                    this.state.totalEmbeddings = data.stats.total_embeddings || 0;
                    this.state.totalRecords = data.stats.total_interfaces || 0;
                    this.state.hasData = this.state.totalEmbeddings > 0 || this.state.totalRecords > 0;

                    console.log(`✅ RAG STATUS: ${this.state.hasData ? 'READY ✓' : 'NO DATA'}`);
                    console.log(`   Embeddings: ${this.state.totalEmbeddings}`);
                    console.log(`   Records: ${this.state.totalRecords}`);

                    if (this.state.hasData) {
                        this.updateDataStatus();
                    }
                }
            })
            .catch(err => {
                console.error('❌ RAG check failed:', err);
                this.state.hasData = false;
            });
        },

        // Update the modal data status display
        updateDataStatus: function() {
            const statusEl = document.getElementById('modalDataStatus');
            const statusText = document.getElementById('modalStatusText');
            if (statusEl && statusText) {
                statusEl.style.display = 'block';
                let statusMsg = '✅ <strong>Vector Search Ready:</strong> ';

                if (this.state.totalEmbeddings > 0) {
                    statusMsg += `${this.state.totalEmbeddings} embeddings, ${this.state.totalRecords} records`;
                } else if (this.state.totalRecords > 0) {
                    statusMsg += `${this.state.totalRecords} records (creating embeddings)`;
                } else {
                    statusMsg += 'Loading...';
                }

                statusText.innerHTML = statusMsg;
            }
        },

        // Send a message to the RAG backend
        sendMessage: async function(message, isModal = false) {
            console.log('🔹 RAG_ENGINE.sendMessage:', message);
            console.log('🔹 Has data:', this.state.hasData);

            // Create session if needed (first message)
            if (!this.state.currentSessionId) {
                await this.createSession(message);
            }

            // Save user message to session
            this.saveMessageToSession(message, 'user');

            const typingId = isModal ? 'typingIndicatorModal' : 'typingIndicator';
            const typingEl = document.getElementById(typingId);
            if (typingEl) typingEl.style.display = 'flex';

            console.log('📨 Calling /chat/send_message...');
            fetch(this.config.chatEndpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify({ message: message })
            })
            .then(res => res.json())
            .then(data => {
                console.log('✅ RAG Response:', data);
                if (typingEl) typingEl.style.display = 'none';

                if (data.success) {
                    const response = data.response || 'No response';
                    const method = data.metadata?.method || 'vector_search';

                    this.addMessage(response, 'ai', isModal, method, data.metadata);
                    this.addToHistory(message);

                    // Save assistant response to session
                    this.saveMessageToSession(response, 'assistant', method, data.metadata);
                } else {
                    this.addMessage(`❌ Error: ${data.error}`, 'ai', isModal);
                    this.addToHistory(message);
                }
            })
            .catch(err => {
                console.error('❌ RAG Error:', err);
                if (typingEl) typingEl.style.display = 'none';
                this.addMessage(`❌ Error: ${err.message}`, 'ai', isModal);
                this.addToHistory(message);
            });
        },

        // Add a message to the chat display
        addMessage: function(text, role, isModal = false, method = null, metadata = null) {
            const containerId = isModal ? 'chatMessagesModal' : 'chatMessages';
            const container = document.getElementById(containerId);
            if (!container) return;

            const msgDiv = document.createElement('div');
            msgDiv.className = `chat-message ${role}`;

            let html;
            if (role === 'ai') {
                html = this.formatAssistantMessage(text, metadata);
            } else {
                html = this.formatText(text);
            }

            // Add method badge for AI messages
            if (role === 'ai' && method) {
                html += `<small style="margin-top: 8px; display: block; opacity: 0.75;">🔍 ${method.replace(/_/g, ' ').toUpperCase()}</small>`;
            }

            msgDiv.innerHTML = `<div class="chat-message-content">${html}</div>`;
            container.appendChild(msgDiv);
            container.scrollTop = container.scrollHeight;

            // Create pending charts after DOM update
            if (pendingCharts && pendingCharts.length > 0) {
                requestAnimationFrame(() => {
                    setTimeout(() => {
                        createPendingCharts();
                    }, 50);
                });
            }
        },

        // Format assistant message with tables, charts, etc.
        formatAssistantMessage: function(text, metadata) {
            let html = text;

            // Check for chart data first
            const chartData = parseChartData(text);
            if (chartData) {
                // Remove the chart data marker from text for display
                html = html.replace(/<!--CHART_DATA:[\s\S]*?:CHART_DATA-->/g, '');

                // Render charts
                const chartsHtml = renderCharts(chartData);

                // Format remaining text (summary)
                let summaryHtml = html;
                summaryHtml = summaryHtml.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
                summaryHtml = summaryHtml.replace(/`([^`]+)`/g, '<code>$1</code>');

                // Format bullet points
                const lines = summaryHtml.split('\n');
                let formattedSummary = [];
                for (const line of lines) {
                    const trimmedLine = line.trim();
                    if (trimmedLine.match(/^[-*•]\s/) || trimmedLine.startsWith('•')) {
                        formattedSummary.push(`<li>${trimmedLine.replace(/^[-*•]\s*/, '')}</li>`);
                    } else if (trimmedLine) {
                        formattedSummary.push(`<p>${trimmedLine}</p>`);
                    }
                }

                return chartsHtml + `
                    <div class="chat-report-summary" style="background: #f8fafc; border-radius: 10px; padding: 16px; margin-top: 16px;">
                        <h4 style="font-size: 0.9rem; color: #1a4d2e; margin: 0 0 12px 0;"><i class="fas fa-list-ul"></i> Summary</h4>
                        <ul style="margin: 0; padding-left: 20px;">${formattedSummary.filter(l => l.startsWith('<li>')).join('')}</ul>
                    </div>
                `;
            }

            // Replace bold markdown
            html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
            html = html.replace(/`([^`]+)`/g, '<code style="background: rgba(0,0,0,0.08); padding: 2px 4px; border-radius: 3px;">$1</code>');

            const lines = html.split('\n');
            let formatted = [];
            let inTable = false;
            let tableRows = [];

            for (let i = 0; i < lines.length; i++) {
                const line = lines[i].trim();

                // Detect table rows (start with |)
                if (line.startsWith('|') && line.endsWith('|')) {
                    // Skip separator rows (|---|---|---|)
                    if (line.match(/^\|[-:\s|]+\|$/) && line.includes('---')) {
                        continue;
                    }

                    if (!inTable) {
                        inTable = true;
                        tableRows = [];
                    }

                    // Parse table cells
                    const cells = line.split('|').filter(c => c.trim() !== '');
                    tableRows.push(cells.map(c => c.trim()));
                } else {
                    // End of table - render it
                    if (inTable && tableRows.length > 0) {
                        formatted.push(renderTable(tableRows));
                        inTable = false;
                        tableRows = [];
                    }

                    // Handle other content
                    if (line.includes('📌') || line.includes('💡')) {
                        continue; // Skip pagination hints
                    } else if (line.match(/^[-*•]\s/)) {
                        formatted.push(`<li>${line.replace(/^[-*•]\s/, '')}</li>`);
                    } else if (line) {
                        formatted.push(`<p>${line}</p>`);
                    }
                }
            }

            // Handle table at end of content
            if (inTable && tableRows.length > 0) {
                formatted.push(renderTable(tableRows));
            }

            return formatted.join('');
        },

        // Add to chat history
        addToHistory: function(message) {
            this.state.history.push({
                message: message,
                timestamp: new Date()
            });
            this.updateHistory();
        },

        // Format text with markdown-like syntax
        formatText: function(text) {
            let html = text;
            html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
            html = html.replace(/`([^`]+)`/g, '<code style="background: rgba(0,0,0,0.08); padding: 2px 4px; border-radius: 3px;">$1</code>');
            html = html.replace(/\n/g, '<br>');
            return html;
        },

        // Update history display
        updateHistory: function() {
            ['historyList', 'historyListModal'].forEach(id => {
                const container = document.getElementById(id);
                if (!container) return;

                if (this.state.history.length === 0) {
                    container.innerHTML = `<div class="empty-state"><i class="fas fa-history"></i><div class="empty-state-title">No chat history</div></div>`;
                    return;
                }

                let html = '';
                this.state.history.forEach(item => {
                    const date = new Date(item.timestamp);
                    const timeStr = this.formatTimeAgo(date);
                    const msgCount = item.message_count || 0;
                    const sessionId = item.session_id || '';
                    const isActive = sessionId === this.state.currentSessionId;

                    html += `<div class="history-item${isActive ? ' active' : ''}" data-session-id="${sessionId}" onclick="RAG_ENGINE.loadSession('${sessionId}')" style="cursor: pointer; padding: 10px; border-bottom: 1px solid #e2e8f0; ${isActive ? 'background: rgba(45, 134, 89, 0.1);' : ''}">
                        <div class="history-time" style="font-size: 0.7rem; color: #888;">${timeStr}</div>
                        <div class="history-text" style="font-size: 0.85rem; color: #333;">${(item.message || '').substring(0, 40)}${(item.message || '').length > 40 ? '...' : ''}</div>
                        <div class="history-count" style="font-size: 0.7rem; color: #666;">${msgCount} messages</div>
                    </div>`;
                });
                container.innerHTML = html;
            });
        },

        // Format time ago
        formatTimeAgo: function(date) {
            const now = new Date();
            const seconds = Math.floor((now - date) / 1000);

            if (seconds < 60) return 'Just now';
            if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
            if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
            if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
            return date.toLocaleDateString();
        },

        // Load a specific session's messages
        loadSession: function(sessionId) {
            if (!sessionId) return;

            console.log('📜 Loading session:', sessionId);
            this.state.currentSessionId = sessionId;

            fetch(`${this.config.sessionsEndpoint}/${sessionId}?limit=${this.config.maxMessagesPerSession}`, {
                credentials: 'include'
            })
            .then(res => res.json())
            .then(data => {
                if (data.success && data.messages) {
                    // Clear current messages
                    const containers = ['chatMessages', 'chatMessagesModal'];
                    containers.forEach(id => {
                        const container = document.getElementById(id);
                        if (container) {
                            container.innerHTML = '';

                            // Add each message
                            data.messages.forEach(msg => {
                                const msgDiv = document.createElement('div');
                                msgDiv.className = `chat-message ${msg.role === 'user' ? 'user' : 'ai'}`;

                                let html;
                                if (msg.role === 'assistant') {
                                    html = this.formatAssistantMessage(msg.content, msg.metadata);
                                    if (msg.method) {
                                        html += `<small style="margin-top: 8px; display: block; opacity: 0.75;">🔍 ${msg.method.replace(/_/g, ' ').toUpperCase()}</small>`;
                                    }
                                } else {
                                    html = this.formatText(msg.content);
                                }

                                msgDiv.innerHTML = `<div class="chat-message-content">${html}</div>`;
                                container.appendChild(msgDiv);
                            });

                            container.scrollTop = container.scrollHeight;
                        }
                    });

                    // Update history to show active session
                    this.updateHistory();
                    console.log(`✓ Loaded ${data.messages.length} messages`);
                }
            })
            .catch(err => {
                console.warn('⚠️ Failed to load session:', err);
            });
        }
    };

    // =========================================================================
    // TABLE RENDERING
    // =========================================================================
    function renderTable(rows) {
        if (rows.length === 0) return '';

        let tableHtml = `
            <div class="chat-table-container" style="width: 100%; overflow-x: auto; margin: 12px 0; border-radius: 8px; border: 1px solid #e2e8f0;">
                <table class="chat-table" style="width: 100%; border-collapse: collapse; font-size: 0.8rem; min-width: 400px;">
        `;

        // First row is header
        tableHtml += '<thead style="background: linear-gradient(135deg, #1a4d2e, #2d6a4f); color: white;"><tr>';
        rows[0].forEach(cell => {
            tableHtml += `<th style="padding: 10px 12px; text-align: left; font-weight: 600; font-size: 0.75rem; text-transform: uppercase;">${cell}</th>`;
        });
        tableHtml += '</tr></thead>';

        // Remaining rows are body
        if (rows.length > 1) {
            tableHtml += '<tbody>';
            for (let i = 1; i < rows.length; i++) {
                const bgColor = i % 2 === 0 ? '#f8fafc' : 'white';
                tableHtml += `<tr style="border-bottom: 1px solid #e2e8f0; background: ${bgColor};">`;
                rows[i].forEach((cell, idx) => {
                    // Highlight Interface ID column
                    if (cell.match(/^INT-\d+$/)) {
                        tableHtml += `<td style="padding: 10px 12px;"><code style="background: linear-gradient(135deg, rgba(45, 134, 89, 0.15), rgba(64, 184, 159, 0.15)); color: #2d8659; padding: 4px 8px; border-radius: 4px; font-weight: 600; cursor: pointer;">${cell}</code></td>`;
                    } else {
                        tableHtml += `<td style="padding: 10px 12px;">${cell}</td>`;
                    }
                });
                tableHtml += '</tr>';
            }
            tableHtml += '</tbody>';
        }

        tableHtml += '</table></div>';
        return tableHtml;
    }

    // =========================================================================
    // CHART RENDERING
    // =========================================================================
    function parseChartData(text) {
        const chartMatch = text.match(/<!--CHART_DATA:([\s\S]*?):CHART_DATA-->/);
        if (chartMatch) {
            try {
                return JSON.parse(chartMatch[1]);
            } catch (e) {
                console.error('Failed to parse chart data:', e);
                return null;
            }
        }
        return null;
    }

    function renderCharts(chartData) {
        if (!chartData || !chartData.charts || chartData.charts.length === 0) {
            return '';
        }

        console.log('📊 Rendering charts:', chartData);
        pendingCharts = [];

        let html = `
            <div class="chat-report-header" style="background: linear-gradient(135deg, rgba(45, 134, 89, 0.1), rgba(64, 184, 159, 0.1)); border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 20px; margin-bottom: 16px; display: flex; align-items: center; gap: 16px;">
                <div style="font-size: 2.5rem; color: #2d8659;">📊</div>
                <div>
                    <h3 style="font-size: 1.1rem; color: #1a4d2e; margin: 0 0 4px 0;">Interface ${chartData.report_type ? chartData.report_type.charAt(0).toUpperCase() + chartData.report_type.slice(1) : ''} Report</h3>
                    <p style="font-size: 0.85rem; color: #555d4f; margin: 0;">Total Interfaces: ${chartData.total_interfaces ? chartData.total_interfaces.toLocaleString() : 'N/A'}</p>
                </div>
            </div>
            <div class="chat-charts-container" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin: 16px 0;">
        `;

        chartData.charts.forEach((chart, index) => {
            const canvasId = `chart_widget_${Date.now()}_${index}`;
            html += `
                <div class="chat-chart-wrapper" style="background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);">
                    <div class="chat-chart-title" style="font-size: 0.9rem; font-weight: 600; color: #1a4d2e; margin-bottom: 12px; text-align: center;">
                        <i class="fas fa-chart-${getChartIcon(chart.type)}" style="color: #2d8659;"></i>
                        ${chart.title}
                    </div>
                    <canvas id="${canvasId}" style="max-height: 280px;"></canvas>
                </div>
            `;
            pendingCharts.push({ canvasId, chart });
        });

        html += '</div>';
        return html;
    }

    function getChartIcon(chartType) {
        switch(chartType) {
            case 'pie':
            case 'doughnut':
                return 'pie';
            case 'bar':
            case 'horizontalBar':
                return 'bar';
            case 'line':
                return 'line';
            default:
                return 'bar';
        }
    }

    function createPendingCharts() {
        console.log('📊 Creating pending charts:', pendingCharts.length);

        // Check if Chart.js is loaded
        if (typeof Chart === 'undefined') {
            console.warn('⚠️ Chart.js not loaded, loading dynamically...');
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js';
            script.onload = () => {
                console.log('✅ Chart.js loaded dynamically');
                pendingCharts.forEach(({ canvasId, chart }) => {
                    createChart(canvasId, chart);
                });
                pendingCharts = [];
            };
            document.head.appendChild(script);
            return;
        }

        pendingCharts.forEach(({ canvasId, chart }) => {
            createChart(canvasId, chart);
        });
        pendingCharts = [];
    }

    function createChart(canvasId, chartConfig) {
        console.log(`📈 Creating chart: ${canvasId}`, chartConfig);

        const canvas = document.getElementById(canvasId);
        if (!canvas) {
            console.error('❌ Canvas not found:', canvasId);
            return;
        }

        // Destroy existing chart if any
        if (chartInstances[canvasId]) {
            chartInstances[canvasId].destroy();
        }

        const ctx = canvas.getContext('2d');
        const colors = chartConfig.colors || ['#2d8659', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#14b8a6'];

        const backgroundColors = chartConfig.type === 'bar' || chartConfig.type === 'horizontalBar'
            ? colors[0]
            : colors.slice(0, chartConfig.data.length);

        let chartType = chartConfig.type;
        let indexAxis = undefined;
        if (chartConfig.type === 'horizontalBar') {
            chartType = 'bar';
            indexAxis = 'y';
        }

        const config = {
            type: chartType,
            data: {
                labels: chartConfig.labels,
                datasets: [{
                    data: chartConfig.data,
                    backgroundColor: backgroundColors,
                    borderColor: chartConfig.type === 'bar' || chartConfig.type === 'horizontalBar'
                        ? colors[0]
                        : colors.map(c => c),
                    borderWidth: chartConfig.type === 'bar' || chartConfig.type === 'horizontalBar' ? 0 : 2,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                indexAxis: indexAxis,
                plugins: {
                    legend: {
                        display: chartConfig.type === 'pie' || chartConfig.type === 'doughnut',
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true,
                            font: { size: 11 }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${context.label}: ${value.toLocaleString()} (${percentage}%)`;
                            }
                        }
                    }
                },
                scales: chartConfig.type === 'bar' || chartConfig.type === 'horizontalBar' ? {
                    x: {
                        ticks: { font: { size: 10 }, maxRotation: 45, minRotation: 0 },
                        grid: { display: false }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: { font: { size: 10 } },
                        grid: { color: 'rgba(0,0,0,0.05)' }
                    }
                } : {}
            }
        };

        try {
            chartInstances[canvasId] = new Chart(ctx, config);
            console.log('✅ Chart created:', canvasId);
        } catch (error) {
            console.error('❌ Chart creation failed:', error);
        }
    }

    // =========================================================================
    // CHAT WIDGET FUNCTIONS - UI Interactions
    // =========================================================================

    // Send chat message from panel
    window.sendChatMessage = function() {
        const input = document.getElementById('chatInput');
        const message = input.value.trim();

        if (!message) return;

        console.log('📨 RAG sendChatMessage called:', message);

        const messagesDiv = document.getElementById('chatMessages');
        const sendBtn = document.getElementById('chatSendBtn');

        // Add user message
        const userMsg = document.createElement('div');
        userMsg.className = 'chat-message user';
        userMsg.innerHTML = `<div class="chat-message-content">${RAG_ENGINE.formatText(message)}</div>`;
        messagesDiv.appendChild(userMsg);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;

        input.value = '';
        sendBtn.disabled = true;

        // Show typing indicator
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) typingIndicator.style.display = 'flex';

        // Send via RAG engine
        RAG_ENGINE.sendMessage(message, false);

        // Re-enable button after response
        setTimeout(() => {
            sendBtn.disabled = false;
        }, 500);
    };

    // Send chat message from modal
    window.sendChatMessageModal = function() {
        const input = document.getElementById('chatInputModal');
        const message = input.value.trim();

        if (!message) return;

        console.log('📨 RAG sendChatMessageModal called:', message);

        const messagesDiv = document.getElementById('chatMessagesModal');
        const sendBtn = document.getElementById('chatSendBtnModal');

        // Add user message
        const userMsg = document.createElement('div');
        userMsg.className = 'chat-message user';
        userMsg.innerHTML = `<div class="chat-message-content">${RAG_ENGINE.formatText(message)}</div>`;
        messagesDiv.appendChild(userMsg);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;

        input.value = '';
        sendBtn.disabled = true;

        // Show typing indicator
        const typingIndicator = document.getElementById('typingIndicatorModal');
        if (typingIndicator) typingIndicator.style.display = 'flex';

        // Send via RAG engine
        RAG_ENGINE.sendMessage(message, true);

        // Re-enable button after response
        setTimeout(() => {
            sendBtn.disabled = false;
        }, 500);
    };

    // Handle keypress in panel input
    window.handleChatKeypress = function(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendChatMessage();
        }
    };

    // Handle keypress in modal input
    window.handleChatKeypressModal = function(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendChatMessageModal();
        }
    };

    // Toggle chat panel visibility
    window.toggleChat = function() {
        const panel = document.getElementById('chatPanel');
        const overlay = document.getElementById('chatOverlay');
        const btn = document.getElementById('floatingChatBtn');

        if (panel && overlay && btn) {
            const isOpen = panel.classList.contains('open');

            if (isOpen) {
                // Closing - explicitly remove classes
                panel.classList.remove('open');
                overlay.classList.remove('active');
                btn.classList.remove('active');
            } else {
                // Opening - add classes
                panel.classList.add('open');
                overlay.classList.add('active');
                btn.classList.add('active');
                const input = document.getElementById('chatInput');
                if (input) input.focus();
            }
        }
    };

    // Close chat panel (explicit close)
    window.closeChat = function() {
        const panel = document.getElementById('chatPanel');
        const overlay = document.getElementById('chatOverlay');
        const btn = document.getElementById('floatingChatBtn');

        if (panel) panel.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
        if (btn) btn.classList.remove('active');
    };

    // Maximize chat to modal
    window.maximizeChat = function() {
        const panel = document.getElementById('chatPanel');
        const overlay = document.getElementById('chatOverlay');
        const modalOverlay = document.getElementById('chatModalOverlay');
        const btn = document.getElementById('floatingChatBtn');

        if (panel) panel.classList.remove('open');
        if (overlay) overlay.classList.remove('active');
        if (btn) btn.classList.remove('active');
        if (modalOverlay) modalOverlay.classList.add('active');

        const input = document.getElementById('chatInputModal');
        if (input) input.focus();
    };

    // Minimize chat from modal to panel
    window.minimizeChat = function() {
        const modalOverlay = document.getElementById('chatModalOverlay');
        const panel = document.getElementById('chatPanel');
        const overlay = document.getElementById('chatOverlay');
        const btn = document.getElementById('floatingChatBtn');

        if (modalOverlay) modalOverlay.classList.remove('active');
        if (panel) panel.classList.add('open');
        if (overlay) overlay.classList.add('active');
        if (btn) btn.classList.add('active');
    };

    // Close modal
    window.closeModal = function() {
        const modalOverlay = document.getElementById('chatModalOverlay');
        const overlay = document.getElementById('chatOverlay');
        const btn = document.getElementById('floatingChatBtn');

        if (modalOverlay) modalOverlay.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        if (btn) btn.classList.remove('active');
    };

    // Clear chat panel - starts a new session
    window.clearChat = function() {
        const container = document.getElementById('chatMessages');
        if (container) {
            container.innerHTML = `
                <div class="chat-message ai">
                    <div class="chat-message-content">
                        👋 Hello! I'm your AI Assistant powered by Hybrid RAG. Ask about integrations or data.
                    </div>
                </div>
            `;
        }
        // Reset session to start a new one on next message
        RAG_ENGINE.state.currentSessionId = null;
        // Reload history from server
        RAG_ENGINE.loadUserHistory();
    };

    // Clear chat modal - starts a new session
    window.clearChatModal = function() {
        const container = document.getElementById('chatMessagesModal');
        if (container) {
            container.innerHTML = `
                <div class="chat-message ai">
                    <div class="chat-message-content">
                        👋 AI Assistant powered by Hybrid RAG vector search.
                    </div>
                </div>
            `;
        }
        // Reset session to start a new one on next message
        RAG_ENGINE.state.currentSessionId = null;
        // Reload history from server
        RAG_ENGINE.loadUserHistory();
    };

    // Switch tabs in panel
    window.switchChatTab = function(tabName, event) {
        document.querySelectorAll('#chatPanel .chat-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        if (event && event.target) {
            event.target.classList.add('active');
        }

        document.querySelectorAll('#chatPanel .chat-content').forEach(content => {
            content.classList.remove('active');
        });

        const contentMap = {
            'chat': 'chatContent',
            'help': 'helpContent',
            'history': 'historyContent'
        };

        const contentEl = document.getElementById(contentMap[tabName]);
        if (contentEl) contentEl.classList.add('active');
    };

    // Switch tabs in modal
    window.switchChatTabModal = function(tabName, event) {
        document.querySelectorAll('.chat-modal .chat-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        if (event && event.target) {
            event.target.classList.add('active');
        }

        document.querySelectorAll('.chat-modal .chat-content').forEach(content => {
            content.classList.remove('active');
        });

        const contentMap = {
            'chat': 'chatContentModal',
            'help': 'helpContentModal',
            'history': 'historyContentModal'
        };

        const contentEl = document.getElementById(contentMap[tabName]);
        if (contentEl) contentEl.classList.add('active');
    };

    // =========================================================================
    // INITIALIZATION
    // =========================================================================
    document.addEventListener('DOMContentLoaded', () => {
        RAG_ENGINE.init();
        console.log('✅ RAG Chat Widget loaded (Full-Featured)');
    });

})();
