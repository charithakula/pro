// =====================================================
// MAIN.JS - UI UTILITIES AND CHAT FUNCTIONS
// Note: Authentication functions are handled by auth.js
// =====================================================

// =====================================================
// NAVIGATION UTILITIES
// =====================================================

/**
 * Toggle user menu dropdown
 */
function toggleUserMenu() {
    const userMenu = document.querySelector('.user-menu');
    if (userMenu) {
        userMenu.classList.toggle('active');
    }
}

/**
 * Toggle mobile menu
 */
function toggleMobileMenu() {
    const navMenu = document.getElementById('navMenu');
    const mobileToggle = document.getElementById('mobileMenuToggle');

    if (navMenu) {
        navMenu.classList.toggle('active');
    }

    if (mobileToggle) {
        mobileToggle.classList.toggle('active');
    }
}

/**
 * Toggle navigation dropdown
 */
function toggleDropdown(event) {
    event.preventDefault();
    event.stopPropagation();

    const navItem = event.target.closest('.nav-item');
    if (!navItem) return;

    const dropdown = navItem.querySelector('.dropdown-menu');
    if (!dropdown) return;

    // Close other dropdowns
    document.querySelectorAll('.dropdown-menu.active').forEach(menu => {
        if (menu !== dropdown) {
            menu.classList.remove('active');
        }
    });

    dropdown.classList.toggle('active');
}

/**
 * Toggle subdropdown menu
 */
function toggleSubdropdown(event) {
    event.stopPropagation();

    const parent = event.currentTarget;
    const subdropdown = parent.nextElementSibling;

    if (subdropdown && subdropdown.classList.contains('subdropdown-menu')) {
        subdropdown.classList.toggle('active');
        parent.classList.toggle('active');
    }
}

/**
 * Navigate to profile page
 */
function goToProfile(event) {
    if (event) event.stopPropagation();
    window.location.href = '/profile';
}

/**
 * Navigate to settings page
 */
function goToSettings(event) {
    if (event) event.stopPropagation();
    window.location.href = '/settings';
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('.nav-item')) {
        document.querySelectorAll('.dropdown-menu.active').forEach(menu => {
            menu.classList.remove('active');
        });
    }

    if (!event.target.closest('.user-info')) {
        document.querySelectorAll('.user-menu.active').forEach(menu => {
            menu.classList.remove('active');
        });
    }
});

// =====================================================
// CHAT PANEL UTILITIES
// =====================================================

let chatPanelOpen = false;
let chatMaximized = false;

/**
 * Toggle chat panel visibility
 */
function toggleChat() {
    console.log('toggleChat called');
    const chatPanel = document.getElementById('chatPanel');
    const chatOverlay = document.getElementById('chatOverlay');
    const floatingBtn = document.getElementById('floatingChatBtn');

    if (!chatPanel || !chatOverlay) {
        console.error('Chat elements not found');
        return;
    }

    chatPanelOpen = !chatPanelOpen;

    chatPanel.classList.toggle('open');
    chatOverlay.classList.toggle('active');
    if (floatingBtn) floatingBtn.classList.toggle('active');

    console.log('Chat panel open:', chatPanel.classList.contains('open'));
}

/**
 * Maximize chat to full screen
 */
function maximizeChat() {
    console.log('maximizeChat called');
    const chatModal = document.getElementById('chatModalOverlay');
    const chatPanel = document.getElementById('chatPanel');

    if (chatModal) {
        chatModal.classList.add('open');
        chatMaximized = true;
    }

    if (chatPanel) {
        chatPanel.classList.remove('open');
    }

    // Sync messages
    syncChatMessages();
}

/**
 * Minimize chat from full screen
 */
function minimizeChat() {
    console.log('minimizeChat called');
    const chatModal = document.getElementById('chatModalOverlay');
    const chatPanel = document.getElementById('chatPanel');

    if (chatModal) {
        chatModal.classList.remove('open');
        chatMaximized = false;
    }

    if (chatPanel) {
        chatPanel.classList.add('open');
    }

    // Sync messages back
    syncChatMessages();
}

/**
 * Close modal completely
 */
function closeModal() {
    console.log('closeModal called');
    const chatModal = document.getElementById('chatModalOverlay');
    const chatPanel = document.getElementById('chatPanel');
    const floatingBtn = document.getElementById('floatingChatBtn');

    if (chatModal) {
        chatModal.classList.remove('open');
        chatMaximized = false;
    }

    if (chatPanel) {
        chatPanel.classList.remove('open');
        chatPanelOpen = false;
    }

    if (floatingBtn) {
        floatingBtn.classList.remove('active');
    }
}

/**
 * Sync messages between panel and modal
 */
function syncChatMessages() {
    const panelMessages = document.getElementById('chatMessages');
    const modalMessages = document.getElementById('chatMessagesModal');

    if (chatMaximized && panelMessages && modalMessages) {
        modalMessages.innerHTML = panelMessages.innerHTML;
        modalMessages.scrollTop = modalMessages.scrollHeight;
    } else if (!chatMaximized && panelMessages && modalMessages) {
        panelMessages.innerHTML = modalMessages.innerHTML;
        panelMessages.scrollTop = panelMessages.scrollHeight;
    }
}

/**
 * Clear chat messages (panel)
 */
function clearChat() {
    console.log('clearChat called');
    const chatMessages = document.getElementById('chatMessages');
    if (chatMessages) {
        chatMessages.innerHTML = `
            <div class="chat-message ai">
                <div class="chat-message-content">
                    👋 Hello! I'm your AI Assistant powered by Hybrid RAG. Ask about integrations or data.
                </div>
            </div>
        `;
    }

    // Clear history if RAG_ENGINE is available
    if (window.RAG_ENGINE) {
        window.RAG_ENGINE.state.history = [];
        window.RAG_ENGINE.updateHistory();
    }
}

/**
 * Clear chat messages (modal)
 */
function clearChatModal() {
    console.log('clearChatModal called');
    const chatMessages = document.getElementById('chatMessagesModal');
    if (chatMessages) {
        chatMessages.innerHTML = `
            <div class="chat-message ai">
                <div class="chat-message-content">
                    👋 AI Assistant powered by Hybrid RAG vector search.
                </div>
            </div>
        `;
    }

    // Clear history if RAG_ENGINE is available
    if (window.RAG_ENGINE) {
        window.RAG_ENGINE.state.history = [];
        window.RAG_ENGINE.updateHistory();
    }
}

/**
 * Switch chat tab (panel)
 */
function switchChatTab(tab, event) {
    console.log('switchChatTab called:', tab);
    if (event) {
        event.preventDefault();
    }

    // Update tab buttons
    document.querySelectorAll('#chatPanel .chat-tab, .chat-panel .chat-tab').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.classList.add('active');
    }

    // Update content
    document.querySelectorAll('#chatPanel .chat-content, .chat-panel .chat-content').forEach(content => {
        content.classList.remove('active');
    });

    const tabMap = {
        'chat': 'chatContent',
        'help': 'helpContent',
        'history': 'historyContent'
    };

    const targetContent = document.getElementById(tabMap[tab]);
    if (targetContent) {
        targetContent.classList.add('active');
    }

    // Hide input for non-chat tabs
    const inputArea = document.getElementById('chatInputArea');
    if (inputArea) {
        inputArea.style.display = tab === 'chat' ? 'flex' : 'none';
    }
}

/**
 * Switch chat tab (modal)
 */
function switchChatTabModal(tab, event) {
    console.log('switchChatTabModal called:', tab);
    if (event) {
        event.preventDefault();
    }

    // Update tab buttons
    document.querySelectorAll('#chatModalOverlay .chat-tab, .chat-modal .chat-tab').forEach(btn => {
        btn.classList.remove('active');
    });
    if (event && event.target) {
        event.target.classList.add('active');
    }

    // Update content
    document.querySelectorAll('#chatModalOverlay .chat-content, .chat-modal .chat-content').forEach(content => {
        content.classList.remove('active');
    });

    const tabMap = {
        'chat': 'chatContentModal',
        'help': 'helpContentModal',
        'history': 'historyContentModal'
    };

    const targetContent = document.getElementById(tabMap[tab]);
    if (targetContent) {
        targetContent.classList.add('active');
    }

    // Hide input for non-chat tabs
    const inputArea = document.getElementById('chatInputAreaModal');
    if (inputArea) {
        inputArea.style.display = tab === 'chat' ? 'flex' : 'none';
    }
}

/**
 * Handle chat input keypress (panel)
 */
function handleChatKeypress(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendChatMessage();
    }
}

/**
 * Handle chat input keypress (modal)
 */
function handleChatKeypressModal(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendChatMessageModal();
    }
}

/**
 * Send chat message (panel)
 * This function will be overridden by header.html if RAG_ENGINE is available
 */
function sendChatMessage() {
    console.log('sendChatMessage called');
    const input = document.getElementById('chatInput');
    const message = input?.value?.trim();

    if (!message) {
        console.log('Empty message');
        return;
    }

    console.log('📨 sendChatMessage:', message);

    const messagesDiv = document.getElementById('chatMessages');
    const sendBtn = document.getElementById('chatSendBtn');

    if (!messagesDiv) {
        console.error('chatMessages element not found');
        return;
    }

    // Add user message
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-message user';
    userMsg.innerHTML = `<div class="chat-message-content">${escapeHtml(message)}</div>`;
    messagesDiv.appendChild(userMsg);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    input.value = '';
    if (sendBtn) sendBtn.disabled = true;

    // Show typing indicator
    const typingIndicator = document.getElementById('typingIndicator');
    if (typingIndicator) typingIndicator.style.display = 'flex';

    // Call RAG engine if available
    if (window.RAG_ENGINE && window.RAG_ENGINE.sendMessage) {
        RAG_ENGINE.sendMessage(message, false);
    } else {
        // Fallback response if RAG_ENGINE not available
        setTimeout(() => {
            if (typingIndicator) typingIndicator.style.display = 'none';

            const aiMsg = document.createElement('div');
            aiMsg.className = 'chat-message ai';
            aiMsg.innerHTML = `<div class="chat-message-content">⚠️ Chat system is loading. Please wait...</div>`;
            messagesDiv.appendChild(aiMsg);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;

            if (sendBtn) sendBtn.disabled = false;
        }, 1000);
    }
}

/**
 * Send chat message (modal)
 * This function will be overridden by header.html if RAG_ENGINE is available
 */
function sendChatMessageModal() {
    console.log('sendChatMessageModal called');
    const input = document.getElementById('chatInputModal');
    const message = input?.value?.trim();

    if (!message) {
        console.log('Empty message');
        return;
    }

    console.log('📨 sendChatMessageModal:', message);

    const messagesDiv = document.getElementById('chatMessagesModal');
    const sendBtn = document.getElementById('chatSendBtnModal');

    if (!messagesDiv) {
        console.error('chatMessagesModal element not found');
        return;
    }

    // Add user message
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-message user';
    userMsg.innerHTML = `<div class="chat-message-content">${escapeHtml(message)}</div>`;
    messagesDiv.appendChild(userMsg);
    messagesDiv.scrollTop = messagesDiv.scrollHeight;

    input.value = '';
    if (sendBtn) sendBtn.disabled = true;

    // Show typing indicator
    const typingIndicator = document.getElementById('typingIndicatorModal');
    if (typingIndicator) typingIndicator.style.display = 'flex';

    // Call RAG engine if available
    if (window.RAG_ENGINE && window.RAG_ENGINE.sendMessage) {
        RAG_ENGINE.sendMessage(message, true);
    } else {
        // Fallback response if RAG_ENGINE not available
        setTimeout(() => {
            if (typingIndicator) typingIndicator.style.display = 'none';

            const aiMsg = document.createElement('div');
            aiMsg.className = 'chat-message ai';
            aiMsg.innerHTML = `<div class="chat-message-content">⚠️ Chat system is loading. Please wait...</div>`;
            messagesDiv.appendChild(aiMsg);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;

            if (sendBtn) sendBtn.disabled = false;
        }, 1000);
    }
}

// =====================================================
// UTILITY FUNCTIONS
// =====================================================

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, m => map[m]);
}

/**
 * Update current time display
 */
function updateTime() {
    const timeEl = document.getElementById('currentTime');
    const dateEl = document.getElementById('currentDate');

    if (timeEl) {
        const now = new Date();
        timeEl.textContent = now.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    if (dateEl) {
        const now = new Date();
        dateEl.textContent = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
}

// =====================================================
// INITIALIZATION
// =====================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ Main.js loaded');

    // Update time every second
    updateTime();
    setInterval(updateTime, 1000);

    // Initialize date/time display
    const dateEl = document.getElementById('currentDate');
    if (dateEl && dateEl.textContent === 'Today') {
        updateTime();
    }

    // Initialize chat overlay click handler
    const chatOverlay = document.getElementById('chatOverlay');
    if (chatOverlay) {
        chatOverlay.addEventListener('click', function() {
            console.log('Chat overlay clicked - closing chat');
            toggleChat();
        });
    }

    console.log('✅ Chat functions initialized');
});

console.log('✅ Main.js utilities ready');