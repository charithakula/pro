"""
Create SQLite tables for authentication when PostgreSQL is unavailable
Run this script to initialize the users table in SQLite
"""

from app import create_app
from backend.auth.auth_models import db

app = create_app()

with app.app_context():
    # Create all tables
    db.create_all()
    print("✅ SQLite tables created successfully!")
    print("   - users table created")
