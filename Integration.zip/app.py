# -*- coding: utf-8 -*-
"""
360° Enterprise Dashboard - Flask Application v4.5.0
WITH HYBRID RAG SYSTEM - Intelligent AI Data Assistant
WITH PROFESSIONAL JWT AUTHENTICATION
WITH AZURE OPENAI CLIENT INITIALIZATION ✅ FIXED
WITH FLASK SESSION & CORS CREDENTIALS ✅ FIXED
Seamlessly integrated with Azure OpenAI + pgvector + PostgreSQL
Features: Direct LLM, SQL-First, and Hybrid query processing

CRITICAL: .env MUST BE LOADED FIRST (before any other imports)
"""

# ============================================================================
# STEP 1: LOAD ENVIRONMENT VARIABLES FIRST (BEFORE ALL OTHER IMPORTS)
# ============================================================================
# ============================================================================
# STEP 1: LOAD ENVIRONMENT VARIABLES FIRST (BEFORE ALL OTHER IMPORTS)
# ============================================================================
from dotenv import load_dotenv
import os
import sys

# Set UTF-8 encoding for Windows console
if sys.platform == 'win32':
    import io
    if isinstance(sys.stdout, io.TextIOWrapper):
        sys.stdout.reconfigure(encoding='utf-8')
    if isinstance(sys.stderr, io.TextIOWrapper):
        sys.stderr.reconfigure(encoding='utf-8')

# Add project root to path so backend modules can be imported
PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, PROJECT_ROOT)

ENV_FILE = os.path.join(PROJECT_ROOT, '.env')

print(f"\n{'='*80}")
print(f"🔍 ENVIRONMENT LOADING DEBUG (app.py)")
print(f"{'='*80}")
print(f"📁 Backend directory: {PROJECT_ROOT}")
print(f"📄 .env path: {ENV_FILE}")
print(f"✅ .env exists: {os.path.exists(ENV_FILE)}")

loaded = load_dotenv(dotenv_path=ENV_FILE)
print(f"✅ .env loaded: {loaded}")
flask_secret = os.getenv('FLASK_SECRET_KEY', 'NOT FOUND')
print(f"🔑 FLASK_SECRET_KEY: {flask_secret[:20]}..." if flask_secret != 'NOT FOUND' else f"🔑 FLASK_SECRET_KEY: NOT FOUND")
print(f"{'='*80}\n")
# ============================================================================
import logging
import traceback
import contextlib
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, send_from_directory, send_file
from flask_cors import CORS
from werkzeug.exceptions import HTTPException
from werkzeug.utils import secure_filename
import io
from hashlib import sha256
from openai import AzureOpenAI

# ============================================================================
# STEP 2: VERIFY .env WAS LOADED (Debug check - optional but helpful)
# ============================================================================
logger = logging.getLogger(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Print .env verification (optional debug)
if os.getenv('DB_PORT'):
    logger.info(f"✓ Environment variables loaded successfully")
    logger.info(f"  Database: {os.getenv('DB_HOST')}:{os.getenv('DB_PORT')}/{os.getenv('DB_NAME')}")
else:
    logger.warning("⚠ Warning: Some environment variables may not be loaded")

# ============================================================================
# CONDITIONAL IMPORTS - DATABASE
# ============================================================================

try:
    from backend.auth.auth_models import db, User
    DB_AVAILABLE = True
except Exception as db_import_err:
    DB_AVAILABLE = False
    db = None
    logger.warning(f"⚠ Database models not available: {db_import_err}")

# ============================================================================
# IMPORT AUTHENTICATION SYSTEM
# ============================================================================

try:
    from backend.auth.auth_models import db as auth_db
    from backend.auth.auth import auth_bp
    AUTH_AVAILABLE = True
    logger.info("✓ Professional authentication system available")
except Exception as auth_import_err:
    AUTH_AVAILABLE = False
    auth_db = None
    auth_bp = None
    logger.warning(f"⚠ Authentication system not available: {auth_import_err}")

# ============================================================================
# IMPORT CUSTOM CONNECTORS
# ============================================================================

try:
    from backend.connectors.db_connector import get_database_connector, DatabaseConnectorError
except Exception as connector_err:
    get_database_connector = None
    DatabaseConnectorError = Exception
    logger.warning(f"⚠ Database connector not available: {connector_err}")

try:
    from backend.connectors.azure_openai_connector import get_azure_openai_connector, AzureOpenAIConnectorError
except Exception:
    get_azure_openai_connector = None
    AzureOpenAIConnectorError = Exception

try:
    from backend.connectors.azure_storage_connector import get_azure_storage_connector, AzureStorageConnectorError
except Exception:
    get_azure_storage_connector = None
    AzureStorageConnectorError = Exception

try:
    from backend.connectors.sharepoint_connector import get_sharepoint_connector, SharePointConnectorError
except Exception:
    get_sharepoint_connector = None
    SharePointConnectorError = Exception

# ============================================================================
# IMPORT HYBRID RAG SERVICES
# ============================================================================

HYBRID_RAG_SERVICES_AVAILABLE = False

try:
    from backend.services.database import get_db_connection, get_db_session, init_db, check_db_health
    HYBRID_RAG_SERVICES_AVAILABLE = True
    logger.info("✓ Hybrid RAG database services available")
except Exception as services_err:
    logger.warning(f"⚠ Hybrid RAG services not available: {services_err}")
    HYBRID_RAG_SERVICES_AVAILABLE = False

try:
    from backend.services.hybrid_rag_service import HybridRAGService
except Exception as rag_err:
    HybridRAGService = None
    logger.warning(f"⚠ HybridRAGService not available: {rag_err}")

try:
    from backend.services.data_import_service import DataImportService
except Exception as import_err:
    DataImportService = None
    DataImportError = Exception
    logger.warning(f"⚠ DataImportService not available: {import_err}")

# ============================================================================
# IMPORT CHAT BLUEPRINT - DUAL STRATEGY
# ============================================================================

CHATBOT_AVAILABLE = False
HYBRID_RAG_AVAILABLE = False
chat_bp = None

logger.info("\n" + "="*80)
logger.info("ATTEMPTING TO IMPORT CHAT BLUEPRINT")
logger.info("="*80 + "\n")

# Strategy 1: Direct import from routes.chat
try:
    logger.info("Strategy 1: Importing directly from routes.chat...")
    from backend.routes.chat import chat_bp
    CHATBOT_AVAILABLE = True
    HYBRID_RAG_AVAILABLE = True
    logger.info("✓ SUCCESS: Chat blueprint imported from routes.chat")
    logger.info("  🧠 Hybrid RAG Features: Intelligent Routing, pgvector, SQL Generation")
except Exception as direct_err:
    logger.warning(f"⚠ Strategy 1 failed: {direct_err}")
    
    # Strategy 2: Import from routes package (via __init__.py)
    try:
        logger.info("Strategy 2: Importing from routes package...")
        from backend.routes import chat_bp
        CHATBOT_AVAILABLE = True
        HYBRID_RAG_AVAILABLE = True
        logger.info("✓ SUCCESS: Chat blueprint imported from routes package")
        logger.info("  🧠 Hybrid RAG Features: Intelligent Routing, pgvector, SQL Generation")
    except Exception as package_err:
        logger.error(f"✗ Strategy 2 failed: {package_err}")
        CHATBOT_AVAILABLE = False
        HYBRID_RAG_AVAILABLE = False
        chat_bp = None

logger.info("\n" + "="*80 + "\n")

# ============================================================================
# CUSTOM EXCEPTIONS
# ============================================================================

class DatabaseError(Exception):
    """Custom exception for database-related errors"""
    pass

class AuthenticationError(Exception):
    """Custom exception for authentication errors"""
    pass

class AIServiceError(Exception):
    """Custom exception for AI service errors"""
    pass

class StorageError(Exception):
    """Custom exception for storage service errors"""
    pass

class SplunkQueryError(Exception):
    """Custom exception for Splunk query errors"""
    pass

class SharePointError(Exception):
    """Custom exception for SharePoint errors"""
    pass

# ============================================================================
# IN-MEMORY STORAGE (FALLBACK)
# ============================================================================

class InMemoryStorage:
    """In-memory storage for when database is unavailable"""
    
    def __init__(self):
        self.users = {}
        self.next_user_id = 1
        
    def create_user(self, email, name, password_hash):
        """Create user in memory"""
        user_id = self.next_user_id
        self.next_user_id += 1
        
        self.users[user_id] = {
            'id': user_id,
            'email': email,
            'name': name,
            'password_hash': password_hash,
            'is_active': True,
            'created_at': datetime.utcnow(),
            'last_login': None
        }
        return self.users[user_id]
    
    def get_user_by_email(self, email):
        """Get user by email"""
        for user in self.users.values():
            if user['email'] == email:
                return user
        return None
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        return self.users.get(user_id)
    
    def update_user_login(self, user_id):
        """Update last login time"""
        if user_id in self.users:
            self.users[user_id]['last_login'] = datetime.utcnow()

# ============================================================================
# GLOBAL CONNECTORS & MODELS
# ============================================================================

db_connector = None
ai_connector = None
storage_connector = None
sharepoint_connector = None
openai_client = None  # ✅ GLOBAL AZURE OPENAI CLIENT
in_memory_storage = InMemoryStorage()

User = None
AzureIntegration = None
SharePointIntegration = None
AIInteraction = None
StorageFile = None
SplunkQuery = None

DATABASE_MODE = 'unavailable'

# ============================================================================
# FILE UPLOAD CONFIGURATION
# ============================================================================

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'py', 'js', 'java', 'cpp', 'c'}
MAX_FILE_SIZE = 10 * 1024 * 1024

def allowed_file(filename):
    """Check if file extension is allowed"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# ============================================================================
# PASSWORD HASHING
# ============================================================================

def hash_password(password):
    """Simple password hashing for in-memory mode"""
    return sha256(password.encode()).hexdigest()

def verify_password(stored_hash, provided_password):
    """Verify password against hash"""
    return stored_hash == hash_password(provided_password)

# ============================================================================
# DECORATORS
# ============================================================================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # Log session state for debugging
            logger.debug(f"🔍 login_required check - Session keys: {list(session.keys())}")
            logger.debug(f"🔍 Has user_id in session: {'user_id' in session}")

            if 'user_id' not in session:
                logger.warning(f"⚠️ No user_id in session - redirecting to login")
                return redirect(url_for('login_page'))

            logger.debug(f"✅ login_required passed for user_id: {session.get('user_id')}")
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"✗ Login required decorator error: {e}")
            return redirect(url_for('login_page'))
    return decorated_function

def api_login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            if 'user_id' not in session:
                return jsonify({'error': 'Unauthorized', 'message': 'User session not found'}), 401
            return f(*args, **kwargs)
        except Exception as e:
            logger.error(f"✗ API login required decorator error: {e}")
            return jsonify({'error': 'Authentication failed', 'message': str(e)}), 401
    return decorated_function


def hybrid_login_required(f):
    """
    ✅ FIXED: Decorator with comprehensive debug logging
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            # ✅ DEBUG: Log everything we receive
            logger.info(f"{'='*60}")
            logger.info(f"🔐 hybrid_login_required: {request.path}")
            logger.info(f"   Session data: {dict(session)}")
            logger.info(f"   Session user_id: {session.get('user_id')}")
            logger.info(f"   Cookies keys: {list(request.cookies.keys())}")
            logger.info(f"   Has 'session' cookie: {'session' in request.cookies}")
            logger.info(f"   Has 'token' cookie: {'token' in request.cookies}")
            
            # First check: Do we have a Flask session?
            if 'user_id' in session:
                logger.info(f"✅ Flask session valid for user_id={session['user_id']}")
                return f(*args, **kwargs)
            else:
                logger.warning(f"❌ No user_id in session. Session keys: {list(session.keys())}")

            # Second check: Do we have a valid JWT token in cookies?
            token = request.cookies.get('token')
            
            if token:
                logger.info(f"🔍 Found JWT token in cookie (length: {len(token)})")
                
                from backend.auth.auth import verify_jwt_token
                payload, error = verify_jwt_token(token)

                if error:
                    logger.warning(f"❌ Token validation error: {error}")
                    return redirect(url_for('login_page'))

                user_id = payload.get('user_id')
                logger.info(f"✅ Token valid for user_id={user_id}")
                
                user = get_user_by_id(user_id)

                if not user:
                    logger.warning(f"❌ User not found for user_id={user_id}")
                    return redirect(url_for('login_page'))

                # Handle both dict and object types
                user_id_val = user.get('id') if isinstance(user, dict) else user.id
                user_is_active = user.get('is_active') if isinstance(user, dict) else user.is_active
                user_email_val = user.get('email') if isinstance(user, dict) else user.email
                user_name_val = user.get('name') if isinstance(user, dict) else user.name

                if not user_is_active:
                    logger.warning(f"❌ User inactive")
                    return redirect(url_for('login_page'))

                # ✅ Set Flask session from JWT
                session['user_id'] = user_id_val
                session['user_email'] = user_email_val
                session['user_name'] = user_name_val
                session.permanent = True
                session.modified = True

                logger.info(f"✅ Session created from JWT for {user_email_val}")
                return f(*args, **kwargs)
            else:
                logger.warning(f"❌ No token cookie found")

            # No valid auth found
            logger.warning(f"❌ REDIRECT TO LOGIN - No valid session or token")
            logger.info(f"{'='*60}")
            return redirect(url_for('login_page'))

        except Exception as e:
            logger.error(f"✗ hybrid_login_required error: {e}", exc_info=True)
            return redirect(url_for('login_page'))

    return decorated_function

# ============================================================================
# DATABASE OPERATIONS (WITH FALLBACK)
# ============================================================================

def get_user_by_email(email):
    """Get user by email - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return User.query.filter_by(email=email).first()
        else:
            return in_memory_storage.get_user_by_email(email)
    except Exception as e:
        logger.warning(f"⚠ Error fetching user: {e}")
        return in_memory_storage.get_user_by_email(email)

def get_user_by_id(user_id):
    """Get user by ID - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return db.session.get(User, user_id)
        else:
            return in_memory_storage.get_user_by_id(user_id)
    except Exception as e:
        logger.warning(f"⚠ Error fetching user by ID: {e}")
        return in_memory_storage.get_user_by_id(user_id)

def init_models(db):
    """Initialize and return all database models"""
    from backend.auth.auth_models import User
    
    # Return a dictionary of models
    # For now, only User model exists - others would be added here
    return {
        'User': User,
        'AzureIntegration': None,  # Placeholder
        'SharePointIntegration': None,  # Placeholder
        'AIInteraction': None,  # Placeholder
        'StorageFile': None,  # Placeholder
        'SplunkQuery': None  # Placeholder
    }

def create_user(email, name, password):
    """Create user - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            user = User(email=email, name=name, is_active=True)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return user
        else:
            password_hash = hash_password(password)
            return in_memory_storage.create_user(email, name, password_hash)
    except Exception as e:
        logger.error(f"✗ Error creating user: {e}")
        if DATABASE_MODE == 'available':
            try:
                db.session.rollback()
            except:
                pass
        password_hash = hash_password(password)
        return in_memory_storage.create_user(email, name, password_hash)

def verify_user_password(user, password):
    """Verify user password - database or in-memory"""
    try:
        if DATABASE_MODE == 'available' and User:
            return user.check_password(password)
        else:
            return verify_password(user['password_hash'], password)
    except Exception as e:
        logger.warning(f"⚠ Error verifying password: {e}")
        return False

# ============================================================================
# APPLICATION FACTORY
# ============================================================================

def create_app(config_name='development'):
    """Create and configure Flask application"""
    
    global db_connector, ai_connector, storage_connector, sharepoint_connector, openai_client
    global User, AzureIntegration, SharePointIntegration, AIInteraction, StorageFile, SplunkQuery
    global DATABASE_MODE
    
    try:
        BACKEND_DIR = os.path.abspath(os.path.dirname(__file__))
        FRONTEND_DIR = os.path.join(PROJECT_ROOT, 'frontend')
        
        logger.info(f"✓ Backend directory: {BACKEND_DIR}")
        logger.info(f"✓ Project root: {PROJECT_ROOT}")
        logger.info(f"✓ Frontend directory: {FRONTEND_DIR}")
        
        if not os.path.exists(FRONTEND_DIR):
            logger.warning(f"⚠ Frontend folder not found at: {FRONTEND_DIR}")
        else:
            logger.info(f"✓ Frontend folder verified!")
        
        app = Flask(
            __name__,
            template_folder=FRONTEND_DIR,
            static_folder=os.path.join(FRONTEND_DIR, 'assets'),
            static_url_path='/assets'
        )
        
        # ====================================================================
        # LOAD CONFIG FROM config.py
        # ====================================================================
        try:
            from config import get_config
            cfg = get_config(config_name)
            app.config.from_object(cfg)
            logger.info("✓ Config loaded from config.py")
            logger.info(f"  Database: {cfg.DB_HOST}:{cfg.DB_PORT}/{cfg.DB_NAME}")
            logger.info(f"  Azure OpenAI: {bool(cfg.AZURE_OPENAI_API_KEY)}")
        except Exception as config_err:
            logger.warning(f"⚠ Config loading error: {config_err}")

        # ====================================================================
        # DATABASE INITIALIZATION (ENHANCED FOR HYBRID RAG)
        # ====================================================================
        
        db_initialized = False
        
        if DB_AVAILABLE:
            try:
                logger.info("🔌 Initializing Database Connector for Hybrid RAG...")
                
                # CRITICAL: Get database connector (reads from .env now)
                db_connector = get_database_connector() if get_database_connector else None
                
                if db_connector:
                    logger.info(f"✓ Database Connector created")
                    logger.info(f"  Host: {db_connector.db_host}:{db_connector.db_port}")
                    logger.info(f"  Database: {db_connector.db_name}")
                    
                    conn_test = db_connector.test_connection()
                    if conn_test.get('connected'):
                        logger.info(f"✓ Database connection verified: {conn_test.get('version', 'Unknown version')}")
                        
                        try:
                            from sqlalchemy import text
                            with app.app_context() if hasattr(app, 'app_context') else contextlib.nullcontext():
                                result = db.session.execute(text("SELECT extname FROM pg_extension WHERE extname = 'vector'"))
                                has_pgvector = result.fetchone() is not None
                                if has_pgvector:
                                    logger.info("✓ pgvector extension detected - Hybrid RAG ready!")
                                else:
                                    logger.warning("⚠ pgvector not found - Run: CREATE EXTENSION vector;")
                        except:
                            logger.info("ℹ pgvector check skipped (will verify during setup)")
                        
                        db_initialized = True
                    else:
                        logger.warning(f"⚠ Database connection test failed: {conn_test.get('error', 'Unknown error')}")
                else:
                    logger.warning("⚠ Database connector not available")
            
            except Exception as db_init_err:
                logger.warning(f"⚠ Database connector initialization warning: {db_init_err}")
        else:
            logger.warning("⚠ Database models not available - using in-memory storage")
        
        # ====================================================================
        # CONFIGURE FLASK - CORE SETTINGS
        # ====================================================================
        
        if db_initialized and db_connector:
            try:
                db_config = db_connector.get_sqlalchemy_config()
                for key, value in db_config.items():
                    app.config[key] = value
                logger.info("✓ SQLAlchemy configuration applied")
            except Exception as db_config_err:
                logger.warning(f"⚠ Database configuration error: {db_config_err}")
                db_initialized = False
        
        if not db_initialized:
            # Use persistent SQLite file instead of in-memory database
            app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
            app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
            logger.warning("⚠ Using SQLite fallback database (app.db)")
    
        # ====================================================================
        # SESSION CONFIGURATION ✅ CRITICAL FOR DASHBOARD ACCESS
        # ====================================================================

        FLASK_SECRET = os.getenv('FLASK_SECRET_KEY') or os.getenv('SECRET_KEY') or 'dev-secret-key-change-in-production'

        # Log what we're using (for debugging)
        logger.info(f"🔑 SECRET_KEY source: {'FLASK_SECRET_KEY env' if os.getenv('FLASK_SECRET_KEY') else 'SECRET_KEY env' if os.getenv('SECRET_KEY') else 'FALLBACK (insecure!)'}")
        logger.info(f"🔑 SECRET_KEY length: {len(FLASK_SECRET)}")

        # ✅ Set BOTH to the SAME value - DO NOT SET AGAIN ANYWHERE ELSE!
        app.config['SECRET_KEY'] = FLASK_SECRET
        app.secret_key = FLASK_SECRET

        app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
        app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

        # Session cookie settings
        app.config['SESSION_COOKIE_SECURE'] = False  # False for localhost (HTTP)
        app.config['SESSION_COOKIE_HTTPONLY'] = True
        app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
        app.config['SESSION_COOKIE_NAME'] = 'session'
        app.config['SESSION_REFRESH_EACH_REQUEST'] = True

        logger.info("✓ Flask Session configuration applied")
        
        # ====================================================================
        # INITIALIZE EXTENSIONS
        # ====================================================================
        
        try:
            if DB_AVAILABLE and db is not None:
                db.init_app(app)
                
                # Initialize auth_db if available
                if AUTH_AVAILABLE and auth_db is not None:
                    auth_db.init_app(app)
                    logger.info("✓ Authentication database initialized")
                
                # ✅ CORS configuration (works for both authenticated and public endpoints)
                CORS(app,
                    allow_headers=["Content-Type", "Authorization"],
                    origins=["http://localhost:8000", "http://127.0.0.1:8000"],
                    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
                    supports_credentials=True)  # Allow requests without credentials (chat page doesn't need auth)

                logger.info("✓ Flask extensions initialized")
                logger.info("✓ CORS configuration applied:")
                logger.info("  - Credentials support: OPTIONAL (allows both authenticated and public requests)")
                logger.info("  - Allowed origins: http://localhost:8000, http://127.0.0.1:8000")
                
                with app.app_context():
                    try:
                        from backend.auth.auth_models import User
                        globals()['User'] = User
                        globals()['AzureIntegration'] = None
                        globals()['SharePointIntegration'] = None
                        globals()['AIInteraction'] = None
                        globals()['StorageFile'] = None
                        globals()['SplunkQuery'] = None
                        
                        db.create_all()
                        logger.info("✓ Database tables created/verified successfully")
                        DATABASE_MODE = 'available'
                        
                        demo_email = 'demo@example.com'
                        existing_user = User.query.filter_by(email=demo_email).first()
                        if not existing_user:
                            demo_user = User(email=demo_email, name='Demo User', is_active=True)
                            demo_user.set_password('demo123')
                            db.session.add(demo_user)
                            db.session.commit()
                            logger.info(f"✓ Demo user created: {demo_email} / demo123")
                        
                    except Exception as models_err:
                        logger.warning(f"⚠ Models initialization error: {models_err}")
                        DATABASE_MODE = 'unavailable'
                        in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
            else:
                # ✅ NO CORS HERE - Already initialized above
                DATABASE_MODE = 'unavailable'
                logger.info("⚠ Using in-memory storage mode")
                logger.info("✓ CORS configuration applied:")
                logger.info("  - Credentials support: OPTIONAL (allows both authenticated and public requests)")
                in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
        except Exception as ext_err:
            logger.warning(f"⚠ Extension initialization warning: {ext_err}")

            DATABASE_MODE = 'unavailable'
            logger.info("✓ CORS configuration applied:")
            logger.info("  - Credentials support: OPTIONAL (allows both authenticated and public requests)")
            try:
                in_memory_storage.create_user('demo@example.com', 'Demo User', hash_password('demo123'))
            except:
                pass
        
        # ====================================================================
        # INITIALIZE HYBRID RAG SERVICES
        # ====================================================================
        
        if HYBRID_RAG_SERVICES_AVAILABLE:
            try:
                logger.info("🧠 Initializing Hybrid RAG Services...")
                
                try:
                    init_db()
                    logger.info("✓ Hybrid RAG database initialized")
                except Exception as rag_db_err:
                    logger.warning(f"⚠ RAG database initialization: {rag_db_err}")
                
                try:
                    rag_health = check_db_health()
                    if rag_health.get('status') == 'healthy':
                        logger.info("✓ Hybrid RAG database health: OK")
                    else:
                        logger.warning(f"⚠ Hybrid RAG health: {rag_health.get('status')}")
                except Exception as rag_health_err:
                    logger.warning(f"⚠ RAG health check: {rag_health_err}")
                
            except Exception as rag_init_err:
                logger.warning(f"⚠ Hybrid RAG services warning: {rag_init_err}")
        
        # ====================================================================
        # INITIALIZE AZURE OPENAI CLIENT ✅ NEW - CRITICAL FIX
        # ====================================================================
        
        try:
            logger.info("🤖 Creating Azure OpenAI Client for Hybrid RAG...")
            from openai import AzureOpenAI
            
            # Check if we have required credentials
            if (app.config.get('AZURE_OPENAI_API_KEY') and 
                app.config.get('AZURE_OPENAI_ENDPOINT') and 
                app.config.get('AZURE_OPENAI_DEPLOYMENT')):
                
                try:
                    # Create the Azure OpenAI client
                    openai_client = AzureOpenAI(
                        api_key=app.config['AZURE_OPENAI_API_KEY'],
                        api_version=app.config['AZURE_OPENAI_API_VERSION'],
                        azure_endpoint=app.config['AZURE_OPENAI_ENDPOINT']
                    )
                    
                    logger.info(f"✅ Azure OpenAI client created successfully!")
                    logger.info(f"   📝 Deployment: {app.config['AZURE_OPENAI_DEPLOYMENT']}")
                    logger.info(f"   🔗 API Version: {app.config['AZURE_OPENAI_API_VERSION']}")
                    logger.info(f"   🌐 Endpoint: {app.config['AZURE_OPENAI_ENDPOINT'][:50]}...")
                    
                    # Store in app.extensions for later use in routes
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['openai_client'] = openai_client
                    
                except Exception as client_create_err:
                    logger.error(f"❌ Failed to create OpenAI client: {client_create_err}")
                    logger.error(f"   💡 Check your Azure credentials:")
                    logger.error(f"      - AZURE_OPENAI_API_KEY")
                    logger.error(f"      - AZURE_OPENAI_ENDPOINT")
                    logger.error(f"      - AZURE_OPENAI_DEPLOYMENT")
                    openai_client = None
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['openai_client'] = None
            else:
                logger.warning("⚠️  Missing Azure OpenAI credentials in config!")
                logger.warning(f"   ❌ AZURE_OPENAI_API_KEY: {bool(app.config.get('AZURE_OPENAI_API_KEY'))}")
                logger.warning(f"   ❌ AZURE_OPENAI_ENDPOINT: {bool(app.config.get('AZURE_OPENAI_ENDPOINT'))}")
                logger.warning(f"   ❌ AZURE_OPENAI_DEPLOYMENT: {bool(app.config.get('AZURE_OPENAI_DEPLOYMENT'))}")
                logger.warning(f"   💡 Add to .env file:")
                logger.warning(f"      AZURE_OPENAI_API_KEY=your-key")
                logger.warning(f"      AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/")
                logger.warning(f"      AZURE_OPENAI_DEPLOYMENT=gpt-35-turbo")
                openai_client = None
                if not hasattr(app, 'extensions'):
                    app.extensions = {}
                app.extensions['openai_client'] = None

        except ImportError as import_err:
            logger.error(f"❌ OpenAI SDK not installed!")
            logger.error(f"   💡 Run: pip install openai")
            openai_client = None
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['openai_client'] = None
        except Exception as openai_init_err:
            logger.error(f"❌ Unexpected error initializing OpenAI: {openai_init_err}")
            import traceback
            logger.error(traceback.format_exc())
            openai_client = None
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['openai_client'] = None
        
        # ====================================================================
        # INITIALIZE AZURE OPENAI CONNECTOR ✅ PRODUCTION-READY
        # ====================================================================

        try:
            logger.info("🤖 Initializing Azure OpenAI Connector...")
            
            # Use the production-ready connector with proper validation
            if get_azure_openai_connector:
                ai_connector = get_azure_openai_connector(config=app.config)
                
                if ai_connector and ai_connector.is_available():
                    # Test the connection
                    test_result = ai_connector.test_connection()
                    
                    if test_result.get('status') == 'success':
                        logger.info("✅ Azure OpenAI Connector initialized and tested!")
                        logger.info(f"   🤖 Model: {ai_connector.deployment}")
                        logger.info(f"   📊 Max Tokens: {ai_connector.max_tokens}")
                        logger.info(f"   🌡️  Temperature: {'Supported' if ai_connector.model_config['supports_temperature'] else 'Fixed at 1.0'}")
                        
                        # Store in app.extensions
                        if not hasattr(app, 'extensions'):
                            app.extensions = {}
                        app.extensions['azure_openai_connector'] = ai_connector
                    else:
                        logger.warning(f"⚠ Azure OpenAI test failed: {test_result.get('message')}")
                        logger.warning(f"   💡 Missing or invalid credentials")
                        if not hasattr(app, 'extensions'):
                            app.extensions = {}
                        app.extensions['azure_openai_connector'] = None
                else:
                    logger.warning("⚠ Azure OpenAI Connector not available")
                    logger.warning(f"   Add to .env:")
                    logger.warning(f"   - AZURE_OPENAI_API_KEY")
                    logger.warning(f"   - AZURE_OPENAI_ENDPOINT")
                    logger.warning(f"   - AZURE_OPENAI_DEPLOYMENT")
                    if not hasattr(app, 'extensions'):
                        app.extensions = {}
                    app.extensions['azure_openai_connector'] = None
            else:
                logger.warning("⚠ Azure OpenAI connector module not found")
                if not hasattr(app, 'extensions'):
                    app.extensions = {}
                app.extensions['azure_openai_connector'] = None

        except Exception as openai_init_err:
            logger.warning(f"⚠ Azure OpenAI initialization: {openai_init_err}")
            if not hasattr(app, 'extensions'):
                app.extensions = {}
            app.extensions['azure_openai_connector'] = None

        
        try:
            logger.info("💾 Initializing Azure Storage Connector...")
            storage_connector = get_azure_storage_connector() if get_azure_storage_connector else None
            if storage_connector:
                try:
                    storage_health = storage_connector.health_check()
                    if storage_health.get('status') == 'healthy':
                        logger.info("✓ Azure Storage service verified")
                except:
                    logger.warning("⚠ Azure Storage health check failed")
            else:
                logger.warning("⚠ Azure Storage connector not available - Storage features disabled")
        except Exception as storage_init_err:
            logger.warning(f"⚠ Azure Storage connector initialization warning: {storage_init_err}")
        
        try:
            logger.info("📄 Initializing SharePoint Connector...")
            sharepoint_connector = get_sharepoint_connector() if get_sharepoint_connector else None
            if sharepoint_connector:
                try:
                    sp_health = sharepoint_connector.health_check()
                    if sp_health.get('status') == 'healthy':
                        logger.info("✓ SharePoint service verified")
                except:
                    logger.warning("⚠ SharePoint health check failed")
            else:
                logger.warning("⚠ SharePoint connector not available - SharePoint features disabled")
        except Exception as sp_init_err:
            logger.warning(f"⚠ SharePoint connector initialization warning: {sp_init_err}")
        
        # ====================================================================
        # REGISTER BLUEPRINTS - AUTHENTICATION FIRST
        # ====================================================================
        
        # Register Authentication Blueprint FIRST
        if AUTH_AVAILABLE and auth_bp:
            try:
                app.register_blueprint(auth_bp)
                logger.info("✓ Professional Authentication blueprint registered")
                logger.info("  JWT tokens enabled")
                logger.info("  Endpoints:")
                logger.info("    POST /api/auth/register - User registration")
                logger.info("    POST /api/auth/login - User login (JWT)")
                logger.info("    POST /api/auth/logout - User logout")
                logger.info("    GET /api/auth/me - Get current user")
                logger.info("    POST /api/auth/forgot-password - Password reset")
                logger.info("    POST /api/auth/change-password - Change password")
                logger.info("    PUT /api/auth/update-profile - Update user profile")
            except Exception as auth_reg_err:
                logger.warning(f"⚠ Failed to register auth blueprint: {auth_reg_err}")
        else:
            logger.warning("⚠ Professional authentication not available - using basic auth")

        # ====================================================================
        # REGISTER ADMIN BLUEPRINT (Right after Auth)
        # ====================================================================
        # ====================================================================
        # REGISTER ADMIN BLUEPRINT (Right after Auth) - WITH DETAILED LOGGING
        # ====================================================================
        logger.info("\n" + "="*80)
        logger.info("REGISTERING ADMIN BLUEPRINT")
        logger.info("="*80)
        
        admin_bp_imported = None
        import_error_msg = None
        
        try:
            logger.info("Step 1: Importing admin_bp from backend.routes.admin_routes...")
            from backend.routes.admin_routes import admin_bp as admin_routes_bp
            admin_bp_imported = admin_routes_bp
            logger.info(f"✅ Import successful!")
            logger.info(f"   admin_bp type: {type(admin_bp_imported)}")
            logger.info(f"   admin_bp name: {admin_bp_imported.name if hasattr(admin_bp_imported, 'name') else 'N/A'}")
            
        except ImportError as import_err:
            import_error_msg = f"ImportError: {import_err}"
            logger.error(f"❌ Import failed (ImportError): {import_err}")
            import traceback
            logger.error(traceback.format_exc())
            
        except Exception as import_err:
            import_error_msg = f"{type(import_err).__name__}: {import_err}"
            logger.error(f"❌ Import failed ({type(import_err).__name__}): {import_err}")
            import traceback
            logger.error(traceback.format_exc())
        
        # Step 2: Check if import was successful
        if admin_bp_imported is None:
            logger.error(f"\n❌ FAILED TO IMPORT ADMIN BLUEPRINT")
            logger.error(f"   Error: {import_error_msg}")
            logger.error(f"\n   Troubleshooting:")
            logger.error(f"   1. Check file exists: backend/routes/admin_routes.py")
            logger.error(f"   2. Check file has: admin_bp = Blueprint('admin', ...)")
            logger.error(f"   3. Check no syntax errors in admin_routes.py")
            logger.error(f"   4. Restart Flask server")
            logger.error("="*80 + "\n")
        else:
            # Step 3: Register the blueprint
            try:
                logger.info(f"\nStep 2: Registering blueprint with app...")
                app.register_blueprint(admin_bp_imported)
                logger.info(f"✅ Blueprint registered successfully!")
                
                # Step 4: Verify routes were registered
                logger.info(f"\nStep 3: Verifying routes...")
                admin_routes = [rule for rule in app.url_map.iter_rules() if '/api/admin' in str(rule)]
                logger.info(f"✅ Found {len(admin_routes)} admin routes:")
                for route in admin_routes:
                    logger.info(f"   - {route.rule} ({', '.join(sorted(route.methods - {'HEAD', 'OPTIONS'}))})")
                
                if len(admin_routes) == 0:
                    logger.warning(f"⚠️  WARNING: No routes found after registration!")
                
                logger.info("\n" + "="*80)
                logger.info("✅ ADMIN BLUEPRINT REGISTRATION COMPLETE")
                logger.info("="*80)
                logger.info("🔐 Available Admin Endpoints:")
                logger.info("   GET /api/admin/health - Health check (no auth)")
                logger.info("   GET /api/admin/users - List all users (admin only)")
                logger.info("   DELETE /api/admin/users/<id> - Delete user (admin only)")
                logger.info("   POST /api/admin/users/<id>/activate - Activate user (admin only)")
                logger.info("   POST /api/admin/users/<id>/deactivate - Deactivate user (admin only)")
                logger.info("   GET /api/admin/settings - View settings (admin only)")
                logger.info("   GET /api/admin/system-info - System info (admin only)")
                logger.info("   GET /api/admin/stats - Statistics (admin only)")
                logger.info("="*80 + "\n")
                
            except Exception as register_err:
                logger.error(f"\n❌ FAILED TO REGISTER BLUEPRINT")
                logger.error(f"   Error: {register_err}")
                logger.error(f"   Error type: {type(register_err).__name__}")
                import traceback
                logger.error(traceback.format_exc())
                logger.error("="*80 + "\n")
        
        # ====================================================================
        # REGISTER SPLUNK BLUEPRINT
        # ====================================================================

        try:
            from backend.routes.splunk import splunk_bp
            app.register_blueprint(splunk_bp)
            logger.info("✓ Splunk routes blueprint registered")
            logger.info("  📊 Splunk API Endpoints:")
            logger.info("     - POST /api/splunk/search - Execute search query")
            logger.info("     - POST /api/splunk/search/stats - Statistics aggregations")
            logger.info("     - POST /api/splunk/search/timechart - Time-series data")
            logger.info("     - POST /api/splunk/analytics/top-events - Top events analysis")
            logger.info("     - POST /api/splunk/analytics/index-stats - Index statistics")
            logger.info("     - GET /api/splunk/health - Service health")
            logger.info("     - GET /api/splunk/status - Connector status")
            logger.info("     - POST /api/splunk/test - Test connection")
        except ImportError as splunk_import_err:
            logger.warning(f"⚠ Splunk routes not found: {splunk_import_err}")
        except Exception as splunk_reg_err:
            logger.warning(f"⚠ Failed to register Splunk blueprint: {splunk_reg_err}")

        
        # ====================================================================
        # REGISTER DATABASE BLUEPRINT
        # ====================================================================

        try:
            from backend.routes.generic_db_routes import db_bp
            app.register_blueprint(db_bp)
            logger.info("✓ Generic database API blueprint registered")
            logger.info("  📊 Endpoints:")
            logger.info("     - POST /api/db/aggregate - Aggregation queries (GROUP BY)")
            logger.info("     - POST /api/db/aggregate/chart - Chart.js formatted aggregation")
            logger.info("     - POST /api/db/stats - Statistical queries")
            logger.info("     - POST /api/db/records - Fetch records with filtering")
            logger.info("     - POST /api/db/query - Raw SQL queries (with validation)")
            logger.info("     - GET /api/db/health - Service health check")
        except Exception as db_reg_err:
            logger.warning(f"⚠ Failed to register database blueprint: {db_reg_err}")


        # ====================================================================
        # REGISTER SHAREPOINT BLUEPRINT
        # ====================================================================

        try:
            from backend.routes.sharepoint import sharepoint_bp
            app.register_blueprint(sharepoint_bp)
            logger.info("✓ SharePoint routes blueprint registered")
            logger.info("  📄 SharePoint API Endpoints (GET-Only - Read-Only Access):")
            logger.info("     - GET /api/sharepoint/health")
            logger.info("     - GET /api/sharepoint/site-info")
            logger.info("     - GET /api/sharepoint/statistics")
            logger.info("     - GET /api/sharepoint/libraries")
            logger.info("     - GET /api/sharepoint/documents/<lib_id>")
            logger.info("     - GET /api/sharepoint/download/<lib_id>/<item_id>")
            logger.info("     - GET /api/sharepoint/search")
            logger.info("     - GET /api/sharepoint/lists")
            logger.info("  🔒 Security: Read-only access only (upload/delete disabled)")
        except ImportError as sharepoint_import_err:
            logger.warning(f"⚠ SharePoint routes not found: {sharepoint_import_err}")
        except Exception as sharepoint_reg_err:
            logger.warning(f"⚠ Failed to register SharePoint blueprint: {sharepoint_reg_err}")


        # ====================================================================
        # INTERFACES ROUTES (CRUD + Embedding Regeneration)
        # ====================================================================

        try:
            from backend.routes.interfaces import interfaces_bp
            app.register_blueprint(interfaces_bp)
            logger.info("✓ Interfaces routes blueprint registered")
            logger.info("  📄 Interfaces API Endpoints:")
            logger.info("     - GET /api/interfaces - List all interfaces")
            logger.info("     - GET /api/interfaces/<id> - Get single interface")
            logger.info("     - PUT /api/interfaces/<id> - Update interface (admin)")
            logger.info("     - DELETE /api/interfaces/<id> - Delete interface (admin)")
            logger.info("     - POST /api/interfaces/<id>/regenerate-embedding - Regenerate embedding")
            logger.info("  🧠 Feature: Automatic embedding regeneration on update")
        except ImportError as interfaces_import_err:
            logger.warning(f"⚠ Interfaces routes not found: {interfaces_import_err}")
        except Exception as interfaces_reg_err:
            logger.warning(f"⚠ Failed to register Interfaces blueprint: {interfaces_reg_err}")


        # Register Chat Blueprint
        if CHATBOT_AVAILABLE and chat_bp:
            try:
                app.register_blueprint(chat_bp)
                
                if HYBRID_RAG_AVAILABLE:
                    logger.info("✓ Hybrid RAG Chat blueprint registered")
                    logger.info("  🧠 Features: Intelligent Routing + pgvector + SQL Generation")
                    logger.info("  📍 Endpoints:")
                    logger.info("     - POST /chat/upload - Import Excel → PostgreSQL + Embeddings")
                    logger.info("     - POST /chat/send_message - Intelligent query processing")
                    logger.info("     - GET /chat/stats - Data statistics")
                    logger.info("     - GET /chat/health - System health check")
                else:
                    logger.info("✓ Standard chat blueprint registered")
                    logger.info("  Available at: /chat")
            
            except Exception as chat_reg_err:
                logger.warning(f"⚠ Failed to register chat blueprint: {chat_reg_err}")
        else:
            logger.warning("⚠ Chat blueprint not registered - feature unavailable")
        
        # ====================================================================
        # FRONTEND ROUTES
        # ====================================================================
        
        @app.route('/')
        def index():
            try:
                if 'user_id' in session:
                    return redirect(url_for('dashboard'))
                try:
                    return render_template('index.html')
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    index_path = os.path.join(FRONTEND_DIR, 'index.html')
                    if os.path.exists(index_path):
                        with open(index_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Index page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering index page: {e}")
                return jsonify({'error': 'Failed to load index page'}), 500

        @app.route('/health')
        def health():
            """Health check endpoint for Azure Web App"""
            return jsonify({'status': 'healthy', 'service': '360 Enterprise Dashboard', 'version': '1.0.0'}), 200

        @app.route('/login')
        def login_page():
            try:
                # Check if this is a logout redirect (force clear session)
                logout_redirect = request.args.get('logout') == 'true'
                if logout_redirect:
                    logger.info("🔓 Logout redirect detected - clearing session")
                    session.clear()

                # Only redirect to dashboard if there's an active session AND not from logout
                if 'user_id' in session and not logout_redirect:
                    return redirect(url_for('dashboard'))

                try:
                    return render_template('auth/login.html')
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    login_path = os.path.join(FRONTEND_DIR, 'auth', 'login.html')
                    if os.path.exists(login_path):
                        with open(login_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Login page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering login page: {e}")
                return jsonify({'error': 'Failed to load login page'}), 500
            
        @app.route('/api/debug/login-test', methods=['POST'])
        def login_test():
            """
            ✅ Test endpoint to verify Set-Cookie header is included
            POST /api/debug/login-test
            Body: {"email": "user@example.com", "password": "SecurePass123"}
            
            Returns the exact response headers that will be sent
            """
            from flask import make_response
            
            try:
                data = request.get_json()
                email = data.get('email')
                password = data.get('password')
                
                logger.info(f"🧪 Testing login with email: {email}")
                
                # Simulate what happens in login endpoint
                test_response_data = {
                    'success': True,
                    'message': 'Test response',
                    'data': {
                        'token': 'test-token-123',
                        'user': {
                            'id': 1,
                            'email': email,
                            'name': 'Test User'
                        }
                    }
                }
                
                # Create response
                response = make_response(jsonify(test_response_data), 200)
                
                # Set session (this should trigger Set-Cookie)
                session['user_id'] = 1
                session['user_email'] = email
                session.permanent = True
                session.modified = True
                
                logger.info(f"📝 Session set in test endpoint")
                logger.info(f"   Session keys: {list(session.keys())}")
                logger.info(f"   Session permanent: {session.permanent}")
                
                return jsonify({
                    'debug': True,
                    'message': 'Check response headers for Set-Cookie',
                    'response_headers': {
                        'Content-Type': response.headers.get('Content-Type'),
                        'Set-Cookie': response.headers.get('Set-Cookie'),
                        'All-Headers': dict(response.headers)
                    },
                    'session_info': {
                        'user_id': session.get('user_id'),
                        'user_email': session.get('user_email'),
                        'session_keys': list(session.keys())
                    }
                }), 200
                
            except Exception as e:
                logger.error(f"Test error: {e}")
                return jsonify({'error': str(e)}), 500
        
        @app.route('/dashboard')
        def dashboard():
            """
            ✅ Dashboard route - JWT-first authentication
            1. Renders dashboard page even without Flask session
            2. JavaScript checks for JWT token in localStorage
            3. If JWT exists, calls /api/auth/me to establish Flask session
            4. If no JWT, JavaScript redirects to login

            This prevents redirect loops when user has valid JWT but no session yet
            """
            try:
                # ✅ CHANGED: Don't check Flask session here
                # Let JavaScript handle authentication via JWT token
                # This prevents redirect loop after login

                # If user has Flask session, use it to get user data
                user = None
                if 'user_id' in session:
                    logger.info(f"✅ Flask session found for user_id={session['user_id']}")
                    user = get_user_by_id(session['user_id'])

                    if not user:
                        logger.warning(f"❌ User not found for session user_id={session['user_id']}")
                        session.clear()
                else:
                    logger.info(f"⚠️ No Flask session - JavaScript will establish it via JWT token")
                
                azure_integrations = []
                sharepoint_integrations = []
                
                if DATABASE_MODE == 'available':
                    try:
                        azure_integrations = AzureIntegration.query.filter_by(user_id=user.id).all()
                    except:
                        pass
                    
                    try:
                        sharepoint_integrations = SharePointIntegration.query.filter_by(user_id=user.id).all()
                    except:
                        pass
                
                try:
                    return render_template('dashboard_overview/index.html', 
                                         user=user,
                                         azure_integrations=azure_integrations,
                                         sharepoint_integrations=sharepoint_integrations,
                                         azure_count=len(azure_integrations),
                                         sharepoint_count=len(sharepoint_integrations))
                except Exception as template_err:
                    logger.warning(f"⚠ Template rendering failed: {template_err}")
                    dashboard_path = os.path.join(FRONTEND_DIR, 'dashboard_overview', 'index.html')
                    if os.path.exists(dashboard_path):
                        with open(dashboard_path, 'r', encoding='utf-8') as f:
                            return f.read()
                    return jsonify({'error': 'Dashboard page not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error rendering dashboard: {e}")
                return jsonify({'error': 'Failed to load dashboard'}), 500
        
        # ====================================================================
        # ROUTES - FACTORY PATTERN
        # ====================================================================
        
        def create_route(route_path, template_path, page_title, prefix):
            """Factory function to create routes"""
            def route_handler():
                try:
                    user = get_user_by_id(session['user_id'])
                    try:
                        return render_template(template_path, user=user, page_title=page_title)
                    except Exception as template_err:
                        logger.warning(f"⚠ Template {template_path} not found via render_template: {template_err}")
                        
                        template_parts = template_path.split('/')
                        template_file = os.path.join(FRONTEND_DIR, *template_parts)
                        
                        if os.path.exists(template_file):
                            with open(template_file, 'r', encoding='utf-8') as f:
                                return f.read()
                        else:
                            return jsonify({
                                'error': f'Template not found: {template_path}',
                                'path': template_file
                            }), 404
                            
                except Exception as e:
                    logger.error(f"✗ Error rendering {page_title} page: {e}")
                    return jsonify({'error': f'Failed to load page: {str(e)}'}), 500
            
            unique_name = f'{prefix}_{route_path.replace("/", "_").replace("-", "_")}'
            route_handler.__name__ = unique_name
            route_handler = login_required(route_handler)
            app.add_url_rule(route_path, unique_name, route_handler)
        
        # Integration routes
        integration_routes = [
            ('/integrations/azure/apim', 'integrations/azure/apim.html', 'Azure API Management'),
            ('/integrations/azure/storage', 'integrations/azure/storage.html', 'Azure File Storage'),
            ('/integrations/azure/openai', 'integrations/azure/openai.html', 'Azure OpenAI'),
            ('/integrations/azure/postgresql', 'integrations/azure/postgresql.html', 'Azure PostgreSQL'),
            ('/integrations/mft', 'integrations/mft.html', 'Managed File Transfer'),
            ('/integrations/sap-cpi', 'integrations/sap-cpi.html', 'SAP Cloud Platform Integration'),
            ('/integrations/ibm-api-connect', 'integrations/ibm-api-connect.html', 'IBM API Connect'),
            ('/integrations/ibm-datapower', 'integrations/ibm-datapower.html', 'IBM DataPower'),
            ('/integrations/splunk', 'integrations/splunk.html', 'Splunk'),
            ('/integrations/sharepoint', 'integrations/sharepoint.html', 'SharePoint'),
            ('/integrations/api-gateway', 'integrations/api-gateway.html', 'API Gateway'),
            ('/integrations/excel', 'integrations/excel.html', 'Excel'),
        ]
        
        for route, template, title in integration_routes:
            create_route(route, template, title, 'integration')
        
        # Chat route
        chat_routes = [
            ('/chat', 'chat/chat.html', 'Chat'),
        ]
        
        for route, template, title in chat_routes:
            create_route(route, template, title, 'chat')
        
        # Data management routes
        data_routes = [
            ('/data-management/import', 'data_management/import.html', 'Import Data'),
            ('/data-management/tables', 'data_management/tables.html', 'Data Tables'),
            ('/data-management/sync-history', 'data_management/sync-history.html', 'Sync History'),
            ('/data-management/rag-analytics', 'data_management/rag-analytics.html', 'RAG Analytics'),
        ]

        for route, template, title in data_routes:
            create_route(route, template, title, 'data')

        # Services routes
        services_routes = [
            ('/services/system-health', 'services_monitoring/system-health.html', 'System Health'),
            ('/services/splunk-report', 'services_monitoring/splunk_report.html', 'Splunk Report Builder'),
            ('/services/analytics', 'services_monitoring/services-analytics.html', 'Services Analytics'),
            ('/services/security', 'services_monitoring/security.html', 'Security'),
        ]
        
        for route, template, title in services_routes:
            create_route(route, template, title, 'service')
        
        # Resources routes
        resources_routes = [
            ('/resources/videos', 'resources/videos.html', 'Video Guides'),
            ('/resources/documentation', 'resources/documentation.html', 'Documentation'),
            ('/resources/faq', 'resources/faq.html', 'FAQ'),
            ('/resources/support', 'resources/support.html', 'Support'),
        ]
        
        for route, template, title in resources_routes:
            create_route(route, template, title, 'resource')
        
        # Account routes
        @app.route('/profile')
        @hybrid_login_required
        def profile():
            try:
                user_id = session.get('user_id')
                logger.info(f"📋 Profile route - Looking up user_id={user_id}")
                
                user = get_user_by_id(user_id)
                
                logger.info(f"📋 Profile route - User lookup result: {user}")
                logger.info(f"📋 Profile route - DATABASE_MODE: {DATABASE_MODE}")
                
                # ✅ FALLBACK: If database unavailable, create user object from session
                if not user and session.get('user_email'):
                    logger.info(f"📋 Profile route - Using session data as fallback")
                    user = {
                        'id': session.get('user_id'),
                        'email': session.get('user_email'),
                        'name': session.get('user_name', 'User'),
                        'is_active': True,
                        'created_at': None,
                        'last_login': None
                    }
                
                if not user:
                    logger.warning(f"❌ Profile route - User NOT FOUND for user_id={user_id}")
                    session.clear()
                    return redirect(url_for('login_page'))
                    
                logger.info(f"✅ Profile route - Rendering for user: {user.email if hasattr(user, 'email') else user.get('email')}")
                return render_template('auth/profile.html', user=user, page_title='Profile')
            except Exception as e:
                logger.error(f"✗ Error rendering profile page: {e}", exc_info=True)
                return jsonify({'error': 'Failed to load page'}), 500


        @app.route('/admin')
        @hybrid_login_required
        def admin():
            try:
                user = get_user_by_id(session['user_id'])

                # ✅ FALLBACK: If database unavailable, create user object from session
                if not user and session.get('user_email'):
                    user = {
                        'id': session.get('user_id'),
                        'email': session.get('user_email'),
                        'name': session.get('user_name', 'User'),
                        'is_active': True
                    }

                if not user:
                    session.clear()
                    return redirect(url_for('login_page'))

                user_id = user.get('id') if isinstance(user, dict) else user.id
                user_email = user.get('email') if isinstance(user, dict) else user.email

                # Check admin access using RBAC system first, then fallback to legacy check
                is_admin = False
                try:
                    from backend.auth.auth import get_user_roles
                    user_roles, _ = get_user_roles(user_id)
                    is_admin = 'admin' in user_roles
                    logger.info(f"RBAC check for {user_email}: roles={user_roles}, is_admin={is_admin}")
                except Exception as rbac_err:
                    logger.warning(f"RBAC check failed, using legacy: {rbac_err}")
                    # Fallback to legacy check
                    is_admin = (user_id == 1 or user_email.endswith('@admin.com'))

                if not is_admin:
                    logger.warning(f"❌ Admin access denied for user: {user_email}")
                    # Return a proper access denied page
                    return render_template('errors/access_denied.html',
                                         user=user,
                                         message='Admin access required',
                                         contact_message='Please contact your system administrator to request admin privileges.',
                                         page_title='Access Denied'), 403

                return render_template('admin/admin.html', user=user, page_title='Admin Dashboard')
            except Exception as e:
                logger.error(f"✗ Error rendering admin page: {e}")
                return jsonify({'error': 'Failed to load page'}), 500

  
        @app.route('/settings')
        @hybrid_login_required
        def settings():
            try:
                user = get_user_by_id(session['user_id'])
                
                # ✅ FALLBACK: If database unavailable, create user object from session
                if not user and session.get('user_email'):
                    user = {
                        'id': session.get('user_id'),
                        'email': session.get('user_email'),
                        'name': session.get('user_name', 'User'),
                        'is_active': True
                    }
                
                if not user:
                    session.clear()
                    return redirect(url_for('login_page'))
                return render_template('auth/settings.html', user=user, page_title='Settings')
            except Exception as e:
                logger.error(f"✗ Error rendering settings page: {e}")
                return jsonify({'error': 'Failed to load page'}), 500

        @app.route('/assets/<path:filename>')
        def serve_assets(filename):
            try:
                assets_path = os.path.join(FRONTEND_DIR, 'assets')
                return send_from_directory(assets_path, filename)
            except FileNotFoundError:
                logger.warning(f"⚠ Asset not found: {filename}")
                return jsonify({'error': 'Asset not found'}), 404
            except Exception as e:
                logger.error(f"✗ Error serving asset {filename}: {e}")
                return jsonify({'error': 'Failed to serve asset'}), 500
        
        # ====================================================================
        # API ROUTES
        # ====================================================================
        
        @app.route('/api/debug/auth-state')
        def debug_auth_state():
            """Debug endpoint to check authentication state"""
            try:
                auth_state = {
                    'session': {
                        'has_user_id': 'user_id' in session,
                        'user_id': session.get('user_id'),
                        'user_email': session.get('user_email'),
                        'keys': list(session.keys())
                    },
                    'cookies': {
                        'token': request.cookies.get('token', 'NOT FOUND')[:50] + '...' if request.cookies.get('token') else 'NOT FOUND',
                        'session': 'EXISTS' if request.cookies.get('session') else 'NOT FOUND',
                        'all_cookies': list(request.cookies.keys())
                    },
                    'headers': {
                        'authorization': request.headers.get('Authorization', 'NOT FOUND')[:50] + '...' if request.headers.get('Authorization') else 'NOT FOUND'
                    }
                }
                return jsonify({'success': True, 'data': auth_state}), 200
            except Exception as e:
                return jsonify({'success': False, 'error': str(e)}), 500

        @app.route('/api/debug/models')
        def debug_models():
            """Debug endpoint to check system status"""
            try:
                return jsonify({
                    'database_mode': DATABASE_MODE,
                    'user_model': str(User) if User else 'In-memory storage',
                    'db_available': DATABASE_MODE == 'available',
                    'in_memory_users': len(in_memory_storage.users),
                    'chatbot_available': CHATBOT_AVAILABLE,
                    'hybrid_rag_available': HYBRID_RAG_AVAILABLE,
                    'hybrid_rag_services': HYBRID_RAG_SERVICES_AVAILABLE,
                    'auth_available': AUTH_AVAILABLE,
                    'chat_bp': str(chat_bp) if chat_bp else 'None',
                    'openai_client_available': openai_client is not None,
                    'session_config': {
                        'SECRET_KEY_SET': bool(app.config.get('SECRET_KEY')),
                        'SESSION_COOKIE_HTTPONLY': app.config.get('SESSION_COOKIE_HTTPONLY'),
                        'SESSION_COOKIE_SAMESITE': app.config.get('SESSION_COOKIE_SAMESITE'),
                        'SESSION_COOKIE_SECURE': app.config.get('SESSION_COOKIE_SECURE'),
                        'PERMANENT_SESSION_LIFETIME': str(app.config.get('PERMANENT_SESSION_LIFETIME'))
                    },
                    'db_connector': {
                        'host': db_connector.db_host if db_connector else 'N/A',
                        'port': db_connector.db_port if db_connector else 'N/A',
                        'database': db_connector.db_name if db_connector else 'N/A'
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            except Exception as e:
                logger.error(f"Debug error: {e}")
                return jsonify({'error': str(e)}), 500
            
        # ====================================================================
        # ADD THIS SECTION RIGHT AFTER THE @app.route('/api/debug/models') ENDPOINT
        # (In your app.py, around line where debug_models() is defined)
        # ====================================================================

        @app.route('/api/debug/session', methods=['GET'])
        def debug_session():
            """
            ✅ Debug endpoint to check if Flask session is set
            GET /api/debug/session
            
            Returns session status and all session data
            """
            try:
                return jsonify({
                    'success': True,
                    'session_status': {
                        'session_exists': 'user_id' in session,
                        'session_user_id': session.get('user_id'),
                        'session_user_email': session.get('user_email'),
                        'session_user_name': session.get('user_name'),
                        'session_permanent': session.get('permanent'),
                        'session_keys': list(session.keys()),
                        'session_size': len(dict(session)),
                        'session_dict': dict(session)  # ← Shows full session content
                    },
                    'config': {
                        'SESSION_COOKIE_SECURE': app.config.get('SESSION_COOKIE_SECURE'),
                        'SESSION_COOKIE_HTTPONLY': app.config.get('SESSION_COOKIE_HTTPONLY'),
                        'SESSION_COOKIE_SAMESITE': app.config.get('SESSION_COOKIE_SAMESITE'),
                        'PERMANENT_SESSION_LIFETIME': str(app.config.get('PERMANENT_SESSION_LIFETIME')),
                        'SECRET_KEY_SET': bool(app.config.get('SECRET_KEY'))
                    },
                    'cookies': {
                        k: v[:20] + '...' if len(str(v)) > 20 else v 
                        for k, v in request.cookies.items()
                    },
                    'request_headers': {
                        'Authorization': request.headers.get('Authorization', 'Not set')[:50] if request.headers.get('Authorization') else 'Not set',
                        'Content-Type': request.headers.get('Content-Type', 'Not set'),
                        'Origin': request.headers.get('Origin', 'Not set')
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            except Exception as e:
                logger.error(f"Debug session error: {e}")
                return jsonify({
                    'success': False,
                    'error': str(e),
                    'session_exists': 'user_id' in session
                }), 500


        @app.route('/api/debug/session/set', methods=['POST'])
        def debug_session_set():
            """
            ✅ Manually set session (for testing)
            POST /api/debug/session/set
            Body: { "user_id": 1, "user_email": "test@example.com", "user_name": "Test" }
            
            This endpoint helps verify that Flask session setting works
            """
            try:
                data = request.get_json()
                
                if not data:
                    return jsonify({
                        'success': False,
                        'error': 'No JSON body provided'
                    }), 400
                
                user_id = data.get('user_id')
                user_email = data.get('user_email')
                user_name = data.get('user_name')
                
                if not user_id:
                    return jsonify({
                        'success': False,
                        'error': 'user_id is required'
                    }), 400
                
                logger.info(f"📝 Setting session manually for user_id={user_id}")
                
                # Set session
                session['user_id'] = user_id
                session['user_email'] = user_email or 'unknown@example.com'
                session['user_name'] = user_name or 'Unknown'
                session.permanent = True
                
                logger.info(f"✅ Session set: user_id={session.get('user_id')}")
                
                return jsonify({
                    'success': True,
                    'message': 'Session set manually',
                    'session_data': {
                        'user_id': session.get('user_id'),
                        'user_email': session.get('user_email'),
                        'user_name': session.get('user_name'),
                        'permanent': session.get('permanent')
                    },
                    'verify_url': '/api/debug/session',
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            except Exception as e:
                logger.error(f"Debug session set error: {e}")
                return jsonify({
                    'success': False,
                    'error': str(e)
                }), 500


        @app.route('/api/debug/session/clear', methods=['POST'])
        def debug_session_clear():
            """
            ✅ Clear session (for testing)
            POST /api/debug/session/clear
            
            Clears all session data
            """
            try:
                logger.info("🧹 Clearing session manually")
                session.clear()
                logger.info("✅ Session cleared")
                
                return jsonify({
                    'success': True,
                    'message': 'Session cleared',
                    'session_after_clear': dict(session),
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            except Exception as e:
                logger.error(f"Debug session clear error: {e}")
                return jsonify({
                    'success': False,
                    'error': str(e)
                }), 500
        
        # ====================================================================
        # ERROR HANDLERS
        # ====================================================================
        
        @app.errorhandler(400)
        def bad_request(error):
            logger.warning(f"400 Bad Request: {error}")
            return jsonify({'error': 'Bad request'}), 400
        
        @app.errorhandler(404)
        def not_found(error):
            logger.warning(f"404 Not Found: {request.path}")
            return jsonify({'error': 'Resource not found'}), 404
        
        @app.errorhandler(500)
        def internal_error(error):
            logger.error(f"✗ Internal server error: {error}")
            try:
                if DATABASE_MODE == 'available':
                    db.session.rollback()
            except Exception as rollback_err:
                logger.warning(f"⚠ Failed to rollback: {rollback_err}")
            return jsonify({'error': 'Internal server error'}), 500
        
        # ====================================================================
        # HEALTH CHECK (ENHANCED FOR HYBRID RAG)
        # ====================================================================
        
        @app.route('/api/health')
        def health_check():
            """Comprehensive health check with Hybrid RAG status"""
            try:
                db_health = {'status': 'unavailable'}
                if DATABASE_MODE == 'available' and db_connector:
                    try:
                        db_health = db_connector.health_check()
                    except Exception as db_health_err:
                        logger.warning(f"⚠ Database health check error: {db_health_err}")
                
                rag_health = {}
                if HYBRID_RAG_SERVICES_AVAILABLE:
                    try:
                        rag_health = check_db_health()
                    except:
                        rag_health = {'status': 'unavailable'}
                
                overall_status = 'healthy' if DATABASE_MODE == 'available' else 'degraded'
                if db_health.get('status') != 'healthy':
                    overall_status = 'degraded'
                
                return jsonify({
                    'status': overall_status,
                    'database_mode': DATABASE_MODE,
                    'database': db_health if isinstance(db_health, dict) else {'status': 'unavailable'},
                    'hybrid_rag': rag_health,
                    'version': '4.5.0',
                    'features': {
                        'all_navigation_routes': True,
                        'fallback_mode': DATABASE_MODE == 'unavailable',
                        'chatbot_enabled': CHATBOT_AVAILABLE,
                        'hybrid_rag_enabled': HYBRID_RAG_AVAILABLE,
                        'hybrid_rag_services': HYBRID_RAG_SERVICES_AVAILABLE,
                        'intelligent_routing': HYBRID_RAG_AVAILABLE,
                        'pgvector_search': HYBRID_RAG_AVAILABLE,
                        'sql_generation': HYBRID_RAG_AVAILABLE,
                        'professional_auth': AUTH_AVAILABLE,
                        'azure_openai_client': openai_client is not None,
                        'session_persistence': True,
                        'cors_credentials': True,
                        'processing_paths': 'Direct LLM, SQL-First, Hybrid' if HYBRID_RAG_AVAILABLE else 'Standard'
                    },
                    'routes': {
                        'total': 35,
                        'integrations': 12,
                        'data_management': 4,
                        'chat': 1,
                        'services': 4,
                        'resources': 4,
                        'account': 2,
                        'chatbot_api': '✓ Hybrid RAG System' if HYBRID_RAG_AVAILABLE else '✓ Standard Chat',
                        'auth_api': '✓ Professional JWT Auth' if AUTH_AVAILABLE else '✓ Basic Auth'
                    },
                    'timestamp': datetime.utcnow().isoformat()
                }), 200
            
            except Exception as e:
                logger.error(f"✗ Health check error: {e}")
                return jsonify({'status': 'unhealthy', 'error': str(e)}), 503
        
        # ====================================================================
        # INITIALIZATION SUMMARY
        # ====================================================================
        
        logger.info(f"✓ Application initialized successfully in {config_name} mode")
        logger.info(f"✓ Database mode: {DATABASE_MODE}")
        logger.info(f"✓ Version: 4.5.0 - WITH HYBRID RAG SYSTEM + PROFESSIONAL AUTH ✅")
        logger.info(f"✓ Total routes: 35+ routes enabled")
        
        if AUTH_AVAILABLE:
            logger.info(f"✓ Professional Authentication: ENABLED ✓")
            logger.info(f"  🔐 JWT Tokens")
            logger.info(f"  👥 User Sessions ✅")
            logger.info(f"  🔄 Password Reset")
            logger.info(f"  📊 Login Tracking")
        
        logger.info(f"✓ Session Management: ENABLED ✅")
        logger.info(f"  🔒 Flask Sessions with 7-day expiration")
        logger.info(f"  🌐 CORS Credentials Support ENABLED ✅")
        logger.info(f"  🔑 HttpOnly Cookies (XSS Protection)")
        logger.info(f"  ✔️  SameSite=Lax (CSRF Protection)")
        
        if HYBRID_RAG_AVAILABLE:
            logger.info(f"✓ Hybrid RAG: ENABLED ✓")
            logger.info(f"  🧠 Intelligent Query Routing")
            logger.info(f"  🔍 pgvector Semantic Search")
            logger.info(f"  📊 SQL Query Generation")
            logger.info(f"  🎯 3 Processing Paths: Direct LLM, SQL-First, Hybrid")
        elif CHATBOT_AVAILABLE:
            logger.info(f"✓ Standard Chat: ENABLED")
        else:
            logger.info(f"⚠ Chat: DISABLED")
        
        if openai_client is not None:
            logger.info(f"✓ Azure OpenAI Client: INITIALIZED ✓")
            logger.info(f"  🤖 LLM Features: ENABLED")
        else:
            logger.info(f"⚠ Azure OpenAI Client: NOT AVAILABLE")
        
        logger.info(f"✓ Features: RAG + Excel + Azure OpenAI Integration + Professional Auth")
        logger.info(f"✓ Database: {db_connector.db_host}:{db_connector.db_port}/{db_connector.db_name}" if db_connector else "✓ Database: In-memory fallback")
        
        return app
        
    except Exception as app_err:
        logger.critical(f"✗ CRITICAL - Application Factory Error: {type(app_err).__name__} - {app_err}")
        logger.debug(traceback.format_exc())
        raise

# ============================================================================
# APPLICATION ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    try:
        app = create_app('development')
        logger.info("🚀 Starting 360° Enterprise Dashboard v4.5.0")
        logger.info("✓ Mode: Development (with graceful database fallback)")
        logger.info("✓ Hybrid RAG System: READY")
        logger.info("✓ Professional Authentication: READY ✅")
        logger.info("✓ Flask Sessions: READY ✅")
        logger.info("✓ CORS Credentials: READY ✅")
        logger.info("✓ Azure OpenAI Client: READY ✅")
        logger.info("✓ Chat URL: http://localhost:8000/chat")
        logger.info("✓ Upload Excel: POST /chat/upload")
        logger.info("✓ Ask Questions: POST /chat/send_message")
        logger.info("✓ Authentication: POST /api/auth/login or /api/auth/register")
        logger.info("✓ Listening on http://localhost:8000")
        logger.info("\n" + "="*80)
        logger.info("🎯 LOGIN FLOW: Fixed with Flask Session + CORS Credentials Support")
        logger.info("   → Sessions: 7-day lifetime, HttpOnly, SameSite=Lax")
        logger.info("   → CORS: Credentials enabled for localhost:8000")
        logger.info("   → Expected: Login → Dashboard ✅ (no more 302 redirects!)")
        logger.info("="*80 + "\n")
        # IMPORTANT: debug=False to prevent reloader from losing routes
        app.run(debug=False, host='0.0.0.0', port=8000, use_reloader=False)
    except Exception as startup_err:
        logger.critical(f"✗ CRITICAL - Startup Error: {type(startup_err).__name__} - {startup_err}")
        logger.debug(traceback.format_exc())
        exit(1)