# 360° Enterprise Integration Dashboard

**Version 4.5.0** | Enterprise-grade integration platform with Hybrid RAG capabilities

A comprehensive enterprise dashboard for Azure services integration, intelligent data querying through Hybrid RAG (Retrieval-Augmented Generation), and professional authentication with role-based access control.

---

## Table of Contents

- [Features](#features)
- [Architecture](#architecture)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Configuration](#configuration)
- [API Reference](#api-reference)
- [Deployment](#deployment)

---

## Features

### Hybrid RAG System
- **Direct LLM**: Fast natural language responses without database queries
- **SQL-First**: Structured data queries with precise results
- **Hybrid Mode**: Combines both for comprehensive answers
- Intelligent query routing with automatic intent detection
- pgvector semantic search for context-aware results
- Local embeddings using all-MiniLM-L6-v2 model

### Professional Authentication
- JWT-based authentication with 24-hour token expiration
- Session management with 7-day lifetime
- Role-Based Access Control (Admin, User, ReadOnly)
- bcrypt password hashing with HttpOnly cookies

### Data Management
- Excel/CSV import with automatic schema detection
- Dynamic SQL query execution with safety validation
- Real-time statistics and analytics
- Chart.js formatted responses

### Enterprise Integrations
- **Azure**: OpenAI, Storage, API Management, Key Vault
- **SharePoint**: Document operations, folder navigation, search
- **Splunk**: Search queries, analytics, health monitoring
- **GitHub/Jenkins**: CI/CD integration support

---

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              CLIENT LAYER                                    │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐ │
│  │   Browser   │  │  Dashboard  │  │    Chat     │  │   Admin Panel       │ │
│  │  (HTML/JS)  │  │    Views    │  │  Interface  │  │                     │ │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘ │
└─────────┼────────────────┼────────────────┼────────────────────┼────────────┘
          │                │                │                    │
          └────────────────┴────────────────┴────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           APPLICATION LAYER                                  │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                        Flask Application (app.py)                       │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │ │
│  │  │ JWT/Session  │  │    CORS      │  │   Routing    │  │  Logging   │  │ │
│  │  │   Manager    │  │   Handler    │  │   Engine     │  │            │  │ │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └────────────┘  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                         Route Blueprints                                │ │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐          │ │
│  │  │  Auth   │ │  Chat   │ │  Admin  │ │ Storage │ │  Splunk │          │ │
│  │  │ Routes  │ │ Routes  │ │ Routes  │ │ Routes  │ │ Routes  │          │ │
│  │  └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘          │ │
│  │  ┌─────────┐ ┌─────────┐ ┌─────────┐                                   │ │
│  │  │SharePnt │ │ GenDB   │ │ Azure   │                                   │ │
│  │  │ Routes  │ │ Routes  │ │ Routes  │                                   │ │
│  │  └─────────┘ └─────────┘ └─────────┘                                   │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            SERVICE LAYER                                     │
│  ┌────────────────────────────────────────────────────────────────────────┐ │
│  │                      Hybrid RAG Service                                 │ │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                  │ │
│  │  │Query Router  │─▶│SQL Generator │─▶│Vector Search │                  │ │
│  │  │(Intent Det.) │  │(Dynamic SQL) │  │ (pgvector)   │                  │ │
│  │  └──────────────┘  └──────────────┘  └──────────────┘                  │ │
│  └────────────────────────────────────────────────────────────────────────┘ │
│                                                                              │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │  Database   │ │    File     │ │   Import    │ │  Embedding  │           │
│  │  Service    │ │   Service   │ │   Service   │ │  Processor  │           │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘           │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CONNECTOR LAYER                                     │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │     DB      │ │Azure OpenAI │ │   Azure     │ │ SharePoint  │           │
│  │ Connector   │ │ Connector   │ │  Storage    │ │ Connector   │           │
│  └──────┬──────┘ └──────┬──────┘ └──────┬──────┘ └──────┬──────┘           │
│         │               │               │               │                   │
│  ┌──────┴──────┐ ┌──────┴──────┐ ┌──────┴──────┐ ┌──────┴──────┐           │
│  │   Splunk    │ │   GitHub    │ │   Jenkins   │ │    APIM     │           │
│  │ Connector   │ │ Connector   │ │ Connector   │ │ Connector   │           │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘           │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DATA LAYER                                         │
│  ┌──────────────────────────────────────┐  ┌──────────────────────────────┐ │
│  │         PostgreSQL Database          │  │      External Services       │ │
│  │  ┌────────────────────────────────┐  │  │  ┌─────────┐  ┌───────────┐  │ │
│  │  │         Schema: IGPT           │  │  │  │  Azure  │  │SharePoint │  │ │
│  │  │  ┌─────────┐  ┌─────────────┐  │  │  │  │ OpenAI  │  │   Sites   │  │ │
│  │  │  │  Users  │  │   Roles     │  │  │  │  └─────────┘  └───────────┘  │ │
│  │  │  └─────────┘  └─────────────┘  │  │  │  ┌─────────┐  ┌───────────┐  │ │
│  │  │  ┌─────────┐  ┌─────────────┐  │  │  │  │  Azure  │  │  Splunk   │  │ │
│  │  │  │ Tables  │  │ Embeddings  │  │  │  │  │ Storage │  │  Servers  │  │ │
│  │  │  │ (Data)  │  │ (pgvector)  │  │  │  │  └─────────┘  └───────────┘  │ │
│  │  │  └─────────┘  └─────────────┘  │  │  │  ┌─────────┐  ┌───────────┐  │ │
│  │  │  ┌─────────┐  ┌─────────────┐  │  │  │  │ GitHub  │  │  Jenkins  │  │ │
│  │  │  │Sessions │  │  RAG Logs   │  │  │  │  │   API   │  │    API    │  │ │
│  │  │  └─────────┘  └─────────────┘  │  │  │  └─────────┘  └───────────┘  │ │
│  │  └────────────────────────────────┘  │  └──────────────────────────────┘ │
│  └──────────────────────────────────────┘                                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Hybrid RAG Processing Flow

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         USER QUERY INPUT                                    │
└─────────────────────────────────┬──────────────────────────────────────────┘
                                  │
                                  ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                         QUERY ROUTER                                        │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Intent Classification                              │  │
│  │  • Greeting Detection    • Data Query Detection                       │  │
│  │  • Complexity Analysis   • Context Requirement Check                  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────┬───────────────────────────────────────────┘
                                 │
            ┌────────────────────┼────────────────────┐
            │                    │                    │
            ▼                    ▼                    ▼
┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐
│   DIRECT LLM      │ │    SQL-FIRST      │ │     HYBRID        │
│   Processing      │ │   Processing      │ │   Processing      │
│                   │ │                   │ │                   │
│ • General Q&A     │ │ • Data queries    │ │ • Complex queries │
│ • Explanations    │ │ • Aggregations    │ │ • Analysis + Data │
│ • Greetings       │ │ • Filters         │ │ • Summaries       │
└─────────┬─────────┘ └─────────┬─────────┘ └─────────┬─────────┘
          │                     │                     │
          │                     ▼                     │
          │           ┌───────────────────┐           │
          │           │  SQL Generator    │           │
          │           │  • Schema lookup  │           │
          │           │  • Query build    │           │
          │           │  • Validation     │           │
          │           └─────────┬─────────┘           │
          │                     │                     │
          │                     ▼                     │
          │           ┌───────────────────┐           │
          │           │  Vector Search    │◀──────────┤
          │           │  • Embeddings     │           │
          │           │  • Similarity     │           │
          │           │  • Context        │           │
          │           └─────────┬─────────┘           │
          │                     │                     │
          ▼                     ▼                     ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                       AZURE OPENAI LLM                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │  • Response Generation    • Context Integration                       │  │
│  │  • Formatting             • Error Handling                            │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────┬──────────────────────────────────────────┘
                                  │
                                  ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                       FORMATTED RESPONSE                                    │
└────────────────────────────────────────────────────────────────────────────┘
```

### Authentication Flow

```
┌──────────┐      ┌──────────────┐      ┌──────────────┐      ┌────────────┐
│  Client  │      │   Flask      │      │   Auth       │      │ PostgreSQL │
│ (Browser)│      │   Server     │      │  Service     │      │  Database  │
└────┬─────┘      └──────┬───────┘      └──────┬───────┘      └─────┬──────┘
     │                   │                     │                    │
     │  POST /login      │                     │                    │
     │  {email, pass}    │                     │                    │
     │──────────────────▶│                     │                    │
     │                   │  Validate Request   │                    │
     │                   │────────────────────▶│                    │
     │                   │                     │   Query User       │
     │                   │                     │───────────────────▶│
     │                   │                     │   User Data        │
     │                   │                     │◀───────────────────│
     │                   │                     │                    │
     │                   │  Verify Password    │                    │
     │                   │  (bcrypt compare)   │                    │
     │                   │◀────────────────────│                    │
     │                   │                     │                    │
     │                   │  Generate JWT       │                    │
     │                   │  (24hr expiry)      │                    │
     │                   │◀────────────────────│                    │
     │                   │                     │                    │
     │                   │  Create Session     │                    │
     │                   │  (7-day lifetime)   │                    │
     │                   │◀────────────────────│                    │
     │                   │                     │                    │
     │  Set-Cookie:      │                     │                    │
     │  session (HTTP)   │                     │                    │
     │  + JWT token      │                     │                    │
     │◀──────────────────│                     │                    │
     │                   │                     │                    │
     │  GET /dashboard   │                     │                    │
     │  Cookie: session  │                     │                    │
     │  Auth: Bearer JWT │                     │                    │
     │──────────────────▶│                     │                    │
     │                   │  Validate JWT       │                    │
     │                   │────────────────────▶│                    │
     │                   │  Check Permissions  │                    │
     │                   │◀────────────────────│                    │
     │                   │                     │                    │
     │  Dashboard HTML   │                     │                    │
     │◀──────────────────│                     │                    │
     │                   │                     │                    │
```

---

## Tech Stack

| Category | Technology | Version |
|----------|-----------|---------|
| **Web Framework** | Flask | 3.1.2 |
| **Database** | PostgreSQL + pgvector | 12+ |
| **ORM** | SQLAlchemy | 2.0.44 |
| **Authentication** | JWT / bcrypt | 2.10.1 / 5.0.0 |
| **AI/LLM** | Azure OpenAI | Latest |
| **Embeddings** | Sentence-Transformers | 5.1.2 |
| **API Framework** | Flask-RESTX | 1.3.2 |
| **Data Processing** | Pandas / Openpyxl | 2.3.3 / 3.1.5 |
| **Cloud Services** | Azure SDK | Latest |
| **Monitoring** | Splunk SDK | 2.1.1 |
| **Production Server** | Gunicorn | 23.0.0 |

---

## Project Structure

```
360-integration-dashboard/
├── app.py                      # Main Flask application
├── config.py                   # Configuration management
├── wsgi.py                     # WSGI entry point
├── requirements.txt            # Python dependencies
├── init.sql                    # Database schema initialization
├── .env.example                # Environment template
│
├── backend/
│   ├── auth/                   # Authentication system
│   │   ├── auth.py             # JWT & session routes
│   │   └── auth_models.py      # User models
│   │
│   ├── routes/                 # API endpoints (blueprints)
│   │   ├── chat.py             # Hybrid RAG endpoints
│   │   ├── admin_routes.py     # Admin panel API
│   │   ├── azure_storage.py    # Azure operations
│   │   ├── generic_db_routes.py# Database queries
│   │   ├── sharepoint.py       # SharePoint integration
│   │   └── splunk.py           # Splunk monitoring
│   │
│   ├── connectors/             # External service connectors
│   │   ├── db_connector.py     # PostgreSQL connection
│   │   ├── azure_openai_connector.py
│   │   ├── azure_storage_connector.py
│   │   ├── sharepoint_connector.py
│   │   └── splunk_connector.py
│   │
│   ├── services/               # Business logic
│   │   ├── database.py         # Database service
│   │   ├── hybrid_rag_service.py
│   │   ├── query_router.py     # Intent detection
│   │   ├── sql_generator.py    # Dynamic SQL
│   │   ├── vector_search.py    # Semantic search
│   │   ├── local_embeddings.py # Embedding generation
│   │   └── data_import_service.py
│   │
│   └── ai_models/              # ML models
│       └── all-MiniLM-L6-v2/   # Local embedding model
│
├── frontend/
│   ├── index.html              # Landing page
│   ├── layouts/                # Header, nav, footer
│   ├── auth/                   # Login, profile, settings
│   ├── dashboard_overview/     # Main dashboard
│   ├── chat/                   # Chat interface
│   ├── admin/                  # Admin panel
│   ├── integrations/           # Integration pages
│   │   └── azure/              # Azure-specific
│   ├── data_management/        # Import, tables, analytics
│   ├── services_monitoring/    # Health, reports
│   ├── resources/              # Help, documentation
│   └── assets/                 # CSS, JS, images
│
├── uploads/                    # User uploads
├── downloads/                  # File downloads
├── logs/                       # Application logs
└── migrations/                 # Database migrations
```

---

## Installation

### Prerequisites

- Python 3.10+
- PostgreSQL 12+ with pgvector extension
- Azure subscription (for AI/storage features)

### Setup

```bash
# Clone repository
git clone <repository-url>
cd 360-integration-dashboard

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your configuration

# Initialize database
psql -U postgres -f init.sql

# Run development server
python app.py
```

---

## Configuration

### Environment Variables

```env
# Database
DB_HOST=localhost
DB_PORT=5434
DB_NAME=integration_dashboard
DB_USER=postgres
DB_PASSWORD=your_password
DB_SCHEMA=igpt

# Flask
FLASK_ENV=development
SECRET_KEY=your_secret_key
FLASK_DEBUG=True

# Azure OpenAI
AZURE_OPENAI_ENDPOINT=https://your-instance.openai.azure.com/
AZURE_OPENAI_API_KEY=your_api_key
AZURE_OPENAI_DEPLOYMENT=gpt-4

# JWT
JWT_SECRET_KEY=your_jwt_secret
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# Feature Flags
ENABLE_AZURE=true
ENABLE_AI=true
ENABLE_SHAREPOINT=true
ENABLE_SPLUNK=true
```

---

## API Reference

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | User registration |
| POST | `/api/auth/login` | User login |
| POST | `/api/auth/logout` | User logout |
| GET | `/api/auth/me` | Current user info |

### Chat & RAG

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/chat/upload` | Import Excel/CSV |
| POST | `/chat/send_message` | Process query |
| GET | `/chat/stats` | Data statistics |

### Admin

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/users` | List users |
| DELETE | `/api/admin/users/<id>` | Delete user |
| GET | `/api/admin/stats` | System stats |

### Database

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/db/aggregate` | GROUP BY queries |
| POST | `/api/db/stats` | Statistical queries |
| POST | `/api/db/records` | Fetch records |

---

## Deployment

### Production with Gunicorn

```bash
gunicorn --workers 4 --bind 0.0.0.0:8000 --timeout 60 wsgi:application
```

### Docker

```dockerfile
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["gunicorn", "--workers", "4", "--bind", "0.0.0.0:8000", "wsgi:application"]
```

### Azure App Service

The application is Azure App Service compatible with standard Python deployment.

---

## Database Schema

Key tables in the `igpt` schema:

- `users` - User accounts
- `roles` - Role definitions (admin, user, readonly)
- `user_roles` - User-role mappings
- `azure_integrations` - Azure connections
- `sharepoint_integrations` - SharePoint links
- `ai_interactions` - Chat history
- `chat_sessions` - Conversation sessions
- `chat_messages` - Individual messages
- `rag_query_logs` - RAG processing logs
- `embedding_cache` - Vector embeddings

Extensions: `uuid-ossp`, `vector` (pgvector)

---

## License

Proprietary - All rights reserved

---

## Support

For issues and feature requests, contact the development team.
