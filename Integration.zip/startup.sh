#!/bin/bash
# ============================================================================
# Azure App Service Startup Script
# 360° Integration Dashboard
# ============================================================================

echo "======================================"
echo "Starting 360° Integration Dashboard"
echo "======================================"

# Set Python path
export PYTHONPATH="${PYTHONPATH}:/home/site/wwwroot"

# Print environment info
echo "Python version: $(python --version)"
echo "Working directory: $(pwd)"
echo "Python path: $PYTHONPATH"

# Run database migrations if needed (optional)
# python -c "from app import create_app, db; app = create_app('production'); app.app_context().push(); db.create_all()"

# Start Gunicorn
echo "Starting Gunicorn server..."
gunicorn --bind=0.0.0.0:8000 \
         --workers=4 \
         --threads=2 \
         --timeout=120 \
         --access-logfile=- \
         --error-logfile=- \
         --log-level=info \
         --worker-class=sync \
         app:app

# If above fails, try alternate configuration
if [ $? -ne 0 ]; then
    echo "Trying alternate Gunicorn configuration..."
    gunicorn --bind=0.0.0.0:8000 \
             --workers=2 \
             --timeout=300 \
             --log-level=debug \
             app:app
fi
